# five_tetra.py ── 一段ずらし（φ）の隙間に、同じ正四面体 5 つが収まるか
# Z[φ] の整数の組 (a,b) = a + bφ（φ² = φ + 1）だけで計算する。割り算・浮動小数なし。
#
# 枠：正十二面体の 20 頂点
#   (±1,±1,±1)            … 立方体の 8 頂点（ギャスケットの A と B ＝ 星型八面体）
#   (0,±φ⁻¹,±φ) とその巡回 … φ でずらした 12 頂点（φ⁻¹ = φ − 1）
#
# 基準（走らせる前に決めたもの）：
#   F1 20 頂点を、同じ正四面体（辺の 2 乗がそろう）5 つに、重複も漏れもなく分けられること。
#   F2 その 5 つの中に、ギャスケットの A（または B）がそのまま入っていること（元の位置とつながる）。
#   F3 5 回の回転（φ の一段）が 5 つを順に巡回させ、その回転軸の向きが 12 本（＋中心で 13）にまとまること。
#   負の対照：φ を使わない立方体の頂点（2 倍の刻み）だけでは、5 回の回転が一つもないこと。
#   F2 が成り立たなければ、元のギャスケットとつながらないので NG。

from itertools import product, combinations, permutations

Z0 = (0, 0)
def zadd(x, y): return (x[0] + y[0], x[1] + y[1])
def zneg(x): return (-x[0], -x[1])
def zsub(x, y): return zadd(x, zneg(y))
def zmul(x, y):
    a, b = x; c, d = y
    return (a * c + b * d, a * d + b * c + b * d)
def Z(n): return (n, 0)
PHI = (0, 1)
PINV = (-1, 1)          # φ⁻¹ = φ − 1

def vsub(p, q): return tuple(zsub(a, b) for a, b in zip(p, q))
def vdot(p, q):
    s = Z0
    for a, b in zip(p, q):
        s = zadd(s, zmul(a, b))
    return s

verts = []
for sx, sy, sz in product((1, -1), repeat=3):
    verts.append((Z(sx), Z(sy), Z(sz)))
for s1, s2 in product((1, -1), repeat=2):
    a = zmul(Z(s1), PINV); b = zmul(Z(s2), PHI)
    verts.append((Z0, a, b))
    verts.append((a, b, Z0))
    verts.append((b, Z0, a))
V = set(verts)
print(f"頂点 {len(verts)}（重複なし {len(V)}）")

def d2(p, q):
    w = vsub(p, q)
    return vdot(w, w)

# ── F1 ── 同じ正四面体を探す
regs = []
for c in combinations(range(20), 4):
    ds = {d2(verts[i], verts[j]) for i, j in combinations(c, 2)}
    if len(ds) == 1:
        regs.append((c, ds.pop()))
sizes = {}
for _, s in regs:
    sizes[s] = sizes.get(s, 0) + 1
print("F1 正四面体（辺の 2 乗 a+bφ ごとの個数）", sizes)
cube_idx = set(range(8))
A = tuple(i for i in range(8) if (1 - (verts[i][0][0] * verts[i][1][0] * verts[i][2][0])) == 0)   # x·y·z = +1
B = tuple(i for i in range(8) if i not in A)
tets = [c for c, s in regs if s == (8, 0)]
parts = []
for combo in combinations(tets, 5):
    used = [i for t in combo for i in t]
    if len(used) == 20 and len(set(used)) == 20:
        parts.append(combo)
print(f"   辺の 2 乗 8 の正四面体 {len(tets)} 個 → 20 頂点を 5 つに分ける分け方 {len(parts)} 通り")

# ── F2 ── ギャスケットの A・B が入っているか
print(f"F2 立方体の中の A {A}、B {B}")
for k, combo in enumerate(parts):
    hasA = tuple(sorted(A)) in [tuple(sorted(t)) for t in combo]
    hasB = tuple(sorted(B)) in [tuple(sorted(t)) for t in combo]
    print(f"   分け方 {k}: A を含む {hasA}  B を含む {hasB}")

# ── F3 ── 5 回の回転（2R の成分が (±φ, ±1, ±φ⁻¹) を並べたもの）
row_entries = []
for perm in permutations((PHI, Z(1), PINV)):
    for sg in product((1, -1), repeat=3):
        row_entries.append(tuple(zmul(Z(s), e) for s, e in zip(sg, perm)))
# 単位立方体の回転（φ を使わない）は成分 0, ±2 の符号付き置換
def apply2(M, p):      # 2R p
    return tuple(vdot(r, p) for r in M)
def dbl(p): return tuple(zadd(a, a) for a in p)
V2 = {dbl(p) for p in verts}
idx2 = {dbl(p): i for i, p in enumerate(verts)}

def is_perm(M):
    for p in verts:
        if apply2(M, p) not in V2:
            return None
    return tuple(idx2[apply2(M, p)] for p in verts)

def det_sign_ok(perm):
    # 回転か（鏡写しを除く）：頂点 0,1,2 の向き付き体積の符号が保たれるかを、置換の偶奇で代用せず
    # 実際の座標で 3x3 の行列式（Z[φ]）を比べる
    def det3(a, b, c):
        x = zmul(a[0], zsub(zmul(b[1], c[2]), zmul(b[2], c[1])))
        y = zmul(a[1], zsub(zmul(b[0], c[2]), zmul(b[2], c[0])))
        z = zmul(a[2], zsub(zmul(b[0], c[1]), zmul(b[1], c[0])))
        return zadd(zsub(x, y), z)
    for i, j, k in combinations(range(20), 3):
        d0 = det3(verts[i], verts[j], verts[k])
        if d0 != Z0:
            d1 = det3(verts[perm[i]], verts[perm[j]], verts[perm[k]])
            return d1 == d0
    return False

rots = set()
for r1 in row_entries:
    for r2 in row_entries:
        if vdot(r1, r2) != Z0: continue
        for r3 in row_entries:
            if vdot(r1, r3) != Z0 or vdot(r2, r3) != Z0: continue
            pm = is_perm((r1, r2, r3))
            if pm is not None and det_sign_ok(pm):
                rots.add(pm)

def compose(p, q): return tuple(p[q[i]] for i in range(len(q)))
def order(p):
    e = tuple(range(len(p))); q = p; n = 1
    while q != e:
        q = compose(p, q); n = n + 1
    return n
fives = [p for p in rots if order(p) == 5]
print(f"F3 (φ, 1, φ⁻¹) を並べた回転 {len(rots)} 個のうち 5 回の回転 {len(fives)} 個")

# 回転軸：5 回の回転で動かない向き＝その回転で巡る 5 頂点の和（二つの 5 頂点の輪の差）
axes = set()
for p in fives:
    seen = set(); rings = []
    for i in range(20):
        if i in seen: continue
        ring = [i]; j = p[i]
        while j != i:
            ring.append(j); j = p[j]
        seen.update(ring); rings.append(ring)
    for ring in rings:
        s = (Z0, Z0, Z0)
        for i in ring:
            s = tuple(zadd(a, b) for a, b in zip(s, verts[i]))
        if s != (Z0, Z0, Z0):
            axes.add(s)
print(f"   5 頂点の輪の和（軸の向き）の種類 {len(axes)}")
ax = sorted(axes)
dots = {}
for a, b in combinations(ax, 2):
    t = vdot(a, b)
    dots[t] = dots.get(t, 0) + 1
self_ = {vdot(a, a) for a in ax}
print(f"   軸の向きどうしの内積（a+bφ と個数）{dots}  自分自身 {self_}")

# 5 つの正四面体を巡回させるか
for k, combo in enumerate(parts):
    sets = [frozenset(t) for t in combo]
    cyc = 0
    for p in fives:
        img = [frozenset(p[i] for i in t) for t in sets]
        if set(img) == set(sets):
            # 5 つが一つの 5 巡回になっているか
            m = {sets[a]: img[a] for a in range(5)}
            x = sets[0]; n = 0
            while True:
                x = m[x]; n = n + 1
                if x == sets[0]: break
            if n == 5: cyc = cyc + 1
    print(f"   分け方 {k}: 5 つを 5 巡回させる 5 回の回転 {cyc} 個（{len(fives)} 個中）")

# ── 負の対照 ── φ を使わない立方体の回転
cube = verts[:8]
cube2 = {dbl(p) for p in cube}
signed = []
for perm in permutations(range(3)):
    for sg in product((1, -1), repeat=3):
        M = []
        for r in range(3):
            row = [Z0, Z0, Z0]
            row[perm[r]] = Z(2 * sg[r])
            M.append(tuple(row))
        signed.append(tuple(M))
cube_rots = []
for M in signed:
    if all(apply2(M, p) in cube2 for p in cube):
        cube_rots.append(tuple(cube.index(tuple(half for half in p)) if False else 0 for p in cube))
# 回転の位数は行列のべきで数える
def matmul2(M, N):     # (2M)(2N)/2 … 成分が 0,±2 なので 2 で割る代わりに 1 回引いて半分にする
    out = []
    for r in M:
        row = []
        for c in range(3):
            s = Z0
            for k in range(3):
                s = zadd(s, zmul(r[k], N[k][c]))
            # s は 4 の倍数か 0 → 2 で割る（±4 → ±2）
            h = 0
            if s[0] >= 0:
                while h + h < s[0]: h = h + 1
            else:
                while h + h > s[0]: h = h - 1
            row.append((h, 0))
        out.append(tuple(row))
    return tuple(out)
I2 = ((Z(2), Z0, Z0), (Z0, Z(2), Z0), (Z0, Z0, Z(2)))
ords = {}
for M in signed:
    if not all(apply2(M, p) in cube2 for p in cube): continue
    Q = M; n = 1
    while Q != I2:
        Q = matmul2(M, Q); n = n + 1
    ords[n] = ords.get(n, 0) + 1
print(f"負の対照：立方体の頂点を保つ符号付き置換（鏡写しを含む）の位数ごとの個数 {dict(sorted(ords.items()))}")

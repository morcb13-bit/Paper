# shell_fold.py ── L 殻と、内側が埋まって符号反転できない原子（M 側）の比較
# 整数と加算・比較だけ。重なりは分離軸（整数の内積）で判定する。
#
# 置き方：v300 と同じ。一辺 12 の枠を一辺 6 の小立方体 2x2x2 に割り、
#   添字の和が奇の小立方体に正四面体（格子の向き A）。偶の 4 つが席。
# 符号反転した相方：同じ小立方体の中の反対の向き（B）の正四面体。
#   L の原子 … A の 4 個だけ（相方の場所は空いている）
#   M の原子 … A の 4 個 ＋ 枠の 8 小立方体すべてに B（相方で埋まっている）
#
# M1：二つの原子を 面・辺・点 でつないだときの食い込み（v300 の写し方）
# M2：電子（A の向きの正四面体）が食い込まずに付ける場所と、原子と分け合う辺の数。
#     分け合う辺が最も多い場所の向き（中心からのベクトル）どうしの内積。

from itertools import product

C = 6  # 小立方体の一辺

def sub(a, b): return (a[0]-b[0], a[1]-b[1], a[2]-b[2])
def add(a, b): return (a[0]+b[0], a[1]+b[1], a[2]+b[2])
def dot(a, b): return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def tet(idx, orient):
    """小立方体（添字 idx）の正四面体。orient=0 は格子の向き A（添字＋角の和が偶）、1 は B。"""
    i, j, l = idx
    out = []
    for a, b, c in product((0, 1), repeat=3):
        if ((i + j + l + a + b + c) % 2) == orient:
            out.append(((i + a) * C, (j + b) * C, (l + c) * C))
    return tuple(out)

def edges_of(t):
    return [(t[x], t[y]) for x in range(4) for y in range(x + 1, 4)]

def axes(t):
    e = edges_of(t)
    ax = []
    for (p, q, r) in ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)):
        ax.append(cross(sub(t[q], t[p]), sub(t[r], t[p])))
    return ax, [sub(q, p) for p, q in e]

def overlap(t1, t2):
    """内部が重なれば True（面・辺・点で接するだけなら False）。分離軸、整数のみ。"""
    a1, e1 = axes(t1)
    a2, e2 = axes(t2)
    cand = a1 + a2
    for u in e1:
        for v in e2:
            w = cross(u, v)
            if w != (0, 0, 0):
                cand.append(w)
    for n in cand:
        p1 = [dot(n, p) for p in t1]
        p2 = [dot(n, p) for p in t2]
        if max(p1) <= min(p2) or max(p2) <= min(p1):
            return False
    return True

def shared_edges(t1, t2):
    s1 = {frozenset(e) for e in edges_of(t1)}
    s2 = {frozenset(e) for e in edges_of(t2)}
    return len(s1 & s2)

frame = list(product((0, 1), repeat=3))
A_atom = [tet(f, 0) for f in frame if sum(f) % 2 == 1]
B_fill = [tet(f, 1) for f in frame]
atoms = {"L": A_atom, "M": A_atom + B_fill}

# ── M1 ── v300 の写し方
def mirror_face(p):           # 面 x+y+z=12 で鏡写し
    s = p[0] + p[1] + p[2]
    d = s - 12
    k = 0                      # k = 2*d/3（d は 3 の倍数になる）
    if d >= 0:
        t = 0
        while t < d:
            t = t + 3; k = k + 2
    else:
        t = 0
        while t > d:
            t = t - 3; k = k - 2
    return (p[0] - k, p[1] - k, p[2] - k)
def mirror_edge(p):            # 辺 (12,0,0)-(0,12,0) の中点で折り返し
    return (12 - p[0], 12 - p[1], 0 - p[2])
def mirror_point(p):           # 角 (12,0,0) で折り返し
    return (24 - p[0], 0 - p[1], 0 - p[2])

joins = [("面（三重）", mirror_face), ("辺（二重）", mirror_edge), ("点（一重）", mirror_point)]

print("=" * 72)
print("M1 二原子のつなぎ方と食い込み（v300 の写し方。食い込み＝内部が重なる組の数）")
print("  基準：L はどのつなぎ方も 0。M は面・辺で >0、点だけ 0 なら「M は一重だけ」。")
print("        M で点まで食い込むなら、M はつながれない（NG）。")
for name, atom in atoms.items():
    row = []
    for jn, f in joins:
        other = [tuple(f(p) for p in t) for t in atom]
        n = 0
        for t1 in atom:
            for t2 in other:
                if overlap(t1, t2):
                    n = n + 1
        row.append(f"{jn} {n}")
    print(f"  {name}：" + "   ".join(row))

# ── M2 ── 電子が付ける場所
print("=" * 72)
print("M2 電子（A の向き）が食い込まずに付ける場所と、原子と分け合う辺の数")
print("  基準：L は分け合う辺が最多の場所が 4 つで、向きの内積がすべて同じ負の値（正四面体）。")
print("        M はそれが立方体の 6 つの面の向きに分かれ、向きどうしの内積が 0 なら 90° 側へ移った。")
print("  負の対照：L のままなら最多の場所は 4 つの席から動かない。")
center = (12, 12, 12)   # 枠の中心を 2 倍した座標で比べるため、小立方体の中心も 2 倍で持つ
for name, atom in atoms.items():
    found = []
    for idx in product(range(-1, 3), repeat=3):
        t = tet(idx, 0)
        if any(overlap(t, a) for a in atom):
            continue
        se = sum(shared_edges(t, a) for a in A_atom)
        if se == 0:
            continue
        cen2 = (idx[0] * 12 + 6, idx[1] * 12 + 6, idx[2] * 12 + 6)   # 中心の 2 倍
        found.append((se, idx, sub(cen2, center)))
    best = max(s for s, _, _ in found)
    tally = {}
    for s, _, _ in found:
        tally[s] = tally.get(s, 0) + 1
    print(f"  {name}：付ける場所 {len(found)}（分け合う辺の数ごとの個数 {dict(sorted(tally.items(), reverse=True))}）")
    top = [(i, v) for s, i, v in found if s == best]
    print(f"     最多（辺 {best} 本）の場所 {len(top)} か所：" + " ".join(str(v) for _, v in top))
    dots = sorted({dot(top[a][1], top[b][1]) for a in range(len(top)) for b in range(a + 1, len(top))})
    print(f"     その向きどうしの内積 {dots}  自分自身 {dot(top[0][1], top[0][1])}")
    # 外形の面ごとにまとめた向き（同じ面に接する場所を足す）
    faces = {}
    for i, v in top:
        key = None
        for ax in range(3):
            if i[ax] < 0: key = (ax, -1)
            if i[ax] > 1: key = (ax, +1)
        if key is None:
            key = ("枠の中",)
        faces.setdefault(key, []).append(v)
    if all(k != ("枠の中",) for k in faces):
        sums = []
        for k, vs in faces.items():
            s = (0, 0, 0)
            for v in vs:
                s = add(s, v)
            sums.append(s)
        dd = sorted({dot(sums[a], sums[b]) for a in range(len(sums)) for b in range(a + 1, len(sums))})
        print(f"     外形の面ごとに足した向き {len(sums)} 本：" + " ".join(str(s) for s in sums))
        print(f"     その内積 {dd}")

# make_figs.py ── 記事 nh3-structure01 の動く図 4 枚を、共通の作り（CSS と 3D の描き方）で書き出す
# 各図は外部ライブラリを読まない HTML 一枚（フォントのみ Google Fonts、無くても既定の書体で動く）。

HEAD = r'''<title>{title}</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Shippori+Mincho:wght@600;800&family=Zen+Kaku+Gothic+New:wght@400;500&family=JetBrains+Mono:wght@400;600&display=swap">
<style>
/* 題 → 動く図 → 説明 の順に縦に積む。色は連載の図と同じ考え方（A は藍、B・水素は朱、芯は灰緑、フォトンは金） */
:root{{
  --bg:#eceff4; --panel:#f8f9fb; --ink:#1b2333; --muted:#5d6779; --line:#cfd5df; --accent:#3b5bdb;
  --a:#3b5bdb; --b:#d9480f; --core:#5c7c6a; --gold:#c99a06;
  --f-disp:"Shippori Mincho","Hiragino Mincho ProN","Yu Mincho",serif;
  --f-body:"Zen Kaku Gothic New","Hiragino Sans","Yu Gothic",system-ui,sans-serif;
  --f-mono:"JetBrains Mono",ui-monospace,Menlo,Consolas,monospace;
}}
@media (prefers-color-scheme: dark){{:root:not([data-theme="light"]){{--bg:#0e131d;--panel:#151c29;--ink:#e3e8f1;--muted:#97a1b3;--line:#2a3446;--accent:#8ea6ff;--a:#8ea6ff;--b:#ff8a5c;--core:#8fb8a0;--gold:#f2c94c;color-scheme:dark}}}}
:root[data-theme="dark"]{{--bg:#0e131d;--panel:#151c29;--ink:#e3e8f1;--muted:#97a1b3;--line:#2a3446;--accent:#8ea6ff;--a:#8ea6ff;--b:#ff8a5c;--core:#8fb8a0;--gold:#f2c94c;color-scheme:dark}}
*{{box-sizing:border-box}}
body{{background:var(--bg);color:var(--ink);font-family:var(--f-body);line-height:1.7;margin:0;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:24px 40px}}
.wrap{{max-width:880px;margin:0 auto;display:grid;gap:18px}}
h1{{font-family:var(--f-disp);font-weight:800;font-size:clamp(1.5rem,4vw,2.2rem);line-height:1.25;margin:0;text-wrap:balance}}
.sub{{font-family:var(--f-mono);color:var(--muted);font-size:.9rem}}
.stage{{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:12px;display:grid;gap:10px;min-width:0}}
canvas{{width:100%;max-width:100%;aspect-ratio:{aspect};display:block;touch-action:none;cursor:grab}}
.ctrl{{display:flex;flex-wrap:wrap;gap:10px;align-items:center}}
button{{font-family:var(--f-body);font-size:.9rem;background:transparent;color:var(--ink);border:1px solid var(--line);border-radius:4px;padding:6px 12px;cursor:pointer}}
button:hover{{border-color:var(--accent)}}
button:focus-visible,input:focus-visible{{outline:2px solid var(--accent);outline-offset:2px}}
label{{font-size:.85rem;color:var(--muted);display:flex;gap:8px;align-items:center;flex-wrap:wrap}}
input[type=range]{{width:140px;accent-color:var(--accent)}}
.read{{display:flex;flex-wrap:wrap;gap:6px 18px;font-family:var(--f-mono);font-size:.88rem;font-variant-numeric:tabular-nums}}
.read b{{font-weight:600;color:var(--ink)}}
.read span{{color:var(--muted)}}
.state{{font-family:var(--f-disp);font-weight:800;font-size:1.25rem}}
.note{{display:grid;gap:8px;max-width:68ch}}
.note p{{margin:0;font-size:.92rem}}
.key{{display:flex;flex-wrap:wrap;gap:12px;font-size:.82rem;color:var(--muted)}}
.key i{{display:inline-block;width:12px;height:12px;border-radius:2px;margin-right:5px;vertical-align:-1px}}
</style>
'''

ENGINE = r'''
// ── 共通：回して描く（画面に置くための換算だけ浮動小数。観察者側の表示） ──
const cv = document.getElementById('cv'), ctx = cv.getContext('2d');
let yaw = 0.7, pitch = 0.42, spin = true, drag = null;
function tok(n){ return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
function fit(){ const r = cv.getBoundingClientRect(), d = window.devicePixelRatio || 1;
  cv.width = Math.round(r.width*d); cv.height = Math.round(r.height*d); }
window.addEventListener('resize', fit);
cv.addEventListener('pointerdown', e => { drag = [e.clientX, e.clientY, yaw, pitch]; cv.setPointerCapture(e.pointerId); cv.style.cursor='grabbing'; });
cv.addEventListener('pointermove', e => { if(!drag) return; yaw = drag[2] + (e.clientX-drag[0])*0.01; pitch = Math.max(-1.4, Math.min(1.4, drag[3] + (e.clientY-drag[1])*0.01)); });
cv.addEventListener('pointerup', () => { drag = null; cv.style.cursor='grab'; });
const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function view(p, s){ // p: 浮動小数の座標（表示のみ）
  const cy=Math.cos(yaw), sy=Math.sin(yaw), cp=Math.cos(pitch), sp=Math.sin(pitch);
  let x = p[0]*cy - p[2]*sy, z = p[0]*sy + p[2]*cy, y = p[1];
  let y2 = y*cp - z*sp, z2 = y*sp + z*cp;
  const W = cv.width, H = cv.height, f = 1;
  return [W/2 + x*s*f, H/2 - y2*s*f, z2];
}
function rgba(hex, a){ hex = hex.replace('#',''); if(hex.length===3) hex = hex.split('').map(c=>c+c).join('');
  const n = parseInt(hex,16); return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${a})`; }
function draw3(faces, lines, dots, s){ // faces: {p:[..], c, a}, lines: {p:[p,q], c, w, dash}, dots: {p, c, r}
  const items = [];
  for(const f of faces){ const q = f.p.map(p=>view(p,s)); items.push({k:'f', z:q.reduce((t,v)=>t+v[2],0)/q.length, q, f}); }
  for(const l of lines){ const q = l.p.map(p=>view(p,s)); items.push({k:'l', z:(q[0][2]+q[1][2])/2 - 0.01, q, f:l}); }
  for(const d of dots){ const q = view(d.p,s); items.push({k:'d', z:q[2]-0.02, q, f:d}); }
  items.sort((u,v)=>v.z-u.z);
  const dpr = window.devicePixelRatio || 1;
  for(const it of items){
    if(it.k==='f'){ ctx.beginPath(); it.q.forEach((v,i)=> i? ctx.lineTo(v[0],v[1]) : ctx.moveTo(v[0],v[1])); ctx.closePath();
      ctx.fillStyle = rgba(it.f.c, it.f.a); ctx.fill();
      if(it.f.e){ ctx.strokeStyle = rgba(it.f.c, Math.min(1,it.f.a+0.35)); ctx.lineWidth = 1*dpr; ctx.stroke(); } }
    else if(it.k==='l'){ ctx.beginPath(); ctx.moveTo(it.q[0][0],it.q[0][1]); ctx.lineTo(it.q[1][0],it.q[1][1]);
      ctx.strokeStyle = it.f.c; ctx.lineWidth = (it.f.w||1)*dpr; ctx.setLineDash(it.f.dash ? [4*dpr,4*dpr] : []); ctx.stroke(); ctx.setLineDash([]); }
    else { ctx.beginPath(); ctx.arc(it.q[0], it.q[1], (it.f.r||3)*dpr, 0, 6.2832); ctx.fillStyle = it.f.c; ctx.fill(); }
  }
}
function tetFaces(t){ return [[t[0],t[1],t[2]],[t[0],t[1],t[3]],[t[0],t[2],t[3]],[t[1],t[2],t[3]]]; }
function tetEdges(t){ const e=[]; for(let i=0;i<4;i++) for(let j=i+1;j<4;j++) e.push([t[i],t[j]]); return e; }
'''

def page(fname, title, sub, aspect, body_stage, note, script):
    html = HEAD.format(title=title, aspect=aspect) + f'''
<div class="wrap">
  <header style="display:grid;gap:4px">
    <h1>{title}</h1>
    <div class="sub">{sub}</div>
  </header>
  <section class="stage">
{body_stage}
  </section>
  <section class="note">
{note}
  </section>
</div>
<script>
{ENGINE}
{script}
</script>
'''
    open(fname, 'w', encoding='utf-8').write(html)
    print(fname, len(html.encode()), 'bytes')

CTRL = '''    <div class="ctrl">
      <button id="play" type="button">一時停止</button>
      <button id="step" type="button">次へ</button>
      <label for="spd">速さ <input id="spd" type="range" min="1" max="8" value="3"></label>
      <label for="rot"><input id="rot" type="checkbox" checked> 自動で回す</label>
    </div>'''

COMMON_CTRL_JS = r'''
let playing = !reduce, speed = 3;
const playBtn = document.getElementById('play');
playBtn.textContent = playing ? '一時停止' : '再生';
playBtn.onclick = () => { playing = !playing; playBtn.textContent = playing ? '一時停止' : '再生'; };
document.getElementById('spd').oninput = e => speed = +e.target.value;
const rotBox = document.getElementById('rot');
if(rotBox) rotBox.onchange = e => spin = e.target.checked;
if(reduce){ spin = false; if(rotBox) rotBox.checked = false; }
'''

# ───────────────────────── 図1 ─────────────────────────
fig1_stage = '''    <canvas id="cv" aria-label="酸素・窒素の2段のギャスケットと、水素が座る4つの席"></canvas>
''' + CTRL + '''
    <div class="read">
      <span class="state" id="el">C</span>
      <span>手 <b id="h">4</b></span><span>対 <b id="p">0</b></span><span>形 <b id="fm">CH₄</b></span>
      <span>埋まった B の角 <b id="fill">4 / 4</b></span>
    </div>
    <div class="key"><span><i style="background:var(--a)"></i>A：原子（2段）</span><span><i style="background:var(--b)"></i>B：水素（1段）</span><span><i style="background:var(--muted)"></i>対の席</span><span><i style="background:var(--core)"></i>芯の正八面体</span></div>'''
fig1_note = '''    <p>藍の 4 個は、酸素や窒素を表す 2 段のギャスケットです。一辺 12 の立方体を 2×2×2 に割り、添字の和が奇数の小立方体に正四面体（A の向き）を置いています。</p>
    <p>朱の正四面体は水素です。座る場所（席）は残りの 4 つの小立方体で、その正四面体は B の向きの大きな正四面体を一度割った四隅とちょうど重なります。A の 2 段と B の 2 段と、真ん中の正八面体の芯を合わせると星型正八面体になります。</p>
    <p>C・N・O・F・Ne の順に、席を手（水素が座れる）と対（ふさがっている）で埋めます。CH₄ は B の 4 つの角がすべて水素で埋まり、芯を除いた星型正八面体が完成します。NH₃ は角が 1 つ、H₂O は 2 つ欠けた形です。</p>'''
fig1_js = COMMON_CTRL_JS + r'''
// 置き方（整数）：一辺 6 の小立方体、向きは 添字＋角 の和が偶
function tet(i,j,l){ const out=[]; for(let a=0;a<2;a++)for(let b=0;b<2;b++)for(let c=0;c<2;c++) if((i+j+l+a+b+c)%2===0) out.push([(i+a)*6,(j+b)*6,(l+c)*6]); return out; }
const A = [[1,0,0],[0,1,0],[0,0,1],[1,1,1]].map(c=>tet(...c));
const seats = [[0,0,0],[1,1,0],[1,0,1],[0,1,1]];          // 手の席は (0,0,0)・(1,1,0) から順に使う（v300 と同じ）
const S = seats.map(c=>tet(...c));
const octa = [[6,6,0],[6,0,6],[0,6,6],[12,6,6],[6,12,6],[6,6,12]];
const octaF = [[0,1,3],[0,3,4],[0,4,2],[0,2,1],[5,1,3],[5,3,4],[5,4,2],[5,2,1]];
// 席の中心から外向きのずれ（落ちてくる向き）：席の中心 − 枠の中心
const sc = seats.map(c=>[(c[0]*12+6)-12,(c[1]*12+6)-12,(c[2]*12+6)-12]);
const ELS = [['C',4,'CH₄'],['N',3,'NH₃'],['O',2,'H₂O'],['F',1,'HF'],['Ne',0,'Ne']];
let ei = 0, t = 0;
document.getElementById('step').onclick = () => { ei = (ei+1)%ELS.length; t = 0; };
const showCore = true;
function frame(){
  if(cv.width===0) fit();
  if(playing) t += speed*0.004;
  if(t > 1.6){ t = 0; ei = (ei+1)%ELS.length; }
  if(spin && !drag) yaw += 0.004;
  const [el,hands,fm] = ELS[ei];
  document.getElementById('el').textContent = el;
  document.getElementById('h').textContent = hands;
  document.getElementById('p').textContent = 4-hands;
  document.getElementById('fm').textContent = fm;
  document.getElementById('fill').textContent = hands + ' / 4';
  ctx.fillStyle = tok('--panel'); ctx.fillRect(0,0,cv.width,cv.height);
  const s = Math.min(cv.width,cv.height)/27, ca = tok('--a'), cb = tok('--b'), cm = tok('--muted'), cc = tok('--core'), ln = tok('--line');
  const ctr = p => [p[0]-6, p[1]-6, p[2]-6];
  const faces=[], lines=[];
  for(const T of A) for(const f of tetFaces(T)) faces.push({p:f.map(ctr), c:ca, a:0.55, e:true});
  if(showCore) for(const f of octaF) faces.push({p:f.map(i=>ctr(octa[i])), c:cc, a:0.18, e:true});
  S.forEach((T,k)=>{
    const isH = k < hands;
    // 水素は外から席へ降りてくる（ずれは整数の席の位置にかける倍率、表示のみ）
    let off = 0; if(isH){ const u = Math.max(0, Math.min(1, (t - k*0.18)/0.5)); off = (1-u)*(1-u)*1.4; }
    const P = T.map(p=>{ const q = ctr(p); return [q[0]+sc[k][0]*off, q[1]+sc[k][1]*off, q[2]+sc[k][2]*off]; });
    if(isH){ for(const f of tetFaces(P)) faces.push({p:f, c:cb, a:0.62, e:true}); }
    else { for(const e of tetEdges(P)) lines.push({p:e, c:cm, w:1.2, dash:true}); }
  });
  // 立方体の枠
  const C=[0,12]; const cube=[]; for(const x of C)for(const y of C)for(const z of C) cube.push([x,y,z]);
  for(let i=0;i<8;i++)for(let j=i+1;j<8;j++){ const a=cube[i],b=cube[j]; if(Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])+Math.abs(a[2]-b[2])===12) lines.push({p:[ctr(a),ctr(b)], c:ln, w:1}); }
  draw3(faces, lines, [], s);
  requestAnimationFrame(frame);
}
fit(); requestAnimationFrame(frame);
'''
page('fig_stella_seats.html', '席が埋まる星型正八面体',
     '酸素・窒素（2段）＋ 水素（1段）＝ 星型正八面体の半分ずつ', '1/1', fig1_stage, fig1_note, fig1_js)

# ───────────────────────── 図2 ─────────────────────────
fig2_stage = '''    <canvas id="cv" aria-label="三重結合の面と二重結合の辺の穴"></canvas>
''' + CTRL.replace('      <label for="rot"><input id="rot" type="checkbox" checked> 自動で回す</label>\n','') + '''
    <div class="read">
      <span class="state" id="st">面の穴を数える</span>
      <span>段 k <b id="k">0</b></span><span>面の点 <b id="fp">6</b></span><span>面の辺 <b id="fe">9</b></span>
      <span>面の穴 <b id="fh">1</b></span><span>埋めた穴 <b id="fm">0</b></span><span>辺の穴 <b>0</b></span>
    </div>
    <div class="key"><span><i style="background:var(--a)"></i>分け合う面（三重）</span><span><i style="background:var(--gold)"></i>穴に入ったフォトン</span><span><i style="background:var(--b)"></i>分け合う辺（二重）</span></div>'''
fig2_note = '''    <p>左は、二つの原子が三重結合で分け合う面です。原子の 2 段のギャスケットをさらにフォトンの段 k まで分けると、面はどの段にも三角形の穴を持ちます。穴の数は k＝0 から 1、7、37、175、781 と増えていきます。</p>
    <p>右は、二重結合で分け合う辺です。どの段まで分けても、単位の線分がすき間なく並び、穴は一つもありません。</p>
    <p>金のフォトンが面の穴を一つずつ埋めていき、最後の一つが埋まった瞬間に、面と面の間に一枚の膜ができて、面ごと浮き上がります。途中で止まれる段はありません。辺には入る場所がないので、この外れ方は起きません。</p>'''
fig2_js = COMMON_CTRL_JS + r'''
spin = false;
// 面：一辺 N = 2^(k+1) の正三角形を三角格子の座標 (a,b)（a+b ≤ N）で持つ。
// 埋まった小三角形は、シェルピンスキーの作り方（四隅を残して真ん中を抜く）で数える（整数のみ）。
function sier(n){ // n 段 → 上向き小三角形の左下の座標の一覧
  let tris = [[0,0,1]]; // [a,b,size]
  let N = 1; for(let i=0;i<n;i++) N += N;
  tris = [[0,0,N]];
  for(let i=0;i<n;i++){ const nx=[]; for(const [a,b,s] of tris){ let h=0; while(h+h<s) h++; nx.push([a,b,h],[a+h,b,h],[a,b+h,h]); } tris = nx; }
  return {tris, N};
}
function counts(n){
  const {tris,N} = sier(n); const P = new Set(), E = new Set();
  for(const [a,b] of tris){ const v=[[a,b],[a+1,b],[a,b+1]]; v.forEach(q=>P.add(q+''));
    for(let i=0;i<3;i++) for(let j=i+1;j<3;j++){ const x=v[i]+'', y=v[j]+''; E.add(x<y? x+'|'+y : y+'|'+x); } }
  // 穴：全体の小三角形（上向き N(N+1)/2 個 ＋ 下向き N(N-1)/2 個 ＝ N²）から埋まった数を引く
  let all = 0; for(let i=0;i<N;i++) all += N;
  const filled = new Set(tris.map(t=>t+''));
  const holes = [];
  for(let a=0;a<N;a++) for(let b=0;a+b<N;b++){ if(!filled.has([a,b,1]+'')) holes.push([a,b,1]); }       // 上向きの穴
  for(let a=0;a+2<=N;a++) for(let b=0;a+b+2<=N;b++) holes.push([a,b,-1]);                               // 下向きはすべて穴
  return {tris, N, p:P.size, e:E.size, holes, all};
}
let k = 0, C = counts(1), m = 0, mf = 0, phase = 0, t = 0, lift = 0;
function setK(nk){ k = nk; C = counts(k+1); m = 0; mf = 0; phase = 0; t = 0; lift = 0;
  // 穴を埋める順は、外側の大きな穴から（座標の和の小さい順＝表示の都合）
  C.holes.sort((u,v)=> (u[0]+u[1]) - (v[0]+v[1]) || u[0]-v[0]); }
setK(0);
document.getElementById('step').onclick = () => setK((k+1)%5);
function tri(a,b,dir,N,ox,oy,L){ // 三角格子 → 画面（表示のみ）
  const u = L/N, h = u*0.8660254;
  const pt = (x,y)=>[ox + (x + y*0.5)*u, oy - y*h];
  return dir>0 ? [pt(a,b),pt(a+1,b),pt(a,b+1)] : [pt(a+1,b),pt(a,b+1),pt(a+1,b+1)];
}
function poly(q, fill){ ctx.beginPath(); q.forEach((v,i)=> i?ctx.lineTo(v[0],v[1]):ctx.moveTo(v[0],v[1])); ctx.closePath(); ctx.fillStyle=fill; ctx.fill(); }
function frame(){
  if(cv.width===0) fit();
  const H = C.holes.length;
  if(playing){
    t += speed*0.006;
    if(phase===0 && t>1){ phase=1; t=0; }
    else if(phase===1){ mf += Math.max(1, H/150)*speed/3; m = Math.min(H, Math.floor(mf)); if(m===H){ phase=2; t=0; } }   // 埋める速さは表示の都合
    else if(phase===2){ lift = Math.min(1, t); if(t>1.6) setK((k+1)%5); }
  }
  document.getElementById('k').textContent = k;
  document.getElementById('fp').textContent = C.p;
  document.getElementById('fe').textContent = C.e;
  document.getElementById('fh').textContent = H;
  document.getElementById('fm').textContent = m;
  document.getElementById('st').textContent = phase===0 ? '面の穴を数える' : phase===1 ? 'フォトンが穴を埋める' : '面ごと浮き上がる';
  const W = cv.width, Hh = cv.height, dpr = window.devicePixelRatio||1;
  ctx.fillStyle = tok('--panel'); ctx.fillRect(0,0,W,Hh);
  const ca = tok('--a'), cg = tok('--gold'), cb = tok('--b'), ink = tok('--ink'), mu = tok('--muted');
  const L = Math.min(W*0.56, Hh*0.95), ox = W*0.04, oy = Hh*0.9;
  // 下の原子の面（固定）
  for(const [a,b] of C.tris) poly(tri(a,b,1,C.N,ox,oy,L), rgba(ca,0.85));
  for(let i=0;i<m;i++){ const [a,b,d] = C.holes[i]; poly(tri(a,b,d,C.N,ox,oy,L), rgba(cg,0.9)); }
  // 浮き上がる上の面（表示のみ）
  if(lift>0){ const dy = -lift*Hh*0.12, dx = lift*W*0.02;
    ctx.save(); ctx.translate(dx,dy);
    for(const [a,b] of C.tris) poly(tri(a,b,1,C.N,ox,oy,L), rgba(ca,0.35));
    for(const [a,b,d] of C.holes) poly(tri(a,b,d,C.N,ox,oy,L), rgba(cg,0.35));
    ctx.restore(); }
  // 外形
  ctx.strokeStyle = mu; ctx.lineWidth = dpr; ctx.beginPath(); const q = tri(0,0,1,1,ox,oy,L); q.forEach((v,i)=> i?ctx.lineTo(v[0],v[1]):ctx.moveTo(v[0],v[1])); ctx.closePath(); ctx.stroke();
  // 右：辺（二重）
  const ex = W*0.78, ey0 = Hh*0.16, ey1 = Hh*0.9, n = C.N;
  for(let i=0;i<=n;i++){ const y = ey0 + (ey1-ey0)*i/n; ctx.beginPath(); ctx.arc(ex, y, 2.2*dpr, 0, 6.2832); ctx.fillStyle = cb; ctx.fill(); }
  ctx.strokeStyle = cb; ctx.lineWidth = 3*dpr; ctx.beginPath(); ctx.moveTo(ex,ey0); ctx.lineTo(ex,ey1); ctx.stroke();
  ctx.fillStyle = ink; ctx.font = `${13*dpr}px ${tok('--f-mono')||'monospace'}`;
  ctx.textAlign='center'; ctx.fillText('辺：穴 0', ex, ey0 - 14*dpr); ctx.textAlign='left';
  ctx.fillText('面：穴 '+H, ox, 18*dpr);
  requestAnimationFrame(frame);
}
fit(); requestAnimationFrame(frame);
'''
page('fig_face_holes.html', '面の穴と辺の穴',
     '三重結合の面はどの段にも穴を持ち、二重結合の辺は持たない', '4/3', fig2_stage, fig2_note, fig2_js)

# ───────────────────────── 図3 ─────────────────────────
fig3_stage = '''    <canvas id="cv" aria-label="正十二面体の頂点に収まる5つの正四面体"></canvas>
''' + CTRL + '''
    <div class="ctrl"><button id="chir" type="button">B の側の 5 つに切り替える</button></div>
    <div class="read">
      <span class="state" id="st">立方体と星型正八面体</span>
      <span>正四面体 <b id="nt">10</b></span><span>5 つに分ける分け方 <b id="np">2</b></span><span>頂点 <b>20 ＝ 5 × 4</b></span>
    </div>
    <div class="key"><span><i style="background:var(--a)"></i>A（立方体の正四面体）</span><span><i style="background:var(--b)"></i>B</span><span><i style="background:var(--core)"></i>φ でずらした残り 4 つ</span></div>'''
fig3_note = '''    <p>はじめは立方体と、その中の二つの正四面体 A・B（星型正八面体）です。座標は φ を含む整数の組 a＋bφ だけで持ち、正十二面体の 20 頂点のうち 8 つが立方体の頂点、残り 12 が φ でずらした頂点です。</p>
    <p>20 頂点からは辺の長さのそろった正四面体が 10 個取れ、20 頂点を重複なしに 5 個ずつ分ける分け方はちょうど 2 通りです。一方は A を含み、もう一方は B を含みます。図は分け方と同時に、そのまま計算しています。</p>
    <p>最後に、5 回対称の軸のまわりに 72° 回すと、5 つの正四面体が順に入れ替わります。この 5 回の回転は 24 個あり、軸の向きは 12 本、中心と合わせて 13 です（five_tetra.py の出力）。</p>'''
fig3_js = COMMON_CTRL_JS + r'''
// Z[φ] の整数の組 (a,b) = a + bφ、φ² = φ + 1
const zm = (x,y)=>[x[0]*y[0]+x[1]*y[1], x[0]*y[1]+x[1]*y[0]+x[1]*y[1]];
const za = (x,y)=>[x[0]+y[0], x[1]+y[1]];
const zs = (x,y)=>[x[0]-y[0], x[1]-y[1]];
const Z = n=>[n,0], PHI=[0,1], PINV=[-1,1];
const V = [];
for(const sx of [1,-1]) for(const sy of [1,-1]) for(const sz of [1,-1]) V.push([Z(sx),Z(sy),Z(sz)]);
for(const s1 of [1,-1]) for(const s2 of [1,-1]){ const a=zm(Z(s1),PINV), b=zm(Z(s2),PHI);
  V.push([Z(0),a,b]); V.push([a,b,Z(0)]); V.push([b,Z(0),a]); }
const d2 = (p,q)=>{ let s=[0,0]; for(let i=0;i<3;i++){ const w=zs(p[i],q[i]); s=za(s,zm(w,w)); } return s; };
const eq = (x,y)=> x[0]===y[0] && x[1]===y[1];
const tets = [];
for(let a=0;a<20;a++)for(let b=a+1;b<20;b++)for(let c=b+1;c<20;c++)for(let d=c+1;d<20;d++){
  const ix=[a,b,c,d]; let ok=true; for(let i=0;i<4&&ok;i++)for(let j=i+1;j<4&&ok;j++) if(!eq(d2(V[ix[i]],V[ix[j]]),[8,0])) ok=false;
  if(ok) tets.push(ix); }
const parts = [];
(function rec(start, used, chosen){ if(chosen.length===5){ parts.push(chosen.slice()); return; }
  for(let i=start;i<tets.length;i++){ if(tets[i].some(v=>used.has(v))) continue; tets[i].forEach(v=>used.add(v)); chosen.push(i); rec(i+1,used,chosen); chosen.pop(); tets[i].forEach(v=>used.delete(v)); } })(0,new Set(),[]);
document.getElementById('nt').textContent = tets.length;
document.getElementById('np').textContent = parts.length;
const isA = ix => ix.every(i=> i<8 && (V[i][0][0]*V[i][1][0]*V[i][2][0]===1));
const isB = ix => ix.every(i=> i<8 && (V[i][0][0]*V[i][1][0]*V[i][2][0]===-1));
let side = 0; // 0: A を含む分け方, 1: B を含む分け方
const partA = parts.find(p=>p.some(i=>isA(tets[i]))), partB = parts.find(p=>p.some(i=>isB(tets[i])));
document.getElementById('chir').onclick = e => { side = 1-side; e.target.textContent = side? 'A の側の 5 つに切り替える' : 'B の側の 5 つに切り替える'; };
const F = 1.6180339887;                                   // 観察者側の表示：a+bφ を画面の長さに直すだけ
const fl = p => p.map(x=> x[0] + x[1]*F);
const P = V.map(fl);
const dodE = []; for(let i=0;i<20;i++)for(let j=i+1;j<20;j++) if(eq(d2(V[i],V[j]),[8,-4])) dodE.push([i,j]);
const cubeE = []; for(let i=0;i<8;i++)for(let j=i+1;j<8;j++) if(eq(d2(V[i],V[j]),[4,0])) cubeE.push([i,j]);
// 5 回の軸：正十二面体の一つの面（5 頂点）の和の向き（表示のみ）
const ax = (()=>{ // 正十二面体の面の中心の向き：最大の内積をとる頂点がちょうど 5 つになる向き（表示のみ）
  const fam=[[0,1,F],[1,F,0],[F,0,1],[0,F,1],[F,1,0],[1,0,F]];
  for(const c of fam){ const d=P.map(p=>p[0]*c[0]+p[1]*c[1]+p[2]*c[2]); const mx=Math.max(...d); if(d.filter(v=>v>mx-1e-9).length===5) return c; } return [0,1,F]; })();
const an = Math.hypot(...ax), AX = ax.map(v=>v/an);
function rotAx(p, th){ const c=Math.cos(th), s=Math.sin(th), d=p[0]*AX[0]+p[1]*AX[1]+p[2]*AX[2];
  const cr=[AX[1]*p[2]-AX[2]*p[1], AX[2]*p[0]-AX[0]*p[2], AX[0]*p[1]-AX[1]*p[0]];
  return [0,1,2].map(i=> p[i]*c + cr[i]*s + AX[i]*d*(1-c)); }
let t = 0, stage = 0;
document.getElementById('step').onclick = () => { stage = (stage+1)%4; t = 0; };
const STN = ['立方体と星型正八面体','φ でずらした正十二面体','同じ正四面体が 5 つ','72° 回すと 5 つが入れ替わる'];
function frame(){
  if(cv.width===0) fit();
  if(playing){ t += speed*0.003; if(t>1.4){ t=0; stage=(stage+1)%4; } }
  if(spin && !drag) yaw += 0.004;
  document.getElementById('st').textContent = STN[stage];
  ctx.fillStyle = tok('--panel'); ctx.fillRect(0,0,cv.width,cv.height);
  const s = Math.min(cv.width,cv.height)/5.2, ca=tok('--a'), cb=tok('--b'), cc=tok('--core'), ln=tok('--line'), mu=tok('--muted');
  const part = side ? partB : partA;
  const th = stage===3 ? Math.min(1,t)*1.2566371 : 0;      // 72° を表示のために回す
  const R = p => rotAx(p, th);
  const faces=[], lines=[], dots=[];
  if(stage===0){ for(const [i,j] of cubeE) lines.push({p:[P[i],P[j]], c:mu, w:1});
    const tA = tets.find(isA), tB = tets.find(isB);
    for(const f of tetFaces(tA.map(i=>P[i]))) faces.push({p:f, c:ca, a:0.45, e:true});
    for(const f of tetFaces(tB.map(i=>P[i]))) faces.push({p:f, c:cb, a:0.35, e:true}); }
  else {
    for(const [i,j] of dodE) lines.push({p:[R(P[i]),R(P[j])], c:ln, w:1});
    if(stage===1){ for(let i=0;i<20;i++) dots.push({p:P[i], c: i<8 ? ca : cc, r:3});
      const tA = tets.find(side? isB : isA); for(const f of tetFaces(tA.map(i=>P[i]))) faces.push({p:f, c: side? cb: ca, a:0.4, e:true}); }
    else { const shown = stage===2 ? Math.min(5, 1 + Math.floor(t*4)) : 5;
      part.forEach((ti,n)=>{ if(n>=shown && !(isA(tets[ti])||isB(tets[ti]))) return;
        const home = isA(tets[ti])||isB(tets[ti]);
        const col = home ? (side? cb : ca) : cc;
        for(const f of tetFaces(tets[ti].map(i=>R(P[i])))) faces.push({p:f, c:col, a: home? 0.42 : 0.2, e:true}); });
      if(stage===3) lines.push({p:[AX.map(v=>v*-2.4), AX.map(v=>v*2.4)], c:mu, w:1.5, dash:true}); }
  }
  draw3(faces, lines, dots, s);
  requestAnimationFrame(frame);
}
fit(); requestAnimationFrame(frame);
'''
page('fig_five_tetra.html', '十二面体に収まる5つの正四面体',
     'φ でずらすと、星型正八面体の A と B がそれぞれ 5 つ組に開く', '1/1', fig3_stage, fig3_note, fig3_js)

# ───────────────────────── 図4 ─────────────────────────
fig4_stage = '''    <canvas id="cv" aria-label="正八面体の隙間に嵌る星型正八面体の入れ子"></canvas>
''' + CTRL + '''
    <div class="read">
      <span class="state" id="st">ギャスケットの隙間</span>
      <span>正八面体 |x|+|y|+|z| ≤ <b id="R">27</b></span><span>星型正八面体の先端 (±<b id="s">9</b>, ±<b id="s2">9</b>, ±<b id="s3">9</b>)</span><span>先端の |x|+|y|+|z| ＝ <b id="tip">27</b></span><span>芯 ≤ <b id="cr">9</b></span>
    </div>
    <div class="key"><span><i style="background:var(--a)"></i>A</span><span><i style="background:var(--b)"></i>B</span><span><i style="background:var(--core)"></i>正八面体の隙間</span></div>'''
fig4_note = '''    <p>はじめの藍の 4 個は、正四面体を一度割った 2 段のギャスケットです。真ん中の灰緑の正八面体が、割ったときに抜けた隙間です。</p>
    <p>その正八面体 |x|＋|y|＋|z| ≤ 27 に、向き合う二つの正四面体（星型正八面体）を嵌めます。先端 (±9, ±9, ±9) は、どれも |x|＋|y|＋|z| ＝ 27 で、正八面体の 8 つの面の真ん中に一つずつ触れます。</p>
    <p>星型正八面体の芯は、また正八面体 |x|＋|y|＋|z| ≤ 9 で、ちょうど 1/3 の大きさです。そこへまた星型正八面体が嵌り、27 → 9 → 3 → 1 と同じ形が繰り返されます。ギャスケットは 2 の刻み、星型正八面体は 3 の刻みで、二つを一緒に整数で持つ枠は 6 の倍数になります。</p>'''
fig4_js = COMMON_CTRL_JS + r'''
// 整数の座標だけで置く。外側の正四面体 A の角 (±27,±27,±27)（積が正）
const R0 = 27;
const Acorn = [[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]].map(v=>v.map(x=>x*R0));
const mid = (p,q)=>[0,1,2].map(i=>{ const s=p[i]+q[i]; let h=0; if(s>=0){ while(h+h<s) h++; } else { while(h+h>s) h--; } return h; });
const sub4 = Acorn.map((c,i)=>[c, ...Acorn.filter((_,j)=>j!==i).map(o=>mid(c,o))]);   // 2 段（四隅の 4 個）
function octa(r){ return [[r,0,0],[-r,0,0],[0,r,0],[0,-r,0],[0,0,r],[0,0,-r]]; }
const OF = [[0,2,4],[0,4,3],[0,3,5],[0,5,2],[1,2,4],[1,4,3],[1,3,5],[1,5,2]];
function stella(s){ // 積の符号で A（正）と B（負）に分ける
  const a=[],b=[]; for(const x of [s,-s])for(const y of [s,-s])for(const z of [s,-s]){ const sg = (x>0?1:-1)*(y>0?1:-1)*(z>0?1:-1); (sg>0?a:b).push([x,y,z]); } return [a,b]; }
const absum = p => Math.abs(p[0])+Math.abs(p[1])+Math.abs(p[2]);
let lv = 0, t = 0;   // lv：何段目の入れ子を見ているか（0: 27, 1: 9, 2: 3）
document.getElementById('step').onclick = () => { lv = (lv+1)%3; t = 0; };
function frame(){
  if(cv.width===0) fit();
  if(playing){ t += speed*0.0025; if(t>1.6){ t=0; lv=(lv+1)%3; } }
  if(spin && !drag) yaw += 0.004;
  let R = R0; for(let i=0;i<lv;i++){ let q=0, r=R; while(r>0){ r-=3; q++; } R=q; }     // 27 → 9 → 3（3 を引いて数える）
  let sv = 0, r = R; while(r>0){ r-=3; sv++; }                                       // 先端の座標 ＝ R/3
  const [sa,sb] = stella(sv);
  document.getElementById('R').textContent = R;
  ['s','s2','s3'].forEach(id=>document.getElementById(id).textContent = sv);
  document.getElementById('tip').textContent = absum(sa[0]);
  document.getElementById('cr').textContent = sv;
  document.getElementById('st').textContent = lv===0 && t<0.5 ? 'ギャスケットの隙間' : '星型正八面体が嵌る（芯は 1/3）';
  ctx.fillStyle = tok('--panel'); ctx.fillRect(0,0,cv.width,cv.height);
  const zoom = Math.pow(3, lv + Math.max(0, t-1.0)/0.6);                            // 表示の拡大だけ
  const s = Math.min(cv.width,cv.height)/(2.6*R0) * zoom;
  const ca=tok('--a'), cb=tok('--b'), cc=tok('--core'), mu=tok('--muted');
  const faces=[], lines=[], dots=[];
  if(lv===0) for(const T of sub4) for(const f of tetFaces(T)) faces.push({p:f, c:ca, a: 0.22, e:true});
  const O = octa(R); for(const f of OF) faces.push({p:f.map(i=>O[i]), c:cc, a:0.16, e:true});
  if(!(lv===0 && t<0.5)){
    for(const f of tetFaces(sa)) faces.push({p:f, c:ca, a:0.5, e:true});
    for(const f of tetFaces(sb)) faces.push({p:f, c:cb, a:0.45, e:true});
    for(const p of sa.concat(sb)) dots.push({p, c:mu, r:2.5});
    const O2 = octa(sv); for(const f of OF) faces.push({p:f.map(i=>O2[i]), c:cc, a:0.3, e:true});
  }
  draw3(faces, lines, dots, s);
  requestAnimationFrame(frame);
}
fit(); requestAnimationFrame(frame);
'''
page('fig_nested_stella.html', '正八面体に嵌る星型正八面体',
     '2 の刻みのギャスケットと 3 の刻みの星型正八面体の入れ子', '1/1', fig4_stage, fig4_note, fig4_js)

# shell_fractal.py ── 符号反転した相方をフラクタル（d 段のギャスケット）のまま入れたときの付ける場所
# 整数と加算・比較だけ。
#
# 置き方：v300 と同じ枠（電子大の小立方体 2x2x2）。電子大の小立方体の一辺を 2^d とし、
#   フォトンの単位立方体の一辺を 1 とする。
#   原子：添字の和が奇の小立方体に A の向きの d 段ギャスケット。
#   相方：枠の 8 小立方体すべてに B の向きの d 段ギャスケット（隙間を残したまま）。
#   d=0 は前回の M（相方が中まで詰まった一個）と同じ。
# 電子：A の向きの d 段ギャスケットを、枠のまわりの小立方体に置く。
#   食い込み＝単位の正四面体が同じ単位立方体に入る組があること（A と A は同一、A と B は八面体で重なる）。
#   分け合う辺＝原子の A ギャスケットと共有する単位の辺の数。
#
# 基準（走らせる前に決めたもの）：
#   どの d でも、分け合う辺が最多の場所が 12 か所（中心と合わせて 13）にそろい、
#   向きの内積の比が −1/3・−1/11 の先へ、0 の手前で止まりながら進むなら、13 は段ごとに保たれる。
#   段によって場所の数がばらつくなら NG。
#   負の対照：相方なし（L）は d によらず 4 か所・−1/3。

from itertools import product

def pow2(k):
    v = 1
    for _ in range(k):
        v = v + v
    return v

def half(s):
    h = 0
    if s >= 0:
        while h + h < s: h = h + 1
    else:
        while h + h > s: h = h - 1
    return h

def mid(p, q):
    return tuple(half(a + b) for a, b in zip(p, q))

def tet(idx, orient, E):
    i, j, l = idx
    out = []
    for a, b, c in product((0, 1), repeat=3):
        if ((i + j + l + a + b + c) % 2) == orient:
            out.append(((i + a) * E, (j + b) * E, (l + c) * E))
    return tuple(out)

def gasket(corners, k):
    tets = [tuple(corners)]
    for _ in range(k):
        nxt = []
        for t in tets:
            a, b, c, d = t
            ab, ac, ad, bc, bd, cd = mid(a, b), mid(a, c), mid(a, d), mid(b, c), mid(b, d), mid(c, d)
            nxt += [(a, ab, ac, ad), (ab, b, bc, bd), (ac, bc, c, cd), (ad, bd, cd, d)]
        tets = nxt
    return tets

def cubes(tets):
    return {tuple(min(p[q] for p in t) for q in range(3)) for t in tets}

def edges(tets):
    s = set()
    for t in tets:
        for x in range(4):
            for y in range(x + 1, 4):
                s.add(frozenset((t[x], t[y])))
    return s

def dot(a, b): return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

frame = list(product((0, 1), repeat=3))
for d in range(0, 4):
    E = pow2(d)
    A_atom = []
    for f in frame:
        if sum(f) % 2 == 1:
            A_atom += gasket(tet(f, 0, E), d)
    B_part = []
    for f in frame:
        B_part += gasket(tet(f, 1, E), d)
    A_cubes, A_edges = cubes(A_atom), edges(A_atom)
    B_cubes = cubes(B_part)
    # 原子の A と相方の B の重なり（同じ単位立方体）
    ab = len(A_cubes & B_cubes)
    for name, occ in (("L（相方なし）", A_cubes), ("M（相方あり）", A_cubes | B_cubes)):
        found = []
        for idx in product(range(-1, 3), repeat=3):
            G = gasket(tet(idx, 0, E), d)
            if cubes(G) & occ:
                continue
            se = len(edges(G) & A_edges)
            if se == 0:
                continue
            v = (4 * idx[0] + 2 - 4, 4 * idx[1] + 2 - 4, 4 * idx[2] + 2 - 4)   # 小立方体の中心−枠の中心（2 倍、E で割った形）
            found.append((se, v))
        best = max(s for s, _ in found)
        top = [v for s, v in found if s == best]
        tally = {}
        for s, _ in found:
            tally[s] = tally.get(s, 0) + 1
        dots = sorted({dot(top[a], top[b]) for a in range(len(top)) for b in range(a + 1, len(top))})
        print(f"d={d} E={E:2d} {name}: 付ける場所 {len(found)} {dict(sorted(tally.items(), reverse=True))}  "
              f"最多（辺 {best}）{len(top)} か所  内積 {dots} 自分自身 {dot(top[0], top[0])}")
    print(f"      原子の A と相方の B が同じ単位立方体に入る数 {ab}")

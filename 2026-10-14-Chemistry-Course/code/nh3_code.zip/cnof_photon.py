# cnof_photon.py  ── 電子＝フォトンのギャスケットの積み重ね（J1〜J3, G1）と C/N/O/F/Ne の書き分け
# 整数と加算・比較だけ。割り算・浮動小数なし。
# 置き方は v300 §2（O：一辺 2E の枠を 2x2x2 に割り、添字の和が奇の小立方体に正四面体、偶の 4 つが席）。
# 電子（H）＝ k 段のフォトンのギャスケット、E = 2^k（フォトンの単位立方体の一辺 1）。

from itertools import product

def pow2(k):
    v = 1
    for _ in range(k):
        v = v + v
    return v

def pow_n(b, k):
    v = 1
    for _ in range(k):
        s = 0
        for _ in range(b):
            s = s + v
        v = s
    return v

def tetra_in_cube(o, E, flip=0):
    """一辺 E の立方体（原点 o、E 単位の添字 o/E）に入る正四面体の 4 頂点。
    向き：添字＋角の和が偶（flip=1 で反対の向き）。"""
    i, j, l = o
    # o は E の倍数として与える。添字の偶奇は o を E で数えた回数の和
    def idx(x):
        n = 0
        s = 0
        if x >= 0:
            while s < x:
                s = s + E; n = n + 1
        else:
            while s > x:
                s = s - E; n = n - 1
        return n
    base = idx(i) + idx(j) + idx(l)
    out = []
    for a, b, c in product((0, 1), repeat=3):
        par = base + a + b + c
        even = (par % 2 == 0)
        if even != bool(flip):
            out.append((i + a * E, j + b * E, l + c * E))
    return tuple(out)

def mid(p, q):
    # 中点（座標は偶数差なので 2 で割り切れる）：引き算を数えて半分を作る
    r = []
    for a, b in zip(p, q):
        s = a + b
        h = 0
        if s >= 0:
            while h + h < s:
                h = h + 1
        else:
            while h + h > s:
                h = h - 1
        r.append(h)
    return tuple(r)

def gasket(corners, k):
    """k 段のギャスケット：単位正四面体（頂点 4 つの組）の集合"""
    tets = [tuple(corners)]
    for _ in range(k):
        nxt = []
        for t in tets:
            a, b, c, d = t
            ab, ac, ad, bc, bd, cd = mid(a, b), mid(a, c), mid(a, d), mid(b, c), mid(b, d), mid(c, d)
            nxt += [(a, ab, ac, ad), (ab, b, bc, bd), (ac, bc, c, cd), (ad, bd, cd, d)]
        tets = nxt
    return tets

def pts(tets):
    s = set()
    for t in tets:
        s.update(t)
    return s

def edges(tets):
    s = set()
    for t in tets:
        for x in range(4):
            for y in range(x + 1, 4):
                s.add(frozenset((t[x], t[y])))
    return s

def cubes(tets):
    # 単位正四面体が入っている単位立方体（最小座標）
    s = set()
    for t in tets:
        s.add(tuple(min(p[q] for p in t) for q in range(3)))
    return s

def o_atom(E, k):
    """O（2 段＝電子大の正四面体 4 個）を k 段のフォトンで作る。添字の和が奇の小立方体。"""
    parts = []
    for a, b, c in product((0, 1), repeat=3):
        if (a + b + c) % 2 == 1:
            o = (a * E, b * E, c * E)
            parts.append(gasket(tetra_in_cube(o, E), k))
    return parts

seats = [(0, 0, 0), (1, 1, 0), (1, 0, 1), (0, 1, 1)]

print("=" * 70)
print("J1 電子の形：k 段のフォトンのギャスケットを席 (0,0,0) に置く")
print("  基準：O の正四面体 3 個と、それぞれ大きな辺 1 本（単位の辺 E 本）を分け合い、食い込み 0。")
print("  負の対照：反対の向きで置くと辺を分け合わない。")
for k in range(1, 5):
    E = pow2(k)
    O = o_atom(E, k)
    Hs = gasket(tetra_in_cube((0, 0, 0), E), k)
    Hb = gasket(tetra_in_cube((0, 0, 0), E, flip=1), k)
    for name, H in (("正しい向き", Hs), ("反対の向き", Hb)):
        per = []
        ov = 0
        for part in O:
            se = len(edges(H) & edges(part))
            per.append(se)
            ov = ov + len(cubes(H) & cubes(part))
        sp = len(pts(H) & set().union(*[pts(p) for p in O]))
        print(f"  k={k} E={E:2d} {name}: 単位の数 {len(H)}（4^k={pow_n(4,k)}）  分け合う単位辺 {per}  分け合う点 {sp}  食い込み {ov}")

print("=" * 70)
print("J2 収まるか：H₂（点でつながる）の隣に、電子大まで積み上がったギャスケットを置く")
print("  基準：H の隣では食い込み >0、空いた席では食い込み 0 なら弁別できる。")
for k in range(1, 4):
    E = pow2(k)
    H1 = gasket(tetra_in_cube((0, 0, 0), E), k)
    H2 = gasket(tetra_in_cube((-E, -E, -E), E), k)     # 角 (0,0,0) を分け合う
    shared_pt = len(pts(H1) & pts(H2))
    occ = cubes(H1) | cubes(H2)
    hit = 0
    n = 0
    for d in product((-1, 0, 1), repeat=3):
        if d == (0, 0, 0):
            continue
        o = (d[0] * E, d[1] * E, d[2] * E)
        if o == (-E, -E, -E):
            continue
        G = gasket(tetra_in_cube(o, E), k)
        n = n + 1
        if cubes(G) & occ:
            hit = hit + 1
    # 対照：O の空いた席に置く
    O = o_atom(E, k)
    G = gasket(tetra_in_cube((0, 0, 0), E), k)
    ctrl = sum(len(cubes(G) & cubes(p)) for p in O)
    print(f"  k={k}: H₂ の分け合う点 {shared_pt}  隣 {n} か所のうち食い込むもの {hit}  空いた席での食い込み {ctrl}")

print("=" * 70)
print("G1 面と辺のフォトンの穴：O を k 段（＝フォトンで k+1 段）に作り、外形の面・辺を数える")
print("  対照：k=0（フォトン＝電子）で v300 の面の 6 点・9 辺が出ること。")
for k in range(0, 5):
    E = pow2(k)
    E2 = E + E
    O = o_atom(E, k)
    P = set().union(*[pts(p) for p in O])
    Ed = set().union(*[edges(p) for p in O])
    face_p = {p for p in P if p[0] + p[1] + p[2] == E2}
    face_e = {e for e in Ed if all(p[0] + p[1] + p[2] == E2 for p in e)}
    # 面の上の小三角形（単位正四面体の面で、面の平面に乗るもの）
    filled = 0
    for part in O:
        for t in part:
            on = [p for p in t if p[0] + p[1] + p[2] == E2]
            if len(on) == 3:
                filled = filled + 1
    area = pow_n(4, k + 1)
    edge_p = {p for p in P if p[2] == 0 and p[0] + p[1] == E2}     # 辺 (2E,0,0)-(0,2E,0)
    edge_e = {e for e in Ed if all(p[2] == 0 and p[0] + p[1] == E2 for p in e)}
    print(f"  k={k}: 面 点 {len(face_p)} 辺 {len(face_e)} 埋まった小三角形 {filled}（3^(k+1)={pow_n(3,k+1)}） "
          f"広さ {area}  穴 {area - filled}   │ 辺 点 {len(edge_p)} 単位辺 {len(edge_e)} 穴 0")

print("=" * 70)
print("J3 底：k 段のギャスケット 1 つを、ほどく規則（1 つ → 1 段下 4 つ）だけで繰り返す")
print("  基準：単位の総数が保たれ、k 回で全部が 0 段（フォトンの 1）になり、個数 0 が現れない。")
print("  負の対照：「0 段を 1 つ消す」を足すと 0 に届く。")
for k in range(1, 5):
    gs = [k]
    hist = []
    for step in range(k):
        nxt = []
        for d in gs:
            if d > 0:
                nxt += [d - 1, d - 1, d - 1, d - 1]
            else:
                nxt.append(d)
        gs = nxt
        units = sum(pow_n(4, d) for d in gs)
        hist.append((len(gs), units))
    zero_seen = any(c == 0 for c, _ in hist)
    # 対照
    g2 = list(gs); steps = 0
    while g2:
        g2.pop(); steps = steps + 1
    print(f"  k={k}: 各回の（個数, 単位の総数）{hist}  0 の出現 {zero_seen}   │ 消す規則を足すと {steps} 回で 0")
print("  J3a 上向き：単位 N 個で作れる最大の段（4^d ≤ N）")
for N in (1, 3, 4, 15, 16, 63, 64, 1000, 4096, 100000):
    d = 0; v = 1
    while pow_n(4, d + 1) <= N:
        d = d + 1
    print(f"    N={N:6d} → 最大 {d} 段（その 1 つに 4^{d}={pow_n(4,d)} 単位）")

print("=" * 70)
print("C N O F Ne の書き分け（席 4 つを 手 と 対 で埋める）")
els = [("C", 4), ("N", 3), ("O", 2), ("F", 1), ("Ne", 0)]
# 席の中心（O の中心 (E,E,E) から、E=6 の枠で 3 倍した整数ベクトル）
vec = [(-1, -1, -1), (1, 1, -1), (1, -1, 1), (-1, 1, 1)]
def dot(a, b): return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
print(f"  席の中心どうしの内積 {sorted({dot(vec[i],vec[j]) for i in range(4) for j in range(i+1,4)})}、自分自身 {dot(vec[0],vec[0])} （どの 2 席の組も同じ）")
bond = {3: "面（三重）", 2: "辺（二重）", 1: "点（一重）", 0: "つながらない"}
print("  元素 手 対 │ H を付けた形 H の数 │ 二原子のつながり 余る手 │ H⁺ が入る席 │ 隣と向き合う組 min(対,H)")
for e, h in els:
    p = 4 - h
    b = h if h <= 3 else 3
    left = h - b
    hplus = p
    hb = p if p < h else h
    form = {4: "CH₄", 3: "NH₃", 2: "H₂O", 1: "HF", 0: "Ne"}[h]
    print(f"  {e:2s} {h}  {p} │ {form:4s} {h} │ {bond[b]:7s} {left} │ {hplus} │ {hb}")

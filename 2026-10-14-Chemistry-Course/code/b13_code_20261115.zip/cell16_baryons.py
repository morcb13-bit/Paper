# 正十六胞体（±e1..±e4）の 8 頂点に、一つの世代の 8 状態を置く読み（整数だけ）。
#   軸 1 = レプトンの軸、軸 2,3,4 = 3 色。符号 + = 上の型（u, ν）、− = 下の型（d, e）。
#   電荷（1/3 単位）= (3s + c) / 2、c = −3（軸 1）または +1（軸 2..4）、s = ±1
# 基準（走らせる前に決めた）：
#   H1 8 頂点の電荷が ν 0、u +2（3色）、e −3、d −1（3色）にちょうどなる
#   H2 3 色を一つずつ使う三点組（軸 2,3,4 から一つずつ）が、すべて正十六胞体の面（三点が互いに辺で結ばれる）になる
#   H3 その 8 個の面の電荷の和が Δ⁺⁺ 6, (uud) 3, (udd) 0, Δ⁻ −3 に並び、uud・udd はちょうど 3 通りずつ
#   対照：3 次元の影の高さ（座標の和）を電荷とした読みでは、uud の三点組は 3 次元のどの正四面体の面にもならない（前回 0 件）
from itertools import combinations, product
V=[(i,s) for i in range(4) for s in (1,-1)]
name={(0,1):'ν',(0,-1):'e'}; name.update({(i,1):'u'+'rgb'[i-1] for i in (1,2,3)}); name.update({(i,-1):'d'+'rgb'[i-1] for i in (1,2,3)})
def q3(v):
    i,s=v; c=-3 if i==0 else 1
    assert (3*s+c)%2==0; return (3*s+c)//2
adj=lambda a,b: a[0]!=b[0]                     # 正十六胞体：対蹠（同じ軸）以外はすべて辺
print("H1 charges (1/3 units):",{name[v]:q3(v) for v in V})
tri=[t for t in combinations(V,3) if all(adj(a,b) for a,b in combinations(t,2))]
print("triangles in 16-cell:",len(tri))
bary=[t for t in tri if sorted(v[0] for v in t)==[1,2,3]]
from collections import Counter
cnt=Counter(); 
for t in bary:
    ups=sum(1 for v in t if v[1]==1); cnt[(ups,sum(q3(v) for v in t))]+=1
print("H2 color-singlet triples that are faces:",len(bary),"of",2**3)
print("H3 (number of u, total charge in 1/3): count",dict(sorted(cnt.items(),reverse=True)))
# 3 次元の影：+e_i → B3[i], −e_i → −B3[i]（立方体の頂点）、高さ＝座標の和
B3=[(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]
sh=lambda v: tuple(v[1]*c for c in B3[v[0]])
print("shadow height vs charge:",[(name[v],sum(sh(v)),q3(v)) for v in V])

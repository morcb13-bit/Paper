# 正十六胞体の読みの残り：反粒子・メソン・レプトンを含む面・世代。整数だけ。
# 基準は走らせる前に固定（A1, M1, M2, L1, G1）。
from itertools import combinations, product
V=[(i,s) for i in range(4) for s in (1,-1)]
C=lambda i: -3 if i==0 else 1
def q(st):                      # st=(i,s,bar)  bar=0 粒子, 1 反粒子（c の符号を反転）
    i,s,b=st; c=C(i)*(-1 if b else 1); assert (3*s+c)%2==0; return (3*s+c)//2
def nm(st):
    i,s,b=st
    if i==0: n={(1,0):'ν',(-1,0):'e',(1,1):'ē',(-1,1):'ν̄'}[(s,b)]
    else:
        n={(1,0):'u',(-1,0):'d',(1,1):'d̄',(-1,1):'ū'}[(s,b)]+'rgb'[i-1]
    return n
S=[(i,s,b) for i,s in V for b in (0,1)]
print("A1 16 seats:",{nm(x):q(x) for x in S})
adj=lambda a,b: a[0]!=b[0]
# M1/M2: q q̄
same=[];edge=[]
for a in S:
    for b in S:
        if a[2]==0 and b[2]==1 and a[0]>0 and b[0]>0:
            kind='same-vertex' if a[:2]==b[:2] else ('antipode' if a[0]==b[0] else 'edge')
            (same if a[0]==b[0] else edge).append((nm(a)+nm(b),kind,q(a)+q(b)))
print("M1 singlet q-qbar kinds:",sorted(set(k for _,k,_ in same)),"| non-singlet kinds:",sorted(set(k for _,k,_ in edge)))
print("M2 singlet mesons (axis r):",[(n,k,c) for n,k,c in same if n.endswith('r') and 'r' in n[:3]])
# L1: 32 triangles + 16 cells, particles only
tri=[t for t in combinations(V,3) if all(adj(a,b) for a,b in combinations(t,2))]
cells=[tuple((i,s[i]) for i in range(4)) for s in product((1,-1),repeat=4)]
bad=0; tab={}
for t in tri+cells:
    singlet = sorted(v[0] for v in t if v[0]>0)==[1,2,3]
    ch=sum(q((i,s,0)) for i,s in t); integer=(ch%3==0)
    tab[(len(t),singlet,integer)]=tab.get((len(t),singlet,integer),0)+1
    bad+= singlet!=integer
print("L1 (size, color-singlet, integer charge): count",tab," mismatches",bad)
# G1: 16-cells inside 24-cell and tesseract (coordinates doubled to stay integer)
def frames(P):
    P=set(P); ax=[p for p in P if p>tuple(-x for x in p)]   # one of each ± pair
    dot=lambda a,b: sum(x*y for x,y in zip(a,b))
    fs=[f for f in combinations(ax,4) if all(dot(a,b)==0 for a,b in combinations(f,2)) and all(tuple(-x for x in a) in P for a in f)]
    return fs
e=[tuple(2 if j==i else 0 for j in range(4)) for i in range(4)]
c16=e+[tuple(-x for x in v) for v in e]
tes=list(product((1,-1),repeat=4))
c24=c16+tes
for name,P in (("24-cell",c24),("tesseract (control)",tes)):
    fs=frames(P); used=[v for f in fs for v in f]
    print("G1",name,": vertices",len(P)," inscribed 16-cells",len(fs)," disjoint" if len(used)==len(set(used)) else " overlap")

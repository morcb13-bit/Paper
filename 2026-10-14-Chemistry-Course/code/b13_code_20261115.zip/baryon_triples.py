# 3 段・星型ギャスケットの頂点から、3 色（3 回軸のまわりの 3 方向）を一つずつ取った三点組を数える。
# 色 = 3 つの座標のうち、ほかの二つと違う一つの位置（x, y, z）。三つとも等しい点・三つとも違う点は色なし。
# 高さ = 座標の和（角 3 を電荷 +1 とする 1/3 単位）。u = 高さ +2、d = 高さ −1。
# 基準（走らせる前に決めた）：
#   B1 陽子 (2,2,−1) と中性子 (2,−1,−1) の三点組が、小さな正四面体（3 段の部品）の面になっているものがあるか
#   B2 その面で、d が真ん中・u が鏡対称（u の二色を入れ替える鏡映で d が動かない）になっているか
#   対照：Δ⁺⁺ (2,2,2)、Δ⁻ (−1,−1,−1)、反陽子側 (−2,−2,1) で同じ数を出す
from fractions import Fraction as F
from itertools import combinations, product
A=[(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]
def gasket(T,k):
    if k==1: return [T]
    out=[]
    for i in range(4):
        out+=gasket([T[i]]+[tuple((a+b)/2 for a,b in zip(T[i],T[j])) for j in range(4) if j!=i],k-1)
    return out
TA=gasket([tuple(F(c) for c in p) for p in A],3)
TB=gasket([tuple(F(-c) for c in p) for p in A],3)
tets=[(t,'A') for t in TA]+[(t,'B') for t in TB]
V={v for t,_ in tets for v in t}
h=lambda v: sum(v)
def color(v):
    for i in range(3):
        o=[v[j] for j in range(3) if j!=i]
        if o[0]==o[1] and v[i]!=o[0]: return i
    return None
faces={}
for t,side in tets:
    for f in combinations(t,3): faces.setdefault(frozenset(f),set()).add(side)
def d2(p,q): return sum((a-b)**2 for a,b in zip(p,q))
def swap(v,i,j):
    w=list(v); w[i],w[j]=w[j],w[i]; return tuple(w)
patterns={"proton (2,2,-1)":(2,2,-1),"neutron (2,-1,-1)":(2,-1,-1),"Delta++ (2,2,2)":(2,2,2),"Delta- (-1,-1,-1)":(-1,-1,-1),
          "antiproton (-2,-2,1)":(-2,-2,1),"antineutron (-2,1,1)":(-2,1,1)}
byc={}
for v in V:
    c=color(v)
    if c is not None: byc.setdefault((h(v),c),[]).append(v)
print("colored points per height:",{k:len(x) for k,x in sorted(byc.items())})
for name,pat in patterns.items():
    total=face=equi=mirror_face=0; examples=[]
    for cols in product(range(3),repeat=3):
        if len(set(cols))<3: continue
        hs=list(pat)
        # 高さの並べ方を色に割り当てる（重複を避けるため、色 0,1,2 の順に高さの順列を一回ずつ）
        pass
    seen=set()
    for perm in set(__import__('itertools').permutations(pat)):
        lists=[byc.get((perm[c],c),[]) for c in range(3)]
        for trip in product(*lists):
            key=frozenset(trip)
            if key in seen: continue
            seen.add(key); total+=1
            ds=[d2(trip[0],trip[1]),d2(trip[1],trip[2]),d2(trip[0],trip[2])]
            if ds[0]==ds[1]==ds[2]: equi+=1
            if key in faces:
                face+=1
                # 鏡対称：高さが同じ二点（u,u または d,d）の色を入れ替える鏡映で、残る一点が動かず二点が入れ替わる
                pts=list(trip); hh=[h(p) for p in pts]
                for a,b in combinations(range(3),2):
                    if hh[a]==hh[b]:
                        c3=3-a-b; i,j=color(pts[a]),color(pts[b])
                        if swap(pts[a],i,j)==pts[b] and swap(pts[c3],i,j)==pts[c3]:
                            mirror_face+=1
                            if len(examples)<2: examples.append((tuple(map(lambda p:tuple(str(x) for x in p),pts)),sorted(faces[key])))
    print(f"{name:22} triples {total:4}  equilateral {equi:3}  gasket faces {face:2}  mirror faces {mirror_face:2}  e.g. {examples[:1]}")

# cell16_bosons.py
# 正十六胞体の 8 頂点（一つの世代）の上で、ボゾンを「頂点から頂点への移り」として数える。
# 整数と加算・比較だけ。電荷は 1/3 単位。
#
# 頂点 (i, s): i=0 レプトン, 1..3 色。s=+1/-1。
# 席: 粒子 c = C[i]、反粒子 -C[i]。電荷 = (3s + c)/2
#
# 事前の基準（走らせる前に固定）
#  W1: 対蹠への移り（同じ軸 + -> -）の電荷の差が、4 軸 x 2 席の 8 通りすべてで 3。
#      対照: 同じ符号の辺への移りで差が 3 になるものは 0 本であること。
#  W2: 同じ符号の辺への移りの電荷の差は、+側(A)と-側(B)で同じ値になる（差が軸だけで決まる）。
#  G1: 色の軸どうしの移り（向きつきの辺 + 動かない移り）が 3+3 で... 向きつき 6 + 留まる 3 = 9、
#      色をすべて同じだけ重む留まりを 1 つ引いて 8。8 にならなければ NG。
#      電荷の差はすべて 0 であること。
#  LQ: レプトンの軸と色の軸を結ぶ同じ符号の辺は、差が 3 の倍数にならない（向きつき 6 本）。
#  P1: 電荷の重みを「留まる移り」の重みとみると、符号の部分 3s と軸の部分 c に分かれ、
#      8 頂点で 3s の和 0、4 軸で c の和 0（どちらも打ち消し合う）。
#      対照: レプトンに c=+1（クオークと同じ）を入れると c の和が 0 にならない。

C = [-3, 1, 1, 1]
NAME = {(0, 1): "nu", (0, -1): "e", (1, 1): "u_r", (2, 1): "u_g", (3, 1): "u_b",
        (1, -1): "d_r", (2, -1): "d_g", (3, -1): "d_b"}
V = [(i, s) for i in range(4) for s in (1, -1)]


def q(v, seat, cc=C):
    i, s = v
    c = cc[i] if seat == 0 else -cc[i]
    t = 3 * s + c
    assert t % 2 == 0
    return t // 2


def kind(a, b):
    if a == b:
        return "stay"
    if a[0] == b[0]:
        return "antipode"
    return "edge_same" if a[1] == b[1] else "edge_cross"


def axes(a, b):
    la, lb = a[0] == 0, b[0] == 0
    if la and lb:
        return "L-L"
    if la or lb:
        return "L-C"
    return "C-C"


ok = {}

# 移りの全表
table = {}
for a in V:
    for b in V:
        for seat in (0, 1):
            k = (kind(a, b), axes(a, b))
            d = q(b, seat) - q(a, seat)
            table.setdefault(k, []).append(d)
print("移りの種類, 軸, 本数(席込み), 差の値")
for k in sorted(table):
    ds = table[k]
    print(k, len(ds), sorted(set(ds)))

# W1
w = [q((i, -1), seat) - q((i, 1), seat) for i in range(4) for seat in (0, 1)]
ctrl = [q(b, seat) - q(a, seat) for a in V for b in V for seat in (0, 1)
        if kind(a, b) == "edge_same" and abs(q(b, seat) - q(a, seat)) == 3]
ok["W1"] = all(x == -3 for x in w) and len(w) == 8 and len(ctrl) == 0
print("W1 対蹠の差", w, "同じ符号の辺で差3の数", len(ctrl))
# 式に c を変えても差が 3 か（式からの自動性の確認）
for cc in ([-3, 1, 1, 1], [1, 1, 1, 1], [5, -1, 7, 3]):
    print("  c =", cc, "対蹠の差", sorted({q((i, -1), 0, cc) - q((i, 1), 0, cc) for i in range(4)}))

# W2
w2 = True
for i in range(4):
    for j in range(4):
        if i != j:
            for seat in (0, 1):
                dA = q((j, 1), seat) - q((i, 1), seat)
                dB = q((j, -1), seat) - q((i, -1), seat)
                w2 &= dA == dB
ok["W2"] = w2
print("W2 A側とB側で差が同じ", w2)

# G1
directed = [(i, j) for i in (1, 2, 3) for j in (1, 2, 3) if i != j]
stays = [(i, i) for i in (1, 2, 3)]
n9 = len(directed) + len(stays)
n8 = n9 - 1
zero = all(q((j, s), seat) - q((i, s), seat) == 0 for (i, j) in directed for s in (1, -1) for seat in (0, 1))
ok["G1"] = len(directed) == 6 and n8 == 8 and zero
print("G1 向きつき", len(directed), "留まり", len(stays), "->", n9, "-1 =", n8, "差0", zero)
# 4 軸に広げると
d4 = [(i, j) for i in range(4) for j in range(4) if i != j]
print("  4 軸: 向きつき", len(d4), "+ 留まり 4 - 1 =", len(d4) + 4 - 1)

# LQ
lq = [(q((j, s), seat) - q((i, s), seat)) for i in range(4) for j in range(4)
      if i != j and (i == 0) != (j == 0) for s in (1, -1) for seat in (0, 1)]
lq_pairs = [(i, j) for i in range(4) for j in range(4) if i != j and (i == 0) != (j == 0)]
ok["LQ"] = len(lq_pairs) == 6 and all(x % 3 != 0 for x in lq)
print("LQ 向きつき", len(lq_pairs), "差の値", sorted(set(lq)))

# P1
s_sum = sum(3 * s for (_, s) in V)
c_sum = sum(C)
c_ctrl = sum([1, 1, 1, 1])
qsum = sum(q(v, 0) for v in V)
ok["P1"] = s_sum == 0 and c_sum == 0 and c_ctrl != 0
print("P1 3sの和", s_sum, "cの和", c_sum, "対照cの和", c_ctrl, "一世代の電荷の和", qsum)

print("判定", ok)

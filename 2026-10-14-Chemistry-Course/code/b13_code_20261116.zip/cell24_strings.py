# cell24_strings.py
# 正四面体の紐が四次元で閉じるか。正二十四胞体（座標 2 倍）と正十六胞体の上で数える。
# 整数と加算・乗算・比較だけ。電荷は 1/3 単位。
#
# 事前の基準（走らせる前に固定）
#  HX1: 実数の成分が +1/2 の単位 u（座標 2 倍で (1,±1,±1,±1)、8 個）それぞれで、
#       C0 の 8 頂点 v に左から u を掛け続ける。
#       全部が 6 歩で閉じ、6 歩すべてが辺（距離の 2 乗 4）、3 歩目が -v（対蹠）なら合格。
#       対照: 実数の成分が -1/2 の u（(-1,±1,±1,±1)、8 個）では 3 歩で閉じ、
#       歩みが辺に乗らない（距離の 2 乗 12）こと。
#  HX2: 紐の上のラベルを「世代の移り＝u を掛ける」で付けたとき（u^k v のラベル = v のラベル、
#       ただし -v は v の対蹠のラベル）、6 歩の電荷の差の並びを数え、
#       3 歩ごとに ±3 がちょうど 1 回入ること。
#       注: ラベルの付け方から、差が出るのは 3 歩目と 6 歩目だけになる（定義からの帰結）。
#  HX3: 正十六胞体の 16 個の胞（各軸から一つずつ選んだ 4 頂点）を、
#       「続く 4 頂点がいつも胞になる」頂点の列（面を共有する紐）としてたどる。
#       (a) 閉じる紐の長さがすべて 8 胞、(b) 16 胞を共有なしの 2 本に分ける分け方が 1 つ以上ある。
#       (c) 参考: その 8 頂点の列が、24 個の単位のどれか一つを左（または右）から掛け続けて作れるか。

from itertools import product, permutations


def qmul(p, q):
    a1, b1, c1, d1 = p
    a2, b2, c2, d2 = q
    return (a1 * a2 - b1 * b2 - c1 * c2 - d1 * d2,
            a1 * b2 + b1 * a2 + c1 * d2 - d1 * c2,
            a1 * c2 - b1 * d2 + c1 * a2 + d1 * b2,
            a1 * d2 + b1 * c2 - c1 * b2 + d1 * a2)


def mul2(p, q):
    r = qmul(p, q)
    assert all(x % 2 == 0 for x in r)
    return tuple(x // 2 for x in r)


def neg(p):
    return tuple(-x for x in p)


def d2(a, b):
    return sum((x - y) * (x - y) for x, y in zip(a, b))


E2 = [tuple(2 if k == i else 0 for k in range(4)) for i in range(4)]
C0 = E2 + [neg(p) for p in E2]
HALF = list(product((1, -1), repeat=4))
U24 = C0 + HALF
ONE = (2, 0, 0, 0)

# ---------- HX1
def orbit(u, v):
    path = [v]
    x = mul2(u, v)
    while x != v:
        path.append(x)
        x = mul2(u, x)
        assert len(path) < 50
    return path


def check(us):
    lens, dists, third = set(), set(), True
    for u in us:
        for v in C0:
            p = orbit(u, v)
            lens.add(len(p))
            for k in range(len(p)):
                dists.add(d2(p[k], p[(k + 1) % len(p)]))
            if len(p) == 6:
                third &= p[3] == neg(v)
    return lens, dists, third


plus = [h for h in HALF if h[0] == 1]
minus = [h for h in HALF if h[0] == -1]
lp, dp, tp = check(plus)
lm, dm, _ = check(minus)
hx1 = lp == {6} and dp == {4} and tp and lm == {3} and dm == {12}
print("HX1 +1/2: 歩数", lp, "距離の2乗", dp, "3歩目が対蹠", tp)
print("    対照 -1/2: 歩数", lm, "距離の2乗", dm)
# 紐が通る正十六胞体の順
def cell_of(p):
    if p in C0:
        return 0
    return 1 if sum(1 for x in p if x < 0) % 2 == 0 else 2
print("    通る正十六胞体の順（u=(1,1,1,1), v=1）", [cell_of(p) for p in orbit((1, 1, 1, 1), ONE)])

# ---------- HX2
C = [-3, 1, 1, 1]
def charge(v, seat):
    i = next(k for k in range(4) if v[k] != 0)
    s = 1 if v[i] > 0 else -1
    c = C[i] if seat == 0 else -C[i]
    return (3 * s + c) // 2

hx2 = True
seq_example = None
for u in plus:
    for v in C0:
        for seat in (0, 1):
            labels = [v, v, v, neg(v), neg(v), neg(v)]
            qs = [charge(x, seat) for x in labels]
            ds = [qs[(k + 1) % 6] - qs[k] for k in range(6)]
            hx2 &= sum(1 for x in ds[0:3] if abs(x) == 3) == 1
            hx2 &= sum(1 for x in ds[3:6] if abs(x) == 3) == 1
            hx2 &= all(x == 0 or abs(x) == 3 for x in ds)
            if u == (1, 1, 1, 1) and v == (0, 2, 0, 0) and seat == 0:
                seq_example = (qs, ds)
print("HX2 合格", hx2, " 例 u赤から: 電荷", seq_example[0], "差", seq_example[1])

# ---------- HX3 正十六胞体の胞の紐
V16 = C0
def axis(p):
    return next(k for k in range(4) if p[k] != 0)

cells = [frozenset(p) for p in product(*[(E2[i], neg(E2[i])) for i in range(4)])]
assert len(cells) == 16

rings = set()
ring_seqs = {}
for start in V16:
    def walk(seq):
        if len(seq) >= 4 and len({axis(p) for p in seq[-4:]}) != 4:
            return
        if len(seq) > 4 and seq[-1] == seq[0] and len(seq) - 1 >= 4:
            # 閉じたか: 先頭の 3 つと続きが合うか確かめる
            core = seq[:-1]
            n = len(core)
            if all(len({axis(core[(k + t) % n]) for t in range(4)}) == 4 for k in range(n)):
                cs = frozenset(frozenset(core[(k + t) % n] for t in range(4)) for k in range(n))
                if len(cs) == n:
                    rings.add(cs)
                    ring_seqs[cs] = core
            return
        if len(seq) > 16:
            return
        for p in V16:
            if p in seq[1:]:
                continue
            if p in seq[-3:]:
                continue
            walk(seq + [p])
    walk([start])

lens = sorted({len(r) for r in rings})
parts = 0
rl = list(rings)
for a in range(len(rl)):
    for b in range(a + 1, len(rl)):
        if not (rl[a] & rl[b]) and len(rl[a] | rl[b]) == 16:
            parts += 1
print("HX3 閉じる紐の数", len(rings), "長さ(胞の数)", lens, " 16胞を2本に分ける分け方", parts)

# (c) 一つの単位を掛け続けて作れるか
gen_L = gen_R = 0
for cs, core in ring_seqs.items():
    n = len(core)
    for u in U24:
        if all(mul2(u, core[k]) == core[(k + 1) % n] for k in range(n)):
            gen_L += 1
        if all(mul2(core[k], u) == core[(k + 1) % n] for k in range(n)):
            gen_R += 1
print("    (c) 一つの単位を左から掛けて作れる紐", gen_L, " 右から", gen_R)
ex = ring_seqs[rl[0]]
print("    紐の例（頂点の列）", ex)

print("判定", {"HX1": hx1, "HX2": hx2, "HX3a": lens == [8], "HX3b": parts > 0})

# cell24_generations.py
# 正二十四胞体（座標 2 倍）の 3 つの正十六胞体に三つの世代を置き、軸の割り当てを数える。
# 整数と加算・比較だけ。
#
# C0 = {±2e_i}、C1 = (±1)^4 で - が偶数個、C2 = - が奇数個。
# 正二十四胞体の辺 = 距離の 2 乗 4。
# 世代 1 のラベル L0: 2e_i に (i,+)、-2e_i に (i,-)。i=0 レプトン。
# ラベル付け = 8 頂点への (軸, 符号) の割り当てで、対蹠が同じ軸・逆符号になるもの（各 384 通り）。
#
# 事前の基準（走らせる前に固定）
#  T1: 同じラベルの 3 点（世代 1,2,3）が 8 ラベルすべてで正二十四胞体の三角形になる
#      (L1, L2) の数 N を数える。N > 0 でなければ NG。
#  T2: その解の中で、C1 と C2 のレプトンの軸が一つに決まるか。決まれば合格、
#      決まらなければ何通りかを書く。
#  T3: 色の入れ替え（3! = 6）で写り合うものを同じとみなした数。
#  対照: 384 x 384 通りのラベル付けのうち T1 を満たす割合（でたらめに置いたときの基準）。
#        と、三角形の代わりに「距離の 2 乗 8」を要求したときの数。

from itertools import permutations, product


def d2(a, b):
    return sum((x - y) * (x - y) for x, y in zip(a, b))


def neg(a):
    return tuple(-x for x in a)


C0 = [tuple(2 if k == i else 0 for k in range(4)) for i in range(4)]
C0 = C0 + [neg(p) for p in C0]
H = [p for p in product((1, -1), repeat=4)]
C1 = [p for p in H if sum(1 for x in p if x < 0) % 2 == 0]
C2 = [p for p in H if sum(1 for x in p if x < 0) % 2 == 1]
assert len(C1) == 8 and len(C2) == 8


def axes_of(cell):
    out = []
    for p in cell:
        if neg(p) not in out and p not in out:
            out.append(p)
    return out  # 4 本の軸の代表


def labelings(cell):
    # ラベル -> 頂点 の辞書を返す（384 通り）
    reps = axes_of(cell)
    res = []
    for perm in permutations(range(4)):
        for signs in product((1, -1), repeat=4):
            lab = {}
            for i in range(4):
                p = reps[perm[i]]
                if signs[i] < 0:
                    p = neg(p)
                lab[(i, 1)] = p
                lab[(i, -1)] = neg(p)
            res.append(lab)
    return res


L0 = {(i, 1): C0[i] for i in range(4)}
L0.update({(i, -1): C0[i + 4] for i in range(4)})
LAB = list(L0.keys())
LS1 = labelings(C1)
LS2 = labelings(C2)
print("ラベル付けの数", len(LS1), len(LS2))


def count(target):
    sols = []
    for a in LS1:
        if not all(d2(L0[l], a[l]) == target for l in LAB):
            continue
        for b in LS2:
            if all(d2(a[l], b[l]) == target and d2(b[l], L0[l]) == target for l in LAB):
                sols.append((a, b))
    return sols


sols = count(4)
N = len(sols)
print("T1 三角形になる (L1,L2) の数", N, "/", len(LS1) * len(LS2))

lep = sorted({(a[(0, 1)], b[(0, 1)]) for a, b in sols})
print("T2 (C1 の nu, C2 の nu) の組", len(lep))
for x in lep:
    print("   ", x)

# T3（取り下げ）: L0 を固定したままでは色の入れ替えは対称にならないため数えない。
from collections import Counter
print("T2 内訳 (nu の組ごとの解の数)", sorted(set(Counter((a[(0, 1)], b[(0, 1)]) for a, b in sols).values())))

# 片側だけ（世代 1 -> 世代 2）のとき
one = [a for a in LS1 if all(d2(L0[l], a[l]) == 4 for l in LAB)]
print("参考 世代1と世代2だけ: 数", len(one), "C1 の nu の置き場所", len({a[(0, 1)] for a in one}))

# 対照
ctrl = count(8)
print("対照 距離の2乗8を要求", len(ctrl))

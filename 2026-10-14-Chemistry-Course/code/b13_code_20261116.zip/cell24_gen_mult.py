# cell24_gen_mult.py
# 世代の回し方を「一つの四元数を掛けるだけ」に絞ると、レプトンの軸が決まるか。
# 整数と加算・乗算・比較だけ。座標は 2 倍（C0 = ±2e_i、C1・C2 = (±1)^4）。
#
# 事前の基準（走らせる前に固定）
#  GM1: cell24_generations の T1 の 168 解のうち、
#       L1 = u1 * L0, L2 = u2 * L1（左から、各段で一つの単位 u を全頂点に掛ける）で書けるものを数え、
#       (C1 の nu, C2 の nu) の組の数を出す。1 なら「回し方が一つに決まる」で合格、
#       2 以上なら数を書いて NG。
#  GM2: 同じことを右から（L1 = L0 * u1, L2 = L1 * u2）で数える。
#  GM3: 左の解と右の解がラベル付けとして一致するか（世代の移りに左右の区別があるか）。
#  対照: 左右どちらでも書けない解の数（168 - 左 - 右 + 両方）が 0 でないこと
#        （掛け算の条件が T1 より狭いこと）。

from itertools import product
import cell24_generations as g


def qmul(p, q):
    a1, b1, c1, d1 = p
    a2, b2, c2, d2 = q
    return (a1 * a2 - b1 * b2 - c1 * c2 - d1 * d2,
            a1 * b2 + b1 * a2 + c1 * d2 - d1 * c2,
            a1 * c2 - b1 * d2 + c1 * a2 + d1 * b2,
            a1 * d2 + b1 * c2 - c1 * b2 + d1 * a2)


def mul2(p, q):
    # 2 倍座標どうしの積を 2 倍座標で返す
    r = qmul(p, q)
    assert all(x % 2 == 0 for x in r)
    return tuple(x // 2 for x in r)


U = [tuple(2 * x for x in e) for e in
     [tuple(1 if k == i else 0 for k in range(4)) for i in range(4)]]
U = U + [tuple(-x for x in p) for p in U] + list(product((1, -1), repeat=4))  # 24 個


def single(src, dst, side):
    # dst のラベル付けが src に一つの u を掛けたものか
    for u in U:
        if all((mul2(u, src[l]) if side == "L" else mul2(src[l], u)) == dst[l] for l in g.LAB):
            return u
    return None


left, right, both = [], [], 0
for a, b in g.sols:
    uL1, uL2 = single(g.L0, a, "L"), single(a, b, "L")
    uR1, uR2 = single(g.L0, a, "R"), single(a, b, "R")
    isL = uL1 is not None and uL2 is not None
    isR = uR1 is not None and uR2 is not None
    if isL:
        left.append((a, b, uL1, uL2))
    if isR:
        right.append((a, b, uR1, uR2))
    if isL and isR:
        both += 1

def nu_pairs(ss):
    return sorted({(a[(0, 1)], b[(0, 1)]) for a, b, _, _ in ss})

print("GM1 左から: 解", len(left), " (nu1, nu2) の組", len(nu_pairs(left)))
for a, b, u1, u2 in left:
    print("    u1", u1, "u2", u2, "nu1", a[(0, 1)], "nu2", b[(0, 1)])
print("GM2 右から: 解", len(right), " (nu1, nu2) の組", len(nu_pairs(right)))
for a, b, u1, u2 in right:
    print("    u1", u1, "u2", u2, "nu1", a[(0, 1)], "nu2", b[(0, 1)])

key = lambda a, b: tuple((a[l], b[l]) for l in g.LAB)
same = {key(a, b) for a, b, _, _ in left} & {key(a, b) for a, b, _, _ in right}
print("GM3 左右で一致する解", len(same), " 両方で書ける解", both)
print("対照 どちらでも書けない解", len(g.sols) - len(left) - len(right) + both, "/", len(g.sols))

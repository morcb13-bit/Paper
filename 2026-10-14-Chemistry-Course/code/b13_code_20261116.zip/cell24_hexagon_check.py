# 6 歩の紐が四次元で正六角形か（整数と加算だけ）
# 正六角形（中心が原点）の条件: 辺 d2=4、一つ飛び d2=12、向かい d2=16、o[k+1] = o[k] + o[k+2]
from itertools import product
def qm(p, r):
    return (p[0]*r[0]-p[1]*r[1]-p[2]*r[2]-p[3]*r[3], p[0]*r[1]+p[1]*r[0]+p[2]*r[3]-p[3]*r[2],
            p[0]*r[2]-p[1]*r[3]+p[2]*r[0]+p[3]*r[1], p[0]*r[3]+p[1]*r[2]-p[2]*r[1]+p[3]*r[0])
mul2 = lambda p, r: tuple(x // 2 for x in qm(p, r))
d2 = lambda a, b: sum((x - y) ** 2 for x, y in zip(a, b))
add = lambda a, b: tuple(x + y for x, y in zip(a, b))
E = [tuple(s * (2 if k == i else 0) for k in range(4)) for i in range(4) for s in (1, -1)]
H = list(product((1, -1), repeat=4))
P = E + H
def orbit(u, v):
    o = [v]; x = mul2(u, v)
    while x != v: o.append(x); x = mul2(u, x)
    return o
hexes, ok = set(), True
for u in [h for h in H if h[0] == 1]:
    for v in E:
        o = orbit(u, v); n = len(o)
        ok &= n == 6
        ok &= all(d2(o[k], o[(k+1) % 6]) == 4 and d2(o[k], o[(k+2) % 6]) == 12 and d2(o[k], o[(k+3) % 6]) == 16 for k in range(6))
        ok &= all(o[(k+1) % 6] == add(o[k], o[(k+2) % 6]) for k in range(6))
        hexes.add(frozenset(o))
# 正二十四胞体のすべての正六角形（中心が原点、辺 d2=4、条件 b = a + c で 6 点を作る）
allhex = set()
for a in P:
    for b in P:
        if d2(a, b) != 4: continue
        c = tuple(y - x for x, y in zip(a, b))  # c = b - a
        if c not in P or d2(b, c) != 4: continue
        o = [a, b, c, tuple(-x for x in a), tuple(-x for x in b), tuple(-x for x in c)]
        if all(d2(o[k], o[(k+1) % 6]) == 4 for k in range(6)):
            allhex.add(frozenset(o))
print("8 個の u × 8 頂点の紐がすべて正六角形", ok)
print("紐が作る正六角形の数", len(hexes))
print("正二十四胞体の中の正六角形の総数", len(allhex))
print("紐の正六角形は三つの正十六胞体から 2 点ずつ",
      all(sorted([0 if max(map(abs, p)) == 2 else (1 if sum(x < 0 for x in p) % 2 == 0 else 2) for p in h]) == [0, 0, 1, 1, 2, 2] for h in hexes))

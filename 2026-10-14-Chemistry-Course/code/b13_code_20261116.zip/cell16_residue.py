# cell16_residue.py
# フィボナッチの残渣（二次元）と、四元数の左右の差（四次元）を数える。
# 整数と加算・乗算（くり返しの加算）・比較だけ。電荷は 1/3 単位。
#
# 事前の基準（走らせる前に固定）
#  R1: F1=F2=1 の組 (F(n+1), F(n)) の残渣 F(n+1)^2 - F(n+1)F(n) - F(n)^2 が
#      n=1..100 で -1, +1 と交互（n 奇数で -1、偶数で +1）。
#      対照: リュカ数 L0=2, L1=1 の組 (L(n+1), L(n)) では残渣が ±5 で交互。
#  R2: 正十六胞体の 8 頂点（±1, ±i, ±j, ±k）と掛ける数 m（同じ 8 個）で、
#      左 m*v と右 v*m が「等しい」か「符号だけ違う」のどちらかに必ずなる。
#      対照: 正二十四胞体の 24 頂点（単位フルヴィッツ四元数）では、
#      等しくも符号違いでもない組が出る（符号だけで書けるのは十六胞体の性質であること）。
#      可換の対照: 複素数 ±1, ±i では符号違いが 0。
#  R3: 左の移り v -> m*v と右の移り v -> v*m の電荷の差 dL, dR を 2 席で数える。
#      (a) dL != dR となる組が 1 つ以上ある（左右で分かれる）。
#      (b) 分かれたときの dL - dR はすべて ±3（＝対蹠への移り＝W の差）。
#      どちらかが崩れたら NG。

# ---------- R1
def residue(a, b):
    return a * a - a * b - b * b

r1 = True
f0, f1 = 1, 1  # F1, F2
fib = []
for n in range(1, 101):
    r = residue(f1, f0)  # (F(n+1), F(n))
    fib.append(r)
    r1 &= r == (-1 if n % 2 == 1 else 1)
    f0, f1 = f1, f0 + f1
l0, l1 = 2, 1
luc = []
for n in range(0, 100):
    luc.append(residue(l1, l0))
    l0, l1 = l1, l0 + l1
luc_ok = all(abs(x) == 5 for x in luc) and all(luc[k] == -luc[k + 1] for k in range(99))
print("R1 フィボナッチ 最初の 6 つ", fib[:6], "交互", r1)
print("   リュカ 最初の 6 つ", luc[:6], "±5 で交互", luc_ok)

# ---------- 四元数（成分 (1, i, j, k)、整数）
def qmul(p, q):
    a1, b1, c1, d1 = p
    a2, b2, c2, d2 = q
    return (a1 * a2 - b1 * b2 - c1 * c2 - d1 * d2,
            a1 * b2 + b1 * a2 + c1 * d2 - d1 * c2,
            a1 * c2 - b1 * d2 + c1 * a2 + d1 * b2,
            a1 * d2 + b1 * c2 - c1 * b2 + d1 * a2)

def neg(p):
    return tuple(-x for x in p)

E = [tuple(1 if k == i else 0 for k in range(4)) for i in range(4)]
Q8 = E + [neg(e) for e in E]

def compare(points):
    eq = sg = other = 0
    for m in points:
        for v in points:
            L, R = qmul(m, v), qmul(v, m)
            if L == R:
                eq += 1
            elif L == neg(R):
                sg += 1
            else:
                other += 1
    return eq, sg, other

eq, sg, ot = compare(Q8)
# 正二十四胞体: 座標 2 倍 (±2e_i と (±1,±1,±1,±1))。積は 4 倍で比べる
from itertools import product
H24 = [tuple(2 * x for x in p) for p in Q8] + list(product((1, -1), repeat=4))
e24, s24, o24 = compare(H24)
C4 = [(1, 0, 0, 0), (-1, 0, 0, 0), (0, 1, 0, 0), (0, -1, 0, 0)]
ec, sc, oc = compare(C4)
r2 = ot == 0 and sg > 0 and o24 > 0 and sc == 0
print("R2 十六胞体 (等しい, 符号違い, それ以外) =", (eq, sg, ot))
print("   対照 二十四胞体 =", (e24, s24, o24), " 可換 ±1,±i =", (ec, sc, oc))

# ---------- R3 電荷
C = [-3, 1, 1, 1]

def vert(p):
    for i in range(4):
        if p[i] != 0:
            return i, p[i]

def charge(p, seat):
    i, s = vert(p)
    c = C[i] if seat == 0 else -C[i]
    t = 3 * s + c
    assert t % 2 == 0
    return t // 2

split = 0
diffs = []
by_m = {}
for m in Q8:
    for v in Q8:
        for seat in (0, 1):
            dL = charge(qmul(m, v), seat) - charge(v, seat)
            dR = charge(qmul(v, m), seat) - charge(v, seat)
            if dL != dR:
                split += 1
                diffs.append(dL - dR)
                by_m[vert(m)] = by_m.get(vert(m), 0) + 1
r3a = split > 0
r3b = all(abs(x) == 3 for x in diffs)
print("R3 左右で分かれた組", split, "/", 8 * 8 * 2, " dL-dR の値", sorted(set(diffs)))
print("   掛ける数ごと (軸, 符号): 分かれた数", dict(sorted(by_m.items())))

print("判定", {"R1": r1 and luc_ok, "R2": r2, "R3a": r3a, "R3b": r3b})

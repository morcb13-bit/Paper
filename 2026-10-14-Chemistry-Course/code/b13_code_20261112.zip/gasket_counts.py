# 正四面体のギャスケット k 段：正四面体・頂点・つなぎ目・空いた角・外側の面の上の頂点・内側の頂点・穴・自由度を整数で数える
from itertools import combinations
from collections import Counter
C=[(0,0,0),(2,2,0),(2,0,2),(0,2,2)]
def sub(k,T):
    if k==1: return [T]
    out=[]
    for i in range(4):
        t=[tuple(2*x for x in T[i])]+[tuple(a+b for a,b in zip(T[i],T[j])) for j in range(4) if j!=i]
        out+=sub(k-1,t)
    return out
for k in (1,2,3,4,5,6):
    tets=sub(k,C); V=set(v for t in tets for v in t)
    big=[tuple(c*2**(k-1) for c in p) for p in C]
    def onface(v):
        for f in combinations(range(4),3):
            a,b,c=[big[i] for i in f]
            u=[b[i]-a[i] for i in range(3)]; w=[c[i]-a[i] for i in range(3)]
            n=(u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0])
            if sum(n[i]*(v[i]-a[i]) for i in range(3))==0: return True
        return False
    share=Counter(v for t in tets for v in t)
    joints=sum(1 for v in V if share[v]==2); corners=sum(1 for v in V if share[v]==1)
    surf=sum(onface(v) for v in V)
    print(f"{k} levels: tets {len(tets)} vertices {len(V)} joints {joints} corners {corners} max_share {max(share.values())} "
          f"on_surface {surf} interior {len(V)-surf} holes {(4**(k-1)-1)//3} dof {6*len(tets)-3*joints-6}")

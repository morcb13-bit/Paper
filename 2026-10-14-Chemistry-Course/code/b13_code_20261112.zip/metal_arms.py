# 腕の数 = 片方だけ座っている席の数。席が S 個（S/2 か所 × 表と裏）、価電子 v 個（族の番号）なら
#   腕(v) = v (v <= S/2)、S - v (v > S/2)
# 規則 12：席 12（星型 2 段で A と B が共有する中点 6 か所 × 2）。対照：席 10、席 14。
# 判定：同じ周期の中の 2 元素の組で、腕の多い方が融点も高い組（一致）と逆の組（不一致）を整数で数える。
from mendeleev import element
rows={4:range(21,31),5:range(39,49),6:[71]+list(range(72,81))}
def arms(v,S): return v if 2*v<=S else max(S-v,0)
for prop in ("melting_point","boiling_point"):
    print("==",prop)
    for S in (12,10,14):
        c=d=t=0
        for p,zs in rows.items():
            vals=[(g,int(round(getattr(element(z),prop)))) for g,z in zip(range(3,13),zs)]
            for i in range(len(vals)):
                for j in range(i+1,len(vals)):
                    a,b=arms(vals[i][0],S),arms(vals[j][0],S)
                    if a==b: t+=1; continue
                    same=(a>b)==(vals[i][1]>vals[j][1])
                    c+=same; d+=not same
        print(f"   seats {S}: concordant {c}  discordant {d}  ties {t}")

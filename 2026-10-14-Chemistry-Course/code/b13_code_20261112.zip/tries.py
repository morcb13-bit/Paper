# ダメ元の試し三つ。判定は a+bφ の整数比較と整数の掛け算だけ。
# T1 図の殻：へ の角は、内に置く版（Cin）はすべて結合の中点より内、外に置く版（Cout）はすべて外か
# T2 境目：図から出る比 R が「金だけ切り替わる窓」 12528/18769 < R < 16560/18769 に入るか
#          （窓の幅は [0,1] の約 21%。候補ごとの偶然の当たりはその程度）
# T3 縮みの順：第5→第6周期の半径の比 r6/r5 が、族が右へ進む（Z が大きくなる）ほど小さくなるか。
#          対照：第4→第5周期で同じ並びを数える
import json
import periodictable as pt

D = json.load(open("fullerene_v.json"))

# ---- a+bφ の整数演算 ----
def mul(x, y):
    a, b = x; c, d = y
    return (a * c + b * d, a * d + b * c + b * d)      # φ² = φ + 1
def add(x, y): return (x[0] + y[0], x[1] + y[1])
def sub(x, y): return (x[0] - y[0], x[1] - y[1])
def sign(x):
    p, q = x                                           # p + qφ = ((2p+q) + q√5)/2
    u, v = 2 * p + q, q
    if v == 0: return (u > 0) - (u < 0)
    if u >= 0 and v >= 0: return 1 if (u or v) else 0
    if u <= 0 and v <= 0: return -1
    l, r = u * u, 5 * v * v
    if u > 0: return (l > r) - (l < r)
    return (r > l) - (r < l)
def sq(v):
    t = (0, 0)
    for c in v: t = add(t, mul(tuple(c), tuple(c)))
    return t
def scale(k, x): return (k * x[0], k * x[1])

A = [[tuple(c) for c in p] for p in D["A"]]
Cin = [[tuple(c) for c in p] for p in D["Cin"]]
Cout = [[tuple(c) for c in p] for p in D["Cout"]]

print("== T1")
rA = {sq(p) for p in A}
mids4 = []        # |2·中点|² = 4|中点|²
for (x, y) in D["B"]:
    m2 = [add(A[x][i], A[y][i]) for i in range(3)]
    mids4.append(sq(m2))
inside = sum(sign(sub(m, scale(4, sq(c)))) > 0 for m, c in zip(mids4, Cin))
outside = sum(sign(sub(scale(4, sq(c)), m)) > 0 for m, c in zip(mids4, Cout))
print(" |A|^2 distinct:", rA)
print(" |Cin|^2 distinct:", {sq(c) for c in Cin})
print(" |Cout|^2 distinct:", {sq(c) for c in Cout})
print(" 4|mid|^2 distinct:", set(mids4))
print(f" Cin inside mid: {inside}/90   Cout outside mid: {outside}/90")

print("== T2 window 12528/18769 < R < 16560/18769")
a2 = next(iter(rA))
cands = {
    "|Cin|^2/|A|^2":  [(sq(c), a2) for c in Cin],
    "|A|^2/|Cout|^2": [(a2, sq(c)) for c in Cout],
    "|Cin|^2/|Cout|^2": [(sq(c), sq(o)) for c, o in zip(Cin, Cout)],
    "4|mid|^2/4|A|^2": [(m, scale(4, a2)) for m in mids4],
    "|Cin|^2/|mid|^2": [(scale(4, sq(c)), m) for c, m in zip(Cin, mids4)],
    "|mid|^2/|Cout|^2": [(m, scale(4, sq(o))) for m, o in zip(mids4, Cout)],
}
for name, pairs in cands.items():
    distinct = sorted(set(pairs))
    hits = []
    for X, Y in distinct:
        lo = sign(sub(scale(18769, X), scale(12528, Y))) > 0
        hi = sign(sub(scale(16560, Y), scale(18769, X))) > 0
        hits.append((X, Y, lo and hi))
    print(f" {name}: " + "; ".join(f"{X}/{Y} in:{h}" for X, Y, h in hits))

print("== T3")
def r(z): s = f"{pt.elements[z].covalent_radius:.2f}"; a, b = s.split("."); return int(a) * 100 + int(b)
P4 = {g: 18 + g for g in range(3, 13)}
P5 = {g: 36 + g for g in range(3, 13)}
P6 = {3: 71, **{g: 68 + g for g in range(4, 13)}}     # 6 周期の 3 族は Lu
def concord(Pa, Pb):
    gs = list(range(3, 13)); c = d = 0
    for i in range(len(gs)):
        for j in range(i + 1, len(gs)):
            g, h = gs[i], gs[j]
            # 右の族の比 rb/ra が小さい（rb_h·ra_g < rb_g·ra_h）なら一致
            L = r(Pb[h]) * r(Pa[g]); R = r(Pb[g]) * r(Pa[h])
            c += L < R; d += L > R
    return c, d
print(" P5->P6 concordant/discordant:", concord(P5, P6))
print(" P4->P5 (control):", concord(P4, P5))
print(" ratios x100 P6/P5:", {g: r(P6[g]) * 100 // r(P5[g]) for g in range(3, 13)})
print(" ratios x100 P5/P4:", {g: r(P5[g]) * 100 // r(P4[g]) for g in range(3, 13)})

# 境目を大きい側から下ろして探す版：s を大きい方から 1 ずつ下げ、
# 2T 周以内に放てなくなった最初の s を境目とする（小さい s では一周 P が s の 4 の倍数になると
# 位相が止まって見える折り返しが起きるため、下から探すと s=1 で止まる）。
from intensity2 import first
def edge_down(P, T, per_lap, mult, smax):
    for s in range(smax, 0, -1):
        if first(P, s * mult, T, per_lap, 2 * T) is None: return s
    return None
for name, L in (("Cu", 4), ("Ag", 8)):
    P = 4 * L; T = 6400 // (L * L)
    print(f"== {name}: P={P} T={T}")
    for n in (1, 2, 4, 8):
        a = edge_down(P, T, 1, 1, 12000)
        b = edge_down(P, T, n, 1, 12000)
        c = edge_down(P, T, 1, n, 12000)
        print(f"   n={n}: edge A {a}  B {b}  C {c}")

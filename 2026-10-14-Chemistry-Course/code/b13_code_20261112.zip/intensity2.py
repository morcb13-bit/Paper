# 境目の基準を「最初に放つまでの周回が 2T 以内（位相がそろって貯まる）」に直した版。
# 1 回でも放てば境目、とした最初の基準は、位相がばらばらでも長く当てれば偶然 T に届くため区別がつかなかった。
from intensity import STEP
def first(P, s, T, per_lap, N):
    re = im = 0
    for j in range(N):
        dx, dy = STEP[(j * P // s) % 4]
        re += per_lap * dx; im += per_lap * dy
        if re * re + im * im >= T * T: return j + 1
    return None
def edge(P, T, per_lap, mult, smax):
    for s in range(1, smax + 1):
        f = first(P, s * mult, T, per_lap, 2 * T)
        if f is not None: return s
    return None
for name, L in (("Cu", 4), ("Ag", 8)):
    P = 4 * L; T = 6400 // (L * L)
    print(f"== {name}: P={P} T={T}")
    for n in (1, 2, 4, 8):
        a = edge(P, T, 1, 1, 20000)      # 穴ごと：1 単位ずつ、閾値 T
        b = edge(P, T, n, 1, 20000)      # 同じ穴に n 単位
        c = edge(P, T, 1, n, 20000)      # 外形を n 倍
        print(f"   n={n}: edge A {a}  B {b}  C {c}")

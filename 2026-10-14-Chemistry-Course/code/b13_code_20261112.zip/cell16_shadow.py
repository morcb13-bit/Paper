# 正十六胞体（±e1..±e4）を (1,1,1,1) 方向に落とした影：頂点・辺の長さ・16 個の胞の影の体積
from itertools import combinations, product
V=[tuple((1 if j==i else 0)*s for j in range(4)) for i in range(4) for s in (1,-1)]
d2=lambda p,q:sum((a-b)**2 for a,b in zip(p,q))
E=[(p,q) for p,q in combinations(V,2) if d2(p,q)==2]
B3=[(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]
sh=lambda v:tuple(sum(v[i]*B3[i][k] for i in range(4)) for k in range(3))
S={v:sh(v) for v in V}
kinds={}
for p,q in E: kinds[d2(S[p],S[q])]=kinds.get(d2(S[p],S[q]),0)+1
def vol6(P):
    a,b,c,d=P; u=[b[i]-a[i] for i in range(3)]; v=[c[i]-a[i] for i in range(3)]; w=[d[i]-a[i] for i in range(3)]
    return abs(u[0]*(v[1]*w[2]-v[2]*w[1])-u[1]*(v[0]*w[2]-v[2]*w[0])+u[2]*(v[0]*w[1]-v[1]*w[0]))
cnt={}
for s in product((1,-1),repeat=4):
    P=[S[tuple(s[i] if j==i else 0 for j in range(4))] for i in range(4)]
    cnt.setdefault(sum(1 for x in s if x>0),[]).append(vol6(P))
print("vertices",len(V),"edges",len(E),"shadow edge len^2:count",kinds)
print("cells by #A vertices -> 6*volume",cnt)

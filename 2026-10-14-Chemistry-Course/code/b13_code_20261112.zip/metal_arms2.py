# 腕の規則（席 12）を別の性質で見る。基準（走らせる前に決めた）：
#   T1 蒸発熱（原子を引きはがす熱）：腕が多いほど大きい → 一致が不一致を上回り、対照（席10・14）より良い
#   T2 原子体積：腕が多いほど小さい（向きを逆にして数える）
#   T3 密度：腕が多いほど大きい
#   山・谷の位置も出す。判定は整数（値は 10 倍して整数化）の比較だけ。
from mendeleev import element
rows={4:range(21,31),5:range(39,49),6:[71]+list(range(72,81))}
def arms(v,S): return v if 2*v<=S else max(S-v,0)
def test(prop,sign):
    print("==",prop,"(more arms -> %s)"%("larger" if sign>0 else "smaller"))
    data={}
    for p,zs in rows.items():
        data[p]=[(g,element(z).symbol,getattr(element(z),prop)) for g,z in zip(range(3,13),zs)]
        ok=[(int(round(v*10)),g,s) for g,s,v in data[p] if v is not None]
        print(f"   P{p}: max {max(ok)[2]}(group {max(ok)[1]})  min {min(ok)[2]}(group {min(ok)[1]})  missing {[s for g,s,v in data[p] if v is None]}")
    for S in (12,10,14):
        c=d=0
        for p in rows:
            vals=[(g,int(round(v*10))) for g,s,v in data[p] if v is not None]
            for i in range(len(vals)):
                for j in range(i+1,len(vals)):
                    a,b=arms(vals[i][0],S),arms(vals[j][0],S)
                    if a==b or vals[i][1]==vals[j][1]: continue
                    same=((a>b)==(vals[i][1]>vals[j][1]))
                    if sign<0: same=not same
                    c+=same; d+=not same
        print(f"   seats {S}: concordant {c}  discordant {d}")
for prop,sign in (("evaporation_heat",1),("fusion_heat",1),("atomic_volume",-1),("density",1)):
    try: test(prop,sign)
    except Exception as e: print(prop,"ERR",e)

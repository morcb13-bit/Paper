# R2 反射（正四面体の4つの面を位相の段にする）と N1 屈折。整数と加算だけ。
# 光のギャスケットは長さ f ごとに一回倒れ、倒れるたびに下の面が次の面へ移る。
# 4 つの面を段 0,1,2,3 とし、段 0:+実 1:+虚 2:-実 3:-虚 として2つの整数に足す。
# 強さ I = 実^2 + 虚^2（整数）。
# 段を2つしか使わない対照（R1' と同じ ±1）は faces=2。
from math import isqrt

def add(acc, n, faces):
    k = n % faces
    if faces == 4:
        if k == 0: acc[0] += 1
        elif k == 1: acc[1] += 1
        elif k == 2: acc[0] -= 1
        else: acc[1] -= 1
    else:
        acc[0] += 1 if k == 0 else -1

def reflect_I(src, det, seats, f, faces):
    acc = [0, 0]
    for x in seats:
        d1 = isqrt((x - src[0])**2 + src[1]**2)
        d2 = isqrt((x - det[0])**2 + det[1]**2)
        add(acc, (d1 + d2) // f, faces)
    return acc[0]**2 + acc[1]**2

def refract_I(src, det, seats, f1, f2, faces):
    # 上（媒質1）では f1 ごと、下（媒質2）では f2 ごとに倒れる
    acc = [0, 0]
    for x in seats:
        d1 = isqrt((x - src[0])**2 + src[1]**2)
        d2 = isqrt((x - det[0])**2 + det[1]**2)
        add(acc, (d1 * f2 + d2 * f1) // (f1 * f2), faces)
    return acc[0]**2 + acc[1]**2

def stationary_X(src, f1, f2, depth, Xs):
    # 境目の座 0 で「倒れる回数」が止まる受け手の位置（整数の比較だけ）
    # 条件：(0-xs)/(d1 f1) = (X-0)/(d2 f2) を掛け算で比べる
    best = None
    d1 = isqrt(src[0]**2 + src[1]**2)
    for X in Xs:
        d2 = isqrt(X * X + depth * depth)
        g = abs((0 - src[0]) * d2 * f2 - X * d1 * f1)
        if best is None or g < best[0]:
            best = (g, X)
    return best[1]

if __name__ == "__main__":
    h = 20000; a = 20000; src = (-a, h)
    # ---- R2 反射 ----
    f = 50                                   # 4 回倒れて一周（一周 200、R1' と同じ）
    mirror = list(range(-10000, 10001, 10))
    Xs = list(range(-40000, 80001, 1000))
    print("== R2 reflect (faces=4 / faces=2, f=50 and s=100 for 2 faces)")
    for faces, ff in ((4, 50), (2, 100)):
        res = [(X, reflect_I(src, (X, h), mirror, ff, faces)) for X in Xs]
        inb = [I for X, I in res if 2000 <= X <= 38000]
        out = [I for X, I in res if X <= -3000 or X >= 45000]
        print(f"faces={faces}: in-band min={min(inb)} max={max(inb)}  out max={max(out)}  min_in>max_out:{min(inb) > max(out)}")
    # ---- N1 屈折 ----
    print("== N1 refract (aperture -3000..3000, detector depth 20000)")
    ap = list(range(-3000, 3001, 10))
    XD = list(range(-10000, 40001, 500))
    for f1, f2, label in ((60, 40, "slow below 3:2"), (60, 60, "control same"), (40, 60, "fast below 2:3")):
        res = [(X, refract_I(src, (X, -h), ap, f1, f2, 4)) for X in XD]
        Xp, Ip = max(res, key=lambda t: t[1])
        Xs_pred = stationary_X(src, f1, f2, h, XD)
        print(f"{label}: peak X={Xp} I={Ip}  stationary X={Xs_pred}  straight X=20000  |peak-stat|<=1500:{abs(Xp - Xs_pred) <= 1500}")

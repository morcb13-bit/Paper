# 一行の規則を周期表全体に当てる。調整する数なし。
#   席の数 S = 周期の長さ（2,8,8,18,18,32）、座った数 v = 周期の中で何番目か、点数 = v(S-v)
#   T1 体積：点数が大きいほど小さい　T2 融点：点数が大きいほど高い
#   対照：周期の区切りを半周期ずらす（v' = v + S/2 を S で折り返す）
#   T3 主要族（1,2,13〜18 族）：角の席に座った数（1,2 族はそのまま、13〜18 族は族−10）が 4 未満なら金属、4 以上なら非金属
from mendeleev import element
starts={1:1,2:3,3:11,4:19,5:37,6:55}; lens={1:2,2:8,3:8,4:18,5:18,6:32}
E={z:element(z) for z in range(1,87)}
def rows(prop):
    out={}
    for p in starts:
        L=[]
        for i in range(lens[p]):
            z=starts[p]+i; val=getattr(E[z],prop)
            if val is not None: L.append((i+1,int(round(val*100)),E[z].symbol))
        out[p]=L
    return out
def conc(data,score,sign):
    res={}
    for p,L in data.items():
        S=lens[p]; c=d=0
        for i in range(len(L)):
            for j in range(i+1,len(L)):
                a,b=score(L[i][0],S),score(L[j][0],S)
                if a==b or L[i][1]==L[j][1]: continue
                same=(a>b)==((L[i][1]>L[j][1]) if sign>0 else (L[i][1]<L[j][1]))
                c+=same; d+=not same
        res[p]=(c,d)
    return res
rule=lambda v,S: v*(S-v)
def shifted(v,S):
    w=(v+S//2-1)%S+1
    return w*(S-w)
for prop,sign,name in (("atomic_volume",-1,"T1 volume"),("melting_point",1,"T2 melting")):
    data=rows(prop)
    a=conc(data,rule,sign); b=conc(data,shifted,sign)
    print("==",name)
    for p in sorted(a): print(f"   period {p}: rule {a[p]}   shifted control {b[p]}")
    print("   total rule",tuple(sum(x[i] for x in a.values()) for i in (0,1)),"  control",tuple(sum(x[i] for x in b.values()) for i in (0,1)))
print("== T3 metal / nonmetal (main groups, periods 2-6)")
hit=miss=0; misses=[]; skipped=[]
for p in (2,3,4,5,6):
    for z in range(starts[p],starts[p]+lens[p]):
        g=E[z].group_id
        if g is None or 3<=g<=12: continue
        val=g if g<=2 else g-10
        ser=E[z].series
        if "etalloid" in ser: skipped.append(E[z].symbol); continue
        actual="metal" if "metal" in ser.lower() and "non" not in ser.lower() else "non"
        pred="metal" if val<4 else "non"
        if pred==actual: hit+=1
        else: miss+=1; misses.append(f"{E[z].symbol}(v={val},{ser})")
print("   hits",hit,"misses",miss,misses,"| metalloids skipped:",skipped)

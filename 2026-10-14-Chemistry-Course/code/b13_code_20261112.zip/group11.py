# 11 番目の金属（11 族：銅・銀・金）だけを見る。整数 pm と比較だけ。
# 一歩 = 10 族 → 11 族（Ni→Cu, Pd→Ag, Pt→Au）の半径の増減
# H1: 第4・第5周期でその一歩は膨らむ（＋）
# H2: 第6周期（金）の一歩は、第4・第5周期のどちらより小さい
# C1: d ブロックの一歩（3→4 族 … 11→12 族）のうち、第4・第5周期の両方で膨らむのは 11 族だけ
# C2: 一歩ずらした 11→12 族（Cu→Zn, Ag→Cd, Au→Hg）では H1・H2 の形にならない
from mendeleev import element

# 族 g の元素の Z（d ブロック 3〜12 族）
ZG = {4: {g: 18 + g for g in range(3, 13)},
      5: {g: 36 + g for g in range(3, 13)},
      6: {3: 57, **{g: 68 + g for g in range(4, 13)}}}   # 6 周期は 3 族を La、4 族以降は Hf(72)〜Hg(80)

SETS = {
    "covalent (Cordero)": lambda e: e.covalent_radius_cordero,
    "metallic (mendeleev)": lambda e: e.metallic_radius,
    "atomic (mendeleev)": lambda e: e.atomic_radius,
}

cache = {}
def r(z, f):
    if z not in cache:
        cache[z] = element(z)
    v = f(cache[z])
    return None if v is None else int(round(v))

def step(p, g, f):
    a, b = r(ZG[p][g - 1], f), r(ZG[p][g], f)
    return None if a is None or b is None else b - a

for name, f in SETS.items():
    print("==", name)
    s11 = {p: step(p, 11, f) for p in (4, 5, 6)}
    s12 = {p: step(p, 12, f) for p in (4, 5, 6)}
    print("  10→11 step  P4,P5,P6:", s11[4], s11[5], s11[6])
    print("  11→12 step  P4,P5,P6:", s12[4], s12[5], s12[6])
    H1 = s11[4] > 0 and s11[5] > 0
    H2 = s11[6] < s11[4] and s11[6] < s11[5]
    both_pos = [g for g in range(4, 13)
                if (step(4, g, f) or 0) > 0 and (step(5, g, f) or 0) > 0]
    C1 = both_pos == [11]
    C2 = not ((s12[4] > 0 and s12[5] > 0) and (s12[6] < s12[4] and s12[6] < s12[5]))
    print(f"  H1 {H1}  H2 {H2}  C1 {C1} (both + in groups {both_pos})  C2 {C2}")
    print("  radii P4/P5/P6 groups 10,11,12:",
          [[r(ZG[p][g], f) for g in (10, 11, 12)] for p in (4, 5, 6)])

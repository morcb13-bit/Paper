# 対称軸への置き方：星型 2 段の共有 6 か所 = 3 本の軸の両端（±x, ±y, ±z）。各点に A 側・B 側の 2 席で 12 席。
# (1) v 個を置いたとき、置き方がどれだけ対称か（その置き方を動かさない対称操作の数の最大）を全数で数える。
# (2) 原子体積との一致を、次の整数の点数で比べる（点数が大きいほど小さい、と数える）：
#     腕 = 片側だけ座った点の数 / 動ける手 = 座った席 × 空いた席 = v(12-v) / 動ける手 + c·v（c = 埋まるたびの縮み）
from itertools import permutations, product, combinations
from mendeleev import element
pts=[(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
A={(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)}
G=[]
for perm in permutations(range(3)):
    for sg in product((1,-1),repeat=3):
        f=lambda p,perm=perm,sg=sg: tuple(sg[i]*p[perm[i]] for i in range(3))
        keep={f(p) for p in A}==A
        G.append((f,keep))
seats=[(p,s) for p in pts for s in (0,1)]
def act(g,seat):
    f,keep=g; p,s=seat
    return (f(p), s if keep else 1-s)
print("(1) v : 最大の対称操作の数 / その置き方での腕（片側だけの点）と、両端がそろった軸の数")
for v in range(13):
    best=(0,None)
    for sub in combinations(seats,v):
        S=set(sub)
        n=sum(1 for g in G if {act(g,x) for x in S}==S)
        if n>best[0]: best=(n,S)
    S=best[1]
    occ={p:sum((p,s) in S for s in (0,1)) for p in pts}
    arms=sum(1 for p in pts if occ[p]==1)
    bal=sum(1 for i in (0,2,4) if occ[pts[i]]==occ[pts[i+1]] and occ[pts[i]]>0)
    print(f"   v={v:2}: {best[0]:2}   arms {arms}  balanced axes {bal}")
rows={4:range(21,31),5:range(39,49),6:[71]+list(range(72,81))}
vol={p:[(g,int(round(element(z).atomic_volume*10))) for g,z in zip(range(3,13),zs)] for p,zs in rows.items()}
def conc(score):
    c=d=0
    for p in rows:
        L=vol[p]
        for i in range(len(L)):
            for j in range(i+1,len(L)):
                a,b=score(L[i][0]),score(L[j][0])
                if a==b or L[i][1]==L[j][1]: continue
                same=(a>b)==(L[i][1]<L[j][1]); c+=same; d+=not same
    return c,d
print("(2) 原子体積：一致 / 不一致")
print("   arms            ",conc(lambda v: v if v<=6 else 12-v))
print("   moves v(12-v)   ",conc(lambda v: v*(12-v)))
for c in range(0,13,2):
    print(f"   moves + {c:2}·v    ",conc(lambda v,c=c: v*(12-v)+c*v))
print("   v only (control)",conc(lambda v: v))

# 正四面体 A と鏡像 B（= −k/3·A）。k=1,2,3 の体積・面の折れ（行列式）・真ん中どうしの距離を整数で
A=[(3,3,3),(3,-3,-3),(-3,3,-3),(-3,-3,3)]
def det3(u,v,w): return u[0]*(v[1]*w[2]-v[2]*w[1])-u[1]*(v[0]*w[2]-v[2]*w[0])+u[2]*(v[0]*w[1]-v[1]*w[0])
sub=lambda p,q:[a-b for a,b in zip(p,q)]
for k in (1,2,3):
    B=[tuple(-k*c//3 for c in a) for a in A]
    fold=abs(det3(sub(A[1],A[0]),sub(B[2],A[0]),sub(B[3],A[0])))
    # 体積：A（6倍で 6·72/6...）は凸包の分割で数える：A ＋ 4 つの角の錐（各 錐 6倍体積 = |det|）
    six=lambda P:abs(det3(sub(P[1],P[0]),sub(P[2],P[0]),sub(P[3],P[0])))
    vA=six(A)
    caps=sum(six([A[j] for j in range(4) if j!=i]+[B[i]]) for i in range(4))
    print(k,"B",B,"6*volume",vA+caps,"tetra units",(vA+caps)//vA,"fold",fold,"gap",3-k)

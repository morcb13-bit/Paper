# 銅・銀・金の段組みから、吸い始める周波数の比を出す規則を総当たりで調べる。判定は整数の掛け算比較だけ。
# 構造（走らせる前に固定）：正四面体のギャスケット k 段（1 段 = 正四面体 1 個）
#   辺 E = 2^(k-1)、小さい正四面体 N = 4^(k-1)、穴（正八面体）H = (4^(k-1)-1)/3、頂点 V = 2(4^(k-1)+1)
#   銅 = 3 段、銀 = 3 段の星型（A と鏡像 B の 2 つ：N,H,V は 2 倍、辺は同じ）
#   金a = 4 段、金b = 4 段で内側 3 段が埋まり、開いているのは差（N,H,V は 4 段 − 3 段、辺は 8）
# 規則：周波数 ∝ q1^a · q2^b（q は E,N,H,V、指数は ±1,±2、q1≠q2、および 1 量だけ）
# 合格窓（最後に一度だけ照合、［知識］）：金/銅 ∈ [1.10, 1.19]、銀/銅 ∈ [1.76, 1.86]
# 偶然の目安：同じ幅の窓を 1.00〜3.00 の格子に動かしたとき、当たる規則の数の平均
from itertools import combinations, product

def g(k):
    E = 2 ** (k - 1); N = 4 ** (k - 1); H = (N - 1) // 3; V = 2 * (N + 1)
    return {"E": E, "N": N, "H": H, "V": V}

cu = g(3)
ag = {q: (v * 2 if q != "E" else v) for q, v in g(3).items()}
g4, g3 = g(4), g(3)
au_a = g4
au_b = {"E": 8, "N": g4["N"] - g3["N"], "H": g4["H"] - g3["H"], "V": g4["V"] - g3["V"]}

def val(s, rule):              # 有理数 (num, den) を整数で
    num = den = 1
    for q, e in rule:
        if e > 0: num *= s[q] ** e
        else: den *= s[q] ** (-e)
    return num, den

def ratio_in(x, y, lo, hi):    # x/y ∈ [lo/100, hi/100]
    (a, b), (c, d) = x, y      # x = a/b, y = c/d, x/y = a d / (b c)
    n, m = a * d, b * c
    return lo * m <= 100 * n <= hi * m

rules = [((q, e),) for q in "ENHV" for e in (1, 2, -1, -2)]
rules += [((q1, e1), (q2, e2)) for q1, q2 in combinations("ENHV", 2) for e1, e2 in product((1, 2, -1, -2), repeat=2)]

def hits(au, w1, w2):
    out = []
    for r in rules:
        c, a, g_ = val(cu, r), val(ag, r), val(au, r)
        if ratio_in(g_, c, *w1) and ratio_in(a, c, *w2): out.append(r)
    return out

print("structures:", "Cu", cu, "Ag", ag, "Au_a", au_a, "Au_b", au_b)
print("rules:", len(rules))
for name, au in (("Au_a (4 levels)", au_a), ("Au_b (4 levels, inner 3 filled)", au_b)):
    h = hits(au, (110, 119), (176, 186))
    base = []
    for c1 in range(100, 291, 10):
        for c2 in range(100, 291, 10):
            base.append(len(hits(au, (c1, c1 + 9), (c2, c2 + 10))))
    print(f"== {name}: hits {len(h)}  chance mean x100 = {100 * sum(base) // len(base)}  max {max(base)}")
    for r in h:
        c, a, g_ = val(cu, r), val(ag, r), val(au, r)
        print("   rule", r, " Cu", c, " Au", g_, " Ag", a)

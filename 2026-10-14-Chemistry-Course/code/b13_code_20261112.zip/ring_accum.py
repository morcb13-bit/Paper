# 連続光が原子のまわりを周回して貯まり、閾値に届いたら同じ角度で放たれる（反射）。
# 一周の長さ P = 4L（開いている辺 L の正四面体の 4 面を一周）。
# 一周で貯まる量は開いている面の大きさ L^2 に比例 → 閾値までの周回数 T = K / L^2。
# 光のギャスケット（大きさ s）の位相は 4 つの面の段：累計の倒れる回数 floor(j*P/s) mod 4。
# T 周のあいだ位相がそろって貯まる（|和|^2 >= T^2/2）最小の s を「境目」とする。
# 境目より大きい（周波数の低い）光は貯まって放たれ、小さい光は打ち消して抜ける。
# 判定は整数だけ。L は 1000 倍の整数（金は c = isqrt(12528*10^6/18769)/1000）。
from math import isqrt

def strength(P, s, T):
    re = im = 0
    for j in range(T):
        k = (j * P // s) % 4
        if k == 0: re += 1
        elif k == 1: im += 1
        elif k == 2: re -= 1
        else: im -= 1
    return re * re + im * im

def edge(L1000, K):
    P = 4 * L1000
    T = K * 1000000 // (L1000 * L1000)      # L^2 は 1000^2 倍しているので戻す
    s = 1
    lo, hi = 1, 10 ** 9
    # strength は s に対して単調に増える前提で二分探索し、両隣で確認する
    while lo < hi:
        mid = (lo + hi) // 2
        if 2 * strength(P, mid, T) >= T * T: hi = mid
        else: lo = mid + 1
    return lo, T

c1000 = isqrt(12528 * 10 ** 6 // 18769)
L = {"Cu": 4000, "Ag": 8000, "Au": 8000 - 4 * c1000}
for K in (6400, 25600):
    res = {m: edge(v, K) for m, v in L.items()}
    print(f"K={K}: c*1000={c1000}")
    for m, (s, T) in res.items():
        print(f"  {m}: L*1000={L[m]}  laps T={T}  edge size s={s}")
    sc = res["Cu"][0]
    print("  edge frequency ratio vs Cu (x1000, = s_Cu*1000//s):",
          {m: sc * 1000 // res[m][0] for m in res})
    # 対照：閾値を L によらず一定（T 固定）にした場合
    T0 = K // 16
    s0 = {}
    for m, v in L.items():
        P = 4 * v; lo, hi = 1, 10 ** 9
        while lo < hi:
            mid = (lo + hi) // 2
            if 2 * strength(P, mid, T0) >= T0 * T0: hi = mid
            else: lo = mid + 1
        s0[m] = lo
    print("  control (T fixed):", {m: s0["Cu"] * 1000 // s0[m] for m in s0})

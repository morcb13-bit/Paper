# 強さはどこに貯まるか：境目（色）と放たれる回数（明るさ）を分けられるか。整数だけ。
# 原子：一周 P = 4L、閾値 T 周（構造で決まる。前回と同じ T = 6400 // L^2）。
# 光：外形の大きさ s（周波数）、強さ n。毎周、位相の段 (j*P//s) mod 4 で 1 単位ずつ届く。
# A（仮説）：強さ n は高次元の穴 n 個。穴ごとに別々に貯まり、|貯め|^2 >= T^2 で放って空く。
# B（対照1）：n 単位を同じ一つの穴に貯める（閾値は同じ T）。
# C（対照2）：強さを外形に入れる（大きさ s*n の光を 1 単位）。
# 基準：A では境目の大きさ（放つ回数が 1 以上になる最小の s）が n によらず同じで、
#       放つ回数は n に比例する。B・C では境目が n とともに動く。
STEP = {0: (1, 0), 1: (0, 1), 2: (-1, 0), 3: (0, -1)}

def releases(P, s, T, per_lap, N):
    re = im = 0; cnt = 0
    for j in range(N):
        dx, dy = STEP[(j * P // s) % 4]
        re += per_lap * dx; im += per_lap * dy
        if re * re + im * im >= T * T:
            cnt += 1; re = im = 0
    return cnt

def run(L, N=8000, svals=range(100, 20001, 100), ns=(1, 2, 4, 8)):
    P = 4 * L; T = 6400 // (L * L)
    out = {}
    for n in ns:
        A = {s: n * releases(P, s, T, 1, N) for s in svals}           # 穴 n 個、それぞれ同じ列
        B = {s: releases(P, s, T, n, N) for s in svals}
        C = {s: releases(P, s * n, T, 1, N) for s in svals}
        edge = lambda d: min((s for s in svals if d[s] > 0), default=None)
        far = svals[-1]
        out[n] = (edge(A), edge(B), edge(C), A[far], B[far])
    return P, T, out

for name, L in (("Cu", 4), ("Ag", 8)):
    P, T, out = run(L)
    print(f"== {name}: L={L} P={P} T={T}")
    print("   n | edge A  edge B  edge C | releases at s=20000: A  B")
    for n, (a, b, c, ra, rb) in out.items():
        print(f"   {n} | {a:6} {b:6} {c:6} | {ra:6} {rb:6}")

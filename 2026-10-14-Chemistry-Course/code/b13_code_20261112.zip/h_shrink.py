# H で縮む：6 次元の整数の腕を見える側（GEN）と残渣の側（G'）に分け、
# 見える側の長さ² の比の飛び飛びの組に、実際の「X–H / X–X」の比が乗るかを数える。
# 判定は a+bφ の整数比較だけ。対照：同じ本数の腕を 3 次元の立方格子で作る。
# 当たりの割合（偶然）は、比 0.500〜0.999 を 0.001 刻みの的として同じ幅で数える。
from itertools import product

def mul(x, y):
    a, b = x; c, d = y
    return (a * c + b * d, a * d + b * c + b * d)
def add(x, y): return (x[0] + y[0], x[1] + y[1])
def sub(x, y): return (x[0] - y[0], x[1] - y[1])
def sc(k, x): return (k * x[0], k * x[1])
def sign(x):
    p, q = x; u, v = 2 * p + q, q
    if v == 0: return (u > 0) - (u < 0)
    if u >= 0 and v >= 0: return 1
    if u <= 0 and v <= 0: return -1
    l, r = u * u, 5 * v * v
    return ((l > r) - (l < r)) if u > 0 else ((r > l) - (r < l))

O, P, Q = (0, 0), (0, 1), (1, -1)          # 0, φ, 1-φ
ONE, M1 = (1, 0), (-1, 0)
GEN = [(ONE, P, O), (M1, P, O), (O, ONE, P), (O, M1, P), (P, O, ONE), (P, O, M1)]
GP  = [(ONE, Q, O), (M1, Q, O), (O, ONE, Q), (O, M1, Q), (Q, O, ONE), (Q, O, M1)]

def vec(n, G):
    v = [O, O, O]
    for k, c in enumerate(n):
        if c:
            for i in range(3): v[i] = add(v[i], sc(c, G[k][i]))
    return v
def sq(v):
    t = O
    for c in v: t = add(t, mul(c, c))
    return t

def arms6():
    out = set(); chk = True
    for n in product(range(-3, 4), repeat=6):
        s = sum(abs(c) for c in n)
        if 1 <= s <= 3:
            a, b = sq(vec(n, GEN)), sq(vec(n, GP))
            chk &= add(a, b) == (5 * sum(c * c for c in n), 0)
            out.add(a)
    return out, chk

def arms3():
    out = set()
    for n in product(range(-3, 4), repeat=3):
        if 1 <= sum(abs(c) for c in n) <= 3:
            out.add((sum(c * c for c in n), 0))
    return out

def hits(pars, num, den, w):
    # num/den（pm）が sqrt(pa/pb) の幅 ±w pm に入る組があるか： (num-w)^2 pb <= den^2 pa <= (num+w)^2 pb
    for pa in pars:
        for pb in pars:
            if sign(sub(pb, pa)) <= 0: continue
            lo = sign(sub(sc(den * den, pa), sc((num - w) ** 2, pb))) >= 0
            hi = sign(sub(sc((num + w) ** 2, pb), sc(den * den, pa))) >= 0
            if lo and hi: return True
    return False

DATA = {  # [知識] 検算していない結合の長さ（pm）：X–H, X–X
    "C": (109, 154), "N": (101, 145), "O": (96, 148),
    "Cu": (146, 222), "Ag": (162, 253), "Au": (152, 247),
}
if __name__ == "__main__":
    p6, chk = arms6(); p3 = arms3()
    print("6D arms: distinct visible |.|^2 =", len(p6), " par^2+perp^2 = 5|n|^2 all:", chk)
    print("3D arms: distinct |.|^2 =", len(p3))
    w = 1
    for name, pars in (("6D", p6), ("3D", p3)):
        got = {k: hits(pars, h, x, w) for k, (h, x) in DATA.items()}
        base = sum(hits(pars, k, 1000, 10 * w) for k in range(500, 1000))   # 同じ約 1% の幅
        print(f"{name}: hits {sum(got.values())}/6 {got}  chance {base}/500")

# R1' 反射：表面の電子の座で受けて出し直す全経路の符号和（整数と加算だけ）
# 光のギャスケットは大きさ s ごとに一回倒れ、倒れるたびに符号が入れ替わる。
# 経路の倒れる回数 n = (|光源→座| + |座→受け手|) // s 、符号 (-1)^n 。
# 長さは整数平方根 isqrt（切り捨て）。和 S は ±1 の足し算だけ。
import sys, random
from math import isqrt

def falls(p, q, seat, s):
    d1 = isqrt((seat - p[0])**2 + p[1]**2)
    d2 = isqrt((seat - q[0])**2 + q[1]**2)
    return (d1 + d2) // s

def S(src, det, seats, s, flip=None):
    t = 0
    for i, x in enumerate(seats):
        n = falls(src, det, x, s)
        sg = 1 if n % 2 == 0 else -1
        if flip is not None:
            sg *= flip[i]
        t += sg
    return t

def run(label, src, seats, s, Xs, flip=None):
    out = []
    for X in Xs:
        out.append((X, S(src, (X, src[1]), seats, s, flip)))
    return out

if __name__ == "__main__":
    s = 100                      # ギャスケットの大きさ（倒れる一歩）
    h = 20000; a = 20000         # 光源 (-a, h)、受け手は高さ h の線上
    src = (-a, h)
    Xs = list(range(-40000, 80001, 1000))
    W = 10000
    mirror = list(range(-W, W + 1, 10))   # 鏡：座 2001 個
    res = {}
    res["main"] = run("main", src, mirror, s, Xs)
    random.seed(1)
    flip = [random.choice((1, -1)) for _ in mirror]
    res["ctrl_random"] = run("ctrl", src, mirror, s, Xs, flip)
    # 斜めの位置の鏡（同じ長さ）を置き、受け手 X=-20000 に向けて符号が + の座だけ残す（格子）
    side = list(range(30000, 50001, 10))
    tgt = (-20000, h)
    grat = [x for x in side if falls(src, tgt, x, s) % 2 == 0]
    res["side_full"] = run("sf", src, side, s, Xs)
    res["side_grating"] = run("sg", src, grat, s, Xs)
    for k, v in res.items():
        print("==", k)
        print(" ".join(f"{X//1000}:{t}" for X, t in v))

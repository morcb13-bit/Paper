# 不足の数（その殻の席の数 − 電子数）だけで、原子の大きさの並びが周期をまたいで揃うか
# 半径は Cordero 2008 の共有結合半径（periodictable パッケージ、Å を整数 pm に直す）
# 判定は整数の符号の一致数と、並べ替え 10,000 回の数え上げだけ
import random
import periodictable as pt

END = {1: 2, 2: 10, 3: 18, 4: 36, 5: 54, 6: 86}
START = {1: 1, 2: 3, 3: 11, 4: 19, 5: 37, 6: 55}

def r_pm(z):
    s = f"{pt.elements[z].covalent_radius:.2f}"
    a, b = s.split(".")
    return int(a) * 100 + int(b)

def sgn(v):
    return (v > 0) - (v < 0)

def steps(p):
    # 不足の数 d → 一歩の増減の符号（周期の最初の元素は除く）
    out = {}
    for z in range(START[p] + 1, END[p] + 1):
        out[END[p] - z] = sgn(r_pm(z) - r_pm(z - 1))
    return out

def matches(a, b, shift=0):
    n = 0; m = 0
    for d, s in a.items():
        if d + shift in b:
            m += 1
            n += (s == b[d + shift])
    return n, m

def perm_count(a, b, obs, trials=10000, seed=1):
    random.seed(seed)
    keys = [d for d in a if d in b]
    vals = [a[d] for d in keys]
    ge = 0
    for _ in range(trials):
        random.shuffle(vals)
        n = sum(v == b[d] for v, d in zip(vals, keys))
        ge += (n >= obs)
    return ge

if __name__ == "__main__":
    S = {p: steps(p) for p in (2, 3, 4, 5)}
    for p in (2, 3, 4, 5):
        print(f"period {p}:", " ".join(f"d{d}:{'+' if s > 0 else '-' if s < 0 else '0'}"
                                       for d, s in sorted(S[p].items(), reverse=True)))
    print()
    for a, b in ((2, 3), (4, 5), (3, 4)):
        n, m = matches(S[a], S[b])
        ge = perm_count(S[a], S[b], n)
        sh = [matches(S[a], S[b], k) for k in (-1, 1)]
        print(f"P{a} vs P{b}: match {n}/{m}  perm>=obs {ge}/10000  pass:{ge <= 500}"
              f"  shift-1 {sh[0][0]}/{sh[0][1]}  shift+1 {sh[1][0]}/{sh[1][1]}")
    print()
    for z in (29, 47, 79):
        p = 4 if z < 37 else 5 if z < 55 else 6
        print(pt.elements[z].symbol, "Z", z, "deficit", END[p] - z, "radius pm", r_pm(z))

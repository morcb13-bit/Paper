# ギャスケットの頂点を正四面体の対称（24 通り）で移り合う組に分け、対称に置ける電子数を列挙する
from itertools import permutations
C=[(0,0,0),(2,2,0),(2,0,2),(0,2,2)]
def sub(k,T):
    if k==1: return [T]
    out=[]
    for i in range(4):
        t=[tuple(2*x for x in T[i])]+[tuple(a+b for a,b in zip(T[i],T[j])) for j in range(4) if j!=i]
        out+=sub(k-1,t)
    return out
for k in (2,3,4):
    s=2**(k-1); V=set(v for t in sub(k,C) for v in t)
    def bary(v):
        x,y,z=v; S=2*s; w1=x+y-z; w2=x-y+z; w3=-x+y+z
        return (2*S-(w1+w2+w3), w1, w2, w3)
    seen=set(); orbits=[]
    for v in V:
        b=bary(v)
        if b in seen: continue
        orb={tuple(b[p[i]] for i in range(4)) for p in permutations(range(4))}
        seen|=orb; orbits.append(len(orb))
    S={0}
    for o in orbits: S|={x+o for x in S}
    print(k,"levels: orbit sizes",sorted(orbits),"symmetric counts<=60",sorted(x for x in S if 0<x<=60),"any odd",any(x%2 for x in S))

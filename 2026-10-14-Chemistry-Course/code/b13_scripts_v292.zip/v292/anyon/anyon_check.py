# Z[ζ10]：整数4つの組。ζ^4 = ζ^3 - ζ^2 + ζ - 1 で繰り上げる
def red(p):
    p = list(p) + [0]*(9-len(p))
    for k in range(len(p)-1, 3, -1):
        c = p[k]; p[k] = 0
        if c: p[k-1] += c; p[k-2] -= c; p[k-3] += c; p[k-4] -= c
    return tuple(p[:4])
def add(a, b): return tuple(x+y for x, y in zip(a, b))
def neg(a): return tuple(-x for x in a)
def mul(a, b):
    r = [0]*7
    for i, x in enumerate(a):
        for j, y in enumerate(b): r[i+j] += x*y
    return red(r)

Z0, ONE, z = (0,0,0,0), (1,0,0,0), (0,1,0,0)
def zp(n):
    r = ONE
    for _ in range(n % 10): r = mul(r, z)
    return r
def conj(a):                       # ζ^k → ζ^-k（10方向の鏡映）
    r = Z0
    for k, c in enumerate(a):
        if c: r = add(r, tuple(c*x for x in zp(9*k)))
    return r

phi  = add(z, neg(zp(4)))          # φ = ζ + ζ^-1
iphi = add(phi, neg(ONE))          # 1/φ = φ - 1

def mm(A, B): return [[add(mul(A[i][0], B[0][j]), mul(A[i][1], B[1][j]))
                       for j in range(2)] for i in range(2)]
def dag(A): return [[conj(A[j][i]) for j in range(2)] for i in range(2)]
I = [[ONE, Z0], [Z0, ONE]]
G = [[phi, Z0], [Z0, ONE]]         # 長さ²の重み (φ, 1)

F  = [[iphi, iphi], [ONE, neg(iphi)]]
R  = [[zp(6), Z0], [Z0, zp(3)]]    # 位相 -144°, 108°
S1, S2 = R, mm(mm(F, R), F)

print("F·F = I              :", mm(F, F) == I)
print("1/φ² + 1/φ = 1       :", add(mul(iphi, iphi), iphi) == ONE)
print("σ1σ2σ1 = σ2σ1σ2      :", mm(mm(S1, S2), S1) == mm(mm(S2, S1), S2))
for name, S in (("F", F), ("σ1", S1), ("σ2", S2)):
    print(f"{name} は長さ²を保つ  :", mm(mm(dag(S), G), S) == G)

two = (2, 0, 0, 0)                 # 負の対照：φ を 2 に置き換える
F2 = [[add(two, neg(ONE))]*2, [ONE, neg(add(two, neg(ONE)))]]
print("対照 φ→2 で F·F = I  :", mm(F2, F2) == I)

f = [0, 1]
for _ in range(12): f.append(f[-1] + f[-2])
print("符号の入れ替わり     :", [f[n+1]*f[n-1] - f[n]*f[n] for n in range(1, 12)])

a, b = 1, 0                        # τ を足していく：(1になる数, τになる数)
for n in range(1, 11):
    print(n, (b, a)); a, b = a + b, a

# 融合の道（τ で始まり、1 が二つ続かない）＝ 長さ n−1 の「1 が続かない」並び（フィボナッチ立方体の頂点）
import itertools
for n in range(2, 11):
    cube = sum(1 for s in itertools.product((0, 1), repeat=n-1) if all(not (s[i] and s[i+1]) for i in range(n-2)))
    a, b = 1, 0
    for _ in range(n-1): a, b = a + b, a
    print(n, '融合の道', a + b, ' フィボナッチ立方体の頂点', cube)

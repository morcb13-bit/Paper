# C60 を 6 次元の番地で組む：原子 = 2v_i + v_j（v は正二十面体の頂点 = ±e_k）
import sys, json, itertools
sys.path.insert(0,'../pt6')
from zphi import *
V=[]                                  # 正二十面体の頂点 12 = ±e_k（6 次元の番地）
for k in range(6):
    for s in (1,-1): V.append(tuple(s if i==k else 0 for i in range(6)))
P={v:par6(v) for v in V}
n2=lambda u: dot(u,u)
# 隣り合う頂点：内積が φ（= (0,1)）
adj={i:[j for j in range(12) if j!=i and dot(P[V[i]],P[V[j]])==(0,1)] for i in range(12)}
assert all(len(a)==5 for a in adj.values())
add=lambda a,b: tuple(x+y for x,y in zip(a,b)); sc=lambda s,a: tuple(s*x for x in a)
atoms=[]; aid={}
for i in range(12):
    for j in adj[i]:
        n=add(sc(2,V[i]),V[j]); aid[(i,j)]=len(atoms); atoms.append(n)
bonds=set()
for i in range(12):
    for j in adj[i]:
        bonds.add(tuple(sorted((aid[(i,j)],aid[(j,i)]))))            # 六角形どうしの結合
        for k in adj[i]:
            if k in adj[j]: bonds.add(tuple(sorted((aid[(i,j)],aid[(i,k)]))))  # 五角形の結合
bonds=sorted(bonds)
print('原子',len(atoms),' 結合',len(bonds))
# 結合の番地の差：成分 2 つが ±1（一歩が 2 つ ＝「へ」）か
diffs=[tuple(b-a for a,b in zip(atoms[x],atoms[y])) for x,y in bonds]
print('結合の差がへ（±1 が 2 成分）:',all(sorted(map(abs,d))==[0,0,0,0,1,1] for d in diffs))
# 物理側の長さ²
L=set(n2(par6(d)) for d in diffs); print('結合の長さ²',L)
R=set(n2(par6(a)) for a in atoms); print('原子の半径²',R)
# へ の角（二通り）
kinds={}
corners=[]
for (x,y),d in zip(bonds,diffs):
    ks=[i for i in range(6) if d[i]]
    c1=add(atoms[x],tuple(d[i] if i==ks[0] else 0 for i in range(6)))
    c2=add(atoms[x],tuple(d[i] if i==ks[1] else 0 for i in range(6)))
    r1,r2=n2(par6(c1)),n2(par6(c2))
    inner,outer=(c1,c2) if (r1[0]+r1[1]*1.618)<(r2[0]+r2[1]*1.618) else (c2,c1)   # 表示の向きを選ぶためだけの比較
    corners.append((inner,outer))
    typ='hh' if any(aid[(i,j)]==x and aid[(j,i)]==y or aid[(i,j)]==y and aid[(j,i)]==x for i in range(12) for j in adj[i]) else 'p'
    kinds[typ]=kinds.get(typ,0)+1
    kinds[(typ,n2(par6(inner)),n2(par6(outer)))]=kinds.get((typ,n2(par6(inner)),n2(par6(outer))),0)+1
print(kinds)
# 環：五角形 12、六角形 20 の一歩の数
print('五角形：へ 5 つ = 一歩 10、六角形：へ 6 つ = 一歩 12（各結合が一歩 2 つ）')
# 一歩ごとの和の偶奇
print('原子の番地の和の偶奇',set(sum(a)%2 for a in atoms))
types=['hh' if (x,y) in set(tuple(sorted((aid[(i,j)],aid[(j,i)]))) for i in range(12) for j in adj[i]) else 'p' for x,y in bonds]
out={'atoms':[[list(map(list,par6(a)))] for a in atoms],
     'A':[list(map(list,par6(a))) for a in atoms],
     'B':bonds,'T':types,
     'Cin':[list(map(list,par6(c[0]))) for c in corners],'Cout':[list(map(list,par6(c[1]))) for c in corners],
     'pent':[[aid[(i,j)] for j in adj[i]] for i in range(12)], 'ico':[list(map(list,P[v])) for v in V]}
json.dump(out,open('c60.json','w'))
print('6 次元の番地の例',atoms[0],'→',par6(atoms[0]))

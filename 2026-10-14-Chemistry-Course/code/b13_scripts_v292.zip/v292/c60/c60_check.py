# 六角形（へ 3 つ）と C60（へ 90）を整数だけで確かめる
# --- Z[φ]：(a,b) = a+bφ、φ² = φ+1 ---
def zm(x,y): a,b=x; c,d=y; return (a*c+b*d, a*d+b*c+b*d)
def za(x,y): return (x[0]+y[0], x[1]+y[1])
def dot(u,v):
    r=(0,0)
    for a,b in zip(u,v): r=za(r,zm(a,b))
    return r
O,I,P,M,Q=(0,0),(1,0),(0,1),(-1,0),(0,-1)
E=[(I,P,O),(M,P,O),(O,I,P),(O,M,P),(P,O,I),(Q,O,I)]      # 正二十面体の五回軸 6 本
def par(n):                                               # 6 次元の番地 → 3 次元（Z[φ]）
    r=[(0,0)]*3
    for k,c in enumerate(n):
        for i in range(3): r[i]=za(r[i],(c*E[k][i][0],c*E[k][i][1]))
    return tuple(r)

# --- 1. へ 3 つの六角形（3 次元の整数格子、和が 1 か 2 の段） ---
H=[(1,0,0),(1,1,0),(0,1,0),(0,1,1),(0,0,1),(1,0,1)]
steps=[tuple(b-a for a,b in zip(H[k],H[(k+1)%6])) for k in range(6)]
print('六角形の 6 歩:',steps)
print('番地の和:',[sum(p) for p in H])
q=[tuple(3*c-sum(p) for c in p) for p in H]               # 対角線 (1,1,1) から見た影（3 倍）
print('対角線から：中心までの長さ²',[sum(c*c for c in v) for v in q],
      ' 辺の長さ²',[sum((a-b)**2 for a,b in zip(q[k],q[(k+1)%6])) for k in range(6)])
print('辺 (0,0,1) から：',[(p[0],p[1]) for p in H])

# --- 2. C60：炭素 = 2v_i + v_j（v は ±e_k の 12 本） ---
V=[tuple(s if i==k else 0 for i in range(6)) for k in range(6) for s in (1,-1)]
adj={i:[j for j in range(12) if dot(par(V[i]),par(V[j]))==(0,1)] for i in range(12)}
A={};atoms=[]
for i in range(12):
    for j in adj[i]:
        A[(i,j)]=len(atoms); atoms.append(tuple(2*a+b for a,b in zip(V[i],V[j])))
B=set()
for i in range(12):
    for j in adj[i]:
        B.add(tuple(sorted((A[(i,j)],A[(j,i)]))))
        for k in adj[i]:
            if k in adj[j]: B.add(tuple(sorted((A[(i,j)],A[(i,k)]))))
diff=[tuple(atoms[y][t]-atoms[x][t] for t in range(6)) for x,y in B]
print('炭素',len(atoms),' 結合',len(B))
print('結合はすべて へ（2 つの成分がそれぞれ ±1）:',all(sorted(map(abs,d))==[0,0,0,0,1,1] for d in diff))
from collections import Counter; print('  符号の組',Counter(tuple(sorted(x for x in d if x)) for d in diff))
print('結合の長さ²:',{dot(par(d),par(d)) for d in diff},'  炭素の半径²:',{dot(par(a),par(a)) for a in atoms})
print('炭素の番地の和の偶奇:',{sum(a)%2 for a in atoms})
pc=[[A[(i,j)] for j in adj[i]] for i in range(12)]
inner={tuple(2*x for x in V[i]) for i in range(12)}
# 五角形の結合の へ の角：一方の角は 2v_i（五角形の 5 本で共通）
ok=all(any(tuple(atoms[A[(i,j)]][t]-V[j][t] for t in range(6))==tuple(2*x for x in V[i]) for j in adj[i]) for i in range(12))
print('五角形の へ の角 2v_i（札の向き）:',ok,' 五角形',len(pc),'枚')

# --- 3. 結合の種類（6–6 と 5–6）で へ の折れ方を比べる ---
neg=lambda u: tuple((-a,-b) for a,b in u)
rows=[]
for i in range(12):
    for j in adj[i]:
        if i<j:   # 6–6：2v_i+v_j → 2v_j+v_i、二歩は −v_i と +v_j
            x,y,s1,s2=atoms[A[(i,j)]],atoms[A[(j,i)]],V[i],V[j]; rows.append(('6-6',x,y,s1,s2))
        for k in adj[i]:
            if k in adj[j] and j<k:   # 5–6：2v_i+v_j → 2v_i+v_k、二歩は −v_j と +v_k
                x,y,s1,s2=atoms[A[(i,j)]],atoms[A[(i,k)]],V[j],V[k]; rows.append(('5-6',x,y,s1,s2))
from collections import Counter
out=Counter()
for t,x,y,s1,s2 in rows:
    opening=dot(neg(par(s1)),par(s2))                                   # へ の開き（二歩の内積）
    mid4=dot(par(tuple(a+b for a,b in zip(x,y))),par(tuple(a+b for a,b in zip(x,y))))   # 中点の半径² × 4
    cin=tuple(a-b for a,b in zip(x,s1)); cout=tuple(a+b for a,b in zip(x,s2))
    out[(t,opening,mid4,dot(par(cin),par(cin)),dot(par(cout),par(cout)))]+=1
for k,v in sorted(out.items()): print('種類 %s  本数 %d  へ の開き %s  中点の半径²×4 %s  角(内)の半径² %s  角(外)の半径² %s'%(k[0],v,k[1],k[2],k[3],k[4]))

# Z[φ]：(a,b)=a+bφ、φ²=φ+1。足し算と整数の掛け算だけ
def zm(x,y): a,b=x; c,d=y; return (a*c+b*d, a*d+b*c+b*d)
def za(x,y): return (x[0]+y[0], x[1]+y[1])
def zn(x): return (-x[0],-x[1])
Z0=(0,0)
O,I,P,M,Q=(0,0),(1,0),(0,1),(-1,0),(0,-1)
E6=[(I,P,O),(M,P,O),(O,I,P),(O,M,P),(P,O,I),(Q,O,I)]   # carrier3d_np.py の E と同じ
def vadd(u,v): return tuple(za(a,b) for a,b in zip(u,v))
def vscale(s,u): return tuple((s*a[0],s*a[1]) for a in u)
def dot(u,v):
    r=Z0
    for a,b in zip(u,v): r=za(r,zm(a,b))
    return r
def cross(u,v):
    return (za(zm(u[1],v[2]),zn(zm(u[2],v[1]))), za(zm(u[2],v[0]),zn(zm(u[0],v[2]))), za(zm(u[0],v[1]),zn(zm(u[1],v[0]))))
def par6(n):   # 6 整数の番地 → 物理側 Z[φ]³
    r=(Z0,Z0,Z0)
    for k,c in enumerate(n):
        if c: r=vadd(r,vscale(c,E6[k]))
    return r

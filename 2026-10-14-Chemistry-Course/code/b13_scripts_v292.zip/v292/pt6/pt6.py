# 検定 PT6：ペンチプセンを担体の上で組む（6 次元の担体／3 次元の格子＝負の対照）
import sys, itertools, json, numpy as np
sys.path.insert(0,'.'); sys.path.insert(1,'../../fluid/code')
from zphi import *
MODE=sys.argv[1]            # '6d' or '3d'
if MODE=='6d':
    import carrier3d_np as cc
    DIM=6; PAR=par6
    _acc={}
    def acc(n):
        if n not in _acc: _acc[n]=bool(cc.accept(np.array([n],np.int64))[0][0])
        return _acc[n]
    def accmany(arr):
        ok,_=cc.accept(arr); return ok
else:
    DIM=3
    def PAR(n): return tuple((c,0) for c in n)
    def acc(n): return True
    def accmany(arr): return np.ones(len(arr),bool)
UNIT=[tuple((s if i==k else 0) for i in range(DIM)) for k in range(DIM) for s in (1,-1)]
def add(u,v): return tuple(a+b for a,b in zip(u,v))
def sub(u,v): return tuple(a-b for a,b in zip(u,v))
def neg(u): return tuple(-a for a in u)
STEPS=np.array(UNIT,np.int64)
# 6 員環：辺 x→y を含み、新しい点 4 つ（r1..r4）で x に戻る
_ring={}
def rings(x,y):
    key=(x,y)
    if key in _ring: return _ring[key]
    yv=np.array(y,np.int64); xv=np.array(x,np.int64)
    S=STEPS; n=len(S)
    idx=np.array(list(itertools.product(range(n),repeat=4)))
    r1=yv+S[idx[:,0]]; r2=r1+S[idx[:,1]]; r3=r2+S[idx[:,2]]; r4=r3+S[idx[:,3]]
    last=xv-r4; ok=(np.abs(last).sum(1)==1)
    pts=[xv[None].repeat(len(r1),0),yv[None].repeat(len(r1),0),r1,r2,r3,r4]
    for i in range(6):
        for j in range(i+1,6): ok&=np.any(pts[i]!=pts[j],1)
    r1,r2,r3,r4=r1[ok],r2[ok],r3[ok],r4[ok]
    if len(r1):
        allp=np.concatenate([r1,r2,r3,r4]); a=accmany(allp).reshape(4,-1).all(0)
        r1,r2,r3,r4=r1[a],r2[a],r3[a],r4[a]
    out=[tuple(map(tuple,q)) for q in zip(r1.tolist(),r2.tolist(),r3.tolist(),r4.tolist())]
    out=list(dict.fromkeys(out)); _ring[key]=out; return out
def core(c9,p,q,r,sp,sq,sr):
    """芯：道 (p,q,r)・(q,r,p)・(r,p,q)。原子と真ん中の結合を返す"""
    e=lambda k,s: tuple((s if i==k else 0) for i in range(DIM))
    ep,eq,er=e(p,sp),e(q,sq),e(r,sr)
    c10=add(add(add(c9,ep),eq),er)
    paths=[(ep,eq,er),(eq,er,ep),(er,ep,eq)]
    atoms=[c9,c10]; mids=[]
    for a,b,c in paths:
        u=add(c9,a); w=add(u,b); atoms+= [u,w]; mids.append((u,w))
    return atoms,mids,c10
def complete(occ,edges):
    """残りの羽根を、重ならないように置けるか（後戻りで探す）"""
    if not edges: return []
    x,y=edges[0]
    for R in rings(x,y):
        if any(p in occ for p in R): continue
        sub_=complete(occ|set(R),edges[1:])
        if sub_ is not None: return [(x,y,R)]+sub_
    return None
zero=((0,0),)*3
def klass(a,b):
    d=dot(a,b); return (zm(d,d), zm(dot(a,a),dot(b,b)), cross(a,b)==zero)
found={}; partial=set(); tried=0
O=tuple([0]*DIM)
for p,q,r in itertools.permutations(range(DIM),3):
    if not (p<q and p<r): continue                  # 巡回の向きは (p,q,r) と (p,r,q) の 2 通りで数える
    for sp,sq,sr in itertools.product((1,-1),repeat=3):
        atoms1,mids1,c10=core(O,p,q,r,sp,sq,sr)
        if len(set(atoms1))<8 or not all(acc(a) for a in atoms1): continue
        a_ax=PAR(sub(c10,O))
        for bi in range(3):
            x,y=mids1[bi]
            for R in rings(x,y):
                if any(pt in atoms1 for pt in R): continue
                occ1=set(atoms1)|set(R)
                r1,r2,r3,r4=R
                for (u,w) in ((r2,r3),(r3,r2)):
                    st=sub(w,u); qq=[i for i in range(DIM) if st[i]][0]; sq2=st[qq]
                    for pp in range(DIM):
                        if pp==qq: continue
                        for rr in range(DIM):
                            if rr in (pp,qq): continue
                            for sp2,sr2 in itertools.product((1,-1),repeat=2):
                                ep=tuple((sp2 if i==pp else 0) for i in range(DIM))
                                c9b=sub(u,ep)
                                atoms2,mids2,c10b=core(c9b,pp,qq,rr,sp2,sq2,sr2)
                                b_ax=PAR(sub(c10b,c9b))
                                K=klass(a_ax,b_ax)
                                if K in found: continue
                                new2=[t for t in atoms2 if t not in (u,w)]
                                if len(set(atoms2))<8 or any(t in occ1 for t in new2) or not all(acc(t) for t in new2): continue
                                partial.add(K); tried+=1
                                outer=[mids1[i] for i in range(3) if i!=bi]+[m for m in mids2 if set(m)!={u,w}]
                                done=complete(occ1|set(atoms2),outer)
                                if done is not None:
                                    found[K]={'D1':sub(c10,O),'D2':sub(c10b,c9b),'a':a_ax,'b':b_ax,
                                              'core1':atoms1,'center':[x,y,*R],'core2':atoms2,'blades':done}
print(MODE,'部分配置を試した数',tried,' 角度の組（部分）',len(partial),' 組み上がった組',len(found))
for K,v in sorted(found.items(),key=lambda kv:str(kv[0])):
    print(' ⟨a,b⟩²=',K[0],' |a|²|b|²=',K[1],' 平行' if K[2] else '','  D1',v['D1'],'D2',v['D2'])
miss=[K for K in partial if K not in found]
print(' 部分だけで組み上がらなかった組',miss)
json.dump({str(k):v for k,v in found.items()},open(f'pt6_{MODE}.json','w'))

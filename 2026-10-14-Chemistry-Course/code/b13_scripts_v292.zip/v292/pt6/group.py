import sys, json; sys.path.insert(0,'.')
from zphi import *
F=json.load(open('pt6_6d.json'))
rows=[]
for k,v in F.items():
    a=tuple(map(tuple,v['a'])); b=tuple(map(tuple,v['b']))
    d=dot(a,b); X=zm(d,d); Y=zm(dot(a,a),dot(b,b))
    rows.append((X,Y,dot(a,a),dot(b,b),v['D1'],v['D2']))
# 角度の組：X1·Y2 = X2·Y1 なら同じ角（割り算なし）
cls=[]
for r in rows:
    for c in cls:
        if zm(r[0],c[0][1])==zm(c[0][0],r[1]): c.append(r); break
    else: cls.append([r])
print('角の種類',len(cls))
for c in sorted(cls,key=lambda c:-len(c)):
    X,Y=c[0][0],c[0][1]
    par = X==Y
    perp = X==(0,0)
    eq=[r for r in c if r[2]==r[3]]
    print(f'⟨a,b⟩²:|a|²|b|² = {X}:{Y}', '平行' if par else '直交' if perp else '', f' 配置の組 {len(c)}  うち |a|²=|b|² {len(eq)}')
    for r in c[:3]: print('    D1',r[4],'D2',r[5],'|a|²',r[2],'|b|²',r[3])

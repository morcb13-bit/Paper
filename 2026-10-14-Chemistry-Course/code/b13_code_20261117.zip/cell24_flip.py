# cell24_flip.py
# 世代の六角形を「向かい合う 2 点を軸に裏返す」操作が、正二十四胞体の対称として作れるか。
# 整数と加算・乗算・比較だけ。座標は 2 倍。
#
# ラベル（六角形の読み）: 世代 1 = C0 の L0、世代 2 の頂点 = u*v、世代 3 = u*u*v（u = (1,1,1,1)、2 倍座標）。
# レプトンの六角形: 0 nu_e=1, 1 nu_mu=u, 2 nu_tau=u^2, 3 e=-1, 4 mu=-u, 5 tau=-u^2
#
# 事前の基準（走らせる前に固定）
#  対称の総数: 正二十四胞体の頂点を頂点に移す一次の写し方を全部数え、1152 になること（道具の検定）。
#  FL1: mu と nu_mu を動かさず、e <-> tau（と nu_e <-> nu_tau）を入れ替える写し方の数。
#       回転（行列式 +1）と鏡映（-1）に分けて数える。回転が 0 なら NG。
#  FL2（集合版。厳密版は世代 2 の 8 頂点を全部止めると恒等写像しかないので不成立と事前に判定）:
#       FL1 の各写し方が、世代 2 の 8 頂点を世代 2 の中に、世代 1 と世代 3 を互いに移すか。
#       移すものについて、ラベルの写り方（世代 1 の (軸,符号) -> 世代 3 の (軸,符号)）を表にし、
#       「どの粒子も同じ名前のまま世代 1 <-> 3」（全ラベルで恒等）となるものが 1 つ以上あれば合格。
#       色の入れ替えを伴うものだけなら「色を入れ替えれば成立」と書き、ラベルが崩れるものだけなら NG。
#  対照: e の軸（nu_e と e を固定）・tau の軸（nu_tau と tau を固定）で同じ裏返しを作る写し方の数と、
#        それが入れ替える組の電荷の差（0 にならない組が必ず混ざること）。

from itertools import product


def qm(p, r):
    return (p[0]*r[0]-p[1]*r[1]-p[2]*r[2]-p[3]*r[3], p[0]*r[1]+p[1]*r[0]+p[2]*r[3]-p[3]*r[2],
            p[0]*r[2]-p[1]*r[3]+p[2]*r[0]+p[3]*r[1], p[0]*r[3]+p[1]*r[2]-p[2]*r[1]+p[3]*r[0])


def mul2(p, r):
    x = qm(p, r)
    assert all(t % 2 == 0 for t in x)
    return tuple(t // 2 for t in x)


neg = lambda p: tuple(-t for t in p)
dot = lambda a, b: sum(x * y for x, y in zip(a, b))
E = [tuple(2 if k == i else 0 for k in range(4)) for i in range(4)]
C0 = E + [neg(p) for p in E]
P = C0 + list(product((1, -1), repeat=4))
PS = set(P)
U = (1, 1, 1, 1)

# ラベル: 頂点 -> (軸, 符号, 世代)
LAB = {}
for i in range(4):
    for s in (1, -1):
        v = E[i] if s > 0 else neg(E[i])
        g2 = mul2(U, v)
        g3 = mul2(U, g2)
        LAB[v] = (i, s, 1)
        LAB[g2] = (i, s, 2)
        LAB[g3] = (i, s, 3)
assert len(LAB) == 24
POS = {lab: v for v, lab in LAB.items()}
C = [-3, 1, 1, 1]
charge = lambda lab: (3 * lab[1] + C[lab[0]]) // 2
NAME = {(0, 1): "nu", (0, -1): "e", (1, 1): "u赤", (2, 1): "u緑", (3, 1): "u青",
        (1, -1): "d赤", (2, -1): "d緑", (3, -1): "d青"}
GEN = {1: "1", 2: "2", 3: "3"}

# 対称の総当たり: 基底 E の像 (w0..w3) で決まる。M p = sum p_i * w_i / 2
def det4(m):
    # 整数の行列式（余因子展開）
    def d3(a):
        return (a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1]) - a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
                + a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]))
    tot = 0
    for c in range(4):
        minor = [[m[r][k] for k in range(4) if k != c] for r in range(1, 4)]
        tot += (-1) ** c * m[0][c] * d3(minor)
    return tot

syms = []
for w0 in P:
    if dot(w0, w0) != 4:
        continue
    for w1 in P:
        if dot(w1, w1) != 4 or dot(w0, w1) != 0:
            continue
        for w2 in P:
            if dot(w2, w2) != 4 or dot(w0, w2) != 0 or dot(w1, w2) != 0:
                continue
            for w3 in P:
                if dot(w3, w3) != 4 or dot(w0, w3) != 0 or dot(w1, w3) != 0 or dot(w2, w3) != 0:
                    continue
                W = (w0, w1, w2, w3)
                img = {}
                ok = True
                for p in P:
                    s = [sum(p[i] * W[i][k] for i in range(4)) for k in range(4)]
                    if any(x % 2 for x in s):
                        ok = False; break
                    q = tuple(x // 2 for x in s)
                    if q not in PS:
                        ok = False; break
                    img[p] = q
                if ok and len(set(img.values())) == 24:
                    d = det4([list(w) for w in W])  # 2 倍の基底なので 16 または -16
                    syms.append((img, 1 if d > 0 else -1))
print("対称の総数", len(syms), " 回転", sum(1 for _, d in syms if d > 0), " 鏡映", sum(1 for _, d in syms if d < 0))


def flips(fixed_pos):
    # レプトンの六角形で、位置 fixed_pos と fixed_pos+3 を動かさず、k -> 2*fixed_pos - k と入れ替える
    hexv = [POS[(0, 1, 1)], POS[(0, 1, 2)], POS[(0, 1, 3)], POS[(0, -1, 1)], POS[(0, -1, 2)], POS[(0, -1, 3)]]
    out = []
    for img, d in syms:
        if all(img[hexv[k]] == hexv[(2 * fixed_pos - k) % 6] for k in range(6)):
            out.append((img, d))
    return out, hexv

hexname = ["nu_e", "nu_mu", "nu_tau", "e", "mu", "tau"]
hexlab = [(0, 1, 1), (0, 1, 2), (0, 1, 3), (0, -1, 1), (0, -1, 2), (0, -1, 3)]
for fp, title in [(1, "FL1 mu の軸"), (0, "対照 e の軸"), (2, "対照 tau の軸")]:
    fl, hexv = flips(fp)
    rot = sum(1 for _, d in fl if d > 0)
    pairs = sorted({tuple(sorted((hexname[k], hexname[(2 * fp - k) % 6]))) for k in range(6) if k != (2 * fp - k) % 6})
    dq = sorted({abs(charge(hexlab[k]) - charge(hexlab[(2 * fp - k) % 6])) for k in range(6)})
    print(f"{title}: 写し方 {len(fl)}（回転 {rot}、鏡映 {len(fl) - rot}）  入れ替わる組 {pairs}  電荷の差 {dq}")
    if fp == 1:
        FL1 = fl

# FL2
print("FL2（mu の軸の写し方それぞれ）")
n_set = n_ident = n_color = 0
for img, d in FL1:
    gens = {}
    for v, lab in LAB.items():
        gens.setdefault((lab[2], LAB[img[v]][2]), 0)
        gens[(lab[2], LAB[img[v]][2])] += 1
    set_ok = gens.get((2, 2), 0) == 8 and gens.get((1, 3), 0) == 8 and gens.get((3, 1), 0) == 8
    if not set_ok:
        print("   回転" if d > 0 else "   鏡映", "世代の写り", dict(sorted(gens.items())))
        continue
    n_set += 1
    labmap = {}
    for i in range(4):
        for s in (1, -1):
            t = LAB[img[POS[(i, s, 1)]]]
            labmap[(i, s)] = (t[0], t[1])
    ident = all(labmap[k] == k for k in labmap)
    color_only = all(labmap[k][1] == k[1] and (k[0] == 0) == (labmap[k][0] == 0) for k in labmap)
    n_ident += ident
    n_color += (color_only and not ident)
    print("   回転" if d > 0 else "   鏡映", "世代 1<->3・2->2",
          "名前そのまま" if ident else ("色だけ入れ替え" if color_only else "名前が崩れる"),
          {NAME[k]: NAME[v] for k, v in labmap.items() if k != v})
print("FL2 集計: 世代の集合で合う", n_set, " 名前そのまま", n_ident, " 色だけ入れ替え", n_color)

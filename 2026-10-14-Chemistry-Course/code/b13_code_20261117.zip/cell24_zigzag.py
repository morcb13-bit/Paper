# cell24_zigzag.py
# へ の六角形（クオーク）は、三次元に写すと平らな正六角形に見えるか。
# 整数と加算・乗算・比較だけ。座標は 2 倍。六角形・角の候補・FL1 は cell24_he.py と同じ作り。
#
# 折れの向き: 辺 (a, b) と角 c について B = 2c - a - b（整数のベクトル）。
#
# 事前の基準（走らせる前に固定）
#  P1: 各六角形（赤・緑・青のクオーク）で、角の選び方 729 通りのうち、
#      6 本の B がすべて一本の向き n に平行（+n / -n）で、n が六角形の平面に直角（V0・V1 との内積 0）なものを数える。
#      0 なら NG。見つかったものは、+n と -n の並びが交互（ジグザグ）か、すべて同じ（王冠）か、その他かを数える。
#  P2: P1 の選び方が、FL1 の回転のどれかで自分自身に移る選び方（HE2 の 9 通り）に入っているかを数える。
#  P3（影の確認）: P1 の選び方で n の方向を落とした影（三次元）で、角が辺の真ん中に重なり、
#      6 頂点が平らな正六角形（隣の距離 4・一つ飛び 12・向かい 16 が影でも保たれる）になること。
#  対照: レプトンの六角形でも P1 を数える。でたらめに選んだときに P1 を満たす割合（数 / 729）。

import io, contextlib
from itertools import product
with contextlib.redirect_stdout(io.StringIO()):
    import cell24_he as H

dot = H.dot


def parallel(u, v):
    return all(u[i] * v[j] - u[j] * v[i] == 0 for i in range(4) for j in range(i + 1, 4))


def bend(a, c, b):
    return tuple(2 * c[i] - a[i] - b[i] for i in range(4))


rots = [W for W in H.FL1 if H.det4(W) > 0]


def invariant(W, name, C, V):
    vmap = {}
    for k in range(6):
        im = H.app(W, V[k])
        if im not in V:
            return False
        vmap[k] = V.index(im)
    for k in range(6):
        a, b = vmap[k], vmap[(k + 1) % 6]
        e = a if (a + 1) % 6 == b else b
        if H.app(W, C[k]) != C[e]:
            return False
    return True


summary = {}
for name, labs in H.hexes.items():
    V = [H.POS[l] for l in labs]
    found = []
    for ch in product(range(3), repeat=6):
        C = [H.cand[(name, k)][ch[k]] for k in range(6)]
        B = [bend(V[k], C[k], V[(k + 1) % 6]) for k in range(6)]
        n = B[0]
        if not all(parallel(n, b) for b in B):
            continue
        if dot(n, V[0]) != 0 or dot(n, V[1]) != 0:
            continue
        signs = [1 if dot(b, n) > 0 else -1 for b in B]
        kind = "ジグザグ" if all(signs[k] == -signs[(k + 1) % 6] for k in range(6)) else ("王冠" if len(set(signs)) == 1 else "その他")
        inv = any(invariant(W, name, C, V) for W in rots)
        # P3: n を落とした影。x -> |n|^2 x - (x・n) n （整数のまま、|n|^2 倍した影）
        nn = dot(n, n)
        sh = lambda x: tuple(nn * x[i] - dot(x, n) * n[i] for i in range(4))
        SV = [sh(v) for v in V]
        SC = [sh(c) for c in C]
        mid_ok = all(tuple(2 * SC[k][i] for i in range(4)) == tuple(SV[k][i] + SV[(k + 1) % 6][i] for i in range(4)) for k in range(6))
        d = lambda x, y: sum((p - q) ** 2 for p, q in zip(x, y))
        hex_ok = all(d(SV[k], SV[(k + 1) % 6]) == 4 * nn * nn and d(SV[k], SV[(k + 2) % 6]) == 12 * nn * nn
                     and d(SV[k], SV[(k + 3) % 6]) == 16 * nn * nn for k in range(6))
        found.append((ch, n, kind, inv, mid_ok and hex_ok))
    summary[name] = found
    kinds = {}
    for f in found:
        kinds[f[2]] = kinds.get(f[2], 0) + 1
    print(f"{name}: P1 {len(found)}/729  形 {kinds}  P2（回転で移り合う） {sum(1 for f in found if f[3])}"
          f"  P3（影が平らな正六角形・角が辺の真ん中） {sum(1 for f in found if f[4])}/{len(found)}")
    for f in found[:4]:
        print(f"    n = {f[1]}  {f[2]}  回転で移り合う {f[3]}")

q_ok = all(len(summary[n]) > 0 for n in summary if n != "レプトン")
print("判定", {"P1 クオーク 3 色とも": q_ok,
               "P2 回転で移り合うものあり（3 色とも）": all(any(f[3] for f in summary[n]) for n in summary if n != "レプトン"),
               "P3 すべて影で正六角形": all(f[4] for n in summary for f in summary[n])})

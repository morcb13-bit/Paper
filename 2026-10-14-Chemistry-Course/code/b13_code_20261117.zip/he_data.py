# 図のための整数データ（cell24_he.py と同じ作り）。回転 3（赤が自分自身に移る）を使う
import json, io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    import cell24_he as H
from itertools import product
lep = [H.POS[l] for l in H.hexes["レプトン"]]
red = [H.POS[l] for l in H.hexes["クオーク赤"]]
rots = [W for W in H.FL1 if H.det4(W) > 0]
W = next(W for W in rots if all(H.app(W, v) in red for v in red))
vmap = {k: red.index(H.app(W, red[k])) for k in range(6)}
# 赤の六角形で回転で移り合う角の選び方（最初の一つ）
for ch in product(range(3), repeat=6):
    C = [H.cand[("クオーク赤", k)][ch[k]] for k in range(6)]
    ok = all(H.app(W, C[k]) == C[(vmap[k] if (vmap[k] + 1) % 6 == vmap[(k + 1) % 6] else vmap[(k + 1) % 6])] for k in range(6))
    if ok: break
fixedC = [k for k in range(6) if H.app(W, C[k]) == C[k]]
E24 = [[a, b] for a in range(24) for b in range(a + 1, 24) if H.d2(H.P[a], H.P[b]) == 4]
out = {"P": H.P, "E": E24, "lep": [H.P.index(v) for v in lep], "red": [H.P.index(v) for v in red],
       "corner": C, "fixedC": fixedC, "W": W, "fixV": [1, 4]}
# 検算: W は lep を k -> 2-k、red を k -> 5-k に写す
assert all(H.app(W, lep[k]) == lep[(2 - k) % 6] for k in range(6))
assert all(H.app(W, red[k]) == red[(5 - k) % 6] for k in range(6))
print(json.dumps(out, separators=(",", ":")))
print("動かない角の辺", fixedC, file=__import__("sys").stderr)

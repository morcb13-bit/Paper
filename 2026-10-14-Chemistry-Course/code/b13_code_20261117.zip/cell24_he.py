# cell24_he.py
# 世代の六角形の辺を「へ」（直角に折れた 2 歩）として描き、ミューオンの軸の裏返し（FL1）がどう働くか。
# 整数と加算・乗算・比較だけ。座標は 2 倍。ラベルと FL1 の写し方は cell24_flip.py と同じ作り。
#
# へ の角: 辺 (a, b)（距離の 2 乗 4）に対し、(±1,±1,0,0) 形の点 c で d2(a,c) = d2(c,b) = 2 のもの。
#
# 事前の基準（走らせる前に固定）
#  HE0（道具）: どの辺にも角の候補がちょうど 3 つあること。角は辺の直線上にも六角形の平面上にもないこと（平らでない）。
#  HE1: FL1 の各写し方 g（回転 3・鏡映 3）について、レプトンの六角形とクオークの 3 本の六角形で、
#       g で動かない角の数と、それが乗る辺を数える。
#       予想（事前）: レプトンでは 0（動かないのは頂点 nu_mu と mu）、クオークでは「自分自身に裏返る 2 本の辺」の上にだけ出る。
#  HE2: 各六角形で、辺ごとに角を 1 つ選ぶ 3^6 = 729 通りのうち、g で全体が自分自身に移る選び方を数える。
#       クオークの 3 本すべてについて、少なくとも 1 つの回転 g で、
#       「g で移り合い、動かない点が角 2 つ（向かい合う辺の上）」となる選び方が 1 つ以上あれば合格。
#       レプトンでは「動かない点が頂点 2 つ（nu_mu, mu）で、角は動く」となる選び方があること。
#  対照: 729 通りのうち g で移り合う選び方の割合（でたらめに選んだときに合う割合）。

from itertools import product


def qm(p, r):
    return (p[0]*r[0]-p[1]*r[1]-p[2]*r[2]-p[3]*r[3], p[0]*r[1]+p[1]*r[0]+p[2]*r[3]-p[3]*r[2],
            p[0]*r[2]-p[1]*r[3]+p[2]*r[0]+p[3]*r[1], p[0]*r[3]+p[1]*r[2]-p[2]*r[1]+p[3]*r[0])


def mul2(p, r):
    x = qm(p, r)
    assert all(t % 2 == 0 for t in x)
    return tuple(t // 2 for t in x)


neg = lambda p: tuple(-t for t in p)
dot = lambda a, b: sum(x * y for x, y in zip(a, b))
d2 = lambda a, b: sum((x - y) ** 2 for x, y in zip(a, b))
E = [tuple(2 if k == i else 0 for k in range(4)) for i in range(4)]
C0 = E + [neg(p) for p in E]
P = C0 + list(product((1, -1), repeat=4))
PS = set(P)
K = sorted({tuple(v) for v in product((-1, 0, 1), repeat=4) if sum(1 for x in v if x) == 2})
assert len(K) == 24
U = (1, 1, 1, 1)

LAB = {}
for i in range(4):
    for s in (1, -1):
        v = E[i] if s > 0 else neg(E[i])
        g2 = mul2(U, v); g3 = mul2(U, g2)
        LAB[v] = (i, s, 1); LAB[g2] = (i, s, 2); LAB[g3] = (i, s, 3)
POS = {lab: v for v, lab in LAB.items()}

# 対称（基底の像 W で持つ）
syms = []
for W in product(P, repeat=4):
    if any(dot(W[i], W[j]) != (4 if i == j else 0) for i in range(4) for j in range(i, 4)):
        continue
    ok = True
    for p in P:
        s = [sum(p[i] * W[i][k] for i in range(4)) for k in range(4)]
        if any(x % 2 for x in s) or tuple(x // 2 for x in s) not in PS:
            ok = False; break
    if ok:
        syms.append(W)
assert len(syms) == 1152


def app(W, p):
    s = [sum(p[i] * W[i][k] for i in range(4)) for k in range(4)]
    if any(x % 2 for x in s):
        return None
    return tuple(x // 2 for x in s)


def det3(a):
    return (a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1]) - a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
            + a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]))


def det4(m):
    return sum((-1) ** c * m[0][c] * det3([[m[r][k] for k in range(4) if k != c] for r in range(1, 4)]) for c in range(4))


def gram_det(vs):
    return det3([[dot(a, b) for b in vs] for a in vs])


hexes = {"レプトン": [(0, 1, 1), (0, 1, 2), (0, 1, 3), (0, -1, 1), (0, -1, 2), (0, -1, 3)]}
for i, c in [(1, "赤"), (2, "緑"), (3, "青")]:
    hexes["クオーク" + c] = [(i, 1, 1), (i, 1, 2), (i, 1, 3), (i, -1, 1), (i, -1, 2), (i, -1, 3)]
NM = ["上1", "上2", "上3", "下1", "下2", "下3"]

# HE0
cand = {}
counts = set(); off_line = off_plane = total = 0
for name, labs in hexes.items():
    V = [POS[l] for l in labs]
    for k in range(6):
        a, b = V[k], V[(k + 1) % 6]
        assert d2(a, b) == 4
        cs = [c for c in K if d2(a, c) == 2 and d2(c, b) == 2]
        counts.add(len(cs))
        cand[(name, k)] = cs
        for c in cs:
            total += 1
            off_line += gram_det([a, b, c]) != 0          # a, b, c が一次独立 ⇒ 原点・a・b の平面にない
            off_plane += gram_det([V[0], V[1], c]) != 0     # 六角形の平面（V0, V1 が張る）にない
print("HE0 角の候補の数", counts, " 角の総数", total, " 六角形の平面から外れる角", off_plane)

# FL1 の写し方
lep = [POS[l] for l in hexes["レプトン"]]
FL1 = [W for W in syms if all(app(W, lep[k]) == lep[(2 - k) % 6] for k in range(6))]
print("FL1 の写し方", len(FL1), " 回転", sum(1 for W in FL1 if det4(W) > 0))

res = {}
for gi, W in enumerate(FL1):
    kind = "回転" if det4(W) > 0 else "鏡映"
    for name, labs in hexes.items():
        V = [POS[l] for l in labs]
        vmap = {k: V.index(app(W, V[k])) if app(W, V[k]) in V else None for k in range(6)}
        if None in vmap.values():
            res[(gi, name)] = None
            print(f"  {kind}{gi} {name}: 六角形が自分自身に移らない")
            continue
        # HE1: 動かない角
        fixed = [(k, c) for k in range(6) for c in cand[(name, k)] if app(W, c) == c]
        fixed_edges = sorted({k for k, _ in fixed})
        fixed_verts = [k for k in range(6) if vmap[k] == k]
        # HE2: 辺ごとに角を 1 つ選ぶ 729 通り
        inv = good = 0
        for choice in product(range(3), repeat=6):
            C = [cand[(name, k)][choice[k]] for k in range(6)]
            ok = True
            for k in range(6):
                a, b = vmap[k], vmap[(k + 1) % 6]
                e = a if (a + 1) % 6 == b else b  # 移った先の辺の番号
                if app(W, C[k]) != C[e]:
                    ok = False; break
            if not ok:
                continue
            inv += 1
            fc = [k for k in range(6) if app(W, C[k]) == C[k]]
            if name == "レプトン":
                good += (len(fc) == 0 and len(fixed_verts) == 2)
            else:
                good += (len(fc) == 2 and len(fixed_verts) == 0 and (fc[1] - fc[0]) % 6 == 3)
        res[(gi, name)] = (kind, inv, good)
        ev = ", ".join(f"{NM[k]}-{NM[(k + 1) % 6]}" for k in fixed_edges)
        print(f"  {kind}{gi} {name}: 動かない頂点 {[NM[k] for k in fixed_verts]}  動かない角 {len(fixed)}（辺 {ev or 'なし'}）"
              f"  移り合う選び方 {inv}/729  そのうち基準の形 {good}")

# 判定
he1_lep = all(res[(gi, "レプトン")] is not None for gi in range(len(FL1)))
he2_q = all(any(res[(gi, n)] and res[(gi, n)][0] == "回転" and res[(gi, n)][2] > 0 for gi in range(len(FL1)))
            for n in hexes if n != "レプトン")
he2_l = any(res[(gi, "レプトン")][2] > 0 for gi in range(len(FL1)))
print("判定", {"HE2 クオーク（回転で角の軸）": he2_q, "HE2 レプトン（頂点の軸）": he2_l})

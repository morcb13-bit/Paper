"""
demo.py
=======
CLI demo for B13 / BASE3120 library.

Run:
    python -m b13phase.demo
"""

from __future__ import annotations
import math
from .constants import BASE, INT64_MAX, Z13_STAR
from .phase_digits import digits_from_int, digits_to_int, digits_add
from .phase_packed_u64 import U64_DIGITS, pack_u64_digits, unpack_u64_digits, add_u64_packed
from .evaluator_proto import fractal_cos_sin_proto, norm_ratio
from .level0_table import verify_canonical, coset_of
from .z13_structure import (coset_pattern, verify_4h_avoidance,
                             phi_residue_orbit, delta_s_orbit)
from .truncated_icosahedron import (R, R_SQ, vertex_coords_float,
                                     vertex_phase_index, central_angle,
                                     opposite_face_angles)
from .great_circle import (great_circle_traversal, theta_values_degrees,
                            phi_arithmetic_verify)


def total_subdivisions(n_digits: int) -> int:
    return BASE ** n_digits


def show_resolution(max_digits: int = 8) -> None:
    print("=== Resolution table (BASE=3120) ===")
    print(f"{'digits':>6} {'BASE^digits':>28} {'int64':>6} {'deg/step':>14}")
    print("-" * 64)
    for n in range(1, max_digits + 1):
        total = total_subdivisions(n)
        ok = total <= INT64_MAX
        deg = 360.0 / total
        print(f"{n:6d} {total:28,d} {('OK' if ok else 'NO'):>6} {deg:14.2e}")
        if not ok:
            break
    print()


def demo_digits() -> None:
    print("=== Digit-array phase demo ===")
    n = 6
    total = total_subdivisions(n)
    print(f"digits={n}, total indices=BASE^digits={total:,}")
    idx = 123456789
    d = digits_from_int(idx, n)
    back = digits_to_int(d)
    print("idx:", idx)
    print("digits(MSD->LSD):", d)
    print("roundtrip:", back, "(ok)" if back == idx else "(mismatch)")
    a = digits_from_int(1000, n)
    b = digits_from_int(2500, n)
    s, carry = digits_add(a, b)
    print("1000 + 2500 in radix-3120 =>", digits_to_int(s), "carry:", carry)
    print()


def demo_packed_u64() -> None:
    print("=== Packed-u64 phase demo (5 digits) ===")
    d = [1, 2, 3, 4, 5]
    x = pack_u64_digits(d)
    d2 = unpack_u64_digits(x)
    print("digits:", d, "packed:", x, "unpacked:", d2)
    a = pack_u64_digits([0, 0, 0, 0, 3000])
    b = pack_u64_digits([0, 0, 0, 0, 500])
    s, carry = add_u64_packed(a, b)
    print("3000+500 =>", unpack_u64_digits(s), "carry:", carry)
    print()


def demo_eval() -> None:
    print("=== Prototype evaluator demo ===")
    n = 3
    total = total_subdivisions(n)
    checkpoints = [
        (0,           "0°"),
        (total // 4,  "90°"),
        (total // 2,  "180°"),
        (total*3//4,  "270°"),
    ]
    print(f"digits={n}, total={total:,}, deg/step={360.0/total:.2e}")
    print(f"{'angle':>6} {'idx':>18} {'digits':>22} {'cos':>8} {'sin':>8} {'|v|²/B²':>10}")
    print("-" * 80)
    for idx, label in checkpoints:
        d = digits_from_int(idx, n)
        cx, cy = fractal_cos_sin_proto(d)
        ratio = norm_ratio(cx, cy)
        print(f"{label:>6} {idx:18,d} {str(d):>22} {cx:8d} {cy:8d} {ratio:10.6f}")
    print()


def demo_z13() -> None:
    print("=== Z₁₃ structure ===")
    print("Z₁₃* cyclic order (2^k mod 13):", Z13_STAR)
    print("Coset pattern:", coset_pattern())
    print("φ-residue orbit (×8):", phi_residue_orbit())
    print("δₛ-residue orbit (×5):", delta_s_orbit())
    ok = verify_4h_avoidance(200)
    print(f"Fib/Pell 4H-avoidance (n=0..200): {'PASS' if ok else 'FAIL'}")
    print()


def demo_vertices() -> None:
    print("=== Truncated icosahedron vertices ===")
    print(f"Circumradius R = {R:.6f}")
    print(f"R² = (9φ+10)/4 = {R_SQ:.6f}")
    print()
    print("Sample vertices f(2^k mod 13, j):")
    print(f"{'k':>3} {'g=2^k':>7} {'coset':>5} {'j':>3} "
          f"{'phase_idx':>10} {'x':>10} {'y':>10} {'z':>10}")
    print("-" * 65)
    for k in [0, 1, 2, 3]:
        g = Z13_STAR[k]
        c = coset_of(g)
        for j in [0, 1]:
            idx = vertex_phase_index(k, j)
            x, y, z = vertex_coords_float(k, j)
            print(f"{k:3d} {g:7d} {c:>5} {j:3d} {idx:10d} "
                  f"{x:10.4f} {y:10.4f} {z:10.4f}")
    print()
    angles = opposite_face_angles()
    print(f"Pentagon opposite pair θ ≈ {angles['pentagon_opposite_deg']:.2f}°")
    print(f"Hexagon opposite pair  θ ≈ {angles['hexagon_opposite_deg']:.2f}°")
    print()


def demo_great_circle() -> None:
    print("=== Great circle analysis (Observation R) ===")
    thetas = theta_values_degrees()
    print(f"θ_a  (edge):          {thetas['theta_a_deg']:.4f}°")
    print(f"θ_h5 (pent. height):  {thetas['theta_h5_deg']:.4f}°")
    print(f"θ_h6 (hex. height):   {thetas['theta_h6_deg']:.4f}°")
    print(f"Sum (2θ_a+4θ_h5+4θ_h6): {thetas['sum_check']:.4f}° (expected 360°)")
    print()
    gc = great_circle_traversal()
    print(f"Arc lengths:")
    print(f"  arc_a  × 2 = {gc['arc_a']:.6f} × 2 = {gc['arc_a']*2:.6f}")
    print(f"  arc_h5 × 4 = {gc['arc_h5']:.6f} × 4 = {gc['arc_h5']*4:.6f}")
    print(f"  arc_h6 × 4 = {gc['arc_h6']:.6f} × 4 = {gc['arc_h6']*4:.6f}")
    print(f"  Total:       {gc['total']:.6f}")
    print(f"  2πR:         {gc['theoretical']:.6f}")
    print(f"  Error:       {gc['error_pct']:.4f}%")
    print(f"  Elements:    {gc['elements']} (= decagon vertices)")
    print()
    print("=== φ-arithmetic verification ===")
    pa = phi_arithmetic_verify()
    for key in ["cos_a", "cos_h5", "cos_h6"]:
        v = pa[key]
        status = "✓" if v["match"] else "✗"
        print(f"  {key}: {v['phi_formula']} = {v['phi_eval']:.8f} "
              f"(exact={v['exact']:.8f}) {status}")
    print(f"  Denominator: {pa['denom_109']}")
    print()


def demo_level0_table() -> None:
    print("=== Level0 table verification ===")
    ok = verify_canonical()
    print(f"Canonical values: {'PASS' if ok else 'FAIL'}")
    from .level0_table import COS_TABLE, SIN_TABLE
    # Show pentagon-relevant angles
    angles = [
        (BASE * 36 // 360,  "36°  cos≈φ/2"),
        (BASE * 72 // 360,  "72°"),
        (BASE * 108 // 360, "108°"),
        (BASE * 144 // 360, "144°"),
    ]
    print(f"{'angle':>8} {'idx':>6} {'cos':>8} {'sin':>8} {'|v|²/B²':>10}")
    for idx, label in angles:
        cx, cy = COS_TABLE[idx], SIN_TABLE[idx]
        ratio = (cx*cx + cy*cy) / (BASE*BASE)
        print(f"{label:>12} {idx:6d} {cx:8d} {cy:8d} {ratio:10.6f}")
    print()


def main() -> None:
    show_resolution()
    demo_digits()
    demo_packed_u64()
    demo_eval()
    demo_level0_table()
    demo_z13()
    demo_vertices()
    demo_great_circle()


if __name__ == "__main__":
    main()

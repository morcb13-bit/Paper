# 火星の翼（大きさ 1 と 4）の図用データ：横から見て、奥行き |z| ≦ 6 の生きている点を升目にまとめる。
# 升目の値＝その升目の点の差（A−B）の和。生きている点が一つもない升目は空。こまは 4 手番ごと（60 こま）。
import json, base64, numpy as np, sys
OUT={}
for s,cell in ((1,2),(4,4)):
    V=json.load(open('mars%d/glide_view_wing+.json'%s))
    N=V['N']; T=V['T']
    pos=np.frombuffer(base64.b64decode(V['pos']),np.int16).reshape(N,3).astype(np.int64)
    H=np.frombuffer(base64.b64decode(V['h']),np.int8).reshape(T,N)
    sel=np.abs(pos[:,2])<=60
    fr=[i for i in range(T) if V['t'][i]%4==0]
    live=(H[fr][:,sel]!=-128)
    P=pos[sel]; xs=P[:,0][live.any(0)]; ys=P[:,1][live.any(0)]
    x0=(xs.min()//(cell*10))*cell*10; x1=xs.max(); y0=(ys.min()//(cell*10))*cell*10; y1=ys.max()
    W=int((x1-x0)//(cell*10))+1; Hh=int((y1-y0)//(cell*10))+1
    ci=((P[:,0]-x0)//(cell*10)).astype(int); cj=((P[:,1]-y0)//(cell*10)).astype(int); cid=cj*W+ci
    frames=[]
    for f in fr:
        h=H[f][sel].astype(np.int64); m=h!=-128
        sm=np.zeros(W*Hh,np.int64); np.add.at(sm,cid[m],h[m])
        cnt=np.zeros(W*Hh,np.int64); np.add.at(cnt,cid[m],1)
        v=np.clip(sm,-127,127).astype(np.int8); v[cnt==0]=-128
        frames.append(v)
    A=np.stack(frames)
    OUT['s%d'%s]=dict(cell=cell,x0=int(x0)//10,y0=int(y0)//10,W=W,H=Hh,T=len(fr),t=[V['t'][i] for i in fr],
        cx=[V['cx'][i] for i in fr],cy=[V['cy'][i] for i in fr],alive=[V['alive'][i] for i in fr],
        d=base64.b64encode(A.tobytes()).decode())
    print(s,'cells',W,'x',Hh,'frames',len(fr),'bytes',A.size,'last',OUT['s%d'%s]['t'][-1],OUT['s%d'%s]['cx'][-1],OUT['s%d'%s]['cy'][-1])
json.dump(OUT,open('mars_fig_data.json','w'))

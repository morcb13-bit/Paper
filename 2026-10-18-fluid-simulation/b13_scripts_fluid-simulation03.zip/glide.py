# グライダーの自由飛行：受けた運動量と重さで物体が自分の進み方を変える。重さ MASS、毎手番の重さ G、初めの速さは 2 手番で 1。
# 位置は、運動量を溜めて MASS に届くたびに 1 進める（足し算と繰り上がりだけ）。
# 事前に固定した基準：F1 空気の帳簿（あり／なし）が毎手番一致、F2 同じ手番数で、上向きに傾けた翼の降りた量 |y| が球より小さい。
# 影響が届いたところにだけ担体を足し、影響が 1 以下になった端は外す。規則は moving.py のまま（担体のクセはそのまま）。
# 物体あり A と物体なし B を同じ点の上で走らせ、影響＝点ごとの粒子数の差 |ΣnA − ΣnB| とする。
# 端（まだ無い隣を持つ点）で影響 > 1 なら、その隣を窓から足す（静かな空気 4 個ずつで、A・B 同じ）。
# 端で影響 ≦ 1 の点は外す（物体の近く R²<14² は外さない）。外した点は、また影響が来れば足し直す。
# まだ無い点へ渡ろうとした粒子は跳ね返る（A・B 同じ）。
# 事前に固定した基準：
#   G3 メモリ：物体が進む後半の 4 区間（各 1/8 行程）で、生きている点の数の最大 ≦ 2×最小
#   G4 抵抗：A の物体が空気に渡した x 方向の運動量（1 手番あたり）が正で、速い順 K=1,2,4,8 に大きい（M1 と同じ順）
#   W1 翼：空気に渡した y 方向の運動量の符号が M1 と同じ（wing+ は負＝翼は上へ押される、wing− は正）。球は |y| が x の 1/10 未満
#   帳簿：A・B それぞれ、粒子数と運動量が、跳ね返り・押し出し・足した点・外した点を数えて毎手番一致
import numpy as np, sys, json, time
from carrier3d_np import accept, par, zm, sgn, build
from tunnel3d import LAB, ADJ, ADJ2, OPP
from tunnel_mirror import MIR
TSTEPS=int(sys.argv[1]); DIST=0; KS=1; MASS=int(sys.argv[2]); SHAPE=sys.argv[3] if len(sys.argv)>3 else 'ball'; R_BODY=64
import os; SC=int(os.environ.get('SCALE','1'))   # 翼の大きさの倍率（既定 1 は v294 と同じ）
KEEP=196 if SHAPE=='ball' else 484*SC*SC
STEPS=np.concatenate([np.eye(6,dtype=np.int64),-np.eye(6,dtype=np.int64)])
phi=(1+5**0.5)/2
def r2(x): return zm(x[:,0],x[:,0])+zm(x[:,1],x[:,1])+zm(x[:,2],x[:,2])
V0,_=build(lambda x: sgn(r2(x)-np.array([256 if SHAPE=='ball' else 576*SC*SC,0]))<0)   # 球は半径 16、翼は半径 24 から始める
addr=[]; idx={}; NB=[]
def add_points(new):
    start=len(addr)
    for a in new: idx[tuple(int(v) for v in a)]=len(addr); addr.append(np.array(a)); NB.append([-1]*12)
    A=np.array(new); newi=list(range(start,len(addr)))
    for k in range(12):
        cand=A+STEPS[k]; ok,_=accept(cand)
        for j,v in enumerate(newi):
            if not ok[j]: continue
            w=idx.get(tuple(int(x) for x in cand[j]))
            if w is None: NB[v][k]=-2
            else: NB[v][k]=w; NB[w][OPP[k]]=v
    return newi
add_points(list(V0)); N=len(addr)
alive=np.ones(N,bool); nA=np.full((N,12),4,np.int64); nB=nA.copy()
cx=0; cy=0
def xpar_all(): return par(np.array(addr))
XP=xpar_all()
def in_body(ix):
    X=XP[ix]; dx=X[:,0]-np.array([cx,0]); dy_=X[:,1]-np.array([cy,0])
    if SHAPE=='ball':
        return sgn(zm(dx,dx)+zm(dy_,dy_)+zm(X[:,2],X[:,2])-np.array([R_BODY,0]))<0
    # 翼（moving.py の楕円体と同じ）：(u/5)²/12² + (w/5)²/2.5² + z²/18² < 1、u=4dx+3sY, w=−3s·dx+4Y
    sg=1 if SHAPE=='wing+' else -1; Y=dy_; Zc=X[:,2]
    near_=(sgn(dx-np.array([20*SC,0]))<0)&(sgn(dx+np.array([20*SC,0]))>0)&(sgn(Y-np.array([20*SC,0]))<0)&(sgn(Y+np.array([20*SC,0]))>0)&(sgn(Zc-np.array([20*SC,0]))<0)&(sgn(Zc+np.array([20*SC,0]))>0)
    out=np.zeros(len(ix),bool); w_=np.where(near_)[0]
    if len(w_)==0: return out
    dxo=dx[w_].astype(object); Yo=Y[w_].astype(object); Zo=Zc[w_].astype(object)
    u=4*dxo+sg*3*Yo; w=-sg*3*dxo+4*Yo; A,B_,C_=144*SC*SC,25*SC*SC,324*SC*SC
    val=zm(u,u)*(B_*C_)+zm(w,w)*(4*A*C_)+zm(Zo,Zo)*(25*A*B_)-np.array([25*A*B_*C_,0],dtype=object)
    p,q=val[:,0],val[:,1]; Aa=2*p+q
    out[w_]=np.array([(a<=0 and b<=0 and not(a==0 and b==0)) or (a>0 and b<0 and a*a<5*b*b) or (a<0 and b>0 and a*a>5*b*b) for a,b in zip(Aa,q)],bool)
    return out
def near_body(ix):
    X=XP[ix]; dx=X[:,0]-np.array([cx,0]); dy_=X[:,1]-np.array([cy,0])
    return sgn(zm(dx,dx)+zm(dy_,dy_)+zm(X[:,2],X[:,2])-np.array([KEEP,0]))<0
def P(n): return np.array([[(n*LAB[:,a,0]).sum(),(n*LAB[:,a,1]).sum()] for a in range(3)])
def dP(cnt,k0,k1): return np.array([[(cnt*(LAB[k1,a,0]-LAB[k0,a,0])).sum(),(cnt*(LAB[k1,a,1]-LAB[k0,a,1])).sum()] for a in range(3)])
def collide(n,c):
    Pp=np.minimum(n[:,0:6],n[:,6:12]); n[:,0:6]-=Pp; n[:,6:12]-=Pp
    for a in range(6):
        others=[b for b in range(6) if b!=a]; b=others[(c+a)%5]; n[:,b]+=Pp[:,a]; n[:,b+6]+=Pp[:,a]
XNEG=np.array([sgn(LAB[k,0][None])[0]<0 for k in range(12)]); XPOS=np.array([sgn(LAB[k,0][None])[0]>0 for k in range(12)])
YNEG=np.array([sgn(LAB[k,1][None])[0]<0 for k in range(12)]); YPOS=np.array([sgn(LAB[k,1][None])[0]>0 for k in range(12)])
G=int(sys.argv[4])                                   # 重さ（毎手番、下向きに足す運動量）
pb=np.array([[MASS//2,0],[0,0],[0,0]],dtype=object)  # 物体の運動量（Z[φ] の整数の組）。初めの速さは 2 手番で 1
acc=np.array([[0,0],[0,0]],dtype=object)             # 位置の繰り上がりのための溜め（x, y）
def zge(z,m): return sgn(np.array([[z[0]-m,z[1]]]))[0]>=0
def zle(z,m): return sgn(np.array([[z[0]+m,z[1]]]))[0]<=0
def effnb():
    nb=np.array(NB); live=nb>=0
    nb2=nb.copy(); nb2[live & ~alive[np.maximum(nb,0)]]=-2
    return nb2
bodyA=np.zeros(len(addr),bool); bodyA[:]=in_body(np.arange(len(addr))); nA[bodyA]=0
ledA=dict(M=int(nA[alive].sum()),P=P(nA[alive])); ledB=dict(M=int(nB[alive].sum()),P=P(nB[alive]))
import os
FR=os.environ.get('FRAMES')=='1'; FRAMES=[]
okA=okB=True; rec=[]; t=0; t0=time.time(); total_steps=DIST*KS
while t<TSTEPS:
    t+=1; c=t%5
    def grow_arrays(newi):
        global nA,nB,alive,XP,bodyA
        k=len(newi)
        nA=np.vstack([nA,np.full((k,12),4,np.int64)]); nB=np.vstack([nB,np.full((k,12),4,np.int64)])
        alive=np.concatenate([alive,np.ones(k,bool)]); XP=np.concatenate([XP,par(np.array([addr[i] for i in newi]))])
        bodyA=np.concatenate([bodyA,np.zeros(k,bool)])
    def revive(ix):
        global alive
        ix=np.unique(np.array(ix,int)); ix=ix[~alive[ix]]
        if len(ix): alive[ix]=True; nA[ix]=4; nB[ix]=4; ledA['M']+=48*len(ix); ledB['M']+=48*len(ix)
    dpush=np.zeros((3,2),np.int64)
    moves=[]
    acc=acc+pb[:2]
    if zge(acc[0],MASS): acc[0]=acc[0]-np.array([MASS,0],dtype=object); moves.append((0,1))
    elif zle(acc[0],MASS): acc[0]=acc[0]+np.array([MASS,0],dtype=object); moves.append((0,-1))
    if zge(acc[1],MASS): acc[1]=acc[1]-np.array([MASS,0],dtype=object); moves.append((1,1))
    elif zle(acc[1],MASS): acc[1]=acc[1]+np.array([MASS,0],dtype=object); moves.append((1,-1))
    for ax,sgm in moves:
        if ax==0: cx+=sgm
        else: cy+=sgm
        # 物体の新しい範囲とその隣を用意する
        for _ in range(4):
            need=set()
            for v in np.where(alive)[0][near_body(np.where(alive)[0])]:
                for k in range(12):
                    if NB[v][k]==-2: need.add(tuple(int(x) for x in addr[v]+STEPS[k]))
                    elif NB[v][k]>=0 and not alive[NB[v][k]]: revive([NB[v][k]])
            need=[np.array(q) for q in need if q not in idx]
            if not need: break
            ni=add_points(need); grow_arrays(ni); ledA['M']+=48*len(ni); ledB['M']+=48*len(ni)
        newb=alive & in_body(np.arange(len(addr))); bodyA=newb
        nb=effnb()
        back=(XNEG if sgm>0 else XPOS) if ax==0 else (YNEG if sgm>0 else YPOS)   # 進む向きと逆を向く粒子は鏡で向きを返す
        for _ in range(20):
            left=np.where(bodyA&(nA.sum(1)>0))[0]
            if len(left)==0: break
            for v in left:
                for k in range(12):
                    cc=nA[v,k]
                    if cc==0: continue
                    k2=MIR[ax][k] if back[k] else k
                    cand=[o for o in [k2]+list(ADJ[k2])+list(ADJ2[k2])+[OPP[k2]] if nb[v,o]>=0]
                    if not cand: continue
                    dest=next((nb[v,o] for o in cand if not bodyA[nb[v,o]]),nb[v,cand[0]])
                    nA[dest,k2]+=cc; nA[v,k]=0; dpush+=dP(np.array([cc]),np.array([k]),np.array([k2]))
    ledA['P']=ledA['P']+dpush   # 一手番の押し出しをまとめて一度だけ帳簿に足す
    # 衝突（生きている点）
    collide(nA,c); collide(nB,c)
    # 作り足し：端で影響 > 1
    nb=effnb(); infl=np.abs(nA.sum(1)-nB.sum(1)); front=alive&(nb==-2).any(1)
    grow=np.where(front&(infl>1))[0]; need=set(); rv=[]
    for v in grow:
        for k in range(12):
            if NB[v][k]==-2: need.add(tuple(int(x) for x in addr[v]+STEPS[k]))
            elif NB[v][k]>=0 and not alive[NB[v][k]]: rv.append(NB[v][k])
    revive(rv)
    need=[np.array(q) for q in need if q not in idx]
    if need: ni=add_points(need); grow_arrays(ni); ledA['M']+=48*len(ni); ledB['M']+=48*len(ni)
    # 外す：端で影響 ≦ 1、物体から離れている
    nb=effnb(); front=alive&(nb==-2).any(1); infl=np.abs(nA.sum(1)-nB.sum(1))
    drop=np.where(front&(infl<=1)&~near_body(np.arange(len(addr))))[0]
    if len(drop):
        ledA['M']-=int(nA[drop].sum()); ledA['P']=ledA['P']-P(nA[drop]); ledB['M']-=int(nB[drop].sum()); ledB['P']=ledB['P']-P(nB[drop])
        alive[drop]=False
    # 渡り
    nb=effnb(); V_=len(addr); vv=np.arange(V_); dBounceA=np.zeros((3,2),np.int64); dBounceB=np.zeros((3,2),np.int64)
    tv=np.full((V_,12),-1); tk=np.tile(np.arange(12),(V_,1)); bnc=np.zeros((V_,12),bool)
    for k in range(12):
        done=np.zeros(V_,bool)
        for o in [k]+list(np.roll(ADJ[k],-c)):
            col=nb[:,o]; m=(~done)&(col!=-1)
            tv[m,k]=np.where(col[m]>=0,col[m],-2); done|=m
        m=~done; tv[m,k]=-2
    bnc=tv<0; tv=np.where(bnc,vv[:,None],tv); tk=np.where(bnc,OPP[tk],tk)
    hitb=bodyA[tv]&~bnc
    tvA=np.where(hitb,vv[:,None],tv); tkA=np.where(hitb,OPP[np.tile(np.arange(12),(V_,1))],tk)
    labs=np.tile(np.arange(12),(V_,1)); al=alive[:,None].repeat(12,1)
    MA=int(nA[alive].sum()); PA=P(nA[alive]); MB=int(nB[alive].sum()); PB=P(nB[alive])
    dA=dP(nA[al&(bnc|hitb)],labs[al&(bnc|hitb)],tkA[al&(bnc|hitb)]); dBd=dP(nA[al&hitb],labs[al&hitb],tkA[al&hitb])
    dB=dP(nB[al&bnc],labs[al&bnc],tk[al&bnc])
    newA=np.zeros(V_*12,np.int64); np.add.at(newA,(tvA*12+tkA)[al],nA[al]); nA=newA.reshape(V_,12)
    newB=np.zeros(V_*12,np.int64); np.add.at(newB,(tv*12+tk)[al],nB[al]); nB=newB.reshape(V_,12)
    ledA['P']=ledA['P']+dA; ledB['P']=ledB['P']+dB
    okA&=bool(int(nA[alive].sum())==ledA['M'] and np.array_equal(P(nA[alive]),ledA['P']))
    okB&=bool(int(nB[alive].sum())==ledB['M'] and np.array_equal(P(nB[alive]),ledB['P']))
    if FR and t%2==0:
        d_=nA.sum(1)-nB.sum(1); fr=np.full(len(addr),-128,np.int16); fr[alive]=np.clip(d_[alive],-127,127); FRAMES.append((t,cx,fr.astype(np.int8),cy))
    imp=-(dBd+dpush)                                         # 空気から物体が受けた運動量
    pb=pb+imp.astype(object); pb[1]=pb[1]-np.array([G,0],dtype=object)
    drag=(dBd+dpush)[0]; dy=(dBd+dpush)[1]; rec.append(dict(t=t,cx=cx,cy=cy,px=float(pb[0][0]+pb[0][1]*phi),py=float(pb[1][0]+pb[1][1]*phi),alive=int(alive.sum()),made=len(addr),dx=[int(drag[0]),int(drag[1])],dy=[int(dy[0]),int(dy[1])]))
    if t%20==0: print(SHAPE,'t',t,'x',cx,'y',cy,'px',int(pb[0][0]+pb[0][1]*phi),'py',int(pb[1][0]+pb[1][1]*phi),'生きている点',int(alive.sum()),'作った点',len(addr),'帳簿',okA,okB,round(time.time()-t0),flush=True)
# 判定
print(SHAPE,'帳簿 A',okA,'B',okB,'終わりの位置 x',cx,'y',cy,'作った点',len(addr),'生きている点の最大',max(r['alive'] for r in rec))
json.dump(dict(shape=SHAPE,mass=MASS,G=G,okA=okA,okB=okB,rec=rec),open('glide_%s.json'%SHAPE if (SC==1 and MASS==2000000) else 'glide_%s_s%d_m%d.json'%(SHAPE,SC,MASS),'w'))
if FR:
    import base64
    Nn=len(addr); Xf=(XP[...,0]+XP[...,1]*phi); pos=np.round(Xf*10).astype(np.int16)
    H=np.full((len(FRAMES),Nn),-128,np.int8)
    for i,(_,_,fr,_) in enumerate(FRAMES): H[i,:len(fr)]=fr
    json.dump(dict(N=Nn,T=len(FRAMES),t=[f[0] for f in FRAMES],cx=[f[1] for f in FRAMES],cy=[f[3] for f in FRAMES],alive=[int((f[2]!=-128).sum()) for f in FRAMES],
                   made=[int(len(f[2])) for f in FRAMES],pos=base64.b64encode(pos.tobytes()).decode(),h=base64.b64encode(H.tobytes()).decode()),open('glide_view_%s.json'%SHAPE,'w'))

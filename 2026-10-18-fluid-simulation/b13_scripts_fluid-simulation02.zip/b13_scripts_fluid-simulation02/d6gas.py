# 6 次元の担体の上の空気。粒子は二つの軸にまたがる斜めの一歩（±e_i ± e_j、60 通り）で進む。整数だけ。
# 静かな空気＝どの点も 60 通りの向きに 4 個ずつ。静かな空気からずれた点だけを持つ（持たない点は静かな空気）。
# 衝突：和の同じ二つ組 A=(a1,a2), B=(b1,b2) のあいだで、粒子数の積の差を 2 で 2 回割った数だけ、多い組から少ない組へ移す
#       （t=(n_a1·n_a2 − n_b1·n_b2) を 0 の向きに 4 で割る。移せる数で頭打ち）。静かな空気では積が等しく何も起きない。
#       移す組の順番は、手番の位相 t%5 で巡らせる。
# 渡り：向き k の粒子は、点を V[k] だけ進む（一対一）。
# 閾値（監督）：静かな空気からのずれ Σ|n−4| が 1 以下の点は静かな空気に戻す。戻した粒子と運動量は帳簿に記録。
# 事前に固定した基準：
#   G0 押し込みなしでは、ずれのある点が 0 のまま
#   G1 ずれの粒子数と運動量（6 次元の整数の組）が、閾値で戻した分を足すと毎手番一致する
#   G2 原点の 60 向きに +8 ずつ押し込むと、ずれのある点の数が増えたあと減って 0 になる（80 手番以内）
#   負の対照（衝突なし）：60 本の筋のまま、点が 0 に戻らない
import numpy as np, sys, json, time, itertools
from collections import defaultdict
PUFF=int(sys.argv[1]); COLL=int(sys.argv[2]); T=int(sys.argv[3]); C0=4; SH=2
V=[]
for i,j in itertools.combinations(range(6),2):
    for si in (1,-1):
        for sj in (1,-1):
            v=np.zeros(6,np.int64); v[i]=si; v[j]=sj; V.append(v)
V=np.array(V); K=len(V)
cls=defaultdict(list)
for a,b in itertools.combinations(range(K),2): cls[tuple(V[a]+V[b])].append((a,b))
MOVES=[]
for s,ps in sorted(cls.items()):
    if len(ps)<2: continue
    for q in range(len(ps)): MOVES.append((ps[q],ps[(q+1)%len(ps)]))   # 組を輪にして隣どうしで受け渡す
OFF=128; B=256; W=B**np.arange(6,dtype=np.int64)
def key(a): return ((a+OFF)*W).sum(-1)
def unkey(k):
    a=np.zeros((len(k),6),np.int64); r=k.copy()
    for i in range(6): a[:,i]=r%B-OFF; r//=B
    return a
VK=(V*W).sum(1)
keys=np.zeros(0,np.int64); n=np.zeros((0,K),np.int64)
if PUFF: keys=key(np.zeros((1,6),np.int64)); n=np.full((1,K),C0+PUFF,np.int64)
def dev_mass(n): return int((n-C0).sum())
def dev_mom(n): return ((n-C0)@V).astype(np.int64)
M0=dev_mass(n); P0=dev_mom(n).sum(0) if len(n) else np.zeros(6,np.int64)
lostM=0; lostP=np.zeros(6,np.int64); rec=[]; t0=time.time(); okG1=True
for t in range(1,T+1):
    if len(keys)==0: rec.append(dict(t=t,nodes=0)); print(t,'点 0'); break
    if COLL:
        ph=(t-1)%5
        for mi in range(ph,len(MOVES),5):
            (a1,a2),(b1,b2)=MOVES[mi]
            d=n[:,a1]*n[:,a2]-n[:,b1]*n[:,b2]
            tr=np.sign(d)*(np.abs(d)>>SH)
            tr=np.minimum(tr,np.minimum(n[:,a1],n[:,a2])); tr=np.maximum(tr,-np.minimum(n[:,b1],n[:,b2]))
            n[:,a1]-=tr; n[:,a2]-=tr; n[:,b1]+=tr; n[:,b2]+=tr
    # 渡り
    cand=np.unique(np.concatenate([keys]+[keys+VK[k] for k in range(K)]))
    order=np.argsort(keys); ks=keys[order]; new=np.full((len(cand),K),C0,np.int64)
    for k in range(K):
        src=cand-VK[k]; pos=np.minimum(np.searchsorted(ks,src),len(ks)-1); hit=ks[pos]==src
        new[hit,k]=n[order[pos[hit]],k]
    dev=np.abs(new-C0).sum(1)
    back=(dev<=1)&(dev>0); lostM+=dev_mass(new[back]); lostP+=dev_mom(new[back]).sum(0) if back.any() else 0
    keep=dev>1; keys=cand[keep]; n=new[keep]
    m=dev_mass(n); p=dev_mom(n).sum(0) if len(n) else np.zeros(6,np.int64)
    g1=(m+lostM==M0) and np.array_equal(p+lostP,P0); okG1&=bool(g1)
    a=unkey(keys); r2=(a*a).sum(1); w=np.abs(n-C0).sum(1)
    rec.append(dict(t=t,nodes=len(keys),mass=m,lostM=lostM,maxdev=int(w.max()) if len(w) else 0,
                    r2w=float((w*r2).sum()/max(w.sum(),1)),G1=bool(g1)))
    print(t,'点',len(keys),'ずれの粒子',m,'閾値で戻した',lostM,'最大のずれ',rec[-1]['maxdev'],'平均の半径²',round(rec[-1]['r2w'],1),'帳簿',g1,round(time.time()-t0),flush=True)
    if len(keys)>1_500_000: print('上限'); break
peak=max(r['nodes'] for r in rec)
G2=(rec[-1]['nodes']==0 and peak>0)
print('押し込み',PUFF,'衝突',COLL,'G1',okG1,'G2',G2,'点の最大',peak,'手番',len(rec),'受け渡しの組',len(MOVES))
json.dump(dict(puff=PUFF,coll=COLL,rec=rec,G1=okG1,G2=G2,peak=peak),open('d6gas_%d_%d.json'%(PUFF,COLL),'w'))

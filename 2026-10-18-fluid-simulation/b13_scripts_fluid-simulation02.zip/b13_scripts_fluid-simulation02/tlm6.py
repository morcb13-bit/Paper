# 6 次元の担体（格子 Z^6）の上の水面に石を投げる。整数だけ。
#
# 点は 12 本の辺を持ち、辺ごとに「入ってくる揺れ」a（符号つき整数）を持つ。静かな水面は全部 0。
# 一手番の規則（ホイヘンスの原理を辺の上で書いたもの。伝送線路の格子 TLM と同じ形）：
#   1) 6 本の軸を、手番の位相 t%5 で 3 組の対に分ける（K6 の 1 因子分解：5 つの位相で 15 対すべてを一度ずつ使う）。
#   2) 対 (a,b) ごとに、その 4 本の辺 (+a,−a,+b,−b) で：S＝入ってくる 4 本の和、h＝S を 2 で割る（0 の向きへ切る）、
#      出ていく揺れ＝h − 入ってきた揺れ。押した辺には押し返しが逆の符号で戻る（張力・復元）。
#   3) 出ていく揺れは辺を渡り、隣の点に、戻る側の辺から入る。
#   4) 閾値：|揺れ|≦1 は静かな水面に戻す（監督）。揺れのない点は持たない（空間は揺れのある所だけ）。
#   S が奇数のとき 2 で割り切れない分は捨てる。これは揺れを減らす向きにしか働かない（粘性）。
#   点の高さ＝入ってくる 12 本の和。
#
# 事前に固定した基準：
#   T0 石なしでは点が 0 のまま。
#   T1 帳簿：Σa²（揺れの量）＋切り捨てで減った量＋閾値で戻した量 ＝ 石の量、が毎手番整数で一致。
#      切り捨ても閾値もなかった手番では Σa² が変わらない。
#   T2 広がる：揺れの量で重みをつけた 6 次元の半径²の平均が、毎手番大きくなる（整数の掛け算で比べる）。
#   T3 波紋：t=12 で、担体（窓を通った点）を 3 次元の半径で幅 2 の帯に分け、点が 5 個以上ある帯の高さの和の符号が
#      内から外へ 2 回以上入れ替わる（山と谷の輪）。負の対照 refl=0（押し返しなし。4 本とも +h を出す＝半分に割るだけ）では 0 回。
#   T4 消える：点の数が増えたあと減って 0 になる（60 手番以内）。
import numpy as np, sys, json, time
from carrier3d_np import accept, par
A0=int(sys.argv[1]); REFL=int(sys.argv[2]); T=int(sys.argv[3]); TH=1
OFF=64; B=128; W=B**np.arange(6, dtype=np.int64)
D=np.concatenate([np.eye(6,dtype=np.int64),-np.eye(6,dtype=np.int64)]); OPP=(np.arange(12)+6)%12
DK=(D*W).sum(1)
def key(a): return ((a+OFF)*W).sum(-1)
def unkey(k):
    a=np.zeros((len(k),6),np.int64); r=k.copy()
    for i in range(6): a[:,i]=r%B-OFF; r//=B
    return a
MATCH=[[(5,r),((r+1)%5,(r+4)%5),((r+2)%5,(r+3)%5)] for r in range(5)]
assert sorted(tuple(sorted(p)) for m in MATCH for p in m)==sorted((i,j) for i in range(6) for j in range(i+1,6))
keys=np.zeros(0,np.int64); amp=np.zeros((0,12),np.int64)
if A0:
    keys=key(np.zeros((1,6),np.int64)); amp=np.full((1,12),-A0,np.int64)   # 石：原点が窪む
E0=int((amp*amp).sum()); lost_cut=0; lost_th=0; rec=[]; frames=[]; t0=time.time()
def r2_6(a): return (a*a).sum(1)
for t in range(1,T+1):
    if len(keys)==0: rec.append(dict(t=t,nodes=0,E=0)); break
    Eb=int((amp*amp).sum()); out=np.empty_like(amp); odd=0
    for a,b in MATCH[(t-1)%5]:
        L=[a,a+6,b,b+6]; S=amp[:,L].sum(1); h=np.sign(S)*(np.abs(S)>>1); odd+=int((S%2!=0).sum())
        for l in L: out[:,l]=(h-amp[:,l]) if REFL else h
    Ea=int((out*out).sum()); lost_cut+=Eb-Ea if REFL else 0
    # 渡り：辺 l へ出た揺れは、隣 v+D[l] に辺 OPP[l] から入る
    tk=[];tl=[];tv=[]
    for l in range(12):
        m=out[:,l]!=0
        tk.append(keys[m]+DK[l]); tl.append(np.full(int(m.sum()),OPP[l])); tv.append(out[m,l])
    tk=np.concatenate(tk); tl=np.concatenate(tl); tv=np.concatenate(tv)
    small=np.abs(tv)<=TH; lost_th+=int((tv[small]*tv[small]).sum()); tk,tl,tv=tk[~small],tl[~small],tv[~small]
    keys,inv=np.unique(tk,return_inverse=True); amp=np.zeros((len(keys),12),np.int64); amp[inv,tl]=tv
    E=int((amp*amp).sum()); addr=unkey(keys); hgt=amp.sum(1)
    num=int(((amp*amp).sum(1)*r2_6(addr)).sum())
    ok,_=accept(addr) if len(addr) else (np.zeros(0,bool),None)
    cut=addr[ok]; X=par(cut); phi=(1+5**0.5)/2; P=X[...,0]+X[...,1]*phi
    frames.append(dict(t=t,p=np.round(P,2).tolist(),h=hgt[ok].tolist()))
    rec.append(dict(t=t,nodes=len(keys),E=E,num=num,lost_cut=lost_cut,lost_th=lost_th,odd=odd,cut=int(ok.sum()),maxh=int(np.abs(hgt).max())))
    print(t,'点',len(keys),'揺れの量',E,'切り捨て',lost_cut,'閾値',lost_th,'担体の上の点',int(ok.sum()),'最大の高さ',rec[-1]['maxh'],round(time.time()-t0),flush=True)
    if len(keys)>4_000_000: print('上限'); break
# 判定
T1=all(r['E']+r['lost_cut']+r['lost_th']==E0 for r in rec if 'num' in r) if REFL else None
R=[r for r in rec if 'num' in r and r['E']>0]
T2=all(R[i]['num']*R[i-1]['E']>R[i-1]['num']*R[i]['E'] for i in range(1,len(R)))
def sign_changes(fr):
    P=np.array(fr['p']); hh=np.array(fr['h'])
    if len(P)==0: return 0,[]
    rr=np.sqrt((P*P).sum(1)); bins={}
    for r_,h_ in zip(rr,hh): b=int(r_//2); bins.setdefault(b,[0,0]); bins[b][0]+=1; bins[b][1]+=int(h_)
    seq=[(b,s) for b,(n_,s) in sorted(bins.items()) if n_>=5 and s!=0]
    ch=sum(1 for i in range(1,len(seq)) if (seq[i][1]>0)!=(seq[i-1][1]>0))
    return ch,seq
f12=next((f for f in frames if f['t']==12),None); T3,seq12=sign_changes(f12) if f12 else (None,[])
peak=max(r['nodes'] for r in rec); T4=(rec[-1]['nodes']==0 and peak>0)
print('A0',A0,'押し返し',REFL,'T1',T1,'T2',T2,'T3 符号の入れ替わり',T3,'T4',T4,'点の最大',peak)
print('t=12 の帯（半径/2, 高さの和）',seq12)
json.dump(dict(A0=A0,refl=REFL,rec=rec,T1=T1,T2=T2,T3=T3,T4=T4,seq12=seq12),open('tlm6_%d_%d.json'%(A0,REFL),'w'))
json.dump(frames,open('tlm6_frames_%d_%d.json'%(A0,REFL),'w'))

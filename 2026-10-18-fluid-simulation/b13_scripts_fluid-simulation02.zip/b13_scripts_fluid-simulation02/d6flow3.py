# 6 次元の担体の上の空気。粒子は担体の辺（±e_i、12 向き）だけを進む。衝突は moving.py と同じ。担体の点（窓を通った点）だけを持つ。
# 窓の縁は担体の壁：行き先が窓の外の粒子は、その場で向きを反対にして留まる（鏡反射。行き先を選ぶ手順は入れない）。
# 静かな空気＝60 向きに 4 個ずつ。静かな空気からずれた点だけを持つ。閾値：ずれ Σ|n−4| ≦ 1 の点は静かな空気に戻す。
#
# 使い方：
#   python3 d6flow.py puff 8 80          押し込み（G2′）
#   python3 d6flow.py body K T [ctrl]    半径 8 の球が、K 手番ごとに x 方向へ 1 進む（G3・G4）。ctrl で衝突なし
#
# 事前に固定した基準：
#   G2′ 押し込み＝残ったずれ＋閾値で戻した分＋放出（粒子数と 6 次元の運動量）が毎手番一致。ずれのある点が 80 手番以内に 0。
#   G3  球が進むあいだ、持つ点の数が一定の幅に収まる：後半の 20 手番ごとの区間の最大 ≦ 2×最小。
#   G4  球が空気に渡した x 方向の運動量（抵抗）が正で、速い順（K=1,2,4,8）に大きい。
import numpy as np, sys, json, time, itertools
from collections import defaultdict
from carrier3d_np import accept, par, zm, sgn
MODE=sys.argv[1] if len(sys.argv)>1 else ""; C0=4
V=np.concatenate([np.eye(6,dtype=np.int64),-np.eye(6,dtype=np.int64)]); K=12; OPPV=(np.arange(12)+6)%12   # 担体の辺 ±e_i そのもの; OPPV=np.array([int(np.where((V==-V[k]).all(1))[0][0]) for k in range(K)])
cls=defaultdict(list)
for a,b in itertools.combinations(range(K),2): cls[tuple(V[a]+V[b])].append((a,b))
MOVES=[]
for s,ps in sorted(cls.items()):
    if len(ps)<2: continue
    for q in range(len(ps)): MOVES.append((ps[q],ps[(q+1)%len(ps)]))
OFF=128; B=256; W=B**np.arange(6,dtype=np.int64)
def key(a): return ((a+OFF)*W).sum(-1)
def unkey(k):
    a=np.zeros((len(k),6),np.int64); r=k.copy()
    for i in range(6): a[:,i]=r%B-OFF; r//=B
    return a
VK=(V*W).sum(1)
# 窓の内外の覚え書き（同じ点を何度も判定しない）
win_k=np.zeros(0,np.int64); win_v=np.zeros(0,bool)
def in_window(ks):
    global win_k,win_v
    u=np.unique(ks); pos=np.searchsorted(win_k,u); pos=np.minimum(pos,max(len(win_k)-1,0))
    known=(len(win_k)>0)&(win_k[pos]==u) if len(win_k) else np.zeros(len(u),bool)
    new=u[~known]
    if len(new):
        st=np.zeros(len(new),bool)
        for c in range(0,len(new),100000):
            a,_=accept(unkey(new[c:c+100000])); st[c:c+100000]=a
        allk=np.concatenate([win_k,new]); allv=np.concatenate([win_v,st]); o=np.argsort(allk); win_k,win_v=allk[o],allv[o]
    pos=np.searchsorted(win_k,ks); return win_v[pos]
VX=par(V[:,:,None]*np.ones((1,1,1),np.int64))  # 使わない（下で直接計算）
phi=(1+5**0.5)/2
PX=par(V)          # 60×3×2  向きの 3 次元成分（Z[φ]）
def collide(n,t):   # moving.py と同じ：正面から向き合う対を、位相で巡る別の軸へ移す
    c=(t-1)%5; Pp=np.minimum(n[:,0:6],n[:,6:12]); n[:,0:6]-=Pp; n[:,6:12]-=Pp
    for a in range(6):
        others=[b for b in range(6) if b!=a]; b=others[(c+a)%5]; n[:,b]+=Pp[:,a]; n[:,b+6]+=Pp[:,a]
def devM(n): return int((n-C0).sum())
def devP(n): return ((n-C0)@V).sum(0).astype(np.int64) if len(n) else np.zeros(6,np.int64)
# ---- 物体（3 次元の球。担体の点の par で判定、Z[φ] の整数比較）
R2B=64
def body_of(ks,cx):
    if len(ks)==0: return np.zeros(0,bool)
    X=par(unkey(ks)); dx=X[:,0]-np.array([cx,0])
    return sgn(zm(dx,dx)+zm(X[:,1],X[:,1])+zm(X[:,2],X[:,2])-np.array([R2B,0]))<0
def run(mode,arg1,T,coll=True):
    keys=np.zeros(0,np.int64); n=np.zeros((0,K),np.int64); cx=0; KS=arg1
    if mode=='puff':
        keys=key(np.zeros((1,6),np.int64)); n=np.full((1,K),C0+arg1,np.int64)
    else:
        # 球の中の担体の点を作り、粒子 0 にする（物体が場所を占める）
        a=np.array(list(itertools.product(range(-9,10),repeat=3)))
        # 球の近くの担体の点を、原点から一歩ずつ広げて集める
        seen={0:True}; front=key(np.zeros((1,6),np.int64)); allk=[front]
        for _ in range(40):
            c=np.unique((front[:,None]+VK[None]).reshape(-1)); c=c[~np.isin(c,np.concatenate(allk))]
            if len(c)==0: break
            c=c[in_window(c)]; X=par(unkey(c)); near=sgn(zm(X[:,0],X[:,0])+zm(X[:,1],X[:,1])+zm(X[:,2],X[:,2])-np.array([144,0]))<0
            front=c[near]; allk.append(front)
            if len(front)==0: break
        cand=np.unique(np.concatenate(allk)); bm=body_of(cand,cx); keys=cand[bm]; n=np.zeros((len(keys),K),np.int64)
    M_body0=devM(n) if mode!='puff' else 0
    M0=devM(n); P0=devP(n); lostM=0; lostP=np.zeros(6,np.int64); emM=0; emP=np.zeros(6,np.int64)
    bodyP=np.zeros(6,np.int64); wallP=np.zeros(6,np.int64); rec=[]; ok=True; t0=time.time()
    for t in range(1,T+1):
        if len(keys)==0: rec.append(dict(t=t,nodes=0)); break
        dpush=np.zeros(6,np.int64)
        if mode=='body' and t%KS==0:
            cx+=1
            # 球の新しい範囲の担体の点を用意し、そこにいた粒子を前（x の正の側）の外の点へ押し出す
            ring=np.unique((keys[:,None]+VK[None]).reshape(-1)); ring=ring[in_window(ring)]
            allk=np.union1d(keys,ring); old=dict(zip(keys.tolist(),range(len(keys))))
            nn=np.full((len(allk),K),C0,np.int64)
            idx=np.array([old.get(k_,-1) for k_ in allk.tolist()]); nn[idx>=0]=n[idx[idx>=0]]
            keys,n=allk,nn; bm=body_of(keys,cx); kidx={k_:i for i,k_ in enumerate(keys.tolist())}
            fwd=np.argsort(-(PX[:,0,0]+PX[:,0,1]*phi))   # x の正の向きが大きい順
            for v in np.where(bm&(n.sum(1)>0))[0]:
                for k in np.where(n[v]>0)[0]:
                    c=n[v,k]; dest=-1; kk=k
                    for f in fwd:
                        w=kidx.get(int(keys[v]+VK[f]))
                        if w is not None and not bm[w]: dest=w; kk=f; break
                    if dest<0: continue
                    n[dest,kk]+=c; n[v,k]=0; dpush+=c*(V[kk]-V[k])
        else:
            bm=body_of(keys,cx) if mode=='body' else np.zeros(len(keys),bool)
        MA=devM(n); PA=devP(n)
        if coll: collide(n,t)
        # 渡り（物体に入る粒子は跳ね返る＝向きを反対にしてその場に留まる）
        cand=np.unique(np.concatenate([keys]+[keys+VK[k] for k in range(K)]))
        cand=cand[in_window(cand)]
        order=np.argsort(keys); ks=keys[order]
        def get(src,k):   # 点 src の向き k の粒子数（持っていなければ静かな空気）
            pos=np.minimum(np.searchsorted(ks,src),len(ks)-1); hit=ks[pos]==src
            return np.where(hit,n[order[pos],k],C0)
        new=np.empty((len(cand),K),np.int64)
        bc=body_of(cand,cx) if mode=='body' else np.zeros(len(cand),bool)
        dwall=np.zeros(6,np.int64); dbounce=np.zeros(6,np.int64)
        for k in range(K):
            src=cand-VK[k]; ok_=in_window(src)
            from_nb=get(src,k)
            # 物体の点からは粒子が出ない
            if mode=='body': from_nb=np.where(body_of(src,cx),0,from_nb)
            ko=OPPV[k]; self_=get(cand,ko)   # 窓の外へ向かおうとした自分の粒子が、向きを反対にして留まる
            val=np.where(ok_,from_nb,self_)
            wall_n=np.where(ok_,0,self_-C0); dwall+=int(wall_n[~bc].sum())*(V[k]-V[ko])   # 静かな空気の分は壁の両側で打ち消すので、ずれの分だけ数える
            new[:,k]=val
        if mode=='body':
            # 物体へ入ろうとした粒子は、元の点で向きを反対にする
            for k in range(K):
                tgt=cand+VK[k]; intob=in_window(tgt)&body_of(tgt,cx)&~bc
                if intob.any():
                    c=get(cand[intob],k); new[np.where(intob)[0],OPPV[k]]+=c; dbounce+=int(c.sum())*(V[OPPV[k]]-V[k])
            # 物体の点そのものは粒子 0（入ってきた粒子は上で元へ返している）
            new[bc]=0
        # 閾値
        dev=np.abs(new-C0).sum(1); back=(dev<=1)&(dev>0)&~bc
        lostM+=devM(new[back]); lostP+=devP(new[back])
        keep=(dev>1)|bc; keys=cand[keep]; n=new[keep]
        bodyP+=dpush+dbounce
        m=devM(n); p=devP(n)
        wallP+=dwall
        g=(m+lostM==M0) and np.array_equal(p+lostP,P0+bodyP+wallP) if mode=='puff' else None
        if mode=='puff': ok&=bool(g)
        bx=int(bodyP@(PX[:,0,0]*0+0)) if False else None
        rec.append(dict(t=t,nodes=len(keys),dev=m,lost=lostM,cx=cx,bodyP=bodyP.tolist(),G=g))
        if t%5==0 or mode=='puff':
            print(mode,KS,t,'点',len(keys),'残ったずれ',m,'閾値',lostM,'x',cx,'帳簿',g,round(time.time()-t0),flush=True)
        if len(keys)>600000: print('上限'); break
    return rec,ok
if __name__=='__main__':
    if MODE=='puff':
        rec,ok=run('puff',int(sys.argv[2]),int(sys.argv[3]))
        peak=max(r['nodes'] for r in rec); G2=rec[-1]['nodes']==0
        print('G2′ 帳簿',ok,'点が0に戻る',G2,'点の最大',peak,'手番',len(rec))
        json.dump(dict(rec=rec,ok=ok,G2=G2),open('d6flow3_puff.json','w'))
    else:
        KS=int(sys.argv[2]); T=int(sys.argv[3]); coll=not(len(sys.argv)>4 and sys.argv[4]=='ctrl')
        rec,_=run('body',KS,T,coll)
        json.dump(dict(K=KS,coll=coll,rec=rec),open('d6flow3_body_%d_%d.json'%(KS,int(coll)),'w'))

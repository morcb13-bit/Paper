# fig1/fig2 の日本語版 HTML をテンプレートとデータから組み立てる（図3は build_fig3_html.py）
css = open('css.txt').read()
for tpl, data, out in [('fig1_tpl.html', 'fig1_data.json', 'bepicolombo_path.html'),
                       ('fig2_tpl.html', 'fig2_data.json', 'bepicolombo_flybys.html')]:
    h = open(tpl).read().replace('/*CSS*/', css).replace('/*DATA*/', open(data).read())
    open(out, 'w').write(h); print(out, len(h.encode()))

import json
css = open('css.txt').read(); d = open('fig3_data.json').read(); tpl = open('fig3_tpl.html').read()
JA = dict(lang='ja', title='水星の衛星になるまで ― 並んで回る 2 年と、捕獲・分離',
  cmt='前半：水星を中心に、太陽の向きを下に固定して見た探査機（JPL Horizons の値、km の整数）。後半：捕獲と分離の概念図（軌道の大きさは公表値）。コマを 1 つずつ足して進める',
  pause='停止', step='一歩', speed='速さ',
  notes='''<p class="note">前半は、水星を真ん中に置き、太陽がいつも下にあるように水星と一緒に回りながら見た、2025 年 1 月（水星 6 の直後）から 2026 年 11 月 1 日までの探査機の位置です。この間、探査機は水星の衛星ではなく、水星とほとんど同じ楕円で太陽のまわりを回っています。楕円の形と向きが少し違うので、水星の一年（88 日）ごとに輪を描いて近づいたり離れたりし、周期の違いで輪全体が少しずつずれていきます。2026 年に入るとイオンエンジンで輪を小さくし、水星へ寄せていきます。</p>
  <p class="note">後半は予想図です。視野を数万 km まで拡大し、2026 年 11 月 21 日に水星の重力に捕まった後を描いています。重なった二機は、何度かの噴射でみおの軌道（高度 590〜11,640 km、一周 9.3 時間）に入り、そこで 12 月 9〜10 日に分かれ、MPO はそこから低い軌道（高度 480〜1,500 km、一周 2.3 時間）へ降ります（完成は 2027 年 3 月の予定）。水星と二つの軌道の大きさは計画値の比で、軌道の面に垂直な向きから見ています。ここからは、水星のまわりを回りながら、水星と一緒に太陽のまわりを公転します。</p>
  <p class="note">前半の位置は JPL Horizons の 20 日ごとの値を補間したもので、水星との距離には 0.005 AU ほどの誤差があります。最後の数週間の細かい動きと、捕まる瞬間の道筋は描いていません。</p>''',
  T=dict(stages=['並んで回る 2 年','近づく','捕獲','分離の後'], sun='太陽の方向', mercury='水星',
    stack='MPO＋みお（重なったまま）', mio='みお', mpo='MPO',
    heads=['', '2026-11 水星に寄せる', '2026-11-21 捕獲 → 分離まで', '2026-12-09〜10 分離の後'],
    subs=['水星から見た探査機（太陽の向きを下に固定）', '視野を縮めて水星に寄る（概念図）', '噴射を重ねてみおの軌道へ（予想図。描いているのは分離時の軌道、大きさは計画値）', 'MPO は低い軌道へ（2027-03 完成予定、予想図）'],
    field='視野の半幅 ', dist='水星からの距離 ', mioOrb='みおの軌道：高度 590〜11,640 km、9.3 時間',
    mpoOrb='MPO の軌道：高度 480〜1,500 km、2.3 時間', pause='停止', play='再生'))
EN = dict(lang='en', title='Becoming a Satellite of Mercury: Two Years Side by Side, Then Capture',
  cmt='First part: the spacecraft seen from Mercury with the Sun fixed below (JPL Horizons values, integer km). Second part: concept view of capture and separation (orbit sizes are the published values). The animation advances by adding one frame at a time',
  pause='Pause', step='Step', speed='Speed',
  notes='''<p class="note">The first part puts Mercury at the centre and turns with it so that the Sun always stays below. It shows the spacecraft from January 2025 (just after Mercury flyby 6) to 1 November 2026. During this time the spacecraft is not a satellite of Mercury: it orbits the Sun on almost the same ellipse as Mercury. Because the two ellipses differ slightly in shape and orientation, it traces a loop every Mercury year (88 days), coming closer and drifting away, and the difference in period slowly shifts the whole loop. In 2026 the ion engine shrinks the loops and brings it in toward Mercury.</p>
  <p class="note">The second part is a projection. The field zooms in to tens of thousands of kilometres and shows what follows Mercury's capture of the stack on 21 November 2026. A series of burns brings the pair into Mio's orbit (590–11,640 km altitude, 9.3 hours), where they separate on 9–10 December; the MPO then lowers itself to its own orbit (480–1,500 km, 2.3 hours, planned for March 2027). Mercury and both orbits are drawn to scale using the planned values, seen face-on to the orbital plane. From here on, the spacecraft orbit Mercury while travelling around the Sun together with it.</p>
  <p class="note">Positions in the first part are JPL Horizons values every 20 days, interpolated, so the distance from Mercury carries an error of about 0.005 AU. The fine motion of the last few weeks and the capture path itself are not drawn.</p>''',
  T=dict(stages=['Two years side by side','Closing in','Capture','After separation'], sun='Direction of the Sun', mercury='Mercury',
    stack='MPO + Mio (still stacked)', mio='Mio', mpo='MPO',
    heads=['', 'Nov 2026: closing in', '21 Nov 2026: capture, until separation', '9–10 Dec 2026: after separation'],
    subs=['The spacecraft seen from Mercury (Sun fixed below)', 'Zooming in toward Mercury (concept)', 'Burns shape the orbit into Mio\'s (projection; shown is the orbit at separation, planned sizes)', 'MPO moves to the lower orbit (planned for Mar 2027, projection)'],
    field='Half-width of view ', dist='Distance from Mercury ', mioOrb='Mio orbit: 590–11,640 km altitude, 9.3 h',
    mpoOrb='MPO orbit: 480–1,500 km altitude, 2.3 h', pause='Pause', play='Play'))
for L, fn in [(JA, 'bepicolombo_capture.html'), (EN, 'bepicolombo_capture_en.html')]:
    h = tpl
    for key in ['lang', 'title', 'cmt', 'pause', 'step', 'speed', 'notes']:
        h = h.replace('{{%s}}' % key, L[key])
    h = h.replace('/*CSS*/', css).replace('/*DATA*/', d).replace('/*TEXT*/', json.dumps(L['T'], ensure_ascii=False))
    assert '{{' not in h
    open(fn, 'w').write(h); print(fn, len(h.encode()))

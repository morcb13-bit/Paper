import numpy as np, json, math
F = np.load('frames.npz'); tt = F['tt']
step = 2; idx = np.arange(0, len(tt), step)
I = lambda a: [int(round(v*10000)) for v in a[idx]]
AU=1.495978707e11; LP=1.616255e-35
def addr(a): return math.log(a*AU/LP)/math.log(13)
# 軌道要素の節（Horizons の接触軌道要素。フライバイの時刻で前→後に切り替える）
FB = [('地球',2458949.6848),('金星1',2459137.6661),('金星2',2459437.0779),('水星1',2459489.4827),
      ('水星2',2459753.9064),('水星3',2460115.3161),('水星4',2460558.4091),('水星5',2460646.1001),('水星6',2460683.7501)]
# (q, a, Q, P) 前後
snap = [(0.887,1.025892,1.165,379.5)] + [
 ((0.880,1.038031,1.196,386.3),(0.624,0.818206,1.013,270.3)),
 ((0.626,0.819634,1.013,271.0),(0.520,0.676118,0.833,203.1)),
 ((0.518,0.675145,0.832,202.6),(0.335,0.532933,0.731,142.1)),
 ((0.335,0.532952,0.731,142.1),(0.321,0.507748,0.695,132.2)),
 ((0.322,0.506529,0.691,131.7),(0.304,0.467595,0.632,116.8)),
 ((0.315,0.473990,0.633,119.2),(0.306,0.450470,0.595,110.4)),
 ((0.309,0.444347,0.580,108.2),(0.306,0.388165,0.470,88.3)),
 ((0.306,0.387215,0.468,88.0),(0.307,0.386937,0.467,87.9)),
 ((0.307,0.386937,0.467,87.9),(0.308,0.381984,0.456,86.2))] + [(0.305,0.379935,0.455,85.5)]
nodes = [(2458416.5, snap[0])]
for k,(lab,t) in enumerate(FB):
    nodes += [(t, snap[k+1][0]), (t+1e-6, snap[k+1][1])]
nodes += [(2461345.5, snap[-1]), (2461365.5, snap[-1])]
nt = np.array([n[0] for n in nodes]); nv = np.array([n[1] for n in nodes])
el = np.array([np.interp(tt[idx], nt, nv[:,j]) for j in range(4)])
rows = dict(
  t0=float(tt[0]), step=step,
  s=[I(F['sx']), I(F['sy'])],
  me=[I(F['mercuryx']), I(F['mercuryy'])], ve=[I(F['venusx']), I(F['venusy'])], ea=[I(F['earthx']), I(F['earthy'])],
  q=[int(round(v*1000)) for v in el[0]], Q=[int(round(v*1000)) for v in el[2]],
  P=[int(round(v*10)) for v in el[3]], ad=[int(round(addr(v)*1000)) for v in el[1]],
  fb=[[lab, int(round((t-tt[0])/step))] for lab,t in FB])
open('fig1_data.json','w').write(json.dumps(rows, separators=(',',':'), ensure_ascii=False))
print('fig1 frames', len(idx), 'bytes', len(json.dumps(rows, separators=(',',':'))))
print('address first/last', rows['ad'][0], rows['ad'][-1])

# ---- 図2：双曲線（惑星中心の接触軌道要素）
GM = {'地球':398600.4,'金星':324858.6,'水星':22031.9}; RAD={'地球':6371.0,'金星':6051.8,'水星':2439.7}
H = [('地球','2020-04-10',1.758965750057465,1.906408630146034E+04,-2.511850673105716E+04),
     ('金星','2020-10-15',4.268147486921333,1.677372912868171E+04,-5.132488419145040E+03),
     ('金星','2021-08-10',2.301204882760822,6.604374654658954E+03,-5.075583977710079E+03),
     ('水星','2021-10-01',6.253756951518207,2.639323108257421E+03,-5.023687111172359E+02),
     ('水星','2022-06-23',5.791838551991543,2.638589850636092E+03,-5.506424772052191E+02),
     ('水星','2023-06-19',2.606353663546848,2.675332507371976E+03,-1.665469172874926E+03),
     ('水星','2024-09-04',1.917584644798364,2.603860354655146E+03,-2.837733139297825E+03),
     ('水星','2024-12-01',1.389037639713678E+01,4.006612804715289E+04,-3.108220180137827E+03),
     ('水星','2025-01-08',1.431859223424018,2.735535300712819E+03,-6.334321816780903E+03)]
labs = ['地球','金星1','金星2','水星1','水星2','水星3','水星4','水星5','水星6']
out=[]
for lab,(pl,date,e,q,a) in zip(labs,H):
    A=-a; R=RAD[pl]; mu=GM[pl]; n=math.sqrt(mu/A**3)
    vinf=math.sqrt(mu/A); vq=math.sqrt(mu*(2/q+1/A)); delta=2*math.degrees(math.asin(1/e))
    Rv = max(3.2*q, 5*R)                     # 表示の半径
    Hmax = math.acosh((Rv/A+1)/e)            # r = A(e cosh H - 1) = Rv
    tmax = (e*math.sinh(Hmax)-Hmax)/n
    N=300; pts=[]
    for k in range(N+1):
        t=-tmax+2*tmax*k/N; M=n*t; Hh=math.asinh(M/e) if e>1 else M
        for _ in range(60): Hh -= (e*math.sinh(Hh)-Hh-M)/(e*math.cosh(Hh)-1)
        X=A*(e-math.cosh(Hh)); Y=A*math.sqrt(e*e-1)*math.sinh(Hh)
        pts += [int(round(X/R*100)), int(round(Y/R*100))]
    out.append(dict(lab=lab, pl=pl, date=date, e=int(round(e*1000)), alt=int(round(q-R)),
        rv=int(round(Rv/R*100)), vinf=int(round(vinf*100)), vq=int(round(vq*100)),
        dl=int(round(delta*10)), tm=int(round(tmax/60)), pts=pts))
    print(f'{lab} e={e:.3f} 高度={q-R:.0f}km v∞={vinf:.2f} 最接近の速さ={vq:.2f} 曲がる角={delta:.1f}° 表示範囲±{tmax/60:.0f}分')
open('fig2_data.json','w').write(json.dumps(out, separators=(',',':'), ensure_ascii=False))

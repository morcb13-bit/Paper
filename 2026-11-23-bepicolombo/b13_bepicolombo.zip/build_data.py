# 観察者側の前処理：Horizons の標本（20日刻み）を 1 日刻みに補間し、惑星の位置を加えて整数化する
import numpy as np, json, math
from astropy.time import Time
from astropy.coordinates import get_body_barycentric, solar_system_ephemeris
import astropy.units as u
solar_system_ephemeris.set('builtin')
D = np.genfromtxt('helio.csv', delimiter=',')
jd, x, y, vx, vy = D.T
r = np.hypot(x, y); th = np.unwrap(np.arctan2(y, x))
# 速度がある点は厳密な微分、ない点は差分で
has = ~np.isnan(vx)
dr = np.where(has, (x*vx + y*vy)/r, np.gradient(r, jd))
dth = np.where(has, (x*vy - y*vx)/r**2, np.gradient(th, jd))
def herm(t):
    i = np.clip(np.searchsorted(jd, t) - 1, 0, len(jd)-2)
    h = jd[i+1]-jd[i]; s = (t-jd[i])/h
    h00=2*s**3-3*s**2+1; h10=s**3-2*s**2+s; h01=-2*s**3+3*s**2; h11=s**3-s**2
    R = h00*r[i]+h10*h*dr[i]+h01*r[i+1]+h11*h*dr[i+1]
    T = h00*th[i]+h10*h*dth[i]+h01*th[i+1]+h11*h*dth[i+1]
    return R*np.cos(T), R*np.sin(T)
T0, T1 = 2458412.5, 2461365.5   # 2018-10-21 〜 2026-11-21
tt = np.arange(T0, T1+0.1, 1.0)
sx, sy = herm(tt)
# 補間の自己確認：標本点そのものを再現するか
ex, ey = herm(jd[jd<=T1]); print('標本点の再現誤差 max', np.max(np.hypot(ex-x[jd<=T1], ey-y[jd<=T1])))
eps = math.radians(23.43927944)
def planet(name, t):
    tm = Time(t, format='jd', scale='tdb')
    p = (get_body_barycentric(name, tm) - get_body_barycentric('sun', tm)).xyz.to(u.au).value
    X, Y, Z = p
    return X, Y*math.cos(eps) + Z*math.sin(eps)
P = {n: planet(n, tt) for n in ['mercury','venus','earth']}
# 確認：フライバイの時刻に探査機が惑星の位置にいるか
fb = [('地球','earth',2458949.6848),('金星1','venus',2459137.6661),('金星2','venus',2459437.0779),
      ('水星1','mercury',2459489.4827),('水星2','mercury',2459753.9064),('水星3','mercury',2460115.3161),
      ('水星4','mercury',2460558.4091),('水星5','mercury',2460646.1001),('水星6','mercury',2460683.7501)]
for lab, n, t in fb:
    a, b = herm(np.array([t])); c, d = planet(n, np.array([t]))
    print(lab, '探査機と惑星の距離 AU', round(float(np.hypot(a-c, b-d)[0]), 4))
np.savez('frames.npz', tt=tt, sx=sx, sy=sy, **{k+'x':v[0] for k,v in P.items()}, **{k+'y':v[1] for k,v in P.items()})

# 観察者側の前処理：図3（水星から見た最後の 2 年 → 捕獲 → 分離）のコマを整数（km）で作る
import numpy as np, json, math
from astropy.time import Time
F = np.load('frames.npz'); t = F['tt']
KM = 1.495978707e8
t0, t1 = Time('2025-01-09').jd, Time('2026-11-01').jd
m = (t >= t0) & (t <= t1)
idx = np.where(m)[0][::2]                                   # 2 日ごと
mx, my, sx, sy = F['mercuryx'][idx], F['mercuryy'][idx], F['sx'][idx], F['sy'][idx]
r = np.hypot(mx, my); ux, uy = mx/r, my/r; tx, ty = -uy, ux  # u：太陽から外向き、t：水星の進む向き
rx, ry = sx-mx, sy-my
X = (rx*tx + ry*ty) * KM; Y = (rx*ux + ry*uy) * KM          # 前方, 太陽と反対向き（km）
A = [[int(round(a)), int(round(b))] for a, b in zip(X, Y)]
dates = [Time(v, format='jd').iso[:10] for v in t[idx]]
WA = 38000000                                               # 前半の視野（半幅 km、約 0.25 AU）
print('前半', len(A), 'コマ、最大距離 %.3f AU、最後 %.4f AU' % (np.hypot(X, Y).max()/KM, math.hypot(*A[-1])/KM))
# つなぎ：視野を WA → 22000 km まで等比で縮め、点は最後のデータ点から捕獲の入口へ（概念）
GM = 22031.9; RM = 2439.7
def kepler(rp, ra, n, phase0=0.0, frac=1.0):
    a = (rp+ra)/2; e = (ra-rp)/(ra+rp); T = 2*math.pi*math.sqrt(a**3/GM); out=[]
    for k in range(n):
        Mn = phase0 + 2*math.pi*frac*k/n; E = Mn
        for _ in range(30): E -= (E - e*math.sin(E) - Mn)/(1 - e*math.cos(E))
        x = a*(math.cos(E)-e); y = a*math.sqrt(1-e*e)*math.sin(E)
        out.append([int(round(-y)), int(round(x))])         # 近水点を上に置き、反時計回り
    return out, T
mio_rp, mio_ra = RM+590, RM+11640; mpo_rp, mpo_ra = RM+480, RM+1500
mio1, Tm = kepler(mio_rp, mio_ra, 240, math.pi)             # 遠水点から 1 周
mio2, _ = kepler(mio_rp, mio_ra, 480, math.pi, 1.0)          # 分離後の 1 周（9.3 時間）
mpo2, Tp = kepler(mpo_rp, mpo_ra, 480, 0.0, Tm/((2*math.pi*math.sqrt(((mpo_rp+mpo_ra)/2)**3/GM))))
print('周期 みお %.2f 時間、MPO %.2f 時間' % (Tm/3600, Tp/3600))
NB = 90; WC = 15000
B = []; start = A[-1]; end = mio1[0]
for k in range(NB):
    s = (k+1)/NB; w = WA*(WC/WA)**s
    f = s*s*(3-2*s)                                          # なめらかに寄せる
    lg = lambda a, b: a*(1-f)+b*f
    B.append([int(round(w)), int(round(lg(start[0], end[0]))), int(round(lg(start[1], end[1])))])
data = dict(A=A, dates=dates, WA=WA, B=B, WC=WC, C1=mio1, C2m=mio2, C2p=mpo2, RM=int(round(RM)),
            mio=[mio_rp-int(RM), mio_ra-int(RM)], mpo=[mpo_rp-int(RM), mpo_ra-int(RM)],
            hm=int(round(Tm/360)), hp=int(round(Tp/360)))
open('fig3_data.json','w').write(json.dumps(data, separators=(',',':')))
print('bytes', len(json.dumps(data, separators=(',',':'))))

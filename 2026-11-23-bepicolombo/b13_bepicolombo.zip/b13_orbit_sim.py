"""
b13_orbit_sim.py ― B13 ライブラリ（平衡13進・足し算だけ）で BepiColombo の 20 日を進める
=====================================================================================
事前に決めた基準（走らせる前に書いたもの）
  区間   : 2024-12-08 → 2024-12-28 TDB（水星5と水星6の間、要素がほぼ一定＝噴射なしの区間）
  初期値 : JPL Horizons（-121、太陽中心、黄道 J2000）の位置・速度
  力     : 太陽の重力だけ（GM = k²、k = 0.01720209895 は [知識]）
  積分   : リープフロッグ（蹴る・流す・蹴る）、1/16 日 × 320 歩
  合格   : 12-28 の Horizons の位置との差 < 0.0005 AU
  負の対照: GM = 0（直進）で差 > 0.05 AU にならなければ、この照合は何も言えていない
  算術   : 同じ手順の浮動小数版（観察者側）との差 < 1e-9 AU
整数の演算はすべて b13_arith.mul / divide と b13_balanced.add / neg（平衡13進の桁の列）。
平方根は divide を使ったニュートンの反復（前の歩の r から始める）。
"""
import sys, time, os
# B13 ライブラリ（b13_balanced.py, b13_arith.py）の置き場所。環境変数 B13LIB で指定、なければ同じフォルダ
sys.path.insert(0, os.environ.get('B13LIB', os.path.dirname(os.path.abspath(__file__))))
from b13_balanced import add, neg, sign, from_decimal, to_int
from b13_arith import mul, divide
N = 13
D = lambda s: from_decimal(s, N)          # 観察者側の入力：10進の文字列から平衡13進へ
def M(a, b): return mul(a, b, N)[0]
def Q(a, b): return divide(a, b, N)[0]    # 一番近い商
def A(a, b): return add(a, b, N)
S = D('1000000000000')                    # 目盛り 10^12（1 AU = 10^12）
S2 = M(S, S)
SIXTEEN = D('16')
TWO = D('2')
def isqrt(n, guess):
    """√n を divide だけのニュートン反復で：x ← (x + n/x)/2 を、動かなくなるまで。"""
    x = guess
    for _ in range(40):
        y = Q(A(x, Q(n, x)), TWO)
        if sign(A(y, neg(x))) == 0:
            return y
        x = y
    return x
def accel(P, GMS, Rg):
    r2 = A(A(M(P[0], P[0]), M(P[1], P[1])), M(P[2], P[2]))   # 目盛り S²
    R = isqrt(r2, Rg)                                         # 目盛り S
    r3 = M(R, r2)                                             # 目盛り S³
    den = M(r3, SIXTEEN)                                      # 1/16 日の蹴り
    return [neg(Q(M(M(GMS, c), S2), den)) for c in P], R      # 速度の増分（目盛り S、1/16 日ぶん）
def run(GMS, x0, v0):
    P = [D(s) for s in x0]; V = [D(s) for s in v0]
    half = lambda dv: [Q(d, TWO) for d in dv]
    dv, R = accel(P, GMS, D('300000000000'))
    for step in range(320):
        V = [A(v, h) for v, h in zip(V, half(dv))]            # 半分蹴る
        P = [A(p, Q(v, SIXTEEN)) for p, v in zip(P, V)]       # 1/16 日流す
        dv, R = accel(P, GMS, R)
        V = [A(v, h) for v, h in zip(V, half(dv))]            # 半分蹴る
    return P
# Horizons（観察者側の入力。AU と AU/日 を 10^12 倍して整数に）
x0 = ['19606056935', '307006713928', '13981865691']
v0 = ['-33818871806', '2985799748', '2106898186']
x1 = (-3.952174606652419E-01, -5.795454738868233E-02, 2.009312383049389E-02)
GMS = D('295912208')                                          # k² × 10^12
t = time.time()
P = run(GMS, x0, v0); t_b13 = time.time() - t
P0 = run(D('0'), x0, v0)
rd = lambda P: [to_int(p, N) / 1e12 for p in P]               # 観察者側の読み
def err(p): return sum((a - b) ** 2 for a, b in zip(p, x1)) ** .5
# 浮動小数の同じ手順（観察者側の照合用）
def run_f(gm):
    p = [int(s) / 1e12 for s in x0]; v = [int(s) / 1e12 for s in v0]; h = 1 / 16
    def acc(p): r = sum(c * c for c in p) ** .5; return [-gm * c / r ** 3 for c in p]
    a = acc(p)
    for _ in range(320):
        v = [vi + ai * h / 2 for vi, ai in zip(v, a)]; p = [pi + vi * h for pi, vi in zip(p, v)]
        a = acc(p); v = [vi + ai * h / 2 for vi, ai in zip(v, a)]
    return p
pf = run_f(295912208 / 1e12)
pb = rd(P)
EN = '--en' in sys.argv
f6 = lambda p: '[' + ', '.join('%.6f' % c for c in p) + ']'
if EN:
    print('Position on 12-28, Horizons :', f6(x1))
    print('Position on 12-28, B13 int  :', f6(pb), '  run time %.1f s' % t_b13)
    print('Difference (B13 - Horizons) : %.6f AU = %.0f km' % (err(pb), err(pb) * 1.495978707e8))
    print('Negative control, GM = 0    : %.6f AU' % err(rd(P0)))
    print('Integer vs floating-point   : %.2e AU' % sum((a - b) ** 2 for a, b in zip(pb, pf)) ** .5)
    print('Pass (< 0.0005):', err(pb) < 0.0005, '/ control misses (> 0.05):', err(rd(P0)) > 0.05)
else:
    print('12-28 の位置 Horizons :', ['%.6f' % c for c in x1])
    print('12-28 の位置 B13整数 :', ['%.6f' % c for c in pb], ' 計算時間 %.1f 秒' % t_b13)
    print('差（B13 − Horizons）  : %.6f AU = %.0f km' % (err(pb), err(pb) * 1.495978707e8))
    print('負の対照 GM=0 の差    : %.6f AU' % err(rd(P0)))
    print('整数版と浮動小数版の差: %.2e AU' % sum((a - b) ** 2 for a, b in zip(pb, pf)) ** .5)
    print('判定 合格(<0.0005)   :', err(pb) < 0.0005, '／ 負の対照が外れる(>0.05):', err(rd(P0)) > 0.05)

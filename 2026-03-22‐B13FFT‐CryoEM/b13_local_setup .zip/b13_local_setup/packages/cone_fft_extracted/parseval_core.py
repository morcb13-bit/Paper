"""
Parseval core for cone-FFT v28.
"""

def step_rule_40(T, U):
    return [6*t + 2*u for t, u in zip(T, U)], \
           [2*t - 6*u for t, u in zip(T, U)]

def step_rule_40_inv(T, U):
    return [(6*t + 2*u) // 40 for t, u in zip(T, U)], \
           [(2*t - 6*u) // 40 for t, u in zip(T, U)]

def build_fractal_integer_signal(B, T0, U0):
    T, U = T0[:], U0[:]
    for _ in range(B): T, U = step_rule_40(T, U)
    return T, U

def build_fractal_integer_signal_inv(B, T, U):
    for _ in range(B): T, U = step_rule_40_inv(T, U)
    return T, U

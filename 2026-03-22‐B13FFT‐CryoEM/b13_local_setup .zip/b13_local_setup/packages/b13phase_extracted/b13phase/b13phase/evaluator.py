"""
evaluator.py
============
Production evaluator for B13 fractal vertex coordinates.

Replaces evaluator_proto.py.

Design
------
Input : (k, j, n)
    k  ∈ Z₁₂  — pentagon index (0..11), tied to Z₁₃* label 2^k mod 13
    j  ∈ Z₅   — vertex within pentagon (0..4), 72° spacing
    n  ∈ Z≥0  — fractal level

Output: B13Vertex namedtuple
    az_idx   : int   — azimuth index in Z_BASE (0..BASE-1), exact
    cos_az   : int   — COS_TABLE[az_idx],  ≈ BASE·cos(az), exact integer
    sin_az   : int   — SIN_TABLE[az_idx],  ≈ BASE·sin(az), exact integer
    cos_theta: int   — ≈ BASE·cos(polar_angle), integer constant per band
    sin_theta: int   — ≈ BASE·sin(polar_angle), integer constant per band
    r_sq_rat : int   — rational part  of R²_n in Z[φ]:  R²_n = r_sq_rat + r_sq_phi·φ
    r_sq_phi : int   — φ-coefficient of R²_n in Z[φ]

All values are integers (or integer pairs for Z[φ] quantities).

Key formulas
------------
  az_idx(k, j, n) = ( m(k,j)·52 + n·312 ) mod BASE
      where  m(k,j) = (5k + 12j) mod 60       — Z₆₀ vertex label
             52      = BASE / 60                — step per Z₆₀ unit
             312     = BASE / 10 = 36°·step    — fractal level step

  Band (polar angle class) determined by k alone:
      k = 0          → north-pole band  (cos_theta > 0, |cos| large)
      k = 1..5       → upper band       (cos_theta > 0, |cos| small)
      k = 6..10      → lower band       (cos_theta < 0, |cos| small)
      k = 11         → south-pole band  (cos_theta < 0, |cos| large)

  R²_n in Z[φ]:
      R²_0 = (9φ + 10)/4  [a=1 scale]
      R²_n = φ^{2n} · R²_0
      φ-multiplication rule: (a+bφ)·φ = b + (a+b)φ  [since φ²=φ+1]

  Error budget:
      az part:   exact (table lookup)
      theta part: ≤ 0.02% (rounding of irrational φ/√3 and 1/√5 to integers)
      r² part:   exact in Z[φ]

Constants
---------
BASE = 3120 = 2⁴ · 3 · 5 · 13

Polar-angle integer constants (×BASE):
    North-pole (k=0):  cos_theta=+2915, sin_theta=1113
    Upper-band (k=1..5): cos_theta=+1395, sin_theta=2791
    Lower-band (k=6..10): cos_theta=−1395, sin_theta=2791
    South-pole (k=11): cos_theta=−2915, sin_theta=1113

Z[φ] norm:
    N(10 + 9φ) = 10² + 10·9 − 9² = 109 = 8·F(7) + F(5)
"""

from __future__ import annotations
from typing import NamedTuple, Tuple

from .constants import BASE
from .level0_table import COS_TABLE, SIN_TABLE

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_STEP_Z60: int = BASE // 60   # = 52  (one Z₆₀ unit in BASE index)
_STEP_LVL: int = BASE // 10   # = 312 (one fractal level = 36°)

assert _STEP_Z60 * 60 == BASE
assert _STEP_LVL * 10 == BASE

# Polar-angle integer constants (scale = BASE = 3120)
# Derived from:   cos_pole = φ/√3,  sin_pole = 1/(φ√3)
#                 cos_band = 1/√5,   sin_band = 2/√5
_COS_POLE: int = 2915   # round(BASE · φ/√3)
_SIN_POLE: int = 1113   # round(BASE / (φ√3))
_COS_BAND: int = 1395   # round(BASE / √5)
_SIN_BAND: int = 2791   # round(BASE · 2/√5)

# R²_0 in Z[φ]:  (9φ+10)/4  — stored as numerator (rat, phi) with denominator 4
# For level-n: multiply by φ² = (1+φ) repeatedly  → (rat,phi) updates
_R2_0_RAT: int = 10   # rational part of 4·R²_0 = 9φ+10  ... no: R²_0=(9φ+10)/4
_R2_0_PHI: int = 9    # φ-coefficient of 4·R²_0
# We work with 4·R²_n to stay in integers:
#   4·R²_0 = 9φ + 10  → (rat=10, phi=9)
#   φ² = φ+1  →  (a+bφ)·(1+φ) = a + (a+b)φ  (one φ² step)
# Actually φ²·(a+bφ) = (b) + (a+b)φ  since φ²=φ+1 → a·φ²+b·φ³ = a(φ+1)+b(2φ+1)=(a+b)+(a+2b)φ
# Let's be careful:
#   (a+bφ)·φ  = bφ² + aφ = b(φ+1)+aφ = b + (a+b)φ
#   (a+bφ)·φ² = (a+bφ)·(φ+1) = a+aφ+bφ+bφ² = a + (a+b)φ + b(φ+1)
#             = (a+b) + (a+2b)φ


# ---------------------------------------------------------------------------
# Z[φ] arithmetic helpers
# ---------------------------------------------------------------------------

ZPhi = Tuple[int, int]   # (rational_part, phi_coeff)


def _zphi_mul_phi(p: ZPhi) -> ZPhi:
    """Multiply a Z[φ] element by φ.  φ·(a+bφ) = b + (a+b)φ."""
    a, b = p
    return (b, a + b)


def _zphi_mul_phi2(p: ZPhi) -> ZPhi:
    """Multiply a Z[φ] element by φ² = φ+1.  φ²·(a+bφ) = (a+b) + (a+2b)φ."""
    a, b = p
    return (a + b, a + 2 * b)


def r_sq_level(n: int) -> ZPhi:
    """
    Return 4·R²_n as Z[φ] = (rat, phi).
    4·R²_0 = 10 + 9φ.
    4·R²_n = φ^{2n} · (10 + 9φ).
    """
    val: ZPhi = (_R2_0_RAT, _R2_0_PHI)   # 10 + 9φ
    for _ in range(n):
        val = _zphi_mul_phi2(val)
    return val   # = φ^{2n}·(10+9φ)


# ---------------------------------------------------------------------------
# Azimuth index
# ---------------------------------------------------------------------------

def az_idx(k: int, j: int, n: int = 0) -> int:
    """
    Return the azimuth index in Z_BASE for vertex (k, j, n).

    Formula:
        m  = (5k + 12j) mod 60          — Z₆₀ vertex label
        az = (m·52 + n·312) mod BASE    — BASE = 3120
    """
    m = (5 * k + 12 * j) % 60
    return (m * _STEP_Z60 + n * _STEP_LVL) % BASE


# ---------------------------------------------------------------------------
# Band classification and polar-angle constants
# ---------------------------------------------------------------------------

def band(k: int) -> int:
    """
    Return band index for k:
        0 → north-pole  (k = 0)
        1 → upper       (k = 1..5)
        2 → lower       (k = 6..10)
        3 → south-pole  (k = 11)
    """
    if k == 0:
        return 0
    if k <= 5:
        return 1
    if k <= 10:
        return 2
    return 3


def theta_ints(k: int) -> Tuple[int, int]:
    """
    Return (cos_theta, sin_theta) as BASE-scaled integers for the band of k.

    cos_theta is signed; sin_theta is always positive.
    """
    b = band(k)
    if b == 0:
        return (_COS_POLE, _SIN_POLE)
    if b == 1:
        return (_COS_BAND, _SIN_BAND)
    if b == 2:
        return (-_COS_BAND, _SIN_BAND)
    return (-_COS_POLE, _SIN_POLE)


# ---------------------------------------------------------------------------
# Output type
# ---------------------------------------------------------------------------

class B13Vertex(NamedTuple):
    """
    Exact-integer description of a B13 fractal vertex.

    Coordinate reconstruction (floating-point, for verification):
        R_n = sqrt((r_sq_rat + r_sq_phi·φ) / 4)
        x   = R_n · (sin_theta / BASE) · (cos_az / BASE)
        y   = R_n · (sin_theta / BASE) · (sin_az / BASE)
        z   = R_n · (cos_theta / BASE)

    All integer fields have no approximation except theta_ints (≤0.02%).
    """
    k: int          # Z₁₂ pentagon index
    j: int          # Z₅  vertex-within-pentagon
    n: int          # fractal level
    az_idx: int     # azimuth in Z_BASE, exact
    cos_az: int     # COS_TABLE[az_idx]
    sin_az: int     # SIN_TABLE[az_idx]
    cos_theta: int  # ≈ BASE·cos(polar), signed
    sin_theta: int  # ≈ BASE·sin(polar), positive
    r_sq_rat: int   # rational part of 4·R²_n
    r_sq_phi: int   # φ-coefficient of 4·R²_n


# ---------------------------------------------------------------------------
# Main evaluator
# ---------------------------------------------------------------------------

def evaluate(k: int, j: int, n: int = 0) -> B13Vertex:
    """
    Evaluate vertex (k, j, n) and return its exact integer representation.

    Parameters
    ----------
    k : int   Pentagon index, 0 ≤ k ≤ 11
    j : int   Vertex within pentagon, 0 ≤ j ≤ 4
    n : int   Fractal level, n ≥ 0

    Returns
    -------
    B13Vertex with all integer fields.
    """
    if not (0 <= k <= 11):
        raise ValueError(f"k must be in 0..11, got {k}")
    if not (0 <= j <= 4):
        raise ValueError(f"j must be in 0..4, got {j}")
    if n < 0:
        raise ValueError(f"n must be ≥ 0, got {n}")

    ai = az_idx(k, j, n)
    ct, st = theta_ints(k)
    r2_rat, r2_phi = r_sq_level(n)

    return B13Vertex(
        k=k, j=j, n=n,
        az_idx=ai,
        cos_az=COS_TABLE[ai],
        sin_az=SIN_TABLE[ai],
        cos_theta=ct,
        sin_theta=st,
        r_sq_rat=r2_rat,
        r_sq_phi=r2_phi,
    )


# ---------------------------------------------------------------------------
# Verification helpers
# ---------------------------------------------------------------------------

def to_float_coords(v: B13Vertex):
    """Convert B13Vertex to floating-point (x, y, z) for verification."""
    import math
    phi = (1.0 + math.sqrt(5.0)) / 2.0
    r_sq = (v.r_sq_rat + v.r_sq_phi * phi) / 4.0
    r = math.sqrt(r_sq)
    cos_az = v.cos_az / BASE
    sin_az = v.sin_az / BASE
    cos_th = v.cos_theta / BASE
    sin_th = v.sin_theta / BASE
    return (r * sin_th * cos_az,
            r * sin_th * sin_az,
            r * cos_th)


def verify_all(n_levels: int = 5) -> dict:
    """
    Verify evaluator against fractal_vertex_recurrence.vertex_coords.

    Checks:
    1. az_idx formula matches level_n_azimuth_idx
    2. r² grows as φ²ⁿ
    3. polar angle invariant across levels
    4. 60 distinct vertices at each level
    """
    import math
    from .fractal_vertex_recurrence import vertex_coords as ref_coords
    from .fractal_vertex_recurrence import level_n_azimuth_idx

    phi = (1.0 + math.sqrt(5.0)) / 2.0
    results = {"az_ok": True, "r2_ok": True, "theta_ok": True,
               "distinct_ok": True, "max_r2_err": 0.0, "max_coord_err": 0.0}

    for n in range(n_levels):
        r2_zphi = r_sq_level(n)
        r2_expected = (r2_zphi[0] + r2_zphi[1] * phi) / 4.0
        r2_ref = ((9 * phi + 10) / 4.0) * phi ** (2 * n)
        r2_err = abs(r2_expected - r2_ref)
        results["max_r2_err"] = max(results["max_r2_err"], r2_err)
        if r2_err > 1e-8:
            results["r2_ok"] = False

        coords_set = set()
        for k in range(12):
            for j in range(5):
                v = evaluate(k, j, n)

                # az_idx check
                ref_az = level_n_azimuth_idx(k, j, n)
                if v.az_idx != ref_az:
                    results["az_ok"] = False

                # coordinate check
                xv, yv, zv = to_float_coords(v)
                xr, yr, zr = ref_coords(k, j, n=n)
                # theta comparison (z/r should match)
                rv = math.sqrt(xv**2 + yv**2 + zv**2)
                rr = math.sqrt(xr**2 + yr**2 + zr**2)
                if rv > 1e-10 and rr > 1e-10:
                    cos_v = zv / rv
                    cos_r = zr / rr
                    err = abs(cos_v - cos_r)
                    results["max_coord_err"] = max(results["max_coord_err"], err)
                    if err > 0.001:   # 0.1% tolerance for integer rounding
                        results["theta_ok"] = False

                coords_set.add(round(v.az_idx, 0) * 10000 + v.cos_theta)

        if len(coords_set) < 60:
            results["distinct_ok"] = False

    return results


def demo():
    """Run a quick demo of the evaluator."""
    print("=== B13 Evaluator (production) ===")
    print()
    print(f"BASE = {BASE}")
    print(f"Step per Z₆₀ unit : {_STEP_Z60} (= BASE/60)")
    print(f"Step per level     : {_STEP_LVL} (= BASE/10 = 36°)")
    print()

    print("Sample vertices:")
    print(f"  {'k':>2} {'j':>2} {'n':>2} | {'az_idx':>6} {'cos_az':>6} {'sin_az':>6} "
          f"| {'cos_θ':>6} {'sin_θ':>6} | 4R²_n (Z[φ])")
    print("  " + "-" * 76)
    for k in range(4):
        for j in [0]:
            for n in [0, 1]:
                v = evaluate(k, j, n)
                r2 = r_sq_level(n)
                print(f"  {v.k:>2} {v.j:>2} {v.n:>2} | {v.az_idx:>6} {v.cos_az:>6} {v.sin_az:>6} "
                      f"| {v.cos_theta:>6} {v.sin_theta:>6} | {r2[0]}+{r2[1]}φ")
    print()

    print("R² progression (Z[φ], 4·R²_n = φ^{2n}·(10+9φ)):")
    for n in range(6):
        rat, phi_c = r_sq_level(n)
        import math
        phi = (1 + math.sqrt(5)) / 2
        val = (rat + phi_c * phi) / 4
        print(f"  n={n}: 4R²={rat}+{phi_c}φ  →  R²={val:.4f}  (φ^{2*n}·R²_0 = {((9*phi+10)/4)*phi**(2*n):.4f})")
    print()

    print("Verification:")
    res = verify_all(n_levels=4)
    for key, val in res.items():
        status = "✓" if val is True else ("✗" if val is False else f"{val:.2e}")
        print(f"  {key}: {status}")

import numpy as np

centers = np.load('data/results/v63_score/particle_centers.npy')
resid   = np.load('data/results/v63_score/residual_2d.npy')
px = 1.34
outer_r_px = 60.0 / px
box = int(outer_r_px * 1.5)
H, W = resid.shape

def rot_sym_fft(patch, cx, cy, r_min_A=20, r_max_A=55):
    h, w = patch.shape
    Y, X = np.ogrid[:h, :w]
    R = np.sqrt((X-cx)**2 + (Y-cy)**2)
    ring = (R >= r_min_A/px) & (R <= r_max_A/px)
    ys, xs = np.where(ring)
    if len(ys) < 10:
        return 0.0, 0.0, 0.0
    angles = np.arctan2(ys - cy, xs - cx)
    bins = 360
    angle_bins = ((angles + np.pi) / (2*np.pi) * bins).astype(int) % bins
    profile = np.zeros(bins)
    counts  = np.zeros(bins)
    np.add.at(profile, angle_bins, patch[ys, xs])
    np.add.at(counts,  angle_bins, 1)
    profile /= np.maximum(counts, 1)
    profile -= profile.mean()
    fft_p = np.fft.rfft(profile)
    power = np.abs(fft_p)**2
    total = float(power[1:20].sum()) + 1e-10
    return float(power[4])/total, float(power[5])/total, float(power[6])/total

scores_4, scores_5, scores_6 = [], [], []
for cy, cx in centers:
    if cy-box<0 or cy+box>=H or cx-box<0 or cx+box>=W:
        continue
    patch = resid[cy-box:cy+box, cx-box:cx+box].copy()
    patch -= patch.mean()
    s4, s5, s6 = rot_sym_fft(patch, box, box)
    scores_4.append(s4)
    scores_5.append(s5)
    scores_6.append(s6)

print(f"粒子数: {len(scores_4)}")
print(f"\n--- 回転対称パワー比（FFTベース）---")
print(f"4回対称(O群特有):  {np.mean(scores_4):.4f} +- {np.std(scores_4):.4f}")
print(f"5回対称(Ih群特有): {np.mean(scores_5):.4f} +- {np.std(scores_5):.4f}")
print(f"6回対称(共通):     {np.mean(scores_6):.4f} +- {np.std(scores_6):.4f}")
print(f"\nミスマッチ指標 S4/S5 = {np.mean(scores_4)/np.mean(scores_5):.3f}")
print(f"  >1 -> O群優勢, <1 -> Ih群優勢")

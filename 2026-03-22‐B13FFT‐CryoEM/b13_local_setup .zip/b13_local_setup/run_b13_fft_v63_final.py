#!/usr/bin/env python3
"""
run_b13_fft.py
==============
実クライオEMデータ（MRC / NPY）に対してB13-FFT残渣解析を実行するスクリプト。

主な機能:
  - MRC または NPY ファイルの読み込み（メモリマップ対応）
  - B13-FFT残渣の計算（行・列両方向）
  - 粒子候補の自動検出（エッジ積ベース）
  - 動径プロファイルの計算と保存
  - 結果の可視化（PNG出力）

使い方:
    # MRCファイルを直接処理（1フレーム目のみ）
    python run_b13_fft.py --input data/mrc/May08_03_05_02_bin-1.mrc

    # 複数フレームを平均して解析
    python run_b13_fft.py \\
        --input data/mrc/May08_03_05_02_bin-1.mrc \\
                data/mrc/May08_07_30_46_bin.mrc \\
        --outdir data/results/two_frames

    # NPYファイルを使用（変換済みの場合）
    python run_b13_fft.py --input data/npy/May08_03.npy --scale 119

    # スケールを指定して解析
    python run_b13_fft.py --input data/mrc/your_file.mrc \\
        --pixel-size 1.34 --scale 119 \\
        --outer-r 60 --inner-r 40
"""

import argparse
import sys
import time
from pathlib import Path

import pathlib as _pathlib

def _add_pkg_paths():
    here = _pathlib.Path(__file__).parent.resolve()
    pkg_root = here / 'packages'
    for sub in [
        pkg_root / 'b13phase_extracted' / 'b13phase',
        pkg_root / 'cone_fft_extracted',
    ]:
        if sub.exists() and str(sub) not in sys.path:
            sys.path.insert(0, str(sub))

_add_pkg_paths()
import numpy as np
import matplotlib
matplotlib.use("Agg")  # ヘッドレス環境対応
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from tqdm import tqdm


# ──────────────────────────────────────────────────────────
# B13-FFT コア関数
# ──────────────────────────────────────────────────────────

def get_b13_bins(img_size: int, scale_factor: int, base: int = 3120) -> list:
    """
    IMG_SIZE のFFTに対するB13ビンインデックスを返す。
    az_idx = (5k+12j)*52 mod BASE をscale_factorでシフトしてIMG空間に写像。
    """
    az_idxs = set(
        (((5*k + 12*j) % 60) * 52) % base
        for k in range(12) for j in range(5)
    )
    bins = set()
    for az in az_idxs:
        b = int((az * scale_factor) % base * img_size / base)
        if 0 <= b < img_size:
            bins.add(b)
        c = img_size - b
        if 0 < c < img_size:
            bins.add(c)
    return sorted(bins)


def b13_fft_residual_2d(image: np.ndarray, scale_factor: int,
                         outer_r_px: float = None,
                         base: int = 3120) -> tuple:
    """
    行・列両方向のB13-FFT残渣を計算する。

    B13の60ビン（scale_factor適用後）に対応する周波数成分を抽出し、
    元画像からその成分を引いた残渣を返す。

    Returns
    -------
    (row_residual, col_residual, edge_product)
      row_residual : 行方向B13残渣
      col_residual : 列方向B13残渣
      edge_product : |row_resid| × |col_resid| （粒子境界検出用）
    """
    H, W = image.shape

    # 行方向残渣
    bins_row = get_b13_bins(W, scale_factor, base)
    fft_row  = np.fft.fft(image, axis=1)
    fft_b13_row = np.zeros_like(fft_row)
    for b in bins_row:
        fft_b13_row[:, b] = fft_row[:, b]
    b13_row  = np.fft.ifft(fft_b13_row, axis=1).real.astype(np.float32)
    row_res  = image - b13_row

    # 列方向残渣
    bins_col = get_b13_bins(H, scale_factor, base)
    fft_col  = np.fft.fft(image, axis=0)
    fft_b13_col = np.zeros_like(fft_col)
    for b in bins_col:
        fft_b13_col[b, :] = fft_col[b, :]
    b13_col  = np.fft.ifft(fft_b13_col, axis=0).real.astype(np.float32)
    col_res  = image - b13_col

    edge_product = np.abs(row_res) * np.abs(col_res)
    return row_res, col_res, edge_product

# ──────────────────────────────────────────────────────────
# 粒子検出
# ──────────────────────────────────────────────────────────

def detect_particles(edge_product: np.ndarray, outer_r_px: float,
                     min_distance_px: float = None,
                     threshold_percentile: float = 92.0) -> list:
    """
    エッジ積画像から粒子中心候補を検出する。

    Returns
    -------
    list of (y, x) tuples  粒子中心座標
    """
    from scipy.ndimage import uniform_filter, label

    if min_distance_px is None:
        min_distance_px = outer_r_px * 1.5

    # 平滑化
    smooth = uniform_filter(edge_product, size=int(outer_r_px * 0.8))

    # 閾値でマスク
    thresh = np.percentile(smooth, threshold_percentile)
    mask = smooth > thresh

    # 連結成分ラベリング
    labeled, n_labels = label(mask)
    centers = []
    for i in range(1, n_labels + 1):
        ys, xs = np.where(labeled == i)
        if len(ys) < 10:  # 小さすぎる領域を除外
            continue
        # 重み付き重心
        weights = smooth[ys, xs]
        cy = int(np.average(ys, weights=weights))
        cx = int(np.average(xs, weights=weights))
        # 端からの距離チェック
        margin = int(outer_r_px * 1.2)
        h, w = edge_product.shape
        if margin <= cy < h - margin and margin <= cx < w - margin:
            centers.append((cy, cx))

    # 近すぎる粒子を除去（greedy non-maximum suppression）
    centers.sort(key=lambda p: smooth[p[0], p[1]], reverse=True)
    kept = []
    for c in centers:
        too_close = any(
            (c[0]-k[0])**2 + (c[1]-k[1])**2 < min_distance_px**2
            for k in kept
        )
        if not too_close:
            kept.append(c)

    return kept


# ──────────────────────────────────────────────────────────
# 動径プロファイル
# ──────────────────────────────────────────────────────────

def radial_profile(image: np.ndarray, center: tuple,
                   max_r_px: float = None) -> tuple:
    """
    粒子中心からの動径プロファイルを計算する。

    Returns
    -------
    (radii, profile)  radii: Å単位、profile: 正規化強度
    """
    cy, cx = center
    h, w = image.shape
    if max_r_px is None:
        max_r_px = min(cy, h - cy, cx, w - cx) - 1

    max_r = int(max_r_px)
    profile = np.zeros(max_r)
    counts  = np.zeros(max_r)

    Y, X = np.ogrid[:h, :w]
    R = np.sqrt((X - cx)**2 + (Y - cy)**2)
    R_int = R.astype(np.int32)

    mask = R_int < max_r
    np.add.at(profile, R_int[mask], image[mask])
    np.add.at(counts,  R_int[mask], 1)

    counts = np.maximum(counts, 1)
    profile = profile / counts

    # 正規化しない（呼び出し側で平均後に正規化）
    radii = np.arange(max_r)
    return radii, profile


# ──────────────────────────────────────────────────────────
# 可視化
# ──────────────────────────────────────────────────────────

def visualize_results(raw_avg: np.ndarray, residual_2d: np.ndarray,
                      row_res: np.ndarray,
                      edge_product: np.ndarray, particles: list,
                      profiles_raw: list, profiles_res: list,
                      outer_r_px: float, inner_r_px: float,
                      pixel_size: float, n_frames: int,
                      outpath: Path,
                      shell_scores: list = None) -> None:
    """解析結果を6パネル図として保存する。"""

    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    fig.patch.set_facecolor("black")

    def ax_setup(ax, title, subtitle=""):
        ax.set_facecolor("black")
        ax.set_title(title + ("\n" + subtitle if subtitle else ""),
                     color="white", fontsize=10, pad=6)
        ax.tick_params(colors="gray")
        for sp in ax.spines.values():
            sp.set_color("gray")

    # パネル1: 生画像平均 + 粒子検出位置
    ax = axes[0, 0]
    ax_setup(ax, "Raw image (average)", f"{n_frames} frames, {len(particles)} particles detected")
    vmin, vmax = np.percentile(raw_avg, [2, 98])
    ax.imshow(raw_avg, cmap="gray", vmin=vmin, vmax=vmax)
    # スコアTOP粒子セット（上位25%）
    top_set = set()
    if shell_scores:
        n_top = max(1, len(shell_scores) // 4)
        top_set = {(s[1], s[2]) for s in shell_scores[:n_top]}
    for (cy, cx) in particles:
        is_top = (cy, cx) in top_set
        color_o = "lime" if is_top else "cyan"
        color_i = "lime" if is_top else "yellow"
        lw_o = 1.5 if is_top else 1.0
        circ_o = plt.Circle((cx, cy), outer_r_px, color=color_o, fill=False, lw=lw_o)
        circ_i = plt.Circle((cx, cy), inner_r_px, color=color_i, fill=False, lw=0.8)
        ax.add_patch(circ_o)
        ax.add_patch(circ_i)
    ax.set_xticks([]); ax.set_yticks([])

    # パネル2: B13残渣 (2D)
    ax = axes[0, 1]
    ax_setup(ax, "B13-FFT residual (2D)", "RdBu: red=+, blue=−")
    # 符号付き残渣をRdBu_rで表示（σの0.5倍で絞る）
    res_std = np.std(residual_2d)
    ax.imshow(residual_2d, cmap="RdBu_r", vmin=-res_std*0.5, vmax=res_std*0.5)
    for (cy, cx) in particles:
        # 外壁リング（シアン）と内壁リング（黄色）の両方を表示
        circ_o = plt.Circle((cx, cy), outer_r_px, color="cyan",   fill=False, lw=0.9, alpha=0.8)
        circ_i = plt.Circle((cx, cy), inner_r_px, color="yellow", fill=False, lw=0.7, alpha=0.7)
        ax.add_patch(circ_o)
        ax.add_patch(circ_i)
    ax.set_xticks([]); ax.set_yticks([])

    # パネル3: エッジ積
    ax = axes[0, 2]
    ax_setup(ax, "B13 edge product", "|row_resid| × |col_resid|")
    ep_norm = edge_product / (np.percentile(edge_product, 99.5) + 1e-8)
    ax.imshow(ep_norm, cmap="hot", vmin=0, vmax=1)
    for (cy, cx) in particles:
        circ = plt.Circle((cx, cy), outer_r_px, color="white", fill=False, lw=0.8, alpha=0.6)
        ax.add_patch(circ)
    ax.set_xticks([]); ax.set_yticks([])

    # パネル4: 動径プロファイル (raw)
    ax = axes[1, 0]
    ax_setup(ax, "Radial profile (raw image)", f"avg over {len(profiles_raw)} particles")
    ax.set_facecolor("black")
    ax.axhline(0, color="gray", lw=0.5)
    for prof in profiles_raw:
        r, p = prof
        r_a = r * pixel_size
        ax.plot(r_a, p, color="gray", alpha=0.3, lw=0.5)
    if profiles_raw:
        all_p = np.array([p for _, p in profiles_raw])
        mean_p = np.mean(all_p[:, :min(len(p) for _, p in profiles_raw)], axis=0)
        r_a = np.arange(len(mean_p)) * pixel_size
        ax.plot(r_a, mean_p, color="white", lw=1.5, label="mean")
    ax.axvline(outer_r_px * pixel_size, color="cyan",  ls="--", lw=1, label=f"outer {int(outer_r_px*pixel_size)}Å")
    ax.axvline(inner_r_px * pixel_size, color="yellow", ls=":",  lw=1, label=f"inner {int(inner_r_px*pixel_size)}Å")
    ax.set_xlabel("radius (Å)", color="white"); ax.set_ylabel("normalized intensity", color="white")
    ax.tick_params(colors="gray"); ax.legend(fontsize=8, facecolor="black", labelcolor="white")

    # パネル5: 動径プロファイル (B13残渣)
    ax = axes[1, 1]
    ax_setup(ax, "Radial profile (B13-FFT residual)", f"avg over {len(profiles_res)} particles")
    ax.set_facecolor("black")
    ax.axhline(0, color="gray", lw=0.5)
    r_min_px = max(1, int(5.0 / pixel_size))
    if profiles_res:
        min_len = min(len(p) for _, p in profiles_res)
        all_p   = np.array([p[:min_len] for _, p in profiles_res])
        mean_p  = np.mean(all_p, axis=0)
        se_p    = np.std(all_p, axis=0, ddof=1) / np.sqrt(len(all_p))
        r_a = np.arange(min_len) * pixel_size
        r_max_show = int(90.0 / pixel_size)
        for p_n in all_p:
            ax.plot(r_a[r_min_px:r_max_show], p_n[r_min_px:r_max_show], color="steelblue", alpha=0.05, lw=0.4)
        ax.fill_between(r_a[r_min_px:r_max_show],
                        mean_p[r_min_px:r_max_show] - se_p[r_min_px:r_max_show],
                        mean_p[r_min_px:r_max_show] + se_p[r_min_px:r_max_show],
                        color="cyan", alpha=0.3, label="+-SE")
        ax.plot(r_a[r_min_px:r_max_show], mean_p[r_min_px:r_max_show], color="cyan", lw=2.0, label="mean")
        zero_count = 0
        last_zero = -999
        min_zero_sep = 8.0  # ゼロ交差の最小間隔(Å) 小振動を除去
        for i in range(r_min_px, min(r_max_show, min_len - 1)):
            if mean_p[i] * mean_p[i+1] < 0:
                r_zero = (r_a[i] + r_a[i+1]) / 2
                if 30 < r_zero < 80 and (r_zero - last_zero) > min_zero_sep:
                    ax.axvline(r_zero, color="lime", ls="-", lw=1.2, alpha=0.9)
                    y_label = 0.037 if zero_count % 2 == 0 else -0.044
                    ax.text(r_zero + 0.5, y_label, f"{r_zero:.0f}A",
                            color="lime", fontsize=9, va="bottom", fontweight="bold")
                    zero_count += 1
                    last_zero = r_zero
    ax.axvline(outer_r_px * pixel_size, color="cyan",  ls="--", lw=1, label=f"outer {int(outer_r_px*pixel_size)}Ang")
    ax.axvline(inner_r_px * pixel_size, color="yellow", ls=":",  lw=1, label=f"inner {int(inner_r_px*pixel_size)}Ang")
    ax.set_xlabel("radius (Ang)", color="white"); ax.set_ylabel("B13 residual (raw)", color="white")
    ax.tick_params(colors="gray"); ax.legend(fontsize=8, facecolor="black", labelcolor="white")
    ax.set_ylim(-0.05, 0.05)

    # パネル6: 個別粒子残渣 (上位6粒子) ── 実際のパッチを2×3グリッドに表示
    ax = axes[1, 2]
    ax_setup(ax, "Top-6 particles (B13 residual)")
    ax.set_facecolor("black")
    ax.set_xticks([]); ax.set_yticks([])
    crop = int(outer_r_px * 1.5)
    n_show = min(6, len(particles))
    if n_show > 0:
        H_r, W_r = residual_2d.shape
        res_std_patch = np.std(residual_2d)
        for idx in range(n_show):
            cy, cx = particles[idx]
            y0, y1 = cy - crop, cy + crop
            x0, x1 = cx - crop, cx + crop
            if y0 < 0 or y1 > H_r or x0 < 0 or x1 > W_r:
                continue
            patch = residual_2d[y0:y1, x0:x1]
            row_g, col_g = divmod(idx, 3)
            # axes[1,2] の座標系でインセット軸を配置
            left   = col_g / 3.0 + 0.01
            bottom = 1.0 - (row_g + 1) / 2.0 + 0.01
            width  = 1.0 / 3.0 - 0.02
            height = 1.0 / 2.0 - 0.02
            ax_in = ax.inset_axes([left, bottom, width, height])
            ax_in.imshow(patch, cmap="RdBu_r",
                         vmin=-res_std_patch * 0.5,
                         vmax= res_std_patch * 0.5,
                         interpolation="nearest")
            # 同心円（内壁・外壁）オーバーレイ
            pc = crop  # パッチ内の中心
            ax_in.add_patch(plt.Circle((pc, pc), outer_r_px,
                                       color="cyan",   fill=False, lw=0.8))
            ax_in.add_patch(plt.Circle((pc, pc), inner_r_px,
                                       color="yellow", fill=False, lw=0.6))
            ax_in.set_xticks([]); ax_in.set_yticks([])
            ax_in.set_title(f"#{idx+1}", color="white", fontsize=7, pad=1)
            for sp in ax_in.spines.values():
                sp.set_color("gray")

    fig.suptitle(
        f"B13-FFT Residual Analysis\n"
        f"scale~{int(outer_r_px*2*pixel_size)}Å | outer={int(outer_r_px*pixel_size)}Å | inner={int(inner_r_px*pixel_size)}Å | {n_frames} frames averaged",
        color="white", fontsize=12, y=0.98
    )
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(outpath, dpi=120, bbox_inches="tight", facecolor="black")
    plt.close(fig)
    print(f"  → 保存: {outpath}")


# ──────────────────────────────────────────────────────────
# メイン処理
# ──────────────────────────────────────────────────────────

def load_frame(path: Path, all_frames: bool = False) -> np.ndarray:
    """MRCまたはNPYファイルから画像データを読み込む。
    all_frames=True の場合は全フレームを平均する（SNR向上）。"""
    suffix = path.suffix.lower()
    if suffix == ".npy":
        data = np.load(path, mmap_mode="r").astype(np.float32)
        if data.ndim == 3:
            print(f"    NPY: {data.shape} → {'全フレーム平均' if all_frames else '最初のフレーム'}を使用")
            return np.mean(data, axis=0) if all_frames else data[0]
        return data
    elif suffix in (".mrc", ".mrcs"):
        import mrcfile
        with mrcfile.mmap(path, mode="r", permissive=True) as mrc:
            data = mrc.data
            if data.ndim == 3:
                nz = data.shape[0]
                if all_frames:
                    print(f"    MRC: shape={data.shape} → 全{nz}フレーム平均を計算中...", flush=True)
                    # メモリ節約のため1フレームずつ積算
                    acc = np.zeros(data.shape[1:], dtype=np.float64)
                    for i in range(nz):
                        acc += data[i].astype(np.float64)
                        if (i+1) % 10 == 0:
                            print(f"      {i+1}/{nz}フレーム処理済み", flush=True)
                    return (acc / nz).astype(np.float32)
                else:
                    print(f"    MRC: shape={data.shape} → 最初のフレームを使用（--all-frames で全平均）")
                    return data[0].astype(np.float32)
            return data[:].astype(np.float32)
    else:
        raise ValueError(f"対応していないファイル形式: {suffix}")


def main():
    parser = argparse.ArgumentParser(
        description="B13-FFT残渣解析を実行する",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--input", nargs="+", required=True, type=Path,
                        help="入力ファイル (.mrc/.mrcs/.npy)。複数指定で平均処理")
    parser.add_argument("--outdir", type=Path, default=Path("data/results"),
                        help="出力ディレクトリ（デフォルト: data/results/）")
    parser.add_argument("--pixel-size", type=float, default=1.34,
                        help="ピクセルサイズ [Å/px]（デフォルト: 1.34）")
    parser.add_argument("--scale", type=float, default=119.0,
                        help="ターゲットスケール [Å]（デフォルト: 119, アポフェリチン外径）")
    parser.add_argument("--outer-r", type=float, default=60.0,
                        help="粒子外径 [Å]（デフォルト: 60）")
    parser.add_argument("--inner-r", type=float, default=40.0,
                        help="粒子内径 [Å]（デフォルト: 40）")
    parser.add_argument("--no-plot", action="store_true",
                        help="可視化をスキップ（高速化）")
    parser.add_argument("--all-frames", action="store_true",
                        help="全フレームを平均してから解析（SNR向上、推奨）")
    args = parser.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    # ── パラメータ表示 ──
    scale_factor = round(args.scale / args.pixel_size)
    outer_r_px   = args.outer_r / args.pixel_size
    inner_r_px   = args.inner_r / args.pixel_size
    print(f"\n{'='*55}")
    print(f"  B13-FFT 残渣解析")
    print(f"{'='*55}")
    print(f"  入力ファイル数 : {len(args.input)}")
    print(f"  ピクセルサイズ : {args.pixel_size} Å/px")
    print(f"  スケール       : {args.scale} Å  (factor={scale_factor})")
    print(f"  外径 / 内径    : {args.outer_r} / {args.inner_r} Å")
    print(f"  出力先         : {args.outdir}")
    print()

    # ── フレーム読み込み ──
    print("[1/4] フレーム読み込み...")
    frames = []
    for path in args.input:
        print(f"  {path.name} ...", end=" ", flush=True)
        try:
            frame = load_frame(path, all_frames=args.all_frames)
            frames.append(frame)
            print(f"shape={frame.shape}, dtype={frame.dtype}")
        except Exception as e:
            print(f"ERROR: {e}")
            sys.exit(1)

    # 平均
    if len(frames) > 1:
        # サイズが異なる場合は最小サイズにクロップ
        min_h = min(f.shape[0] for f in frames)
        min_w = min(f.shape[1] for f in frames)
        frames = [f[:min_h, :min_w] for f in frames]
        raw_avg = np.mean(frames, axis=0)
        print(f"  → {len(frames)}フレーム平均: shape={raw_avg.shape}")
    else:
        raw_avg = frames[0]

    # ── B13-FFT残渣計算 ──
    print("\n[2/4] B13-FFT残渣計算...")
    row_res, col_res, edge_product = b13_fft_residual_2d(raw_avg, scale_factor)
    residual_2d = (row_res + col_res) / 2.0  # 符号付き（絶対値なし）
    bins_used = len(get_b13_bins(raw_avg.shape[1], scale_factor))
    print(f"  B13ビン数(行): {bins_used}/{raw_avg.shape[1]}")
    print(f"  残渣RMS: {np.std(row_res):.4f}")

    # 結果保存（numpy）
    np.save(args.outdir / "residual_2d.npy", residual_2d)
    np.save(args.outdir / "edge_product.npy", edge_product)
    print(f"  → {args.outdir}/residual_2d.npy, edge_product.npy")

    # ── 粒子検出 ──
    print("\n[3/4] 粒子候補検出...")
    particles = detect_particles(edge_product, outer_r_px)
    print(f"  {len(particles)} 粒子候補を検出")

    # 動径プロファイル計算
    profiles_raw, profiles_res = [], []
    max_r = int(outer_r_px * 1.5)
    box = max_r
    H, W = raw_avg.shape
    for (cy, cx) in tqdm(particles, desc="  動径プロファイル計算", leave=False):
        try:
            if cy-box < 0 or cy+box >= H or cx-box < 0 or cx+box >= W:
                continue
            patch_raw = raw_avg[cy-box:cy+box, cx-box:cx+box].copy()
            patch_res = residual_2d[cy-box:cy+box, cx-box:cx+box].copy()
            patch_raw -= patch_raw.mean()
            patch_res -= patch_res.mean()
            center = (box, box)
            r, p = radial_profile(patch_raw, center, max_r)
            profiles_raw.append((r, p))
            r, p = radial_profile(patch_res, center, max_r)
            profiles_res.append((r, p))
        except Exception:
            pass

    # 殻検出スコア計算
    shell_scores = []
    for (cy, cx), (_, p_res) in zip(
            [(cy,cx) for (cy,cx) in particles
             if not(cy-box<0 or cy+box>=H or cx-box<0 or cx+box>=W)],
            profiles_res):
        r = np.arange(len(p_res)) * args.pixel_size
        tm = (r >= 20) & (r <= 38)
        trough = -p_res[tm].min() if tm.any() else 0.0
        zm = (r >= 35) & (r <= 48)
        pz = p_res[zm]
        sharpness = 0.0
        for i in range(len(pz)-1):
            if pz[i]*pz[i+1] < 0:
                sharpness = abs(pz[i] - pz[i+1])
                break
        score = trough * (1.0 + sharpness * 50)
        shell_scores.append((score, cy, cx))
    shell_scores.sort(reverse=True)
    if shell_scores:
        np.save(args.outdir / "shell_scores.npy", np.array(shell_scores))
        top_score = shell_scores[0][0]
        mean_score = np.mean([s[0] for s in shell_scores])
        print(f"  → 殻スコア: mean={mean_score:.4f}  max={top_score:.4f}  N={len(shell_scores)}")

    # 平均プロファイル保存
    if profiles_res:
        min_len = min(len(p) for _, p in profiles_res)
        mean_res = np.mean([p[:min_len] for _, p in profiles_res], axis=0)
        np.save(args.outdir / "mean_radial_profile.npy", mean_res)
        print(f"  → 平均動径プロファイル保存: {args.outdir}/mean_radial_profile.npy")

    # 粒子座標保存
    if particles:
        np.save(args.outdir / "particle_centers.npy", np.array(particles))
        print(f"  → 粒子座標保存: {args.outdir}/particle_centers.npy")

    # ── 可視化 ──
    if not args.no_plot:
        print("\n[4/4] 可視化...")
        outpng = args.outdir / "b13_result.png"
        visualize_results(
            raw_avg, residual_2d, row_res, edge_product, particles,
            profiles_raw, profiles_res,
            outer_r_px, inner_r_px, args.pixel_size,
            n_frames=len(frames),
            outpath=outpng,
            shell_scores=shell_scores if shell_scores else None
        )
    else:
        print("\n[4/4] 可視化: スキップ")

    elapsed = time.time() - t0
    print(f"\n{'='*55}")
    print(f"  完了  ({elapsed:.1f}秒)")
    print(f"  結果: {args.outdir}/")
    print(f"{'='*55}\n")


if __name__ == "__main__":
    main()

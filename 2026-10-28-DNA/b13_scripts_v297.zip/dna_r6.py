# dna_r6.py  事前登録 R6：アデニンの六角形を共有結合の決めごとだけで組む（整数だけ）
from itertools import combinations, product

def add(a, b): return tuple(x + y for x, y in zip(a, b))
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def crs(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def n2(a): return dot(a, a)

def tet(s):
    """八分円 s = (±1,±1,±1) の正四面体：正八面体の面 3 頂点＋立方体の角（とがった先）"""
    return [(6*s[0], 0, 0), (0, 6*s[1], 0), (0, 0, 6*s[2]), (6*s[0], 6*s[1], 6*s[2])]
def center4(T):            # 中心の 4 倍（割らない）
    c = (0, 0, 0)
    for v in T: c = add(c, v)
    return c
def reflect(T, p):         # 頂点 p で点対称に折り返す
    return [sub((2*p[0], 2*p[1], 2*p[2]), v) for v in T]

def overlap(A, B):
    """二つの正四面体の中身が重なるか（分離軸、整数の内積だけ）。頂点・辺・面で接するだけなら重ならない"""
    axes = []
    for T in (A, B):
        for i, j, k in combinations(range(4), 3):
            axes.append(crs(sub(T[j], T[i]), sub(T[k], T[i])))
    ea = [sub(A[j], A[i]) for i, j in combinations(range(4), 2)]
    eb = [sub(B[j], B[i]) for i, j in combinations(range(4), 2)]
    for u in ea:
        for w in eb:
            c = crs(u, w)
            if c != (0, 0, 0): axes.append(c)
    for ax in axes:
        pa = [dot(ax, v) for v in A]; pb = [dot(ax, v) for v in B]
        if max(pa) <= min(pb) or max(pb) <= min(pa): return False
    return True
def shared(A, B): return len(set(A) & set(B))
KIND = {0: "なし", 1: "頂点（単結合）", 2: "辺（二重・芳香環）", 3: "面（三重）"}

# 帯：(1,1,1) 軸のまわりを一周する 6 個（隣は符号が一つだけ違う）、ふた 2 個
BAND = [(1,1,-1), (-1,1,-1), (-1,1,1), (-1,-1,1), (1,-1,1), (1,-1,-1)]
CAPS = [(1,1,1), (-1,-1,-1)]

def shadow3(p):            # (1,1,1) から写した影の 3 倍
    s = p[0] + p[1] + p[2]
    return (3*p[0] - s, 3*p[1] - s, 3*p[2] - s)

def build(names, tip_H, n6_at=None, n6_mode="vertex"):
    atoms = {n: tet(s) for n, s in zip(names, BAND)}
    caps = [tet(s) for s in CAPS]
    Hs = [(n, atoms[n][3]) for n in tip_H]          # H はとがった先
    if n6_at:
        T = atoms[n6_at]
        if n6_mode == "vertex":
            atoms["N6"] = reflect(T, T[3])           # とがった先で点対称に折り返す
        else:                                        # 負の対照：辺（とがった先と、もう一頂点）の中点で折り返す
            m2 = add(T[3], T[0])
            atoms["N6"] = [sub(m2, v) for v in T]
        free = [v for v in atoms["N6"] if v not in T]
        Hs += [("N6", free[0]), ("N6", free[1])]   # 残り 3 頂点のうち 2 つに H、1 つは空き
    return atoms, caps, Hs

def report(atoms, caps, label):
    print(f"\n[{label}]")
    names = list(atoms)
    ring = [n for n in names if n != "N6"]
    for a, b in zip(ring, ring[1:] + ring[:1]):
        A, B = atoms[a], atoms[b]
        print(f"   {a}–{b}：分け合う {KIND[shared(A, B)]}  中心距離²×16 {n2(sub(center4(A), center4(B)))}")
    if "N6" in atoms:
        A, B = atoms["C6"], atoms["N6"]
        print(f"   C6–N6：分け合う {KIND[shared(A, B)]}  中心距離²×16 {n2(sub(center4(A), center4(B)))}")
    allT = [(n, atoms[n]) for n in names] + [("ふた", c) for c in caps]
    bad = [(x, y) for (x, A), (y, B) in combinations(allT, 2) if overlap(A, B)]
    print("   中身の重なり：", bad if bad else "なし")
    return bad

print("R0. ベンゼン（再現）")
atoms, caps, Hs = build(["C1", "C2", "C3", "C4", "C5", "C6"], ["C1", "C2", "C3", "C4", "C5", "C6"])
report(atoms, caps, "ベンゼン C6H6")
cs = [center4(atoms[n]) for n in atoms]
print("   C–H の長さ²×16：", sorted({n2(sub((4*h[1][0], 4*h[1][1], 4*h[1][2]), center4(atoms[h[0]]))) for h in Hs}))
sh = [shadow3(c) for c in cs]
print("   (1,1,1) から写した影（長さ×12、長さ²×144）：中心までの長さ²", sorted({n2(p) for p in sh}),
      " 隣どうしの長さ²", sorted({n2(sub(sh[i], sh[(i+1) % 6])) for i in range(6)}))
print("   （×16 と ×144 で割らずに比べる：C–C 576 = 16×36、C–H 432 = 16×27、影の隣 3456 = 144×24）")

print("\nR1・R3. アデニンの六角形＋N6")
names = ["N1", "C2", "N3", "C4", "C5", "C6"]
atoms, caps, Hs = build(names, ["C2"], n6_at="C6")
bad = report(atoms, caps, "アデニンの六角形 + NH2")
print("   H の席：", [h[0] for h in Hs], "  空いた頂点（N1・N3 のとがった先、N6 の一つ）は H なし")
print("   C4・C5 のとがった先：", atoms["C4"][3], atoms["C5"][3], "（五角形の側に残す）")
cnt = {"C": sum(1 for n in atoms if n[0] == "C"), "N": sum(1 for n in atoms if n[0] == "N"), "H": len(Hs)}
print("   数えた組成：", cnt)

print("\nR1 の負の対照：N6 を辺でつけたら「辺」と返すか")
atoms2, caps2, _ = build(names, ["C2"], n6_at="C6", n6_mode="edge")
print("   C6–N6：", KIND[shared(atoms2["C6"], atoms2["N6"])])

print("\nR2 の負の対照：重なる正四面体を「重なる」と返すか")
T = tet((1, 1, -1)); T2 = [add(v, (1, 0, 0)) for v in T]
print("   一歩ずらした同じ正四面体：", "重なる" if overlap(T, T2) else "重ならない")
print("   辺を分け合う隣（N1 と C2）：", "重なる" if overlap(tet(BAND[0]), tet(BAND[1])) else "重ならない")

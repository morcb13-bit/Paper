# dna_g3.py  G3：dGMP 全体を、変更後の規則（1–3 の組は頂点を分け合ってよい）に固定して組む（整数だけ）
# 組み方は dna_build1.py（dAMP）のまま。違いは塩基の置換基だけ：
#   アデニンの N6・H(N6)a・H(N6)b・H(C2) を外し、O6（C6 の辺 (6,0,0)–(6,−6,−6) の中点で折り返す：G0 で合格した辺）、
#   N2（C2 のとがった先で折り返す）と H(N2) 2 個（G1 の 3 通り）、H(N1)（N1 のとがった先：G2）を付ける。
#   五角形・H(C8)・N9 の口・糖・C5′・O5′・O3′・P・リン酸の O・糖の H は dAMP と同じ探し方（最初に見つかったもの）。
# 規則：途中の置き方の判定（Mol.ok_with）を、1–3 の組を許す形に置き換える。G3 の途中では規則を変えない。
# 事前基準（それぞれ別々に判定して返す）：
#   1 C6=O6：全体でも O6 は C6 とだけ頂点 2（辺）、ほかは 1–3 の組だけと頂点を分け合い、どれとも重ならない
#   2 C2–N2 と N2–H×2：同上（N2 は C2 と頂点 1、H は N2 と頂点 1）
#   3 N1–H：同上
#   4 五角形：dAMP と同じ 8 通りの閉じ方のどれかで閉じる
#   5 糖・リン酸：dAMP と同じ決めごとで付く
#   6 頂点の分け合い：全原子の組で、結合した組は分け合う／結合していない組は 1–3 の組だけが分け合ってよい
#   7 中身の重なり：全原子の組で 0（整数の分離軸）
#   8 組成・原子数：C10 H14 N5 O7 P1、原子 37
#   9 頂点の和：1018（予測値。H 10・C N O 34・P 130 の和）
#   記録：全部満たせば【合格】、塩基の部分は置けるが全体で残るなら【部分合格】、見つからなければ【今回の探索範囲では見つからなかった】。
import json, itertools
src = open("dna_build1.py").read().split("n_ad = 0; found = None")[0]
exec(src)
J6 = json.load(open("dna_adenine6.json"))
ring = ["N1", "C2", "N3", "C4", "C5", "C6"]
R0 = {k: [tuple(v) for v in J6["atoms"][k]] for k in ring}
def refl_o(T, p): return [tuple(2*c - x for c, x in zip(p, v)) for v in T]
def refl_edge_o(T, a, b): m2 = tuple(x + y for x, y in zip(a, b)); return [tuple(c - x for c, x in zip(m2, v)) for v in T]
def mid_o(a, b): return tuple((x + y) // 2 for x, y in zip(a, b))
def H_o(T, p): return refl_o([mid_o(p, v) for v in T], p)
tip = {k: next(v for v in R0[k] if not any(v in R0[j] for j in ring if j != k)) for k in ring}
O6 = refl_edge_o(R0["C6"], (6, 0, 0), (6, -6, -6))
N2 = refl_o(R0["C2"], tip["C2"])
HN1 = H_o(R0["N1"], tip["N1"])
frN2 = [v for v in N2 if v not in R0["C2"]]

# ---- 変更後の規則：1–3 の組は頂点を分け合ってよい ----
def ok13(self, name, T, bonded):
    nb13 = set()
    for b in bonded:
        for e in self.B:
            if b in e: nb13 |= set(e) - {b}
    for k, U in self.A.items():
        s = len(set(T) & set(U))
        if k in bonded:
            if s == 0: return False
        elif s and k not in nb13: return False
        if overlap(T, U): return False
    return True
Mol.ok_with = ok13

def g_bases():
    for hi, (p, q) in enumerate(itertools.combinations(frN2, 2)):
        base0 = {**R0, "O6": O6, "N2": N2, "H(N2)a": H_o(N2, p), "H(N2)b": H_o(N2, q), "H(N1)": HN1}
        bg = {k: [tuple(v) for v in D2(V)] for k, V in base0.items()}
        for si, s in enumerate(P5["sols"]):
            m = Mol()
            for k, T in bg.items(): m.A[k] = T
            for a, b in [("N1","C2"),("C2","N3"),("N3","C4"),("C4","C5"),("C5","C6"),("C6","N1"),("C6","O6"),("C2","N2"),
                         ("N2","H(N2)a"),("N2","H(N2)b"),("N1","H(N1)")]:
                m.B.add(frozenset((a, b)))
            ok = True
            for k in ("N7", "C8", "N9"):
                T = [tuple(v) for v in D2(s[k])]; bd = {"N7": ["C5"], "C8": ["N7"], "N9": ["C8", "C4"]}[k]
                if not m.ok_with(k, T, bd): ok = False; break
                m.add_(k, T, bd)
            if not ok: continue
            for pp in free(m, "C8"):
                Hc8 = H_at(m.A["C8"], pp)
                if not m.ok_with("H(C8)", Hc8, ["C8"]): continue
                m2 = copy(m); m2.add_("H(C8)", Hc8, ["C8"])
                for qq in free(m2, "N9"):
                    yield hi, si, m2, qq

def one_three(B):
    nb = {}
    for e in B:
        a, b = tuple(e); nb.setdefault(a, set()).add(b); nb.setdefault(b, set()).add(a)
    out = set()
    for c, ns in nb.items():
        for x, y in itertools.combinations(sorted(ns), 2): out.add(frozenset((x, y)))
    return out - B
def final_checks(h):
    B = set(h.B); o13 = one_three(B); names = list(h.A)
    share_bad = []; over_bad = []
    for a, b in itertools.combinations(names, 2):
        e = frozenset((a, b)); s = len(set(h.A[a]) & set(h.A[b]))
        if e in B and s == 0: share_bad.append((a, b, "結合なのに分け合わない"))
        if e not in B and s and e not in o13: share_bad.append((a, b, f"頂点 {s}（結合していない・1–3 でない）"))
        if overlap(h.A[a], h.A[b]): over_bad.append((a, b))
    return share_bad, over_bad, B, o13

# ---- 塩基の部分だけ（項目 1〜4）を先に数える ----
n_base = 0; parts = {"五角形まで閉じた塩基": 0}
for hi, si, m, q in g_bases():
    n_base += 1
print("塩基（G1 の 3 通り × 五角形 8 通り × H(C8) × N9 の口）で五角形まで置けた候補：", n_base)
found = None; tried_sug = 0
for hi, si, m, q in g_bases():
    for s in sugars(m, q):
        tried_sug += 1
        for dd in subst(s):
            for f in phosphate_O(dd):
                for h in hydrogens(f):
                    found = (hi, si, h); break
                if found: break
            if found: break
        if found: break
    if found: break
print("糖の五角形を閉じた置き方（試した数）：", tried_sug)
if not found:
    print("【今回の探索範囲では見つからなかった】（塩基は置けたので、全体で残る：部分合格の候補）" if n_base else "【今回の探索範囲では見つからなかった】")
else:
    hi, si, h = found
    share_bad, over_bad, B, o13 = final_checks(h)
    def bond_share(a, b): return len(set(h.A[a]) & set(h.A[b]))
    def item(names_bonds):
        return all(bond_share(a, b) == n for a, b, n in names_bonds)
    cnt = {}
    for k in h.A: cnt[EL(k)] = cnt.get(EL(k), 0) + 1
    VN = {"H": 10, "C": 34, "N": 34, "O": 34, "P": 130}
    vs = sum(VN[EL(k)] for k in h.A)
    touch = lambda x: [k for k in h.A if k != x and set(h.A[k]) & set(h.A[x])]
    print(f"見つかった dGMP：H(N2) の置き方 {hi+1}・五角形の置き方 {si+1}")
    print("  1 C6=O6：C6 と頂点", bond_share("C6", "O6"), " 触れる原子", touch("O6"))
    print("  2 C2–N2：", bond_share("C2", "N2"), " N2–H：", bond_share("N2", "H(N2)a"), bond_share("N2", "H(N2)b"), " N2 に触れる原子", touch("N2"))
    print("  3 N1–H：", bond_share("N1", "H(N1)"), " 触れる原子", touch("H(N1)"))
    print("  4 五角形：", [bond_share(a, b) for a, b in [("C5","N7"),("N7","C8"),("C8","N9"),("N9","C4"),("C4","C5")]])
    print("  5 糖・リン酸：N9–C1′", bond_share("N9", "C1'"), " O5′–P", bond_share("O5'", "P"), " P–OP1", bond_share("P", "OP1"))
    print("  6 頂点の分け合い：", "合格" if not share_bad else share_bad[:5])
    print("    頂点を分け合う 1–3 の組：", sorted(tuple(sorted(e)) for e in o13 if bond_share(*tuple(e))))
    print("  7 中身の重なり：", "0" if not over_bad else over_bad[:5])
    print("  8 組成：", cnt, " 原子", len(h.A), " 期待 C10 H14 N5 O7 P1・37 →", cnt == {"C": 10, "H": 14, "N": 5, "O": 7, "P": 1} and len(h.A) == 37)
    print("  9 頂点の和：", vs, " 予測 1018 →", vs == 1018)
    ok = not share_bad and not over_bad and cnt == {"C": 10, "H": 14, "N": 5, "O": 7, "P": 1} and vs == 1018
    print("判定：", "【合格】" if ok else "【部分合格】")
    json.dump({"atoms": {k: [list(v) for v in T] for k, T in h.A.items()}, "bonds": [sorted(e) for e in h.B]}, open("dna_dGMP.json", "w"))

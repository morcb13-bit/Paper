# dna_check_helix.py  図（dna02_helix.html）の検定：共有結合の決めごと（B13）と教科書（B 型）の二つの側
# 図の座標は教科書から借りた浮動小数なので、この検定は観察者側の物差し（浮動小数）で測る。整数の判定ではない。
#
# 事前基準 ── 側 1：共有結合の決めごと（第 1 章 dAMP で使ったもの）
#   辺の結合：塩基の六角形の 6 本、六角形の外の二重結合（C=O, P=O）。五角形の中の結合は C4–C5 以外は頂点。
#   頂点の結合：それ以外すべて（H を含む）。
#   1a 頂点の結合：二つのギャスケットの最も近い頂点の組の隔たりが、小さい方の辺の 1% 以下なら「分け合う」。
#   1b 辺の結合：頂点の組が 2 組（別々の頂点どうし）とも 1% 以下なら「分け合う」。
#   1c 中身の重なり：分離軸で、食い込みが小さい方の辺の 1% を超えたら「重なる」。
#   1d 結合していない組が頂点を分け合っていない（1% 以下の組が無い）。
#   合格＝1a〜1d がすべて満たされる。
#   正の対照：第 1 章の整数の dAMP（dna_dAMP.json）を同じ物差しで測る → 全部合格すること（物差しが OK を返せる）。
#   負の対照：図の各ギャスケットを中心のまわりに勝手に回す → 1a の合格が減ること（NG を返せる）。
#
# 事前基準 ── 側 2：教科書（[知識]、こちらで検算していない値。許容幅も事前に決める）
#   2a 右巻き        2b 1 回り 10 塩基対（1 段の回転 36°±1°）  2c 1 段の上がり 3.38±0.1 Å
#   2d P の軸からの半径 約 9 Å（8.5〜10）  2e 二本は逆向き  2f 相補（A–T・G–C）
#   2g 水素結合の本数 A–T 2・G–C 3、長さ 2.7〜3.1 Å  2h C1′–C1′ 約 10.5 Å（10〜11）
#   2i 塩基対の面が軸にほぼ垂直（傾き 10° 以内）
#   負の対照：座標を鏡に写す（z → −z）→ 2a が「左巻き」と返すこと。
#   注意：側 2 の数値は借りた座標そのものの性質で、ギャスケットを置いたことからは出ない。
import json, itertools, math
import numpy as np
EDGE6 = {"N1", "C2", "N3", "C4", "C5", "C6"}
IMID = {"C4", "C5", "N7", "C8", "N9"}

def gasket_tets(path_fig):
    html = open(path_fig).read(); s = html.index("const D = ") + 10; e = html.index(";\n", s)
    D = json.loads(html[s:e]); return D

def edge_len(T): return float(np.linalg.norm(np.array(T[0]) - np.array(T[1])))
def overlap_depth(A, B):
    """分離軸の最小の食い込み（正なら重なり）"""
    A = np.array(A, float); B = np.array(B, float); axes = []
    for T in (A, B):
        for i, j, k in itertools.combinations(range(4), 3): axes.append(np.cross(T[j]-T[i], T[k]-T[i]))
    for i, j in itertools.combinations(range(4), 2):
        for k, l in itertools.combinations(range(4), 2):
            c = np.cross(A[j]-A[i], B[l]-B[k])
            if np.linalg.norm(c) > 1e-9: axes.append(c)
    best = 1e9
    for ax in axes:
        ax = ax / np.linalg.norm(ax); pa = A @ ax; pb = B @ ax
        best = min(best, min(pa.max() - pb.min(), pb.max() - pa.min()))
    return best
def pair_gaps(A, B):
    A = np.array(A, float); B = np.array(B, float)
    g = sorted((float(np.linalg.norm(A[i]-B[j])), i, j) for i in range(4) for j in range(4))
    first = g[0]; second = next(x for x in g[1:] if x[1] != first[1] and x[2] != first[2])
    return first[0], second[0]

def side1(tets, names, bonds, kind, label, tol=0.01):
    n = len(tets); bs = {frozenset(b) for b in bonds}
    ok_v = ok_e = nv = ne = 0; worst = []
    for b in bonds:
        i, j = b; e = min(edge_len(tets[i]), edge_len(tets[j]))
        g1, g2 = pair_gaps(tets[i], tets[j])
        if kind(i, j) == "edge":
            ne += 1; ok = g1 <= tol*e and g2 <= tol*e; ok_e += ok
        else:
            nv += 1; ok = g1 <= tol*e; ok_v += ok
        worst.append((g1 / e, names[i], names[j]))
    over = share = 0
    C = np.array([np.mean(t, 0) for t in tets]); R = np.array([np.linalg.norm(np.array(t[0]) - np.mean(t, 0)) for t in tets])
    for i in range(n):
        for j in range(i+1, n):
            if np.linalg.norm(C[i]-C[j]) > R[i] + R[j] + 1e-6: continue
            e = min(edge_len(tets[i]), edge_len(tets[j]))
            if overlap_depth(tets[i], tets[j]) > tol*e: over += 1
            if frozenset((i, j)) not in bs and pair_gaps(tets[i], tets[j])[0] <= tol*e: share += 1
    worst.sort()
    med = worst[len(worst)//2][0]
    print(f"[{label}] 頂点の結合 {ok_v}/{nv} 合格  辺の結合 {ok_e}/{ne} 合格  重なる組 {over}  結合していないのに頂点を分け合う組 {share}"
          f"  頂点の隔たり／辺 の中央 {med:.3f}  最大 {worst[-1][0]:.3f}")
    return ok_v == nv and ok_e == ne and over == 0 and share == 0

# ---- 側 1：図 ----
D = gasket_tets("dna02_helix.html")
B = json.load(open("bdna10.json")); A = B["atoms"]
tets = [a[3] for a in D["atoms"]]; names = [f"{a[0]}{a[1]}{a[3]}" for a in A]
def kind_fig(i, j):
    a, b = A[i], A[j]
    if a[3] in EDGE6 and b[3] in EDGE6 and a[1] == b[1] and a[0] == b[0]: return "edge"
    o = next(o for x, y, o in B["bonds"] if {x, y} == {i, j})
    if o == 2 and not (a[3] in IMID and b[3] in IMID): return "edge"
    return "vertex"
bonds = [(i, j) for i, j, o in B["bonds"]]
print("側 1：共有結合の決めごと")
r_fig = side1(tets, names, bonds, kind_fig, "図")

# 正の対照：整数の dAMP
J = json.load(open("dna_dAMP.json")); nm = list(J["atoms"]); T2 = [J["atoms"][k] for k in nm]
ix = {k: n for n, k in enumerate(nm)}
bd2 = [(ix[a], ix[b]) for a, b in J["bonds"]]
band_alt = {frozenset(x) for x in [("N1","N3"),("N1","C5"),("C2","C4"),("C2","C6"),("N3","C5"),("C4","C6")]}
def kind_d(i, j):
    s = len({tuple(v) for v in T2[i]} & {tuple(v) for v in T2[j]}); return "edge" if s == 2 else "vertex"
# 帯の一つおきの接点は帯の性質として結合の側に数える（第 1 章と同じ扱い）
bd2x = bd2 + [(ix[a], ix[b]) for a, b in (tuple(x) for x in band_alt)]
r_pos = side1(T2, nm, bd2x, kind_d, "正の対照：整数の dAMP")

# 負の対照：図の各ギャスケットを勝手に回す
rng = np.random.default_rng(13)
def rand_rot():
    q = rng.normal(size=4); q /= np.linalg.norm(q); w, x, y, z = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
T3 = []
for t in tets:
    t = np.array(t); c = t.mean(0); T3.append(((t - c) @ rand_rot().T + c).tolist())
r_neg = side1(T3, names, bonds, kind_fig, "負の対照：向きを勝手に回した図")

# ---- 側 2：教科書 ----
print("\n側 2：教科書（B 型）")
X = np.array([a[5] for a in A])
def helix(X, label):
    P = {(a[0], a[1]): X[k] for k, a in enumerate(A) if a[3] == "P"}
    res = []
    for ch in ("A", "B"):
        ks = sorted(r for c, r in P if c == ch)
        pts = [P[(ch, r)] for r in ks]
        ang = [math.degrees(math.atan2(p[1], p[0])) for p in pts]; z = [p[2] for p in pts]
        dth = [((ang[i+1]-ang[i]+180) % 360) - 180 for i in range(len(ang)-1)]
        dz = [z[i+1]-z[i] for i in range(len(z)-1)]
        tw = [t if h > 0 else -t for t, h in zip(dth, dz)]       # 上がる向きに揃えた回転
        res.append((ch, np.mean(tw), np.mean(np.abs(dz)), np.mean([math.hypot(p[0], p[1]) for p in pts]), np.sign(np.mean(dz))))
    for ch, tw, rise, rad, sg in res:
        print(f"   [{label}] 鎖 {ch}：上がる向きに見た 1 段の回転 {tw:+.1f}°（{'右' if tw>0 else '左'}巻き）"
              f"  1 回り {360/abs(tw):.2f} 塩基対  上がり {rise:.2f} Å  P の半径 {rad:.2f} Å  5′→3′ の向き {'+z' if sg>0 else '−z'}")
    return res
h = helix(X, "図")
hm = helix(X * np.array([1, 1, -1]), "負の対照：鏡")
ok2a = all(r[1] > 0 for r in h); ok2b = all(abs(abs(r[1]) - 36) <= 1 for r in h)
ok2c = all(abs(r[2] - 3.38) <= 0.1 for r in h); ok2d = all(8.5 <= r[3] <= 10 for r in h)
ok2e = h[0][4] != h[1][4]
# 相補・水素結合・C1'–C1'・塩基対の面
comp = {"DA": "DT", "DT": "DA", "DG": "DC", "DC": "DG"}
idx = {(a[0], a[1], a[3]): k for k, a in enumerate(A)}
rA = sorted({a[1] for a in A if a[0] == "A"})
ok2f = ok2g = ok2h = ok2i = True; rows = []
HBP = {"DA": [("N6","O4"),("N1","N3")], "DT": [("O4","N6"),("N3","N1")], "DG": [("O6","N4"),("N1","N3"),("N2","O2")], "DC": [("N4","O6"),("N3","N1"),("O2","N2")]}
ax = np.array([0, 0, 1.0])
for r in rA:
    na = next(a[2] for a in A if a[0] == "A" and a[1] == r); nb = next(a[2] for a in A if a[0] == "B" and a[1] == -r)
    ok2f &= comp[na] == nb
    # 水素結合の本数：N・O どうしで 3.2 Å 以内の組を数える（手で与えた組は使わない）
    sa = [k for k, a in enumerate(A) if a[0] == "A" and a[1] == r and a[4] in "NO" and a[3] not in ("O3'", "O5'", "O4'", "O1P", "O2P", "OP1", "OP2")]
    sb = [k for k, a in enumerate(A) if a[0] == "B" and a[1] == -r and a[4] in "NO" and a[3] not in ("O3'", "O5'", "O4'", "O1P", "O2P", "OP1", "OP2")]
    hb = [(A[p][3], A[q][3], float(np.linalg.norm(X[p]-X[q]))) for p in sa for q in sb if np.linalg.norm(X[p]-X[q]) <= 3.2]
    want = 2 if na in ("DA", "DT") else 3
    ok2g &= len(hb) == want and all(2.7 <= x[2] <= 3.1 for x in hb)
    c1 = float(np.linalg.norm(X[idx[("A", r, "C1'")]] - X[idx[("B", -r, "C1'")]])); ok2h &= 10 <= c1 <= 11
    ring = [idx[("A", r, n)] for n in EDGE6] + [idx[("B", -r, n)] for n in EDGE6]
    Y = X[ring] - X[ring].mean(0); nrm = np.linalg.svd(Y)[2][2]
    tilt = math.degrees(math.acos(abs(nrm @ ax))); ok2i &= tilt <= 10
    rows.append((r, na[1] + "–" + nb[1], len(hb), [round(x[2], 2) for x in hb], round(c1, 2), round(tilt, 1)))
print("   塩基対：番号・組・水素結合の本数・長さ・C1′–C1′・面の傾き")
for row in rows: print("     ", row)
for k, v in [("2a 右巻き", ok2a), ("2b 1 回り 10", ok2b), ("2c 上がり 3.38", ok2c), ("2d P の半径 約 9", ok2d), ("2e 逆向き", ok2e),
             ("2f 相補", ok2f), ("2g 水素結合 2・3 本、2.7〜3.1 Å", ok2g), ("2h C1′–C1′ 10〜11 Å", ok2h), ("2i 面の傾き 10° 以内", ok2i)]:
    print(f"   {k}：{'合格' if v else 'NG'}")
print("   負の対照（鏡）：", "左巻きと返した" if all(r[1] < 0 for r in hm) else "NG を返せない")
print("\n判定：側 1（決めごと）", "合格" if r_fig else "NG", "／ 正の対照", "合格" if r_pos else "NG（物差しが壊れている）",
      "／ 負の対照", "NG を返した" if not r_neg else "合格（物差しが甘い）")

# dna_chain1.py  dAMP を 3′–5′ でつなぐ（整数だけ）
# つなぎ方：一つ目の O3′ が、二つ目のリン酸の OP2 か OP3 の席に入る。
#   二つ目の OP（その席の O）と H、一つ目の H(O3′) が抜ける＝水 1 個（O 1・H 2）。
#   O3′–P は、リン酸の O–P と同じ決めごと（P の角の小さな正四面体を頂点で折り返した位置）になる。
# 二つ目の置き方：一つ目を立方格子の対称（符号つきの置換 48 通り）で回し、整数で並進したもの。
#   条件は「回した OP の席の 4 頂点が、一つ目の O3′ の 4 頂点にそのまま重なる」ことだけ。
# 事前基準：
#   合格＝中身の重なり 0、かつ頂点を分け合う組が結合の組と一致（帯の一つおきは除く）、
#         頂点の和 = 984×2 − 54（水 1 個分：O 34、H 10×2）＝ 1914、原子 36×2 − 3 = 69。
#   負の対照 1：OP を抜かずに重ねる → 「重なる」を返すこと（同じ席に O が二つ）。
#   負の対照 2：合格した置き方を並進だけ 12 ずらす → 結合が切れる（O3′–P が頂点を分け合わない）と返すこと。
import json, itertools
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
g = {}; exec(src, g)
overlap = g["overlap"]
d = json.load(open("dna_dAMP.json"))
A = {k: [tuple(v) for v in T] for k, T in d["atoms"].items()}
B = {frozenset(b) for b in d["bonds"]}
band_alt = {frozenset(x) for x in [("N1","N3"),("N1","C5"),("C2","C4"),("C2","C6"),("N3","C5"),("C4","C6")]}
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
VN = {"H": 10, "C": 34, "N": 34, "O": 34, "P": 130}

def mats():
    for perm in itertools.permutations(range(3)):
        for sg in itertools.product((1, -1), repeat=3):
            yield perm, sg
def app(M, v):
    perm, sg = M
    return tuple(sg[i] * v[perm[i]] for i in range(3))
def det(M):
    perm, sg = M
    inv = sum(1 for i in range(3) for j in range(i+1, 3) if perm[i] > perm[j])
    return (-1) ** inv * sg[0] * sg[1] * sg[2]
def move(T, M, t): return [tuple(a + b for a, b in zip(app(M, v), t)) for v in T]

def judge(atoms, bonds):
    names = list(atoms)
    bad = [(a, b) for a, b in itertools.combinations(names, 2) if overlap(atoms[a], atoms[b])]
    mis = []
    for a, b in itertools.combinations(names, 2):
        s = len(set(atoms[a]) & set(atoms[b])) > 0
        e = frozenset((a, b))
        base_a, base_b = a.split("#")[0], b.split("#")[0]
        same_unit = a.split("#")[1] == b.split("#")[1]
        if same_unit and frozenset((base_a, base_b)) in band_alt: continue
        if s != (e in bonds): mis.append((a, b, "分け合う" if s else "切れている"))
    return bad, mis

def chain(n, M, t, seat):
    """n 個つなぐ。k 個目は 一つ目を (M,t) で k 回動かしたもの"""
    atoms, bonds = {}, set()
    cur = dict(A)
    for k in range(n):
        tag = f"#{k}"
        drop = set()
        if k > 0: drop |= {seat, f"H({seat})"}          # 5′ 側：席の OP と H が抜ける
        if k < n - 1: drop.add("H(O3')")                # 3′ 側：H(O3′) が抜ける
        for name, T in cur.items():
            if name not in drop: atoms[name + tag] = T
        for b in B:
            a1, b1 = tuple(b)
            if a1 not in drop and b1 not in drop: bonds.add(frozenset((a1 + tag, b1 + tag)))
        if k > 0: bonds.add(frozenset((f"O3'#{k-1}", f"P#{k}")))
        cur = {name: move(T, M, t) for name, T in cur.items()}
    return atoms, bonds

O3 = set(A["O3'"])
hits = []
for seat in ("OP2", "OP3"):
    for M in mats():
        R = [app(M, v) for v in A[seat]]
        for v in R:
            t = tuple(a - b for a, b in zip(A["O3'"][0], v))
            if {tuple(a + b for a, b in zip(w, t)) for w in R} == O3:
                hits.append((seat, M, t)); break
print("O3′ に OP の席が重なる回し方：", len(hits), "（OP2・OP3 × 48 通りの中で）")

res = []
for seat, M, t in hits:
    atoms, bonds = chain(2, M, t, seat)
    bad, mis = judge(atoms, bonds)
    vs = sum(VN[EL(k.split('#')[0])] for k in atoms)
    ok = not bad and not mis
    res.append((seat, M, t, ok, len(bad), len(mis), len(atoms), vs))
    print(f"  席 {seat}  置換 {M[0]} 符号 {M[1]} 行列式 {det(M):+d}  並進 {t}  原子 {len(atoms)}  頂点の和 {vs}  "
          f"重なり {len(bad)}  食い違い {len(mis)}  → {'合格' if ok else 'NG'}")

good = [r for r in res if r[3]]
print("合格：", len(good))

print("\n負の対照 1：OP を抜かずに重ねる")
seat, M, t = hits[0]
atoms = {k + "#0": T for k, T in A.items()}
atoms.update({k + "#1": move(T, M, t) for k, T in A.items()})
bad = [(a, b) for a, b in itertools.combinations(atoms, 2) if overlap(atoms[a], atoms[b])]
print("   重なる組：", len(bad), bad[:3])

if good:
    seat, M, t = good[0][:3]
    print("\n負の対照 2：合格した置き方を x へ 12 ずらす")
    t2 = (t[0] + 12, t[1], t[2])
    atoms, bonds = chain(2, M, t2, seat)
    bad, mis = judge(atoms, bonds)
    print("   重なり", len(bad), " 食い違い", [m for m in mis if "P#1" in m or "O3'#0" in m][:3])
    json.dump({"hits": [(s, M[0], M[1], t) for s, M, t, *_ in good]}, open("dna_chain1.json", "w"))

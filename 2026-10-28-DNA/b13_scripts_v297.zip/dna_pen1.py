# dna_pen1.py  段 1：鎖の頂点を 5 回軸に垂直な面へ写し、72° おきの 5 本の向き e0〜e4 の整数の和（＝ Z[φ]e0 + Z[φ]e1）で書けるか
# e0：正十二面体の頂点 V[0] を面へ写したもの、e1 = R72 e0（どちらも Q(φ) の成分）。φe0 = e1 + e4 などで 5 本の整数の和は Z[φ]e0 + Z[φ]e1 になる。
# 判定：写した点 q = a e0 + b e1 の a, b（Q(φ)）を厳密に解き、a, b の分母を記録する。
#   正：Z[φ] 鎖（dna_z5_strand13.json）、負の対照：立方格子の鎖（dna_strand_int.json、10 個で戻るが細長いもの）
#   基準：負の対照が NG（分母が残る・または面に乗らない）を返せなければ、この段は判定にならない、と記録する。
import json, io, contextlib
exec(open("dna_z5.py").read().split('print("段階 1')[0])
with contextlib.redirect_stdout(io.StringIO()):
    exec(open("dna_z5.py").read().split('print("\\n段階 3')[0])
from math import lcm
nn = vdot(n5, n5)
def proj(q): k = vdot(q, n5) / nn; return tuple(x - k * y for x, y in zip(q, n5))
e0 = proj(V[0]); e1 = mvec(R72, e0)
g00, g01, g11 = vdot(e0, e0), vdot(e0, e1), vdot(e1, e1); det = g00 * g11 - g01 * g01
def coef(q):
    p = proj(q); r0, r1 = vdot(p, e0), vdot(p, e1)
    a = (r0 * g11 - r1 * g01) / det; b = (r1 * g00 - r0 * g01) / det
    assert tuple(a * x + b * y for x, y in zip(e0, e1)) == p
    return a, b
def run(label, pts):
    dens = [max(a.den(), b.den()) for a, b in map(coef, pts)]
    print(f"  {label}：点 {len(pts)}  すべて Z[φ]e0+Z[φ]e1：{all(d == 1 for d in dens)}  分母の最小公倍数 {lcm(*dens)}")
Z = json.load(open("dna_z5_strand13.json"))
ptsZ = list({tuple(Q(c[0], c[1]) for c in v) for U in Z["units"] for T in U.values() for v in T})
C = json.load(open("dna_strand_int.json"))
ptsC = list({tuple(Q(c) for c in v) for U in C["units"] for T in U.values() for v in T})
print("段 1：e0 =", e0, " e1 =", e1)
run("Z[φ] の鎖", ptsZ); run("負の対照：立方格子の鎖", ptsC)

# dna_adenine6.py  アデニンの六角形の側を、ベンゼン環（dna_benzene.py）と同じ決めごとで組む（整数だけ）
# 帯の 6 個：N1 C2 N3 C4 C5 C6。C2 のとがった先に H。C6 のとがった先で N6（2 段）と頂点を分け合う（単結合）。
# N6 の空いた頂点のうち二つに H。N1・N3 のとがった先は空き（電子の席）。C4・C5 のとがった先は五角形の側に残す。
import json
from itertools import combinations
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
g = {}; exec(src, g)
tet, overlap, shared, sub, n2, center4 = g["tet"], g["overlap"], g["shared"], g["sub"], g["n2"], g["center4"]
BAND, CAPS = g["BAND"], g["CAPS"]
def mid(a, b): return tuple((x + y) // 2 for x, y in zip(a, b))
def refl(T, p): return [sub((2*p[0], 2*p[1], 2*p[2]), v) for v in T]
def corner_cell(T, p): return [mid(p, v) for v in T]          # 頂点 p の角の小さな正四面体（1 段）
def H_at(T, p): return refl(corner_cell(T, p), p)              # p で頂点を分け合う H

names = ["N1", "C2", "N3", "C4", "C5", "C6"]
A = {n: tet(s) for n, s in zip(names, BAND)}
tip = {n: A[n][3] for n in names}
A["N6"] = refl(A["C6"], tip["C6"])
free6 = [v for v in A["N6"] if v != tip["C6"]]
# N6 の空いた 3 頂点のうち、どの二つに H を置いても重ならないかを全部試す
choices = []
for a, b in combinations(free6, 2):
    Hs = {"H(C2)": H_at(A["C2"], tip["C2"]), "H(N6)a": H_at(A["N6"], a), "H(N6)b": H_at(A["N6"], b)}
    allT = list(A.items()) + list(Hs.items()) + [("ふた", tet(s)) for s in CAPS]
    bad = [(x, y) for (x, X), (y, Y) in combinations(allT, 2) if overlap(X, Y)]
    choices.append(((a, b), Hs, bad))
print("N6 の H の置き方（空いた 3 頂点から 2 つ）：", [("重なりなし" if not c[2] else c[2]) for c in choices])
(a, b), Hs, bad = next(c for c in choices if not c[2])
allT = {**A, **Hs}
print("隣どうしが分け合う頂点（環）：", {f"{x}–{y}": shared(A[x], A[y]) for x, y in zip(names, names[1:] + names[:1])})
print("C6–N6 が分け合う頂点：", shared(A["C6"], A["N6"]), " 中心距離²×16：", n2(sub(center4(A["C6"]), center4(A["N6"]))))
print("H が分け合う頂点：", {k: shared(v, A["C2"] if "C2" in k else A["N6"]) for k, v in Hs.items()})
print("結合していない組で頂点を分け合うもの：",
      [(x, y, shared(X, Y)) for (x, X), (y, Y) in combinations(allT.items(), 2)
       if shared(X, Y) and {x, y} not in [{p, q} for p, q in zip(names, names[1:] + names[:1])] + [{"C6", "N6"}, {"C2", "H(C2)"}, {"N6", "H(N6)a"}, {"N6", "H(N6)b"}]])
print("中身の重なり（ふたを含む）：", bad if bad else "なし")
print("空いた頂点：N1", tip["N1"], " N3", tip["N3"], " N6", [v for v in free6 if v not in (a, b)],
      " 五角形の側へ：C4", tip["C4"], " C5", tip["C5"])
cnt = {"C": 4, "N": 4, "H": 3}
print("組成：", cnt)
json.dump({"atoms": {k: v for k, v in allT.items()}, "caps": [tet(s) for s in CAPS],
           "open": {"N1": tip["N1"], "N3": tip["N3"], "C4": tip["C4"], "C5": tip["C5"]}},
          open("dna_adenine6.json", "w"))

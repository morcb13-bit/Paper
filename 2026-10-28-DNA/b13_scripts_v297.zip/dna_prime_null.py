# dna_prime_null.py  20 種のアミノ酸の「数」（5H + 17(C+N+O) + 65S）が素数になる割合は、でたらめな組成と比べて多いか
# 事前基準：
#   帰無 A：アミノ酸の数の範囲（110〜315）の整数すべてで、素数の割合。
#   帰無 B：20 種と同じ範囲の組成（C 2〜11、H 5〜14、N 1〜4、O 2〜4、S は 20 種中 2 種の割合）をでたらめに 20 個作る。
#           分子になれる条件として H+N が偶数、不飽和度 C − H/2 + N/2 + 1 ≥ 0（整数で：2C − H + N + 2 ≥ 0）を課す。[知識]
#           これを 200000 回くり返し、素数が 5 個以上になる回の割合を数える。
#   判定：割合が 5% 未満なら「20 種の素数は、でたらめな組成より多い」と言える。5% 以上なら言えない。
import random
def isp(n):
    if n < 2: return False
    p = 2
    while p * p <= n:
        if n % p == 0: return False
        p += 1
    return True
AA = {"C2H5NO2":0,"C3H7NO2":0,"C3H7NO3":0,"C5H9NO2":0,"C5H11NO2":0,"C4H9NO3":0,"C3H7NO2S":0,"C6H13NO2":0,"C6H13NO2 ":0,"C4H8N2O3":0,
      "C4H7NO4":0,"C5H10N2O3":0,"C6H14N2O2":0,"C5H9NO4":0,"C5H11NO2S":0,"C6H9N3O2":0,"C9H11NO2":0,"C6H14N4O2":0,"C9H11NO3":0,"C11H12N2O2":0}
import re
def parse(f): return {e: int(n or 1) for e, n in re.findall(r"([A-Z][a-z]?)(\d*)", f)}
def num(c): return 5*c.get("H",0) + 17*(c.get("C",0)+c.get("N",0)+c.get("O",0)) + 65*c.get("S",0)
vals = [num(parse(f.strip())) for f in AA]
k_obs = sum(isp(v) for v in vals)
print("20 種の数：", sorted(vals), " 素数の個数", k_obs)
# 帰無 A
lo, hi = min(vals), max(vals)
pa = sum(isp(n) for n in range(lo, hi + 1)) / (hi - lo + 1)
print(f"帰無 A：{lo}〜{hi} の整数で素数の割合 {pa:.3f}（20 個なら平均 {20*pa:.1f} 個）")
# 20 種の数そのものの偶奇
print("20 種の数の偶奇：奇数", sum(v % 2 for v in vals), "／偶数", sum(1 - v % 2 for v in vals))
# 帰無 B
random.seed(13)
def draw():
    while True:
        c = {"C": random.randint(2, 11), "H": random.randint(5, 14), "N": random.randint(1, 4), "O": random.randint(2, 4),
             "S": 1 if random.random() < 2/20 else 0}
        if (c["H"] + c["N"]) % 2 == 0 and 2*c["C"] - c["H"] + c["N"] + 2 >= 0: return c
R = 200000; ge = 0; tot = 0; odd = 0
for _ in range(R):
    ks = [num(draw()) for _ in range(20)]
    k = sum(isp(v) for v in ks); tot += k; ge += (k >= k_obs)
print(f"帰無 B：でたらめな組成 20 個あたりの素数の平均 {tot/R:.2f} 個、{k_obs} 個以上になる回の割合 {ge/R:.3f}")
print("判定：", "でたらめな組成より多い（5% 未満）" if ge / R < 0.05 else "でたらめな組成と区別できない（5% 以上）")

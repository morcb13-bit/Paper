# dna_z5c.py  36° で 1 段ずつ回る dAMP の鎖を Z[φ] の整数で組む
# 材料：第 1 章の立方格子の dAMP（dna_confs.json の置き方）。その正四面体の向きは 2 通りだけで、
#   どちらも正十二面体 D の中の立方体 (±φ,±φ,±φ) の二つの正四面体と同じ向き（D の向き）。座標は 10 倍して使う。
# 広げた単結合（監督の決めごと「単結合なら頂点で接する」の文言どおり）：
#   C3′–O3′ だけ、D の正四面体（C3′）と D′ の正四面体（O3′）が頂点一つで接してよい。
# 組み方：
#   O3′ の向き ＝ R(席の向き)（R は 5 回軸まわりの ±36°）。O3′ は C3′ の空いた頂点に、自分の頂点の一つで接して置く。
#   H(O3′) は O3′ の角の小さな正四面体を、その頂点で折り返したもの（決めごとどおり）。
#   つなぎ目 g = (R, t)：R(席) + t = O3′。k 個目の単位 = g^k(単位)。R^10 = 恒等なので 10 個で 1 回り。
# 事前基準（判定はすべて Z[φ] の整数の組 (a, b) と、その符号だけ）：
#   (i) 単位の中：O3′ は C3′ と頂点をちょうど 1 つ分け合い、他のどの原子とも頂点を分け合わず、中身が重ならない。H(O3′) も同様（O3′ とだけ頂点 1）。
#   (ii) 鎖：10 個（と 20 個）で、単位の間の組はどれも重ならず、頂点を分け合うのは O3′#k–P#k+1 だけ。
#   (iii) 右巻き：軸 n、n に垂直な u について n·(u × Ru) と n·t の符号が同じ。
#   返すもの：(i) を通る O3′ の置き方の数、(ii) を通る鎖の数、右巻き・左巻き、頂点の和の帳尻。
#   負の対照：(a) O3′ を D の向き（R をかけない席の向き）で置いたら、つなぎ目の式 R(席) + t = O3′ が解けないと返すこと。
#             (b) 合格した鎖の t を 1 つずらしたら (ii) が「切れている」と返すこと。
import json, sys, time
from fractions import Fraction as F
from itertools import combinations, product
exec(open("dna_z5.py").read().split('print("段階 1')[0])
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    exec(open("dna_z5.py").read().split('print("\\n段階 3')[0])
# ---- Z[φ] の整数の組 ----
def zm(x, y): return (x[0]*y[0] + x[1]*y[1], x[0]*y[1] + x[1]*y[0] + x[1]*y[1])
def za(x, y): return (x[0] + y[0], x[1] + y[1])
def zs(x, y): return (x[0] - y[0], x[1] - y[1])
def zsg(x):
    u, w = 2 * x[0] + x[1], x[1]
    if u >= 0 and w >= 0: return 0 if (u == 0 and w == 0) else 1
    if u <= 0 and w <= 0: return -1
    s = u * u - 5 * w * w
    return (1 if s > 0 else -1) if u > 0 else (-1 if s > 0 else 1)
def vsub_(u, v): return tuple(zs(a, b) for a, b in zip(u, v))
def vadd_(u, v): return tuple(za(a, b) for a, b in zip(u, v))
def vdot_(u, v):
    s = (0, 0)
    for a, b in zip(u, v): s = za(s, zm(a, b))
    return s
def vcr_(u, v): return (zs(zm(u[1], v[2]), zm(u[2], v[1])), zs(zm(u[2], v[0]), zm(u[0], v[2])), zs(zm(u[0], v[1]), zm(u[1], v[0])))
def zmax(L):
    m = L[0]
    for q in L[1:]:
        if zsg(zs(q, m)) > 0: m = q
    return m
def zmin(L):
    m = L[0]
    for q in L[1:]:
        if zsg(zs(q, m)) < 0: m = q
    return m
def le_(x, y): return zsg(zs(y, x)) >= 0
def box(T): return [(zmin([v[i] for v in T]), zmax([v[i] for v in T])) for i in range(3)]
def apart_(b1, b2): return any(zsg(zs(b2[i][0], b1[i][1])) > 0 or zsg(zs(b1[i][0], b2[i][1])) > 0 for i in range(3))
def overlap_(A, B):
    axes = []
    for T in (A, B):
        for i, j, k in combinations(range(4), 3): axes.append(vcr_(vsub_(T[j], T[i]), vsub_(T[k], T[i])))
    for i, j in combinations(range(4), 2):
        for k, l in combinations(range(4), 2):
            c = vcr_(vsub_(A[j], A[i]), vsub_(B[l], B[k]))
            if any(x != (0, 0) for x in c): axes.append(c)
    for ax in axes:
        pa = [vdot_(ax, v) for v in A]; pb = [vdot_(ax, v) for v in B]
        if le_(zmax(pa), zmin(pb)) or le_(zmax(pb), zmin(pa)): return False
    return True
def toZ(q): assert q.isZ(), q; return (int(q.a), int(q.b))
def RZ(R, v):  # Q(φ) の行列を Z[φ] の点に。結果が Z[φ] に入ることを確かめる
    return tuple(toZ(sum((R[i][k] * Q(v[k][0], v[k][1]) for k in range(3)), Q())) for i in range(3))
# ---- 材料 ----
D = json.load(open("dna_confs.json"))
if len(sys.argv) > 2:   # 1 つの置き方の JSON を渡したときは、それだけを使う
    D = {"confs": [{"atoms": json.load(open(sys.argv[2]))["atoms"]}]}
SCALE = 10
def unitZ(atoms): return {k: [tuple((SCALE * c, 0) for c in v) for v in T] for k, T in atoms.items()}
def power(R, k):
    X = I3
    for _ in range(k): X = mmul(X, R)
    return X
Rp = R36; Rm = power(R36, 9)
nax = tuple(toZ(x) for x in n5)
def hand_of(R, t):
    e = next(x for x in (((1,0),(0,0),(0,0)), ((0,0),(1,0),(0,0))) if any(c != (0, 0) for c in vcr_(nax, x)))
    u = tuple((SCALE * c[0], SCALE * c[1]) for c in vcr_(nax, e)); Ru = RZ(R, u)
    turn = zsg(vdot_(nax, vcr_(u, Ru))); rise = zsg(vdot_(nax, t))
    return "右" if turn * rise > 0 else "左" if turn * rise < 0 else "—"
def mid_(a, b):
    s = za(a, b); assert s[0] % 2 == 0 and s[1] % 2 == 0; return (s[0] // 2, s[1] // 2)
def corner_(T, p): return [tuple(mid_(x, y) for x, y in zip(p, v)) for v in T]
def refl_(T, p): return [tuple(zs((2*c[0], 2*c[1]), x) for c, x in zip(p, v)) for v in T]
def ok_in_unit(U, name, T, bonded):
    for k, W in U.items():
        s = len(set(T) & set(W))
        if k in bonded:
            if s != 1: return False
        elif s: return False
        if apart_(box(T), box(W)): continue
        if overlap_(T, W): return False
    return True
def free_(U, name):
    used = set()
    for k, W in U.items():
        if k != name: used |= set(W)
    return [v for v in U[name] if v not in used]
def place_(U, R, t, drop):
    return {k: [vadd_(RZ(R, v), t) for v in T] for k, T in U.items() if k not in drop}
VN = {"H": 10, "C": 34, "N": 34, "O": 34, "P": 130}
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
def chain_ok(U, R, t, seat, n):
    units = []; Rk = I3; Tk = ((0,0),(0,0),(0,0))
    for k in range(n):
        drop = set()
        if k > 0: drop |= {seat, f"H({seat})"}
        if k < n - 1: drop.add("H(O3')")
        units.append(place_(U, Rk, Tk, drop))
        Tk = vadd_(RZ(Rk, t), Tk); Rk = mmul(Rk, R)
    bx = [{k: box(T) for k, T in W.items()} for W in units]
    ub = [[(zmin([b[i][0] for b in B.values()]), zmax([b[i][1] for b in B.values()])) for i in range(3)] for B in bx]
    for i in range(n):
        for j in range(i + 1, n):
            if apart_(ub[i], ub[j]): continue
            for a, Ta in units[j].items():
                for b, Tb in units[i].items():
                    s = set(Ta) & set(Tb); want = (j == i + 1 and a == "P" and b == "O3'")
                    if bool(s) != want: return (i, j, a, b, "分け合う" if s else "切れている"), units
                    if apart_(bx[j][a], bx[i][b]): continue
                    if overlap_(Ta, Tb): return (i, j, a, b, "重なる"), units
    return None, units

NCONF = int(sys.argv[1]) if len(sys.argv) > 1 else 5
t0 = time.time(); stats = {"O3置き方": 0, "鎖10": 0, "鎖20": 0}; hands = {}; good = []
neg_a = None
for ci in range(NCONF):
    U0 = unitZ(D["confs"][ci]["atoms"])
    base = {k: T for k, T in U0.items() if k not in ("O3'", "H(O3')")}
    for seat in ("OP2", "OP3"):
        S = U0[seat]; cS = tuple((sum(v[i][0] for v in S), sum(v[i][1] for v in S)) for i in range(3))
        for Rname, R in (("+36°", Rp), ("−36°", Rm)):
            RS = [RZ(R, v) for v in S]
            for p in free_(base, "C3'"):
                for j in range(4):
                    d = vsub_(p, RS[j]); O3 = [vadd_(v, d) for v in RS]
                    if not ok_in_unit(base, "O3'", O3, {"C3'"}): continue
                    U1 = dict(base); U1["O3'"] = O3
                    for q in free_(U1, "O3'"):
                        H = refl_(corner_(O3, q), q)
                        if not ok_in_unit(U1, "H(O3')", H, {"O3'"}): continue
                        U2 = dict(U1); U2["H(O3')"] = H
                        stats["O3置き方"] += 1
                        t = d   # R(席) + t = O3′ のとき、t は R(席) を O3′ に重ねる並進そのもの
                        bad, units = chain_ok(U2, R, t, seat, 10)
                        if bad: break
                        stats["鎖10"] += 1
                        bad2, units20 = chain_ok(U2, R, t, seat, 20)
                        if bad2: break
                        stats["鎖20"] += 1
                        h = hand_of(R, t); hands[h] = hands.get(h, 0) + 1
                        good.append((ci, seat, Rname, h, U2, R, t))
                        break
    print(f"  置き方 {ci} まで：{stats}  右/左 {hands}  （{time.time()-t0:.0f} 秒）", flush=True)
print("結果：", stats, " 巻き", hands)
# 負の対照 (a)：O3′ を D の向き（席の向きそのまま）で置くと、R(席) + t = O3′ の t が無い
ci = 0; U0 = unitZ(D["confs"][ci]["atoms"])
RS = set(RZ(Rp, v) for v in U0["OP2"])
def shape(T):
    c = tuple((sum(v[i][0] for v in T), sum(v[i][1] for v in T)) for i in range(3))
    return frozenset(tuple(zs((4*v[i][0], 4*v[i][1]), c[i]) for i in range(3)) for v in T)
print("負の対照 (a)：席を回した向きと、D の向きの O3′（立方格子の dAMP のもの）が同じ向きか：", shape(list(RS)) == shape(U0["O3'"]), "（False なら t は無い）")
if good:
    ci, seat, Rname, h, U2, R, t = next((g for g in good if g[3] == "右"), good[0])
    t2 = (za(t[0], (SCALE * 12, 0)), t[1], t[2])
    bad, _ = chain_ok(U2, R, t2, seat, 10)
    print("負の対照 (b)：t をずらした鎖 →", bad)
    bad, units = chain_ok(U2, R, t, seat, 20)
    vs = sum(VN[EL(k)] for W in units for k in W)
    print("選んだ鎖：置き方", ci, seat, Rname, h + "巻き", " 20 個の頂点の和", vs, "（期待 984×20 − 54×19 = 18654）")
    json.dump({"conf": ci, "seat": seat, "rot": Rname, "hand": h, "axis": [list(x) for x in nax],
               "units": [{k: [[list(c) for c in v] for v in T] for k, T in W.items()} for W in units]},
              open(sys.argv[3] if len(sys.argv) > 3 else "dna_z5_strand.json", "w"))

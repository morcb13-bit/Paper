# dna_g0b.py  G0 のやり直し：変更前の規則と、1–3 の組に広げた規則を並べて判定する（整数だけ）
# 変えるのは一つだけ：
#   変更前：結合していない組は頂点を分け合わない。例外は帯の一つおき（N1–N3, N1–C5, C2–C4, C2–C6, N3–C5, C4–C6）だけ。
#   変更後：例外を「同じ原子に結合した二つ（1–3 の組）」に広げる。帯の一つおきは、この 1–3 の組に含まれる。
# 固定するもの：材料（dna_adenine6.json の帯 6 個）、C6 の辺の中点で O6 を折り返す付け方、原子の大きさ、中身の重なりの判定（整数の分離軸）。
# 事前基準：
#   C6 の候補の辺 4 本それぞれについて、O6 が触れる原子・分け合う頂点の数・1–3 の組か・中身が重なるか、を記録し、
#   変更前と変更後の合否を並べる。変更前の G0 = 0 はそのまま残す。
#   判定：変更後に 1 通り以上合格 → 新しい例外のもとで C=O の置き方が得られた。0 のまま → 1–3 の例外だけでは解けない。
#         頂点の分け合いは許されても中身が重なる → 接し方の規則と立体の置き方を分けて考え直す。
#   対照：(a) 第 1 章の dAMP を変更前・変更後の両方で判定し、どちらも合格のままであること（規則を広げても既存の結果が変わらない）。
#         (b) 変更後でも、1–4 の組（C6 から二つ先）と頂点を分け合う置き方は不合格と返すこと。
import json
from itertools import combinations
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
g = {}; exec(src, g); overlap = g["overlap"]
def refl_edge(T, a, b): m2 = tuple(x + y for x, y in zip(a, b)); return [tuple(c - x for c, x in zip(m2, v)) for v in T]
J = json.load(open("dna_adenine6.json"))
ring = ["N1", "C2", "N3", "C4", "C5", "C6"]
A = {k: [tuple(v) for v in J["atoms"][k]] for k in ring}
ring_bonds = {frozenset(p) for p in zip(ring, ring[1:] + ring[:1])}
band_alt = {frozenset(x) for x in [("N1","N3"),("N1","C5"),("C2","C4"),("C2","C6"),("N3","C5"),("C4","C6")]}
def one_three(bonds):
    nb = {}
    for e in bonds:
        a, b = tuple(e); nb.setdefault(a, set()).add(b); nb.setdefault(b, set()).add(a)
    out = set()
    for c, ns in nb.items():
        for x, y in combinations(sorted(ns), 2): out.add(frozenset((x, y)))
    return out - bonds
def judge(atoms, bonds, rule):
    allow = band_alt if rule == "変更前" else one_three(bonds)
    bad = []
    for a, b in combinations(atoms, 2):
        e = frozenset((a, b)); s = len(set(atoms[a]) & set(atoms[b]))
        if e in bonds:
            if s == 0: bad.append((a, b, "結合なのに頂点を分け合わない"))
        elif s and e not in allow: bad.append((a, b, f"頂点 {s} を分け合う（結合していない）"))
        if overlap(atoms[a], atoms[b]): bad.append((a, b, "中身が重なる"))
    return bad
print("候補の辺ごとの記録（O6 を C6 の辺の中点で折り返す）")
edges = [e for e in combinations(A["C6"], 2) if not any(set(e) <= set(A[j]) for j in ("N1", "C5"))]
res = {"変更前": 0, "変更後": 0}
bonds = ring_bonds | {frozenset(("C6", "O6"))}
for a, b in edges:
    M = dict(A); M["O6"] = refl_edge(A["C6"], a, b)
    touch = [(k, len(set(M["O6"]) & set(A[k])), frozenset((k, "O6")) in one_three(bonds), overlap(M["O6"], A[k])) for k in ring]
    print(f"  辺 {a}–{b}")
    for k, s, o13, ov in touch:
        if s or ov: print(f"     {k}：分け合う頂点 {s}  1–3 の組 {o13}  中身が重なる {ov}")
    for rule in ("変更前", "変更後"):
        bad = judge(M, bonds, rule)
        print(f"     {rule}：", "合格" if not bad else [x for x in bad if "O6" in x])
        res[rule] += not bad
print("\nG0：変更前", res["変更前"], "通り（前回の 0 と同じか）  変更後", res["変更後"], "通り")

print("\n対照 (a)：第 1 章の dAMP を両方の規則で判定")
d = json.load(open("dna_dAMP.json"))
At = {k: [tuple(v) for v in T] for k, T in d["atoms"].items()}; Bd = {frozenset(b) for b in d["bonds"]}
for rule in ("変更前", "変更後"):
    bad = judge(At, Bd, rule); print(f"   {rule}：", "合格" if not bad else bad[:3])
new13 = [tuple(sorted(e)) for e in one_three(Bd) if len(set(At[tuple(e)[0]]) & set(At[tuple(e)[1]]))]
print("   dAMP の中で頂点を分け合う 1–3 の組：", sorted(new13), "（帯の一つおき 6 組だけなら、規則を広げても dAMP は変わらない）")
print("\n対照 (b)：変更後でも 1–4 の組との頂点の分け合いは不合格か → 上の記録で C4・C2 に触れる辺が「変更後」で不合格になっているかを見る")

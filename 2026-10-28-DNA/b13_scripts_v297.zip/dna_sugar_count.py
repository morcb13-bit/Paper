import io, contextlib, json
src = open("dna_build1.py").read().split("n_ad = 0; found = None")[0]
exec(src)
J = json.load(open("dna_dAMP.json"))
for si, m, q in adenines():
    if si == J["pent"]:
        # dAMP で N9 と C1' が分け合う頂点 q だけ数える
        C1 = [tuple(v) for v in J["atoms"]["C1'"]]
        if q not in C1: continue
        n = sum(1 for _ in sugars(m, q)); print("糖の五角形（O4' まで閉じる置き方）：", n, "通り（N9 の口 1 つ、C5'・O3'・H を付ける前）"); break

# dna_pen2.py  段 2a：目の大きさを固定して、鎖の影が 5 本の向きの網に乗るかを判定する（厳密な Z[φ]）
# タイルの辺：C・N・O の正四面体を内側にもつ正十二面体の、5 回軸に垂直な面（上の面）の辺。影でも長さが変わらない。
#   正十二面体 (±φ,±φ,±φ),(0,±1,±φ²),… の立方体の辺は 2φ、正十二面体の辺は 2。原子の正四面体の立方体の辺に合わせて s 倍する。
#   Z[φ] の鎖（10 倍・2 倍の尺度）：立方体の辺 120 → s = 60/φ。立方格子の鎖（2 倍の尺度）：立方体の辺 12 → s = 6/φ。
# 網：e_k ＝ s ×（上の面の 5 本の辺、72° おき）。点 q の影 = a e0 + b e1 の a, b が Z[φ] に入れば「網に乗る」。
# 事前基準：正（Z[φ] の鎖）と負の対照（立方格子の鎖）で、網に乗る点の割合を返す。負の対照で割合が下がらなければ判定にならない。
import json, io, contextlib
exec(open("dna_z5.py").read().split('print("段階 1')[0])
with contextlib.redirect_stdout(io.StringIO()):
    exec(open("dna_z5.py").read().split('print("\\n段階 3')[0])
from collections import Counter
nn = vdot(n5, n5)
def proj(q): k = vdot(q, n5) / nn; return tuple(x - k * y for x, y in zip(q, n5))
fv = sorted(f0)
# 上の面の辺を順に並べる（隣どうしは辺² = 4）
order = [fv[0]]
while len(order) < 5:
    order.append(next(j for j in fv if j not in order and d2(V[order[-1]], V[j]) == 4))
E = [vsub(V[order[(i + 1) % 5]], V[order[i]]) for i in range(5)]
assert all(vdot(e, n5) == 0 and vdot(e, e) == 4 for e in E)
def module_test(label, pts, s):
    e0 = tuple(s * x for x in E[0]); e1 = tuple(s * x for x in E[1])
    g00, g01, g11 = vdot(e0, e0), vdot(e0, e1), vdot(e1, e1); det = g00 * g11 - g01 * g01
    ok = Counter(); tot = Counter()
    for name, q in pts:
        p = proj(q); r0, r1 = vdot(p, e0), vdot(p, e1)
        a = (r0 * g11 - r1 * g01) / det; b = (r1 * g00 - r0 * g01) / det
        good = a.isZ() and b.isZ(); el = name
        ok[el] += good; tot[el] += 1
    allok = sum(ok.values()); alln = sum(tot.values())
    print(f"  {label}：網に乗る点 {allok}/{alln}  " + "  ".join(f"{k} {ok[k]}/{tot[k]}" for k in sorted(tot)))
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else ("O3′" if n == "O3'" else n[0])
Z = json.load(open("dna_z5_strand13.json"))
ptsZ = list({(EL(n), tuple(Q(c[0], c[1]) for c in v)) for U in Z["units"] for n, T in U.items() for v in T})
C = json.load(open("dna_strand_int.json"))
ptsC = list({(EL(n), tuple(Q(c) for c in v)) for U in C["units"] for n, T in U.items() for v in T})
inv_phi = PHI - 1
print("段 2a：タイルの辺 = 正十二面体の上の面の辺（s 倍）")
module_test("Z[φ] の鎖（s = 60/φ）", ptsZ, 60 * inv_phi)
module_test("負の対照：立方格子の鎖（s = 6/φ）", ptsC, 6 * inv_phi)

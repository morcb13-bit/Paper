# dna_z5b.py  段階 5：36° のつなぎ目（O3′ と次の OP の席）が、dAMP の結合の決めごとと両立するか（Z[φ] の厳密な計算）
# 尺度：dna_z5.py の座標を √5（= 2φ − 1）倍して、二つの正十二面体（元の D と 36° 回した D′）の正四面体 20 個をすべて Z[φ] に置く。
# 正四面体の「向き」：重心を原点に置いた 4 頂点の組（どの正四面体も重心は原点）。D の向き 10、D′ の向き 10。
#
# 事前基準：
#   5a つなぎ目：席の向き S を R36 で回すと O3′ の向き S′ にそのまま重なる組 (S, S′) を 20×20 で数える。
#      同じ正十二面体どうし（D–D、D′–D′）は 0 と返すこと（負の対照）。
#   5b 決めごとの向きの移り方：第 1 章の結合の決めごとは、向きを
#        頂点・平行移動 → そのまま、頂点・折り返し → 符号反転、辺（辺の中点で折り返す）→ 符号反転、
#        大きさ違い（±2 倍）・P の角の小さな正四面体の折り返し → そのまま／符号反転
#      にしか移さない。20 の向きそれぞれに これらを施して、D から D′ へ移るものを数える。
#      0 なら「一つのヌクレオチドの中は一つの正十二面体の向きだけ」→ O3′ と席は同じ正十二面体 → 5a により 36° のつなぎ目は不成立。
#   5c 新しい接し方の候補：D の正四面体と D′ の正四面体を頂点一つで重ね（10×10×4×4 通り）、
#      分け合う頂点がちょうど 1 で中身が重ならない（整数の分離軸、Z[φ] の符号判定）ものを数える。
#      正の対照：D の正四面体とその頂点での折り返し（決めごとの単結合）が「重ならない・頂点 1」と返すこと。
#      負の対照：同じ正四面体を少しずらして重ねたもの（頂点を重ねずに中心を近づける）が「重なる」と返すこと。
exec(open("dna_z5.py").read().split('print("段階 1')[0])
from itertools import combinations, product
import io, contextlib
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    exec(open("dna_z5.py").read().split('print("\\n段階 3')[0].split('exec(')[0] if False else open("dna_z5.py").read().split('print("\\n段階 3')[0])
SQ5 = 2 * PHI - 1
def sc(v, k): return tuple(k * x for x in v)
TD = [tuple(sc(V[i], SQ5) for i in T) for T in tets]                           # D の 10 個
TDp = [tuple(sc(mvec(R36, V[i]), SQ5) for i in T) for T in tets]               # D′ の 10 個
assert all(x.isZ() for T in TD + TDp for v in T for x in v)
SH = [frozenset(T) for T in TD] + [frozenset(T) for T in TDp]
fam = ["D"] * 10 + ["D′"] * 10
idx = {s: i for i, s in enumerate(SH)}
def rot(T, R): return frozenset(mvec(R, v) for v in T)
def neg(T): return frozenset(tuple(-x for x in v) for v in T)

print("5a つなぎ目：R36(席の向き) = O3′ の向き となる組")
from collections import Counter
c5a = Counter()
for i, S in enumerate(SH):
    j = idx.get(rot(S, R36))
    if j is not None: c5a[(fam[i], fam[j])] += 1
print("   ", dict(c5a), "  同じ正十二面体どうし：", c5a[("D", "D")] + c5a[("D′", "D′")])

print("5b 決めごとが向きをどこへ移すか")
c5b = Counter()
for i, S in enumerate(SH):
    for name, T in (("そのまま", S), ("符号反転", neg(S))):
        j = idx.get(T)
        c5b[(fam[i], "外" if j is None else fam[j], name)] += 1
print("   ", dict(c5b))
cross = sum(v for (a, b, _), v in c5b.items() if b != "外" and a != b)
print("   D と D′ のあいだを移る決めごと：", cross)

print("5c D と D′ の正四面体を頂点一つで重ねる（新しい接し方の候補）")
def sgn(x):
    u, w = 2 * x.a + x.b, x.b       # x = (u + w√5)/2
    if u >= 0 and w >= 0: return 0 if (u == 0 and w == 0) else 1
    if u <= 0 and w <= 0: return -1
    s = u * u - 5 * w * w
    return (1 if s > 0 else -1) if u > 0 else (-1 if s > 0 else 1)
def le(x, y): return sgn(y - x) >= 0
def overlap_q(A, B):
    axes = []
    for T in (A, B):
        for i, j, k in combinations(range(4), 3): axes.append(vcross(vsub(T[j], T[i]), vsub(T[k], T[i])))
    for i, j in combinations(range(4), 2):
        for k, l in combinations(range(4), 2):
            c = vcross(vsub(A[j], A[i]), vsub(B[l], B[k]))
            if any(sgn(x) != 0 for x in c): axes.append(c)
    for ax in axes:
        pa = [vdot(ax, v) for v in A]; pb = [vdot(ax, v) for v in B]
        mxa = max(pa, key=lambda q: (sgn(q - pa[0]), 0)) if False else None
        def mx(L):
            m = L[0]
            for q in L[1:]:
                if sgn(q - m) > 0: m = q
            return m
        def mn(L):
            m = L[0]
            for q in L[1:]:
                if sgn(q - m) < 0: m = q
            return m
        if le(mx(pa), mn(pb)) or le(mx(pb), mn(pa)): return False
    return True
def shift(T, d): return tuple(tuple(x + y for x, y in zip(v, d)) for v in T)
A0 = TD[0]
refl = tuple(tuple(2 * c - x for c, x in zip(A0[0], v)) for v in A0)
print("   正の対照（頂点での折り返し）：重なる", overlap_q(A0, refl), " 分け合う頂点", len(set(A0) & set(refl)))
near = shift(A0, tuple(x - y for x, y in zip(A0[0], A0[1])))   # 辺の向きに一辺ぶんずらす：頂点は重なるが中身は？
half = tuple(tuple(x * Q(F(1, 2)) for x in v) for v in A0)     # 半分の大きさで中に入れる（中身が重なるはず）
print("   負の対照（半分の大きさで中に入れる）：重なる", overlap_q(A0, shift(half, (Q(), Q(), Q()))))
ok = 0; tot = 0; kinds = Counter()
for a, A in enumerate(TD):
    for b, B in enumerate(TDp):
        for i, j in product(range(4), range(4)):
            tot += 1
            Bm = shift(B, vsub(A[i], B[j]))
            if len(set(A) & set(Bm)) != 1: continue
            if overlap_q(A, Bm): continue
            ok += 1; kinds[(a < 5, b < 5)] += 1
print(f"   D と D′ を頂点一つで重ねた {tot} 通りのうち、頂点 1 だけ分け合い中身が重ならないもの：{ok}")
print("   組ごと（D の組 1 か, D′ の組 1 か）：", dict(kinds))

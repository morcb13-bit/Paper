# dna_g0.py  G（グアニン）の置換基：C6=O6 を辺で付けられるか、N2・H(N2)・H(N1) を付けられるか（整数だけ）
# 材料：dna_adenine6.json の帯 6 個（N1 C2 N3 C4 C5 C6、座標は元の尺度）。アデニンの N6・H(N6)・H(C2) は外す。
# 決めごと（第 1 章のまま）：
#   辺の結合（C=O）：相手の辺の中点で点対称に折り返す。分け合う頂点はちょうど 2（その辺）。
#   頂点の結合（C–N）：相手のとがった先（空いた頂点）で点対称に折り返す。
#   H：相手の角の小さな正四面体を、その頂点で折り返す。
#   結合していない組は頂点を分け合わない。ただし帯の一つおきの接点（N1–N3, N1–C5, C2–C4, C2–C6, N3–C5, C4–C6）は帯の性質として除く。
# 事前基準：
#   G0：C6 の 6 本の辺のうち、隣（N1・C5）と分け合っていない辺を数え、そこで折り返した O6 が
#       重ならず、C6 以外と頂点を分け合わないものを数える。0 なら「今の帯では C=O を辺で付けられない」。
#   G1：C2 のとがった先で N2 を折り返し、N2 の空いた頂点 3 つのうち 2 つに H を付けられる置き方を数える。
#   G2：N1 のとがった先に H を付けられるか。
#   負の対照：(a) O6 を C6 のとがった先で頂点の結合として付けたら、分け合う頂点 1（辺ではない）と返すこと。
#             (b) 隣と分け合っている辺（C6–N1）で折り返したら、N1 と重なる（または頂点を分け合う）と返すこと。
import json
from itertools import combinations
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
g = {}; exec(src, g); overlap = g["overlap"]
def mid(a, b): return tuple((x + y) // 2 for x, y in zip(a, b))
def refl(T, p): return [tuple(2*c - x for c, x in zip(p, v)) for v in T]
def refl_edge(T, a, b): m2 = tuple(x + y for x, y in zip(a, b)); return [tuple(c - x for c, x in zip(m2, v)) for v in T]
def corner(T, p): return [mid(p, v) for v in T]
def H_at(T, p): return refl(corner(T, p), p)
J = json.load(open("dna_adenine6.json"))
ring = ["N1", "C2", "N3", "C4", "C5", "C6"]
A = {k: [tuple(v) for v in J["atoms"][k]] for k in ring}
band_alt = {frozenset(x) for x in [("N1","N3"),("N1","C5"),("C2","C4"),("C2","C6"),("N3","C5"),("C4","C6")]}
def check(M, name, T, bonded, need):
    """need：bonded と分け合う頂点の数。失敗の理由を返す（None なら合格）"""
    for k, U in M.items():
        s = len(set(T) & set(U))
        if k in bonded:
            if s != need: return f"{k} と分け合う頂点 {s}（必要 {need}）"
        elif s: return f"{k} と頂点 {s} を分け合う（結合していない）"
        if overlap(T, U): return f"{k} と重なる"
    return None
tip = {k: [v for v in A[k] if sum(1 for j in ring if j != k and v in A[j]) == 0] for k in ring}
print("帯のとがった先（どの隣とも分け合わない頂点）：", {k: v for k, v in tip.items()})
print("\nG0：C6=O6 を辺で付ける")
edges = list(combinations(A["C6"], 2))
nb = [e for e in edges if not any(set(e) <= set(A[j]) for j in ("N1", "C5"))]
print("   C6 の辺 6 本のうち、N1・C5 と分け合っていない辺：", len(nb))
ok = []
for a, b in nb:
    O6 = refl_edge(A["C6"], a, b)
    why = check(A, "O6", O6, {"C6"}, 2)
    print(f"   辺 {a}–{b}：", "合格" if why is None else why)
    if why is None: ok.append(O6)
print("   G0：", len(ok), "通り")
print("   負の対照 (a)：とがった先での頂点の結合 → 分け合う頂点", len(set(A["C6"]) & set(refl(A["C6"], tip["C6"][0]))))
e_n1 = next(e for e in edges if set(e) <= set(A["N1"]))
print("   負の対照 (b)：C6–N1 の辺で折り返す →", check(A, "O6", refl_edge(A["C6"], *e_n1), {"C6"}, 2))
print("\nG1：C2 に N2（とがった先で折り返し）、N2 に H を 2 つ")
N2 = refl(A["C2"], tip["C2"][0]); M = dict(A)
why = check(M, "N2", N2, {"C2"}, 1); print("   N2：", "合格" if why is None else why)
M["N2"] = N2
fr = [v for v in N2 if v not in A["C2"]]
g1 = 0
for p, q in combinations(fr, 2):
    Ha, Hb = H_at(N2, p), H_at(N2, q)
    w1 = check(M, "Ha", Ha, {"N2"}, 1)
    M2 = dict(M); M2["Ha"] = Ha
    w2 = check(M2, "Hb", Hb, {"N2"}, 1) if w1 is None else w1
    print(f"   H の頂点 {p}, {q}：", "合格" if w2 is None else w2); g1 += w2 is None
print("   G1：", g1, "通り")
print("\nG2：N1 のとがった先に H")
print("   ", check(dict(A), "H(N1)", H_at(A["N1"], tip["N1"][0]), {"N1"}, 1) or "合格")

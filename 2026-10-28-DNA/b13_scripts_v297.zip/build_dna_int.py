# build_dna_int.py  整数の一本鎖（dna_strand_int.json、20 個＝2 回り）を動く図にする。座標は整数のまま、画面の換算だけ浮動小数
import json
J = json.load(open("dna_strand_int.json"))
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
BASE = {"N1","C2","N3","C4","C5","C6","N6","N7","C8","N9"}; SUG = {"C1'","C2'","C3'","C4'","O4'","C5'","O5'","O3'"}
def part(n):
    if n.startswith("H("): n = n[2:n.index(")")]
    return 0 if n in BASE else 1 if n in SUG else 2
atoms = [[EL(n), k, part(n), V] for k, U in enumerate(J["units"]) for n, V in U.items()]
D = {"atoms": atoms, "hb": [], "axis": J["axis"]}
desc = open("dna_int_desc.html").read()
html = open("dna_int_template.html").read().replace("__TITLE__", "整数で組んだDNAの一本鎖 ― 10個で1回りする右巻き ―").replace("__DESC__", desc).replace("__DATA__", json.dumps(D, separators=(",", ":")))
open("dna02_int_strand.html", "w").write(html); print("dna02_int_strand.html", len(html.encode()), "bytes  原子", len(atoms))

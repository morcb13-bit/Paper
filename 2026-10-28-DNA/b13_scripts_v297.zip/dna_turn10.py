# dna_turn10.py  手順 2：置き方を一つに固定して、通るつなぎ目を 10 本並べ、10 歩で回転が恒等に戻る鎖を探す（整数だけ）
# 置き方とつなぎ目は dna_confs.json（手順 1）。
# k 個目の単位 = H_k(置き方)。H_0 = 恒等、H_{k+1} = H_k ∘ g_k（g_k はつなぎ目 (M,t)：二つ目の席を一つ目の O3′ に重ねる動き）。
#   回転部分 R_{k+1} = R_k M_k、並進 T_{k+1} = R_k t_k + T_k。
#   k 個目は、入ってくる席の O と H（k ≥ 1）と、H(O3′)（k ≤ 8）を抜く。単位の間の結合は O3′#k–P#k+1 だけ。
# 事前基準：
#   残す鎖：(i) 10 個のどの二つの単位の間も、重なり 0・頂点を分け合うのは結合した組だけ
#           (ii) R_10 = 恒等  (iii) 正味の並進 T_10 ≠ 0
#           (iv) 軸（T_10 の向き）のまわりに、10 個の P がちょうど 1 回りする（回り数 ±1）
#   回り数：P の中心×4 を軸に垂直な面へ写し（(a·a)p − (a·p)a、割らない）、u ⊥ a、w = a×u の座標で整数にし、
#           10 点の重心（×10 のまま）のまわりで、閉じた多角形の回り数を符号だけで数える。+1 が右巻き、−1 が左巻き。
#   返すもの：置き方ごとの残った鎖の数、位数の内訳、右巻き／左巻き。内訳 {1:1,2:2,3:3,4:4} があるか。
#   負の対照：(a) R_10 ≠ 恒等 の並びを判定に通すと「閉じない」と返すこと
#             (b) 残った右巻きの鎖を鏡（z → −z）に写すと回り数が −1 になること
#   見立て（手順 1 の表から、走らせる前）：一つの置き方では OP2・OP3 の向きがそろうので、位数は {1,2,3} か {2,4} の片方だけ。
#     したがって置き方を固定する限り、内訳 {1:1,2:2,3:3,4:4} は出ないはず。
import json, itertools, time, sys
from collections import Counter
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
G = {}; exec(src, G); overlap = G["overlap"]
D = json.load(open("dna_confs.json"))
NODE_CAP = int(sys.argv[1]) if len(sys.argv) > 1 else 200000
KEEP = int(sys.argv[2]) if len(sys.argv) > 2 else 200
N = 10

def mat(perm, sg): return tuple(tuple(sg[i] if j == perm[i] else 0 for j in range(3)) for i in range(3))
def mm(A, B): return tuple(tuple(sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)) for i in range(3))
def mv(A, v): return tuple(sum(A[i][k] * v[k] for k in range(3)) for i in range(3))
I3 = ((1,0,0),(0,1,0),(0,0,1))
def addv(a, b): return tuple(x + y for x, y in zip(a, b))
def subv(a, b): return tuple(x - y for x, y in zip(a, b))
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def crs(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def bbox(T): return (tuple(min(v[i] for v in T) for i in range(3)), tuple(max(v[i] for v in T) for i in range(3)))
def apart(b1, b2): return any(b1[1][i] < b2[0][i] or b2[1][i] < b1[0][i] for i in range(3))
def place(A, R, T, drop):
    return {k: [addv(mv(R, v), T) for v in V] for k, V in A.items() if k not in drop}

def winding(Ps, a):
    """Ps：P の中心×4（整数）、a：軸。回り数（整数）。0 は回らない"""
    aa = dot(a, a)
    e = next(x for x in ((1,0,0),(0,1,0),(0,0,1)) if crs(a, x) != (0,0,0))
    u = crs(a, e); w = crs(a, u)
    Q = [subv(tuple(aa * c for c in p), tuple(dot(a, p) * c for c in a)) for p in Ps]
    xy = [(dot(u, q), dot(w, q)) for q in Q]
    n = len(xy); sx = sum(x for x, _ in xy); sy = sum(y for _, y in xy)
    P2 = [(n * x - sx, n * y - sy) for x, y in xy]
    wn = 0
    for i in range(n):
        x1, y1 = P2[i]; x2, y2 = P2[(i + 1) % n]
        c = x1 * y2 - x2 * y1
        if y1 <= 0 < y2 and c > 0: wn += 1
        elif y2 <= 0 < y1 and c < 0: wn -= 1
    return wn

def final_judge(Rs, Ts, units):
    if Rs[-1] != I3: return "閉じない"
    Tn = Ts[-1]
    if Tn == (0, 0, 0): return "上がらない"
    Ps = [tuple(sum(v[i] for v in U["P"]) for i in range(3)) for U in units]
    return winding(Ps, Tn)

def search(ci):
    A = {k: [tuple(v) for v in V] for k, V in D["confs"][ci]["atoms"].items()}
    J = [(s, mat(p, g), tuple(t), o) for s, p, g, t, o in D["joints"][ci]["joints"]]
    if not J: return None
    Ms = list({j[1] for j in J})
    reach = [{I3}]
    for r in range(1, N + 1): reach.append({mm(M, X) for M in Ms for X in reach[-1]})
    def inv(R): return tuple(tuple(R[j][i] for j in range(3)) for i in range(3))
    found = []; nodes = [0]
    def rec(k, Rs, Ts, units, boxes, seq):
        # k = 選んだつなぎ目の本数、置いた単位は k+1 個（0〜k）
        if nodes[0] > NODE_CAP or len(found) >= KEEP: return
        if k == N:
            res = final_judge(Rs, Ts, units)
            if isinstance(res, int) and abs(res) == 1: found.append((tuple(j[3] for j in seq), res, Ts[-1], [(j[0], j[1], j[2]) for j in seq]))
            return
        R, T = Rs[-1], Ts[-1]
        for j in J:
            seat, M, t, o = j
            nodes[0] += 1
            R1 = mm(R, M); T1 = addv(mv(R, t), T)
            if inv(R1) not in reach[N - k - 1]: continue
            if k + 1 == N:   # 10 本目：11 個目（= 0 個目を並進したもの）の位置を決めるだけ
                rec(N, Rs + [R1], Ts + [T1], units, boxes, seq + [j]); continue
            drop = {seat, f"H({seat})"}
            if k + 1 <= N - 2: drop.add("H(O3')")
            U = place(A, R1, T1, drop)
            B = {kk: bbox(V) for kk, V in U.items()}
            ok = True
            for pi, (PU, PB) in enumerate(zip(units, boxes)):
                for a, Va in U.items():
                    for b, Vb in PU.items():
                        s = set(Va) & set(Vb)
                        want = (pi == k and a == "P" and b == "O3'")
                        if bool(s) != want: ok = False; break
                        if apart(B[a], PB[b]): continue
                        if overlap(Va, Vb): ok = False; break
                    if not ok: break
                if not ok: break
            if ok: rec(k + 1, Rs + [R1], Ts + [T1], units + [U], boxes + [B], seq + [j])
    U0 = place(A, I3, (0, 0, 0), {"H(O3')"})
    rec(0, [I3], [(0, 0, 0)], [U0], [{kk: bbox(V) for kk, V in U0.items()}], [])
    return found, nodes[0], Counter(j[3] for j in J)

t0 = time.time()
tot = Counter(); comp = Counter(); hand = Counter(); conf_hits = []
lim = int(sys.argv[3]) if len(sys.argv) > 3 else len(D["confs"])
for ci in range(lim):
    r = search(ci)
    if r is None: continue
    found, nodes, jo = r
    if found:
        conf_hits.append((ci, len(found), dict(jo)))
        for orders, wn, Tn, seq in found:
            comp[tuple(sorted(Counter(orders).items()))] += 1; hand["右" if wn > 0 else "左"] += 1
print(f"置き方 {lim} 通りを探した（{time.time()-t0:.0f} 秒、置き方ごとに鎖は最大 {KEEP} 本・節点 {NODE_CAP} で打ち切り）")
print("鎖が見つかった置き方：", len(conf_hits))
for c in conf_hits[:15]: print("   置き方", c[0], " 鎖", c[1], " つなぎ目の位数", c[2])
print("右巻き／左巻き：", dict(hand))
print("位数の内訳（上位）：")
for k, v in comp.most_common(15): print("  ", dict(k), v)
print("内訳 {1:1,2:2,3:3,4:4}：", comp.get(((1,1),(2,2),(3,3),(4,4)), 0))
json.dump({"hits": conf_hits}, open("dna_turn10.json", "w"))

# 負の対照
if conf_hits:
    ci = conf_hits[0][0]; found, _, _ = search(ci)
    A = {k: [tuple(v) for v in V] for k, V in D["confs"][ci]["atoms"].items()}
    orders, wn, Tn, seq = found[0]
    # (a) 最後のつなぎ目を別の回し方に替えて R_10 ≠ 恒等 にする
    J = [(s, mat(p, g), tuple(t), o) for s, p, g, t, o in D["joints"][ci]["joints"]]
    def build(seqx, mirror=False):
        Rs, Ts, units = [I3], [(0,0,0)], [place(A, I3, (0,0,0), set())]
        for k, (seat, M, t) in enumerate(seqx):
            Ts.append(addv(mv(Rs[-1], t), Ts[-1])); Rs.append(mm(Rs[-1], M))
            if k < N - 1: units.append(place(A, Rs[-1], Ts[-1], set()))
        if mirror:
            units = [{kk: [(v[0], v[1], -v[2]) for v in V] for kk, V in U.items()} for U in units]
            Ts = [(x, y, -z) for x, y, z in Ts]
        return Rs, Ts, units
    alt = next(j for j in J if j[1] != seq[-1][1])
    Rs, Ts, units = build(seq[:-1] + [(alt[0], alt[1], alt[2])])
    print("負の対照 (a)：最後の一歩を替えた並び →", final_judge(Rs, Ts, units))
    Rs, Ts, units = build(seq)
    print("   元の並び →", final_judge(Rs, Ts, units))
    Rs, Ts, units = build(seq, mirror=True)
    Rs = [I3] * len(Rs)   # 鏡に写しても積は恒等のまま（判定は回り数だけを見る）
    print("負の対照 (b)：鏡に写した並び → 回り数", final_judge(Rs, Ts, units))

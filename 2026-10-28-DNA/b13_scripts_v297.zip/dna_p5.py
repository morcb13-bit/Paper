# dna_p5.py  アデニンの五角形：帯の C4・C5 から N7・C8・N9 を付けて閉じるか（整数だけ）
# 結合の種類：辺の共有（辺の中点で折り返す）、頂点の共有（頂点で折り返す）、
#             頂点の共有（平行移動：同じ向きの正四面体が頂点で接する。帯の一つおき・ギャスケットの中の小さな正四面体と同じ）
# 基準（走らせる前に決める）
#   負の対照：平行移動を使わない（折り返しだけ）なら 0 通り（S1 と同じ）
#   問い：平行移動を許すと、C5→N7→C8→N9→C4 が閉じる置き方が何通りあるか。帯の 6 個・ふた・N6 とその H と中身が重ならないこと
#   閉じたら：どの結合が平行移動か、高さ（(1,1,1) 成分）がどう並ぶか（ジグザグか）を記録する
import json
from itertools import combinations
from collections import Counter
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
g = {}; exec(src, g)
overlap, shared, add, sub, dot, center4 = g["overlap"], g["shared"], g["add"], g["sub"], g["dot"], g["center4"]
J = json.load(open("dna_adenine6.json"))
A = {k: [tuple(v) for v in V] for k, V in J["atoms"].items()}
caps = [[tuple(v) for v in V] for V in J["caps"]]

def moves(T, allow_trans):
    out = []
    for p in T:                                                    # 頂点で折り返す
        out.append(("頂点・折り返し", [sub((2*p[0], 2*p[1], 2*p[2]), v) for v in T]))
    for p, q in combinations(T, 2):                                # 辺の中点で折り返す
        m2 = add(p, q); out.append(("辺", [sub(m2, v) for v in T]))
    if allow_trans:
        for p in T:
            for q in T:
                if p != q:                                         # q を p に重ねる平行移動
                    d = sub(p, q); out.append(("頂点・平行移動", [add(v, d) for v in T]))
    return out
def kind_of(X, Y):
    s = shared(X, Y)
    if s == 2: return "辺"
    if s == 1:
        same = sorted(sub(a, b) for a, b in zip(sorted(X), sorted(Y)))
        d = sub(sorted(Y)[0], sorted(X)[0])
        return "頂点・平行移動" if sorted(add(v, d) for v in X) == sorted(Y) else "頂点・折り返し"
    return "なし"

fixed = list(A.values()) + caps
def run(allow_trans, use_caps=True):
    obst = list(A.values()) + (caps if use_caps else [])
    sols = []
    for k1, N7 in moves(A["C5"], allow_trans):
        if any(overlap(N7, X) or N7 == X for X in obst): continue
        for k2, C8 in moves(N7, allow_trans):
            if any(overlap(C8, X) or sorted(C8) == sorted(X) for X in obst + [N7]): continue
            for k3, N9 in moves(C8, allow_trans):
                if any(overlap(N9, X) or sorted(N9) == sorted(X) for X in obst + [N7, C8]): continue
                k4 = kind_of(N9, A["C4"])
                if k4 == "なし": continue
                if not allow_trans and k4 == "頂点・平行移動": continue
                # 環の中で隣でない組（C5–C8、C5–N9、N7–N9、N7–C4、C8–C4）は頂点を分け合わないこと
                ring = {"C5": A["C5"], "N7": N7, "C8": C8, "N9": N9, "C4": A["C4"]}
                if any(shared(ring[a], ring[b]) for a, b in [("C5","C8"),("C5","N9"),("N7","N9"),("N7","C4"),("C8","C4")]): continue
                sols.append(((k1, k2, k3, k4), N7, C8, N9))
    return sols
print("負の対照：折り返しだけ（平行移動なし）→", len(run(False)), "通り")
S = run(True)
print("平行移動を許す →", len(S), "通り（ふたとも重ならない）")
S2 = run(True, use_caps=False)
print("（ふたを外すと →", len(S2), "通り）")
print("結合の種類の並び（C5–N7, N7–C8, C8–N9, N9–C4）：", Counter(s[0] for s in S))
h = lambda T: dot(center4(T), (1, 1, 1))
print("高さ（(1,1,1) 成分×4）C5, N7, C8, N9, C4：", Counter((h(A["C5"]), h(s[1]), h(s[2]), h(s[3]), h(A["C4"])) for s in S))
if S:
    json.dump({"atoms": {**{k: v for k, v in A.items()}, "N7": S[0][1], "C8": S[0][2], "N9": S[0][3]}, "caps": caps,
               "kinds": S[0][0]}, open("dna_p5.json", "w"))

print("\n8 通りの中身")
BONDS = {frozenset(x) for x in [("N1","C2"),("C2","N3"),("N3","C4"),("C4","C5"),("C5","C6"),("C6","N1"),("C6","N6"),
         ("C2","H(C2)"),("N6","H(N6)a"),("N6","H(N6)b"),("C5","N7"),("N7","C8"),("C8","N9"),("N9","C4")]}
out = []
for n, (ks, N7, C8, N9) in enumerate(S, 1):
    allA = {**A, "N7": N7, "C8": C8, "N9": N9}
    extra = [(a, b, shared(allA[a], allA[b])) for a, b in combinations(allA, 2)
             if frozenset((a, b)) not in BONDS and shared(allA[a], allA[b])]
    hs = [h(N7), h(C8), h(N9)]
    print(f"   {n}: 平行移動の位置 {[i for i, k in enumerate(ks) if k == '頂点・平行移動']}  高さ N7・C8・N9 {hs}  結合していない組の接点 {len(extra)}：{[(a,b) for a,b,_ in extra]}")
    out.append({"kinds": ks, "N7": N7, "C8": C8, "N9": N9, "extra": [[a, b] for a, b, _ in extra]})
json.dump({"base": {k: v for k, v in A.items()}, "caps": caps, "sols": out}, open("dna_p5_all.json", "w"), ensure_ascii=False)

# build_dna_helix.py  教科書の B 型 DNA（10 塩基対＝1 回り）の原子の位置に、ギャスケットを一個ずつ置く図
# 原子の位置・結合：PyMOL の fnab（理想 B 型）で作った bdna10.json（[知識]を借りた側。こちらで決めたものではない）
# ギャスケットの置き方（こちらの決めごと）：
#   大きさの比は dAMP と同じ（辺：H 1・C N O 2・P 4）、段は H 1・C N O 2・P 3
#   各結合 A–B の上で、A と B の大きさの比で分けた点を「接点」とし、正四面体の頂点を接点の向きへ向ける
#   （結合の向きと頂点の割り当ては全通り試して、ずれの二乗和が最小のもの）。外接半径は接点までの距離の平均
import json, itertools, math
import numpy as np
d = json.load(open("bdna10.json"))
A, BD = d["atoms"], d["bonds"]
X = np.array([a[5] for a in A])
SZ = {"H": 1, "C": 2, "N": 2, "O": 2, "P": 4}
nb = [[] for _ in A]
for i, j, o in BD:
    nb[i].append(j); nb[j].append(i)
T0 = np.array([[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], float) / math.sqrt(3)
def kabsch(P, Q, w):
    H = (P * w[:, None]).T @ Q
    U, S, Vt = np.linalg.svd(H)
    D = np.diag([1, 1, np.sign(np.linalg.det(Vt.T @ U.T))])
    return Vt.T @ D @ U.T
out = []
for i, a in enumerate(A):
    el = a[4]; ch = a[0]
    vecs, ws, rs = [], [], []
    for j in nb[i]:
        v = X[j] - X[i]; L = np.linalg.norm(v)
        rs.append(L * SZ[el] / (SZ[el] + SZ[A[j][4]])); vecs.append(v / L); ws.append(1.0)
    if len(vecs) == 1:                      # 腕が一本：相手の先の腕を弱い手がかりにしてねじれを決める
        j = nb[i][0]
        for k in nb[j]:
            if k != i:
                v = X[k] - X[i]; vecs.append(v / np.linalg.norm(v)); ws.append(0.2); break
    V = np.array(vecs); w = np.array(ws)
    best = None
    for perm in itertools.permutations(range(4), len(V)):
        P = T0[list(perm)]
        R = kabsch(P, V, w)
        e = float(((P @ R.T - V) ** 2).sum(1) @ w)
        if best is None or e < best[0]: best = (e, R)
    R = best[1]; rad = float(np.mean(rs))
    verts = X[i] + rad * (T0 @ R.T)
    out.append([el, 0 if ch == "A" else 1, a[2], [[round(float(c), 2) for c in v] for v in verts]])
# 塩基対の水素結合（[知識]：A–T は N6–O4・N1–N3、G–C は O6–N4・N1–N3・N2–O2）
pairs = {("DA", "DT"): [("N6", "O4"), ("N1", "N3")], ("DT", "DA"): [("O4", "N6"), ("N3", "N1")],
         ("DG", "DC"): [("O6", "N4"), ("N1", "N3"), ("N2", "O2")], ("DC", "DG"): [("N4", "O6"), ("N3", "N1"), ("O2", "N2")]}
idx = {(a[0], a[1], a[3]): k for k, a in enumerate(A)}
resA = sorted({a[1] for a in A if a[0] == "A"}); resB = sorted({a[1] for a in A if a[0] == "B"})
hb = []
for r in resA:
    rb = -r                                  # fnab の相手の番号は −r
    na = next(a[2] for a in A if a[0] == "A" and a[1] == r); nbn = next(a[2] for a in A if a[0] == "B" and a[1] == rb)
    for x, y in pairs[(na, nbn)]:
        p, q = idx[("A", r, x)], idx[("B", rb, y)]
        hb.append([p, q, round(float(np.linalg.norm(X[p] - X[q])), 2)])
print("水素結合の長さ（Å）：", sorted({h[2] for h in hb}))
seq = "".join(next(a[2] for a in A if a[0] == "A" and a[1] == r)[1] for r in resA)
D = {"atoms": out, "hb": [h[:2] for h in hb], "seq": seq}
html = open("dna_helix_template.html").read().replace("__DATA__", json.dumps(D, separators=(",", ":")))
open("dna02_helix.html", "w").write(html)
print("dna02_helix.html", len(html.encode()), "bytes  原子", len(out), " 配列", seq)

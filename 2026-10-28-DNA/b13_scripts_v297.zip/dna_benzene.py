# dna_benzene.py  ベンゼン環をシェルピンスキーのギャスケットで組む（ベンゼン環の記事の決めごと、整数だけ）
# 炭素：星型正八面体の帯の正四面体（辺の長さ² 72）。隣とは辺を分け合う。H：誰とも分け合わない頂点（とがった先）に、
# 炭素の角の小さな正四面体（1 段、辺の長さ² 18）をとがった先で折り返して置く（頂点を一つ分け合う）
import json
from itertools import combinations
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
g = {}; exec(src, g)
tet, overlap, shared, add, sub, dot, n2 = g["tet"], g["overlap"], g["shared"], g["add"], g["sub"], g["dot"], g["n2"]
BAND, CAPS, center4 = g["BAND"], g["CAPS"], g["center4"]

def cells1(T):             # 1 段：角の小さな正四面体 4 つ（中点は座標が偶数なので整数）
    m = lambda a, b: tuple((x + y) // 2 for x, y in zip(a, b))
    return [[m(T[i], T[j]) for j in range(4)] for i in range(4)]
def nverts(T, d):
    cells = [T]
    for _ in range(d): cells = [c for C in cells for c in cells1(C)]
    return len({v for c in cells for v in c})

C = [tet(s) for s in BAND]
caps = [tet(s) for s in CAPS]
H = []
for T in C:
    tip = T[3]
    corner = [v for v in cells1(T) if tip in v][0]            # とがった先の小さな正四面体
    H.append([sub((2*tip[0], 2*tip[1], 2*tip[2]), v) for v in corner])

print("1. 炭素の正四面体")
print("   辺の長さ²：", sorted({n2(sub(a, b)) for T in C for a, b in combinations(T, 2)}))
print("   隣どうしが分け合う頂点の数：", [shared(C[i], C[(i+1) % 6]) for i in range(6)], "（2 ＝ 辺）")
print("   一つおきが分け合う頂点の数：", [shared(C[i], C[(i+2) % 6]) for i in range(6)])
print("2. 高さ（(1,1,1) の向きの成分 ×4）：", [dot(center4(T), (1, 1, 1)) for T in C], "→ 上下が交互（ジグザグ）")
def shadow(p, ax):          # ax の向きに写した影（|ax|² 倍）
    k = dot(p, ax); a2 = dot(ax, ax)
    return tuple(a2 * x - k * y for x, y in zip(p, ax))
for name, ax in (("真上 (1,1,1)", (1, 1, 1)), ("真横 (1,-1,0)", (1, -1, 0)), ("軸 (0,0,1)", (0, 0, 1))):
    sh = [shadow(center4(T), ax) for T in C]
    rad = sorted({n2(p) for p in sh}); nb = sorted({n2(sub(sh[i], sh[(i+1) % 6])) for i in range(6)})
    reg = len(rad) == 1 and len(nb) == 1
    print(f"3. {name} から写した影：中心までの長さ² {rad}  隣どうし {nb}  → {'正六角形' if reg else '正六角形ではない'}")
print("4. H（1 段）")
print("   辺の長さ²：", sorted({n2(sub(a, b)) for T in H for a, b in combinations(T, 2)}))
print("   炭素と分け合う頂点の数：", [shared(C[i], H[i]) for i in range(6)], "（1 ＝ 頂点）")
print("   C–H の中心距離²×16：", sorted({n2(sub(center4(C[i]), center4(H[i]))) for i in range(6)}))
allT = [("C%d" % (i+1), T) for i, T in enumerate(C)] + [("H%d" % (i+1), T) for i, T in enumerate(H)] + [("ふた", T) for T in caps]
bad = [(a, b) for (a, A), (b, B) in combinations(allT, 2) if overlap(A, B)]
print("5. 中身の重なり：", bad if bad else "なし")
print("6. ギャスケットの頂点：C 2 段", nverts(C[0], 2), "× 6、H 1 段", nverts(H[0], 1), "× 6 → 計",
      6 * nverts(C[0], 2) + 6 * nverts(H[0], 1))
json.dump({"C": C, "H": H, "caps": caps}, open("dna_benzene.json", "w"))

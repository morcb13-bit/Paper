# dna_pick.py  図にする鎖を選ぶ（整数だけ）
# 候補：dna_turn10.py の鎖のうち右巻き（回り数 +1）。
# 事前基準：同じ 10 本のつなぎ目を 2 周くり返した 20 個の鎖が、
#   どの二つの単位の間も 重なり 0・頂点を分け合うのは O3′#k–P#k+1 だけ（整数の分離軸と頂点の一致）、
#   頂点の和 = 984×20 − 54×19 = 18654、2 周目も回り数 +1（20 点で +2）。
#   通ったものの中から、軸に垂直な面に写した P の半径²（整数）の 最大／最小 が小さいもの（丸いもの）を選ぶ。比べるのは掛け算だけ。
import json, sys
NCONF = int(sys.argv[1]) if len(sys.argv) > 1 else 12
sys.argv = [sys.argv[0], "20000", "50"]
exec(open("dna_turn10.py").read().split("t0 = time.time()")[0])
VN = {"H": 10, "C": 34, "N": 34, "O": 34, "P": 130}
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
def chain_units(A, seq, n):
    Rs, Ts = [I3], [(0, 0, 0)]; units = []
    for k in range(n):
        seat_in = seq[(k - 1) % 10][0] if k > 0 else None
        drop = set()
        if seat_in: drop |= {seat_in, f"H({seat_in})"}
        if k < n - 1: drop.add("H(O3')")
        units.append(place(A, Rs[-1], Ts[-1], drop))
        seat, M, t = seq[k % 10]
        Ts.append(addv(mv(Rs[-1], t), Ts[-1])); Rs.append(mm(Rs[-1], M))
    return units, Rs, Ts
def judge_all(units):
    boxes = [{k: bbox(V) for k, V in U.items()} for U in units]
    ub = [bbox([v for V in U.values() for v in V]) for U in units]
    for i in range(len(units)):
        for j in range(i + 1, len(units)):
            if apart(ub[i], ub[j]): continue
            for a, Va in units[j].items():
                for b, Vb in units[i].items():
                    s = set(Va) & set(Vb); want = (j == i + 1 and a == "P" and b == "O3'")
                    if bool(s) != want: return (i, j, a, b, "分け合う" if s else "切れている")
                    if apart(boxes[j][a], boxes[i][b]): continue
                    if overlap(Va, Vb): return (i, j, a, b, "重なる")
    return None
def roundness(units, a):
    aa = dot(a, a); e = next(x for x in ((1,0,0),(0,1,0),(0,0,1)) if crs(a, x) != (0,0,0))
    u = crs(a, e); w = crs(a, u)
    Ps = [tuple(sum(v[i] for v in U["P"]) for i in range(3)) for U in units[:10]]
    Q = [subv(tuple(aa * c for c in p), tuple(dot(a, p) * c for c in a)) for p in Ps]
    xy = [(dot(u, q), dot(w, q)) for q in Q]; n = 10; sx = sum(x for x, _ in xy); sy = sum(y for _, y in xy)
    r2 = [(n * x - sx) ** 2 + (n * y - sy) ** 2 for x, y in xy]
    return max(r2), min(r2)
cands = []; tried = 0
for ci in range(NCONF):
    r = search(ci)
    if not r: continue
    A = {k: [tuple(v) for v in V] for k, V in D["confs"][ci]["atoms"].items()}
    for orders, wn, Tn, seq in r[0]:
        if wn != 1: continue
        tried += 1
        units, Rs, Ts = chain_units(A, seq, 20)
        bad = judge_all(units)
        if bad: continue
        vs = sum(VN[EL(k)] for U in units for k in U)
        Ps = [tuple(sum(v[i] for v in U["P"]) for i in range(3)) for U in units]
        wn2 = winding(Ps, Ts[10])
        mx, mn = roundness(units, Ts[10])
        cands.append((ci, orders, seq, vs, wn2, mx, mn, Ts[10]))
        print('  通った', ci, orders, wn2, flush=True)
print("右巻きの候補", tried, " 2 周（20 個）で通ったもの", len(cands))
# 丸さで並べる：mx/mn が小さい順（mx1*mn2 < mx2*mn1 を掛け算で比べる）
import functools
cands.sort(key=functools.cmp_to_key(lambda p, q: (p[5] * q[6] > q[5] * p[6]) - (p[5] * q[6] < q[5] * p[6])))
for c in cands[:8]:
    print(f"   置き方 {c[0]}  位数 {c[1]}  頂点の和 {c[4] and c[3]}  20 点の回り数 {c[4]}  半径² 最大/最小 {c[5]}/{c[6]}  1 回りの並進 {c[7]}")
best = cands[0]
ci, orders, seq, vs, wn2, mx, mn, T10 = best
A = {k: [tuple(v) for v in V] for k, V in D["confs"][ci]["atoms"].items()}
units, Rs, Ts = chain_units(A, seq, 20)
print("選んだ鎖：置き方", ci, " 位数", orders, " 頂点の和", vs, "（期待 18654）", " 20 点の回り数", wn2)
json.dump({"conf": ci, "orders": orders, "axis": T10, "units": [{k: [list(v) for v in V] for k, V in U.items()} for U in units]},
          open("dna_strand_int.json", "w"))

# dna_a13.py  A（dAMP）を変更後の規則（1–3 の組は頂点を分け合ってよい）で組み直す（整数だけ）。組み方は dna_build1.py のまま、判定だけ替える
# 事前基準：全原子の組で 頂点の分け合い（結合・1–3 だけ）と中身の重なり 0、組成 C10 H14 N5 O6 P1・原子 36、頂点の和 984。
#   第 1 章の dAMP（dna_dAMP.json、変更前の規則）と、原子の座標が同じかを比べる。違えば、どの原子が動いたかを返す。
import json, itertools
SRC_B1 = open("dna_build1.py").read().split("n_ad = 0; found = None")[0]
exec(SRC_B1)
exec(open("dna_g3.py").read().split("def g_bases():")[0].split("# ---- 変更後の規則")[1].join(["", ""]) if False else "")
def ok13(self, name, T, bonded):
    nb13 = set()
    for b in bonded:
        for e in self.B:
            if b in e: nb13 |= set(e) - {b}
    for k, U in self.A.items():
        s = len(set(T) & set(U))
        if k in bonded:
            if s == 0: return False
        elif s and k not in nb13: return False
        if overlap(T, U): return False
    return True
Mol.ok_with = ok13
def one_three(B):
    nb = {}
    for e in B:
        a, b = tuple(e); nb.setdefault(a, set()).add(b); nb.setdefault(b, set()).add(a)
    out = set()
    for c, ns in nb.items():
        for x, y in itertools.combinations(sorted(ns), 2): out.add(frozenset((x, y)))
    return out - B
found = None
for si, m, q in adenines():
    for s in sugars(m, q):
        for dd in subst(s):
            for f in phosphate_O(dd):
                for h in hydrogens(f): found = (si, h); break
                if found: break
            if found: break
        if found: break
    if found: break
si, h = found
B = set(h.B); o13 = one_three(B); bad = []
for a, b in itertools.combinations(h.A, 2):
    e = frozenset((a, b)); s = len(set(h.A[a]) & set(h.A[b]))
    if e in B and s == 0: bad.append((a, b, "結合なのに分け合わない"))
    if e not in B and s and e not in o13: bad.append((a, b, f"頂点 {s}"))
    if overlap(h.A[a], h.A[b]): bad.append((a, b, "重なる"))
cnt = {}
for k in h.A: cnt[EL(k)] = cnt.get(EL(k), 0) + 1
VN = {"H": 10, "C": 34, "N": 34, "O": 34, "P": 130}
vs = sum(VN[EL(k)] for k in h.A)
print("頂点の分け合いと重なり：", "合格" if not bad else bad[:4])
print("組成", cnt, "原子", len(h.A), " 頂点の和", vs, "（984）")
print("頂点を分け合う 1–3 の組：", sorted(tuple(sorted(e)) for e in o13 if set(h.A[tuple(e)[0]]) & set(h.A[tuple(e)[1]])))
old = json.load(open("dna_dAMP.json"))["atoms"]
moved = [k for k in h.A if [list(v) for v in h.A[k]] != old.get(k)]
print("第 1 章の dAMP と座標が違う原子：", moved)
json.dump({"atoms": {k: [list(v) for v in T] for k, T in h.A.items()}, "bonds": [sorted(e) for e in h.B], "pent": si}, open("dna_dAMP13.json", "w"))
# 4 つの糖の置き方を比べる（塩基に付く C1′ から見た相対の位置で）
def sugar_rel(path, root):
    A = json.load(open(path))["atoms"]; c = A["C1'"][0]
    names = ["C1'", "C2'", "C3'", "C4'", "O4'", "C5'", "O5'", "O3'", "P"]
    return [[[x - y for x, y in zip(v, c)] for v in A[n]] for n in names]
ref = sugar_rel("dna_dAMP13.json", "N9")
for nm, p in (("dGMP", "dna_dGMP.json"), ("dTMP", "dna_dTMP.json"), ("dCMP", "dna_dCMP.json"), ("第 1 章の dAMP", "dna_dAMP.json")):
    print(f"糖・リン酸の形（C1′ から見た相対位置）が組み直した dAMP と同じか：{nm} {sugar_rel(p, None) == ref}")

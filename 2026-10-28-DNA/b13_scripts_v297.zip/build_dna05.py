# build_dna_z5.py  Z[φ] の鎖（dna_z5_strand.json）を動く図にする。座標は Z[φ] の整数の組 (a, b)＝a + bφ、画面の換算だけ浮動小数
import json
J = json.load(open("dna_z5_strand13.json"))
PHI = (1 + 5 ** 0.5) / 2
f = lambda c: round(c[0] + c[1] * PHI, 3)
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
BASE = {"N1","C2","N3","C4","C5","C6","N6","N7","C8","N9"}; SUG = {"C1'","C2'","C3'","C4'","O4'","C5'","O5'","O3'"}
def part(n):
    if n.startswith("H("): n = n[2:n.index(")")]
    return 0 if n in BASE else 1 if n in SUG else 2
atoms = [[EL(n), k, part(n), [[f(c) for c in v] for v in V]] for k, U in enumerate(J["units"]) for n, V in U.items()]
D = {"atoms": atoms, "hb": [], "axis": [f(c) for c in J["axis"]]}
desc = open("dna05_desc.html").read()
html = open("dna_int_template.html").read().replace("__TITLE__", "DNAの一本鎖 ― 36°ずつ回って10個で1回り ―").replace("__DESC__", desc).replace("__DATA__", json.dumps(D, separators=(",", ":")))
open("dna05_strand.html", "w").write(html); print("dna05_strand.html", len(html.encode()), "bytes  原子", len(atoms))

# build_ch1n.py  第 1 章（dAMP）の図：部品ごと 3 枚＋つないだ 1 枚（dna_dAMP.json から。座標は整数、画面の換算だけ浮動小数）
import json
T0 = open("gasket_fig_template.html").read().replace('max="2" value="2"', 'max="3" value="2"')
J = json.load(open("dna_dAMP.json")); A = J["atoms"]
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
def own(n):
    base = ["N1","C2","N3","C4","C5","C6","N6","N7","C8","N9"]; sug = ["C1'","C2'","C3'","C4'","O4'","C5'","O5'","O3'"]
    ph = ["P","OP1","OP2","OP3"]
    if n in base: return 0
    if n in sug: return 1
    if n in ph: return 2
    inner = n[2:n.index(")")]
    return own(inner)
def share(a, b): return [v for v in A[a] if v in A[b]][0]
def build(out, title, desc, part, marks, rings):
    atoms = [[n, EL(n), V] for n, V in A.items() if own(n) in part]
    D = {"atoms": atoms, "caps": [], "marks": marks, "rings": rings}
    html = T0.replace("__TITLE__", title).replace("__DESC__", desc).replace("__DATA__", json.dumps(D, ensure_ascii=False, separators=(",", ":")))
    html = html.replace('<button id="tCap">ふた</button>', '<button id="tCap" style="display:none">ふた</button>')
    open(out, "w").write(html); print(out, len(html.encode()), "bytes")
HEX = ["N1","C2","N3","C4","C5","C6"]; PEN = ["C5","N7","C8","N9","C4"]; SUG = ["C1'","C2'","C3'","C4'","O4'"]
pN9, pO5 = share("N9", "C1'"), share("O5'", "P")
SUB = '<p class="sub">座標はすべて整数で、画面に写す換算だけ浮動小数を使う。「段」はギャスケットを割る段（H 1・C N O 2・P 3 まで）、「水素」は H の出し入れ。ドラッグで向きを変えられる。</p>'
build("dna01_1_adenine.html", "dAMP その1 アデニン",
"""<p>六角形の側は、ベンゼン環と同じ星型正八面体の帯の 6 個（N1・C2・N3・C4・C5・C6）。隣どうしは辺を分け合い、上・下・上・下のジグザグになる。C2 に H、C6 に NH₂。</p>
<p>五角形の側は、C5 と C4 から N7・C8・N9 を頂点の分け合い（単結合）でつないで閉じる。頂点での折り返しだけでは閉じず、同じ向きのまま頂点を重ねる平行移動を混ぜると閉じる。閉じ方は 8 通りあり、図はその一つ。C8 に H が一つ付く。</p>
<p>黄色の点は N9 の空いた頂点で、次の図の糖（C1′）とここで頂点を分け合う。</p>""" + SUB,
      {0}, [["N9", pN9, "--hi"]], [HEX, PEN])
build("dna01_2_sugar.html", "dAMP その2 デオキシリボース",
"""<p>糖も五角形（C1′・C2′・C3′・C4′・O4′）。結合はすべて単結合なので、5 本とも頂点を一つずつ分け合う。アデニンの五角形と同じく、折り返しと平行移動を混ぜて閉じる。</p>
<p>C4′ から C5′、C5′ から O5′、C3′ から O3′ が頂点でつながる。H は C1′ に 1、C2′ に 2（デオキシ＝2′ に O が無い）、C3′ に 1、C4′ に 1、C5′ に 2、O3′ に 1。</p>
<p>黄色の点は二つの口。C1′ の口は前の図の N9 と、O5′ の口は次の図のリン（P）と頂点を分け合う。</p>""" + SUB,
      {1}, [["C1'", pN9, "--hi"], ["O5'", pO5, "--hi"]], [SUG])
build("dna01_3_phosphate.html", "dAMP その3 リン酸",
"""<p>リンは 3 段のギャスケットで、辺の長さは酸素の 2 倍。四つの頂点がそれぞれ腕になる。</p>
<p>一つ目の頂点は糖の O5′ と分け合う（黄色の点）。二つ目では、リンの角の小さな正四面体（1 段割ったもの）と OP1 が辺を分け合う（P=O の二重結合）。残りの二つの頂点には OP2・OP3 が頂点でつながり、それぞれ H を一つ持つ。</p>""" + SUB,
      {2}, [["P", pO5, "--hi"]], [])
build("dna01_4_dAMP.html", "dAMP（デオキシアデノシン一リン酸）",
"""<p>前の 3 枚の部品をつないだもの。アデニンの N9 と糖の C1′、糖の O5′ とリンが、それぞれ頂点を一つ分け合う。</p>
<p>原子は 36 個（C10・H14・N5・O6・P1）。どの二つも中身は重ならず、頂点を分け合うのは結合した組だけ（ベンゼンの帯で一つおきの原子が接する点を除く）。</p>
<p>ギャスケットの頂点の和は 984。部品のまま（アデニン・デオキシリボース・リン酸）なら 1092 で、つなぐときに水 2 個（108）が抜けた分だけ少ない。</p>""" + SUB,
      {0, 1, 2}, [], [HEX, PEN, SUG])

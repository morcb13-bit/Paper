# dna_dAMP_check.py  組んだ dAMP（dna_dAMP.json）を整数だけで検める：組成・頂点の帳簿・重なり・結合の種類・糖の五角形の閉じ方の数
import json, itertools, io, contextlib
from collections import Counter
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
g = {}; exec(src, g); overlap, sub, add, dot = g["overlap"], g["sub"], g["add"], g["dot"]
J = json.load(open("dna_dAMP.json")); A = {k: [tuple(v) for v in V] for k, V in J["atoms"].items()}
B = [tuple(b) for b in J["bonds"]]
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
NV = {"H": 10, "C": 34, "N": 34, "O": 34, "P": 130}
cnt = Counter(EL(k) for k in A)
print("1. 組成：", "".join(f"{e}{cnt[e]}" for e in "CHNOP"), "  原子", len(A), "  ギャスケットの頂点の和", sum(NV[e]*c for e, c in cnt.items()))
parts = {"アデニン C5H5N5": 5*34+5*10+5*34, "デオキシリボース C5H10O4": 5*34+10*10+4*34, "リン酸 H3PO4": 130+4*34+3*10}
print("   部品の頂点の和：", parts, " 計", sum(parts.values()), "  水 2 個（O 1・H 2 ずつ）", 2*(34+2*10), " → 差し引き", sum(parts.values()) - 2*(34+2*10))
print("2. 中身の重なり（全", len(A)*(len(A)-1)//2, "組）：", sum(1 for a, b in itertools.combinations(A, 2) if overlap(A[a], A[b])))
def kind(a, b):
    X, Y = A[a], A[b]; s = len(set(X) & set(Y))
    if s == 2: return "辺"
    if s == 1:
        p = (set(X) & set(Y)).pop(); n2 = lambda T: sorted(dot(sub(u, v), sub(u, v)) for u, v in itertools.combinations(T, 2))[0]
        if n2(X) != n2(Y): return "頂点（大きさ違い）"
        refl = sorted(tuple(2*c - x for c, x in zip(p, v)) for v in X)
        if refl == sorted(Y): return "頂点・折り返し"
        d = sub(p, next(v for v in X if v != p)) if False else None
        return "頂点・平行移動" if any(sorted(add(v, sub(p, q)) for v in X) == sorted(Y) for q in X) else "頂点・その他"
    return f"{s}"
heavy = lambda n: not n.startswith("H")
print("3. 結合の種類（H を除く）：", Counter(kind(a, b) for a, b in B if heavy(a) and heavy(b)))
for ring in (["C5","N7","C8","N9","C4"], ["C1'","C2'","C3'","C4'","O4'"]):
    ks = [kind(ring[i], ring[(i+1) % 5]) for i in range(5)]
    print("   五角形", "–".join(ring), "：", ks)
print("   OP1 と P：P の角の小さな正四面体と分け合う頂点", len(set(A["OP1"]) & {tuple((x+y)//2 for x, y in zip(A["P"][i], A["P"][j])) for i in range(4) for j in range(4)}), "（2 ＝ 辺）")
h = lambda n: sum(sum(v) for v in A[n])                       # (1,1,1) の向きの高さ ×4
print("4. 高さ（(1,1,1) の向き、中心×4）：", {n: h(n) for n in ["N1","C2","N3","C4","C5","C6","N7","C8","N9","C1'","C2'","C3'","C4'","O4'","C5'","O5'","P"]})

# dna_conf1.py  手順 1：dAMP の置き方を広げ、3′–5′ のつなぎ目の回転に位数 1・2・3・4 のどれが出るかを数える（整数だけ）
# 置き方：dna_build1.py の決めごとそのまま（アデニンの五角形 8 通り × H(C8) × N9 の口 × 糖 × C5′・O5′・O3′・P × リン酸の O × H）。
#   H の置き方はつなぎ目の向きを変えないので、各置き方で最初に通った一つだけ取る。上限 CAP 個で止める。
# つなぎ目（今朝と同じ）：二つ目の OP2 か OP3 の席が一つ目の O3′ にそのまま重なる回し方（符号つきの置換 48）と整数の並進。
#   二つ目の席の O と H、一つ目の H(O3′) を抜いて、二つの単位の間だけ判定する
#   （単位の中は dAMP で検算済み）：重なり 0、頂点を分け合うのは O3′–P だけ。
# 事前基準：
#   位数ごとに、つなぎ目として通る (置き方, 席, 回し方) の数を数える。位数 1・2・3・4 のどれが 0 かを返す。
#   正の対照：今朝の置き方（dna_dAMP.json）が含まれ、そこで位数 4・2 の通り方が今朝と同じ 6 通り出ること。
#   負の対照：鏡（行列式 −1）は数え分け、合格しても「使えない」とする（糖が鏡像になる）。
#   見立て（走らせる前の読み）：O3′ と席の正四面体が同じ向きなら回し方は 位数 1・2・3、逆向きなら 位数 2・4 しか無い。
import json, itertools, time, sys
src = open("dna_build1.py").read().split("n_ad = 0; found = None")[0]
exec(src)
CAP = int(sys.argv[1]) if len(sys.argv) > 1 else 400
TLIM = float(sys.argv[2]) if len(sys.argv) > 2 else 400
t0 = time.time()
confs = []; seen = set()
def key(h): return frozenset((k, tuple(map(tuple, v))) for k, v in h.A.items())
done = False
for si, m, q in adenines():
    for s in sugars(m, q):
        for dd in subst(s):
            for f in phosphate_O(dd):
                for h in hydrogens(f):
                    kk = key(h)
                    if kk not in seen:
                        seen.add(kk); confs.append((si, {k: [tuple(v) for v in T] for k, T in h.A.items()}, set(h.B)))
                    break
                if len(confs) >= CAP or time.time() - t0 > TLIM: done = True; break
            if done: break
        if done: break
    if done: break
print("集めた置き方：", len(confs), f"（{time.time()-t0:.0f} 秒）")

def mats():
    for perm in itertools.permutations(range(3)):
        for sg in itertools.product((1, -1), repeat=3): yield perm, sg
def app(M, v): perm, sg = M; return tuple(sg[i] * v[perm[i]] for i in range(3))
def det(M):
    perm, sg = M; inv = sum(1 for i in range(3) for j in range(i+1, 3) if perm[i] > perm[j])
    return (-1) ** inv * sg[0] * sg[1] * sg[2]
def order(M):
    v = [(1,0,0),(0,1,0),(0,0,1)]; w = list(v)
    for k in range(1, 7):
        w = [app(M, x) for x in w]
        if w == v: return k
def shape(T):  # 向き：重心からの 4 本（重心×4 で割らずに）を正の数で約したもの
    c = [sum(v[i] for v in T) for i in range(3)]
    off = [tuple(4*v[i] - c[i] for i in range(3)) for v in T]
    from math import gcd
    gg = 0
    for o in off:
        for x in o: gg = gcd(gg, abs(x))
    return frozenset(tuple(x // gg for x in o) for o in off)
def bbox(T): return [min(v[i] for v in T) for i in range(3)], [max(v[i] for v in T) for i in range(3)]
def apart(b1, b2): return any(b1[1][i] < b2[0][i] or b2[1][i] < b1[0][i] for i in range(3))
def joints(A, seat):
    O3 = set(A["O3'"]); out = []
    for M in mats():
        R = [app(M, v) for v in A[seat]]
        t = tuple(a - b for a, b in zip(A["O3'"][0], R[0]))
        for v in R:
            t = tuple(a - b for a, b in zip(A["O3'"][0], v))
            if {tuple(x + y for x, y in zip(w, t)) for w in R} == O3: break
        else: continue
        U0 = {k: T for k, T in A.items() if k != "H(O3')"}
        U1 = {k: [tuple(x + y for x, y in zip(app(M, v), t)) for v in T] for k, T in A.items() if k not in (seat, f"H({seat})")}
        b0 = {k: bbox(T) for k, T in U0.items()}; b1 = {k: bbox(T) for k, T in U1.items()}
        ok = True
        for a, Ta in U0.items():
            for b, Tb in U1.items():
                s = set(Ta) & set(Tb); want = (a == "O3'" and b == "P")
                if bool(s) != want: ok = False; break
                if apart(b0[a], b1[b]): continue
                if overlap(Ta, Tb): ok = False; break
            if not ok: break
        out.append((M, t, ok))
    return out

from collections import Counter
cnt = Counter(); cnt_m = Counter(); same_or = Counter(); per_conf = []
for ci, (si, A, Bd) in enumerate(confs):
    rec = []
    for seat in ("OP2", "OP3"):
        so = shape(A["O3'"]) == shape(A[seat]); same_or[so] += 1
        for M, t, ok in joints(A, seat):
            o = order(M); dt = det(M)
            if dt == 1:
                cnt[(o, ok)] += 1
                if ok: rec.append((seat, M[0], M[1], t, o))
            else:
                cnt_m[ok] += 1
            # 見立ての確かめ：同じ向きなら位数 1・2・3、逆向きなら 2・4
            if dt == 1 and ((so and o == 4) or (not so and o in (1, 3))):
                print("見立てに外れる回し方", ci, seat, M, o)
    per_conf.append({"conf": ci, "pent": si, "joints": rec})
print("席と O3′ の向き（同じ向き True／逆向き False）の数：", dict(same_or))
print("回し方（行列式 +1）：位数ごとに 通る／通らない")
for o in (1, 2, 3, 4):
    print(f"   位数 {o}：通る {cnt[(o, True)]}  通らない {cnt[(o, False)]}")
print("鏡（行列式 −1）：通る", cnt_m[True], " 通らない", cnt_m[False], "（通っても糖が鏡像なので使わない）")
# 正の対照：今朝の置き方
J = json.load(open("dna_dAMP.json")); A0 = {k: [tuple(v) for v in T] for k, T in J["atoms"].items()}
hit = [i for i, (_, A, _) in enumerate(confs) if A == A0]
print("正の対照：今朝の dAMP は集めた中の", hit, "番", "→ 通るつなぎ目", len(per_conf[hit[0]]["joints"]) if hit else "（含まれない）",
      [ (j[0], j[4]) for j in per_conf[hit[0]]["joints"]] if hit else "")
json.dump({"confs": [{"pent": si, "atoms": {k: [list(v) for v in T] for k, T in A.items()}, "bonds": [sorted(b) for b in Bd]} for si, A, Bd in confs],
           "joints": [{"conf": p["conf"], "joints": [[j[0], list(j[1]), list(j[2]), list(j[3]), j[4]] for j in p["joints"]]} for p in per_conf]},
          open("dna_confs.json", "w"))

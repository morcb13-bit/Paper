# dna_mods.py  修飾した DNA のヌクレオチドがギャスケットの決めごとで組めるか（整数だけ、dna_tc.py と同じ規則：1–3 の組は頂点を分け合ってよい）
# dUMP：ウラシル（チミンからメチル基を外し、C5 に H）。C2=O2・C4=O4 は辺、N3–H・C5–H・C6–H。組成 C9 H13 N2 O8 P1、原子 34、数 453
# 5-メチル-dCMP：シトシンの C5 の H をメチル基（C7 と H×3）に替える。組成 C10 H16 N3 O7 P1、原子 37、数 485
# 事前基準：全原子の組で 重なり 0・頂点の分け合いは結合と 1–3 の組だけ、組成・原子数・数（5H+17(C+N+O)+65P）が一致。
# 負の対照：帯の C2 に O を 2 つ（候補の辺の 2 本目にも）付けようとしたら NG と返すこと（数の上では 17 を足すだけで書ける組み合わせ）。
import json, itertools
exec(open("dna_tc.py").read().split('print("=== T（dTMP） ===")')[0])
def number(h):
    c = {}
    for k in h.A: c[EL(k)] = c.get(EL(k), 0) + 1
    return c, 5*c.get("H",0) + 17*(c.get("C",0)+c.get("N",0)+c.get("O",0)) + 65*c.get("P",0)
B0 = set(ring_bonds)
O2 = next(O for e, O, bad in try_O(dict(R0), B0, "C2", "O2") if not bad)
O4 = next(O for e, O, bad in try_O(dict(R0), B0, "C4", "O4") if not bad)
print("=== dUMP ===")
A = {**R0, "O2": O2, "O4": O4, "H(N3)": H_o(R0["N3"], tip["N3"]), "H(C5)": H_o(R0["C5"], tip["C5"]), "H(C6)": H_o(R0["C6"], tip["C6"])}
B = B0 | {frozenset(p) for p in [("C2","O2"),("C4","O4"),("N3","H(N3)"),("C5","H(C5)"),("C6","H(C6)")]}
print("  塩基：", judge(A, B) or "合格")
h = build_full(A, B, "N1")
if h:
    ok = report_full("dUMP", h, ({"C": 9, "H": 13, "N": 2, "O": 8, "P": 1}, 34), 0 and 0 or 2*453 - 0) if False else None
    bad = judge(h.A, set(h.B)); c, n = number(h)
    print("  全体：", "合格" if not bad else bad[:3], " 組成", c, " 原子", len(h.A), " 数", n, "（予測 453）")
else: print("  【今回の探索範囲では見つからなかった】")
print("=== 5-メチル-dCMP ===")
N4 = refl_o(R0["C4"], tip["C4"]); frN4 = [v for v in N4 if v not in R0["C4"]]
C7 = refl_o(R0["C5"], tip["C5"]); frC7 = [v for v in C7 if v not in R0["C5"]]
found = None
for p, q in itertools.combinations(frN4, 2):
    A = {**R0, "O2": O2, "N4": N4, "H(N4)a": H_o(N4, p), "H(N4)b": H_o(N4, q), "C7": C7, "H(C6)": H_o(R0["C6"], tip["C6"])}
    for i, v in enumerate(frC7): A[f"H(C7){'abc'[i]}"] = H_o(C7, v)
    B = B0 | {frozenset(x) for x in [("C2","O2"),("C4","N4"),("N4","H(N4)a"),("N4","H(N4)b"),("C5","C7"),("C6","H(C6)")]} | {frozenset(("C7", f"H(C7){'abc'[i]}")) for i in range(3)}
    if judge(A, B): continue
    print("  塩基：合格")
    h = build_full(A, B, "N1")
    if h: found = h; break
if found:
    bad = judge(found.A, set(found.B)); c, n = number(found)
    print("  全体：", "合格" if not bad else bad[:3], " 組成", c, " 原子", len(found.A), " 数", n, "（予測 485）")
else: print("  【今回の探索範囲では見つからなかった】")
print("=== 負の対照：帯の C2 に O を 2 つ辺で ===")
res = try_O(dict(R0), B0, "C2", "O2")
print("  C2 の候補の辺で合格するもの：", sum(1 for r in res if not r[2]), "本（2 つ目の O を置ける辺は無い）")
ok2 = [r for r in res if not r[2]]
bad2 = []
for e, O, _ in res:
    if ok2 and O == ok2[0][1]: continue
    A = {**R0, "O2": ok2[0][1], "O2b": O}; B = B0 | {frozenset(("C2","O2")), frozenset(("C2","O2b"))}
    bad2.append(bool(judge(A, B)))
print("  2 つ目を残りの辺に置いた 3 通りが、すべて NG：", all(bad2), bad2)

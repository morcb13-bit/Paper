# dna_tc.py  T（dTMP）と C（dCMP）を、G3 と同じ変更後の規則（1–3 の組は頂点を分け合ってよい）に固定して組む（整数だけ）
# 材料：dna_adenine6.json の帯 6 個（N1 C2 N3 C4 C5 C6）。ピリミジンは五角形を持たず、糖の C1′ は N1 のとがった先（口）に付く。
# 置換基（決めごとは第 1 章・G3 のまま）：
#   C=O：その C の辺の中点で O を折り返す（辺を分け合う）。候補の辺は、帯の隣と分け合っていない辺すべて。
#   頂点の結合（C–C, C–N）：とがった先で折り返す。H：角の小さな正四面体をその頂点で折り返す。
#   T：C2=O2, C4=O4, C5–C7（メチル）と H×3, N3–H, C6–H
#   C：C2=O2, C4–N4 と H×2, C5–H, C6–H, N3 には H を付けない（とがった先は空きのまま）
# 糖・リン酸・H：dna_build1.py と同じ探し方（C1′ の相手を N9 から N1 に替えるだけ）。最初に見つかったもの。
# 事前基準（それぞれ別々に記録）：
#   T1 O2 単独、T2 O4 単独（候補の辺ごとに合否）、T3 O2 と O4 を同時に、T4 メチルと H×3、T5 N3–H と C6–H、
#   T6 dTMP 全体：頂点の分け合い（結合・1–3 だけ）、中身の重なり 0、組成 C10 H15 N2 O8 P1・原子 36、頂点の和 960（予測値）
#   C1 O2 単独、C2 N4 と H×2、C3 C5–H と C6–H、C4 N3 のとがった先が空きのまま、
#   C5 dCMP 全体：同上、組成 C9 H14 N3 O7 P1・原子 34、頂点の和 916（予測値）
#   共通：頂点を分け合う 1–3 の組をすべて記録（G3 の C2′–O4′ が出るか）。G3 を同じ規則で再現できるか（dna_dGMP.json と一致）。
import json, itertools, io, contextlib
SRC_B1 = open("dna_build1.py").read().split("n_ad = 0; found = None")[0]
exec(SRC_B1)
exec(SRC_B1[SRC_B1.index("def sugars(m, q):"):SRC_B1.index("def subst(m")].replace("def sugars(m, q):", "def sugars_at(m, q, root):").replace('m.A["N9"]', "m.A[root]").replace('["N9"]', "[root]"))
J6 = json.load(open("dna_adenine6.json"))
ring = ["N1", "C2", "N3", "C4", "C5", "C6"]
R0 = {k: [tuple(v) for v in J6["atoms"][k]] for k in ring}
def refl_o(T, p): return [tuple(2*c - x for c, x in zip(p, v)) for v in T]
def refl_edge_o(T, a, b): m2 = tuple(x + y for x, y in zip(a, b)); return [tuple(c - x for c, x in zip(m2, v)) for v in T]
def mid_o(a, b): return tuple((x + y) // 2 for x, y in zip(a, b))
def H_o(T, p): return refl_o([mid_o(p, v) for v in T], p)
tip = {k: next(v for v in R0[k] if not any(v in R0[j] for j in ring if j != k)) for k in ring}
ring_bonds = {frozenset(p) for p in zip(ring, ring[1:] + ring[:1])}
def ok13(self, name, T, bonded):
    nb13 = set()
    for b in bonded:
        for e in self.B:
            if b in e: nb13 |= set(e) - {b}
    for k, U in self.A.items():
        s = len(set(T) & set(U))
        if k in bonded:
            if s == 0: return False
        elif s and k not in nb13: return False
        if overlap(T, U): return False
    return True
Mol.ok_with = ok13
def one_three(B):
    nb = {}
    for e in B:
        a, b = tuple(e); nb.setdefault(a, set()).add(b); nb.setdefault(b, set()).add(a)
    out = set()
    for c, ns in nb.items():
        for x, y in itertools.combinations(sorted(ns), 2): out.add(frozenset((x, y)))
    return out - B
def judge(A, B):
    o13 = one_three(B); bad = []
    for a, b in itertools.combinations(A, 2):
        e = frozenset((a, b)); s = len(set(A[a]) & set(A[b]))
        if e in B and s == 0: bad.append((a, b, "結合なのに分け合わない"))
        if e not in B and s and e not in o13: bad.append((a, b, f"頂点 {s}"))
        if overlap(A[a], A[b]): bad.append((a, b, "重なる"))
    return bad
def O_edges(X):
    return [e for e in itertools.combinations(R0[X], 2) if not any(set(e) <= set(R0[j]) for j in ring if j != X)]
def try_O(A, B, X, name):
    out = []
    for a, b in O_edges(X):
        O = refl_edge_o(R0[X], a, b); A2 = dict(A); A2[name] = O; B2 = B | {frozenset((X, name))}
        bad = [x for x in judge(A2, B2) if name in x[:2]]
        out.append(((a, b), O, bad))
    return out
VN = {"H": 10, "C": 34, "N": 34, "O": 34, "P": 130}
def report_full(tag, h, want, vwant):
    bad = judge(h.A, set(h.B))
    cnt = {}
    for k in h.A: cnt[EL(k)] = cnt.get(EL(k), 0) + 1
    vs = sum(VN[EL(k)] for k in h.A)
    o13 = sorted(tuple(sorted(e)) for e in one_three(set(h.B)) if set(h.A[tuple(e)[0]]) & set(h.A[tuple(e)[1]]))
    print(f"  {tag} 全体：頂点の分け合いと重なり", "合格" if not bad else bad[:4])
    print(f"     組成 {cnt} 原子 {len(h.A)} → {cnt == want[0] and len(h.A) == want[1]}   頂点の和 {vs}（予測 {vwant}）→ {vs == vwant}")
    print(f"     頂点を分け合う 1–3 の組：{o13}")
    print(f"     C2′–O4′ が出るか：{('C2' + chr(39), 'O4' + chr(39)) in o13}")
    return (not bad) and cnt == want[0] and len(h.A) == want[1] and vs == vwant
def build_full(base, bonds, root):
    bg = {k: [tuple(v) for v in D2(V)] for k, V in base.items()}
    m = Mol()
    for k, T in bg.items(): m.A[k] = T
    for e in bonds: m.B.add(e)
    for q in free(m, root):
        for s in sugars_at(m, q, root):
            for dd in subst(s):
                for f in phosphate_O(dd):
                    for h in hydrogens(f): return h
    return None

print("=== T（dTMP） ===")
B0 = set(ring_bonds)
for X, nm, tg in (("C2", "O2", "T1"), ("C4", "O4", "T2")):
    res = try_O(dict(R0), B0, X, nm)
    print(f"  {tg} {X}={nm} 単独：候補の辺 {len(res)} 本")
    for e, O, bad in res: print(f"     辺 {e[0]}–{e[1]}：", "合格" if not bad else bad)
okO2 = [r for r in try_O(dict(R0), B0, "C2", "O2") if not r[2]]
okO4 = [r for r in try_O(dict(R0), B0, "C4", "O4") if not r[2]]
both = []
for (e2, O2, _), (e4, O4, _) in itertools.product(okO2, okO4):
    A = {**R0, "O2": O2, "O4": O4}; B = B0 | {frozenset(("C2", "O2")), frozenset(("C4", "O4"))}
    bad = judge(A, B); both.append((O2, O4, bad))
print("  T3 O2 と O4 を同時に：", sum(1 for x in both if not x[2]), "/", len(both), "通り合格", [x[2] for x in both if x[2]][:2])
foundT = None
for O2, O4, bad in both:
    if bad: continue
    C7 = refl_o(R0["C5"], tip["C5"])
    A = {**R0, "O2": O2, "O4": O4, "C7": C7}; B = B0 | {frozenset(("C2","O2")), frozenset(("C4","O4")), frozenset(("C5","C7"))}
    print("  T4 C5–C7：", judge(A, B) or "合格")
    frC7 = [v for v in C7 if v not in R0["C5"]]
    Hs = {f"H(C7){'abc'[i]}": H_o(C7, p) for i, p in enumerate(frC7)}
    A.update(Hs); B |= {frozenset(("C7", k)) for k in Hs}
    print("     C7 の H×3：", judge(A, B) or "合格")
    A["H(N3)"] = H_o(R0["N3"], tip["N3"]); A["H(C6)"] = H_o(R0["C6"], tip["C6"])
    B |= {frozenset(("N3", "H(N3)")), frozenset(("C6", "H(C6)"))}
    print("  T5 N3–H・C6–H：", judge(A, B) or "合格")
    if judge(A, B): continue
    h = build_full(A, B, "N1")
    if h is None: print("  T6：【今回の探索範囲では見つからなかった】"); continue
    okT = report_full("T6 dTMP", h, ({"C": 10, "H": 15, "N": 2, "O": 8, "P": 1}, 36), 960)
    print("  T 判定：", "【合格】" if okT else "【部分合格】"); foundT = h
    json.dump({"atoms": {k: [list(v) for v in T] for k, T in h.A.items()}, "bonds": [sorted(e) for e in h.B]}, open("dna_dTMP.json", "w"))
    break

print("\n=== C（dCMP） ===")
res = try_O(dict(R0), B0, "C2", "O2")
print(f"  C1 C2=O2 単独：候補の辺 {len(res)} 本、合格 {sum(1 for r in res if not r[2])}")
for e, O2, bad in res:
    if bad: continue
    N4 = refl_o(R0["C4"], tip["C4"])
    A = {**R0, "O2": O2, "N4": N4}; B = B0 | {frozenset(("C2", "O2")), frozenset(("C4", "N4"))}
    frN4 = [v for v in N4 if v not in R0["C4"]]
    c2 = None
    for p, q in itertools.combinations(frN4, 2):
        A2 = dict(A); A2["H(N4)a"] = H_o(N4, p); A2["H(N4)b"] = H_o(N4, q)
        B2 = B | {frozenset(("N4", "H(N4)a")), frozenset(("N4", "H(N4)b"))}
        if not judge(A2, B2): c2 = (A2, B2); break
    print("  C2 C4–N4 と H×2：", "合格" if c2 else "NG")
    if not c2: continue
    A, B = c2
    A["H(C5)"] = H_o(R0["C5"], tip["C5"]); A["H(C6)"] = H_o(R0["C6"], tip["C6"])
    B = B | {frozenset(("C5", "H(C5)")), frozenset(("C6", "H(C6)"))}
    print("  C3 C5–H・C6–H：", judge(A, B) or "合格")
    if judge(A, B): continue
    h = build_full(A, B, "N1")
    if h is None: print("  C5：【今回の探索範囲では見つからなかった】"); continue
    n3tip = tuple(2 * c for c in tip["N3"])
    print("  C4 N3 のとがった先は空きのまま：", not any(n3tip in T for k, T in h.A.items() if k != "N3"))
    okC = report_full("C5 dCMP", h, ({"C": 9, "H": 14, "N": 3, "O": 7, "P": 1}, 34), 916)
    print("  C 判定：", "【合格】" if okC else "【部分合格】")
    json.dump({"atoms": {k: [list(v) for v in T] for k, T in h.A.items()}, "bonds": [sorted(e) for e in h.B]}, open("dna_dCMP.json", "w"))
    break

print("\n=== 共通：G3 の再現 ===")
buf = io.StringIO()
with contextlib.redirect_stdout(buf): exec(open("dna_g3.py").read(), {})
print("  dna_g3.py をもう一度走らせた判定：", [l for l in buf.getvalue().splitlines() if l.startswith("判定")])

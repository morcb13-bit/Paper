# dna_chain2.py  合格した 3′–5′ のつなぎを同じ動きで繰り返す（整数だけ）
# 鏡（行列式 −1）は二つ目の糖が鏡像になるので外す（dAMP は右手・左手を持つ）。
# 同じ動き (M,t) を繰り返すと、立方格子の回転の位数 k（1・2・3・4）で一回りするねじになる。
# 事前基準：n 個まで、中身の重なり 0 かつ 頂点の分け合い＝結合 を保つ最大の n を数える（上限 24）。
#   ねじの向き：軸 a、軸に垂直な u について (a·(u×Ru)) と (a·t) の符号が同じなら右ねじ、違えば左ねじ。
#   一段の上がり：a·t（|a|² を掛けたまま、割らない）。
import json, itertools
exec(open("dna_chain1.py").read().split("O3 = set(")[0])
J = json.load(open("dna_chain1.json"))
def crs(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def dot(a, b): return sum(x*y for x, y in zip(a, b))
def order(M):
    v = [(1,0,0),(0,1,0),(0,0,1)]
    w = list(v)
    for k in range(1, 7):
        w = [app(M, x) for x in w]
        if w == v: return k
def axis(M):
    # 回転軸：M v = v となる整数の向き（基底の像の和で探す）
    for a in itertools.product(range(-1, 2), repeat=3):
        if a != (0,0,0) and app(M, a) == a: return a
def bbox(T): return [min(v[i] for v in T) for i in range(3)], [max(v[i] for v in T) for i in range(3)]
def apart(b1, b2): return any(b1[1][i] < b2[0][i] or b2[1][i] < b1[0][i] for i in range(3))
def grow(M, t, seat, N):
    """一つずつ足し、足した単位を既にある原子とだけ比べる（箱で先に外す）。比べ方は judge と同じ"""
    atoms, bonds = chain(N, M, t, seat)   # 原子と結合の帳簿だけ作る（判定はしない）
    by = {}
    for k in atoms: by.setdefault(int(k.split("#")[1]), []).append(k)
    box = {k: bbox(T) for k, T in atoms.items()}
    placed = []
    for n in range(N):
        new = by[n]
        for a in new:
            for b in placed + [x for x in new if x < a]:
                e = frozenset((a, b)); s = set(atoms[a]) & set(atoms[b])
                same = a.split("#")[1] == b.split("#")[1]
                if same: continue          # 同じ単位の中は dAMP で検算済み（端で抜いた原子は他を増やさない）
                # 端の扱い：chain(N) の中の n 個目は、n 個で止めた鎖の端とは H(O3') の有無だけが違う
                if apart(box[a], box[b]) and not s:
                    if e in bonds: return n, (a, b, "切れている")
                    continue
                if overlap(atoms[a], atoms[b]): return n, (a, b, "重なる")
                if bool(s) != (e in bonds): return n, (a, b, "分け合う" if s else "切れている")
        placed += new
    return N, None
for seat, perm, sg, t in J["hits"]:
    M = (tuple(perm), tuple(sg)); t = tuple(t)
    if det(M) != 1: continue
    k = order(M); a = axis(M)
    u = next(x for x in [(1,0,0),(0,1,0),(0,0,1)] if crs(a, x) != (0,0,0))
    u = crs(a, u)
    turn = dot(a, crs(u, app(M, u))); rise = dot(a, t)
    hand = "右" if turn * rise > 0 else "左" if turn * rise < 0 else "—"
    best, first = grow(M, t, seat, 24)
    print(f"席 {seat}  置換 {M[0]} 符号 {M[1]}  位数 {k}  軸 {a}  上がり(a·t) {rise}  {hand}ねじ  "
          f"つながる最大 {best}{'（上限）' if first is None else ''}  最初の衝突 {first}")

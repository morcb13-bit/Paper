# build_ch24.py  第 2〜4 章（dGMP・dTMP・dCMP）と、組み直した第 1 章（dAMP）の図。座標は整数、画面の換算だけ浮動小数
import json
T0 = open("gasket_fig_template.html").read().replace('max="2" value="2"', 'max="3" value="2"')
T0 = T0.replace('<button id="tCap">ふた</button>', '<button id="tCap" style="display:none">ふた</button>')
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
SUG = {"C1'","C2'","C3'","C4'","O4'","C5'","O5'","O3'"}; PH = {"P","OP1","OP2","OP3"}
def own(n):
    if n.startswith("H("): n = n[2:n.index(")")]
    return 1 if n in SUG else 2 if n in PH else 0
SUB = '<p class="sub">座標はすべて整数で、画面に写す換算だけ浮動小数を使う。「段」はギャスケットを割る段（H 1・C N O 2・P 3 まで）、「水素」は H の出し入れ。ドラッグで向きを変えられる。</p>'
HEX = ["N1","C2","N3","C4","C5","C6"]; PEN = ["C5","N7","C8","N9","C4"]; SG5 = ["C1'","C2'","C3'","C4'","O4'"]
def build(out, title, desc, path, part, root, rings):
    A = json.load(open(path))["atoms"]
    atoms = [[n, EL(n), V] for n, V in A.items() if own(n) in part]
    mouth = [v for v in A[root] if v in A["C1'"]][0]
    marks = [[root, mouth, "--hi"]] if part == {0} else []
    D = {"atoms": atoms, "caps": [], "marks": marks, "rings": rings}
    html = T0.replace("__TITLE__", title).replace("__DESC__", desc + SUB).replace("__DATA__", json.dumps(D, ensure_ascii=False, separators=(",", ":")))
    open(out, "w").write(html); print(out, len(html.encode()), "bytes")
build("dna02_1_guanine.html", "dGMP その1 グアニン",
"""<p>六角形の側は、アデニンと同じ星型正八面体の帯の 6 個（N1・C2・N3・C4・C5・C6）。五角形の側も、アデニンと同じ決めごとで C4–C5 から N7・C8・N9 を閉じる。</p>
<p>違いは置換基だけ。C6 に O6 が辺で付く（C=O の二重結合）。O6 を付けられる C6 の辺はちょうど 1 本で、そこでは O6 が N1・C5 とも頂点を一つずつ分け合う。どちらも C6 を挟んだ隣（1–3 の組）。C2 に NH₂（N2 と H 2 個）、N1 に H、C8 に H。</p>
<p>黄色の点は N9 の空いた頂点で、糖（C1′）とここで頂点を分け合う。</p>""", "dna_dGMP.json", {0}, "N9", [HEX, PEN])
build("dna02_2_dGMP.html", "dGMP（デオキシグアノシン一リン酸）",
"""<p>グアニンに、第 1 章と同じ決めごとで糖とリン酸をつないだもの。N9 と C1′、O5′ と P が、それぞれ頂点を一つ分け合う。</p>
<p>原子は 37 個（C10・H14・N5・O7・P1）。どの二つも中身は重ならず、頂点を分け合うのは結合した組と、同じ原子に結合した二つ（1–3 の組）だけ。ギャスケットの頂点の和は 1018。</p>""", "dna_dGMP.json", {0, 1, 2}, "N9", [HEX, PEN, SG5])
build("dna03_1_thymine.html", "dTMP その1 チミン",
"""<p>チミンは六角形 1 つだけ（ピリミジン）。帯の 6 個はアデニン・グアニンと同じ。</p>
<p>C2 と C4 に O が辺で付く（C=O が 2 つ）。どちらの C でも、O を付けられる辺はちょうど 1 本で、二つを同時に付けても重ならない。C5 にメチル基（C7 と H 3 個）、N3 に H、C6 に H。</p>
<p>黄色の点は N1 の空いた頂点で、糖（C1′）とここで頂点を分け合う。</p>""", "dna_dTMP.json", {0}, "N1", [HEX])
build("dna03_2_dTMP.html", "dTMP（デオキシチミジン一リン酸）",
"""<p>チミンに糖とリン酸をつないだもの。N1 と C1′、O5′ と P が、それぞれ頂点を一つ分け合う。</p>
<p>原子は 36 個（C10・H15・N2・O8・P1）。どの二つも中身は重ならず、頂点を分け合うのは結合した組と 1–3 の組だけ。ギャスケットの頂点の和は 960。</p>""", "dna_dTMP.json", {0, 1, 2}, "N1", [HEX, SG5])
build("dna04_1_cytosine.html", "dCMP その1 シトシン",
"""<p>シトシンも六角形 1 つだけ（ピリミジン）。C2 に O が辺で付く（付けられる辺はちょうど 1 本）。C4 に NH₂（N4 と H 2 個）、C5 と C6 に H。N3 には H を付けず、とがった先は空いたまま。</p>
<p>黄色の点は N1 の空いた頂点で、糖（C1′）とここで頂点を分け合う。</p>""", "dna_dCMP.json", {0}, "N1", [HEX])
build("dna04_2_dCMP.html", "dCMP（デオキシシチジン一リン酸）",
"""<p>シトシンに糖とリン酸をつないだもの。N1 と C1′、O5′ と P が、それぞれ頂点を一つ分け合う。</p>
<p>原子は 34 個（C9・H14・N3・O7・P1）。どの二つも中身は重ならず、頂点を分け合うのは結合した組と 1–3 の組だけ。ギャスケットの頂点の和は 916。</p>""", "dna_dCMP.json", {0, 1, 2}, "N1", [HEX, SG5])

# dna_build1.py  dAMP をシェルピンスキーのギャスケットの決めごとだけで組む（立方格子の整数、座標は 2 倍）
# 決めごと：原子は正四面体（H 1 段 辺² 72、C・N・O 2 段 辺² 288、P 3 段 辺² 1152 ＝座標 2 倍の尺度）
#   単結合：頂点を一つ分け合う（頂点での折り返し、または同じ向きのまま頂点を重ねる平行移動。大きさが違うときは −2 倍・2 倍）
#   芳香環・二重結合：辺を分け合う。H：相手の角の小さな正四面体を、その頂点で折り返す
# 判定（すべて整数）：中身が重ならない／結合していない原子は頂点を分け合わない（帯の一つおきの接点だけは帯そのものの性質として除く）
import json, itertools, sys
src = open("dna_r6.py").read(); src = src[:src.index('print("R0.')]
g = {}; exec(src, g)
overlap, add, sub = g["overlap"], g["add"], g["sub"]
D2 = lambda T: [tuple(2*c for c in v) for v in T]
def mid(a, b): return tuple((x + y) // 2 for x, y in zip(a, b))
def corner(T, p): return [mid(p, v) for v in T]
def refl(T, p): return [tuple(2*c - x for c, x in zip(p, v)) for v in T]
def H_at(T, p): return refl(corner(T, p), p)
def single(T, p, scale=1):
    """T の頂点 p で頂点を一つ分け合う相手の候補（scale=2 なら 2 倍の大きさ：P）"""
    out = [[tuple(c + scale*(c - x) for c, x in zip(p, v)) for v in T]]                 # 折り返し（−scale 倍）
    for q in T:
        if q != p: out.append([tuple(c + scale*(x - y) for c, x, y in zip(p, v, q)) for v in T])  # 平行移動（q を p へ）
    return out
J = json.load(open("dna_adenine6.json")); P5 = json.load(open("dna_p5_all.json"))
base = {k: [tuple(v) for v in D2(V)] for k, V in J["atoms"].items()}
band_alt = {frozenset(x) for x in [("N1","N3"),("N1","C5"),("C2","C4"),("C2","C6"),("N3","C5"),("C4","C6")]}
class Mol:
    def __init__(self): self.A = {}; self.B = set()
    def ok_with(self, name, T, bonded):
        for k, U in self.A.items():
            s = len(set(T) & set(U))
            if k in bonded:
                if s == 0: return False
            elif s: return False
            if overlap(T, U): return False
        return True
    def add_(self, name, T, bonded):
        self.A[name] = T
        for b in bonded: self.B.add(frozenset((name, b)))
def free(m, name):
    used = set()
    for k, U in m.A.items():
        if k != name: used |= set(U)
    return [v for v in m.A[name] if v not in used]
EL = lambda n: "H" if n.startswith("H") else "P" if n == "P" else n[0]
log = []
def try_place(m, name, cands, bonded):
    return [T for T in cands if m.ok_with(name, T, bonded)]
def copy(m):
    n = Mol(); n.A = dict(m.A); n.B = set(m.B); return n
# ---- アデニン ----
def adenines():
    for si, s in enumerate(P5["sols"]):
        m = Mol()
        for k, T in base.items(): m.A[k] = T
        for a, b in [("N1","C2"),("C2","N3"),("N3","C4"),("C4","C5"),("C5","C6"),("C6","N1"),("C6","N6"),("C2","H(C2)"),("N6","H(N6)a"),("N6","H(N6)b")]:
            m.B.add(frozenset((a, b)))
        ok = True
        for k in ("N7", "C8", "N9"):
            T = [tuple(v) for v in D2(s[k])]; bd = {"N7": ["C5"], "C8": ["N7"], "N9": ["C8", "C4"]}[k]
            if not m.ok_with(k, T, bd): ok = False; break
            m.add_(k, T, bd)
        if not ok: continue
        for p in free(m, "C8"):
            Hc8 = H_at(m.A["C8"], p)
            if not m.ok_with("H(C8)", Hc8, ["C8"]): continue
            m2 = copy(m); m2.add_("H(C8)", Hc8, ["C8"])
            for q in free(m2, "N9"):
                yield si, m2, q
# ---- 糖の五角形：C1'（N9 の口 q と頂点を分け合う）→ C2' → C3' → C4' → O4' → C1' ----
def sugars(m, q):
    for C1 in try_place(m, "C1'", single(m.A["N9"], q), ["N9"]):
        m1 = copy(m); m1.add_("C1'", C1, ["N9"])
        for p1 in free(m1, "C1'"):
            for C2 in try_place(m1, "C2'", single(C1, p1), ["C1'"]):
                m2 = copy(m1); m2.add_("C2'", C2, ["C1'"])
                for p2 in free(m2, "C2'"):
                    for C3 in try_place(m2, "C3'", single(C2, p2), ["C2'"]):
                        m3 = copy(m2); m3.add_("C3'", C3, ["C2'"])
                        for p3 in free(m3, "C3'"):
                            for C4 in try_place(m3, "C4'", single(C3, p3), ["C3'"]):
                                m4 = copy(m3); m4.add_("C4'", C4, ["C3'"])
                                for p4 in free(m4, "C4'"):
                                    for O4 in single(C4, p4):
                                        if m4.ok_with("O4'", O4, ["C4'", "C1'"]):
                                            m5 = copy(m4); m5.add_("O4'", O4, ["C4'", "C1'"]); yield m5
def subst(m):
    """C5'・O5'・O3'・P・OP1（二重：辺）・OP2・OP3 と H をすべて付ける（最初に見つかった置き方を返す）"""
    def H_all(m, name, n):
        for ps in itertools.combinations(free(m, name), n):
            mm = copy(m); ok = True
            for k, p in enumerate(ps):
                Hh = H_at(m.A[name], p); hn = f"H({name}){'abc'[k]}" if n > 1 else f"H({name})"
                if not mm.ok_with(hn, Hh, [name]): ok = False; break
                mm.add_(hn, Hh, [name])
            if ok: yield mm
    for p in free(m, "C4'"):
        for C5 in try_place(m, "C5'", single(m.A["C4'"], p), ["C4'"]):
            a = copy(m); a.add_("C5'", C5, ["C4'"])
            for p5 in free(a, "C5'"):
                for O5 in try_place(a, "O5'", single(C5, p5), ["C5'"]):
                    b = copy(a); b.add_("O5'", O5, ["C5'"])
                    for p3 in free(b, "C3'"):
                        for O3 in try_place(b, "O3'", single(b.A["C3'"], p3), ["C3'"]):
                            c = copy(b); c.add_("O3'", O3, ["C3'"])
                            for pp in free(c, "O5'"):
                                for P in try_place(c, "P", single(O5, pp, 2), ["O5'"]):
                                    d = copy(c); d.add_("P", P, ["O5'"])
                                    yield d
def phosphate_O(d):
    fv = free(d, "P")
    for v1 in fv:                                   # OP1：P の角の小さな正四面体と辺を分け合う（二重結合）
        K = corner(d.A["P"], v1)
        for w in K:
            if w == v1: continue
            m2 = add(v1, w); O1 = [sub(m2, x) for x in K]
            if not d.ok_with("OP1", O1, ["P"]): continue
            e = copy(d); e.add_("OP1", O1, ["P"])
            rest = [v for v in fv if v != v1]
            for c2 in single(d.A["P"], rest[0], 1):
                pass
            # OP2・OP3：P の残りの頂点で、P の角の小さな正四面体を折り返した大きさ（辺² 288）で頂点を分け合う
            def O_at(v): return refl(corner(d.A["P"], v), v)
            O2, O3 = O_at(rest[0]), O_at(rest[1])
            if e.ok_with("OP2", O2, ["P"]):
                f = copy(e); f.add_("OP2", O2, ["P"])
                if f.ok_with("OP3", O3, ["P"]):
                    f.add_("OP3", O3, ["P"]); yield f
def hydrogens(f):
    plan = [("C1'", 1), ("C2'", 2), ("C3'", 1), ("C4'", 1), ("C5'", 2), ("O3'", 1), ("OP2", 1), ("OP3", 1)]
    def go(m, i):
        if i == len(plan): yield m; return
        name, n = plan[i]
        for ps in itertools.combinations(free(m, name), n):
            mm = copy(m); ok = True
            for k, p in enumerate(ps):
                Hh = H_at(m.A[name], p); hn = f"H({name}){'ab'[k]}" if n > 1 else f"H({name})"
                if not mm.ok_with(hn, Hh, [name]): ok = False; break
                mm.add_(hn, Hh, [name])
            if ok: yield from go(mm, i + 1)
    yield from go(f, 0)
n_ad = 0; found = None; first_sug = None
for si, m, q in adenines():
    n_ad += 1
    for s in sugars(m, q):
        if first_sug is None: first_sug = (si, n_ad); print("最初に閉じた糖：五角形の置き方", si + 1, flush=True)
        for d in subst(s):
            for f in phosphate_O(d):
                for h in hydrogens(f):
                    found = (si, h); break
                if found: break
            if found: break
        if found: break
    if found: break
n_sug = "（最初に見つかったところで止めた）"
print("アデニン（五角形 8 通り × H(C8) × N9 の口）の候補：", n_ad)
print("糖の五角形が閉じる置き方（全候補の合計）：", n_sug)
if found:
    si, h = found
    cnt = {}
    for k in h.A: cnt[EL(k)] = cnt.get(EL(k), 0) + 1
    print("見つかった dAMP：五角形の置き方", si + 1, " 組成", cnt, " 原子", len(h.A))
    names = list(h.A)
    bad = [(a, b) for a, b in itertools.combinations(names, 2) if overlap(h.A[a], h.A[b])]
    sh = [(a, b) for a, b in itertools.combinations(names, 2) if (len(set(h.A[a]) & set(h.A[b])) > 0) != (frozenset((a, b)) in h.B) and frozenset((a, b)) not in band_alt]
    print("検算：中身の重なり", bad if bad else "なし", "  結合と頂点の分け合いの食い違い", sh if sh else "なし")
    kinds = {}
    for e in h.B:
        a, b = tuple(e); kinds[len(set(h.A[a]) & set(h.A[b]))] = kinds.get(len(set(h.A[a]) & set(h.A[b])), 0) + 1
    print("結合の数（分け合う頂点の数ごと）：", kinds)
    json.dump({"atoms": {k: v for k, v in h.A.items()}, "bonds": [sorted(e) for e in h.B], "pent": si}, open("dna_dAMP.json", "w"))

# dna_z5.py  Z[φ] の正四面体の複合で、36°・72° の回転と照合が成り立つかを検定する（厳密な代数、浮動小数なし）
# 数は a + bφ（a, b は有理数、φ² = φ + 1）で持つ。Z[φ] に入るとは a, b がともに整数であること。
#
# 座標：v296 §3.5 の記述から組む。正十二面体の 20 頂点 (±φ,±φ,±φ)・(0,±1,±φ²)・(±1,±φ²,0)・(±φ²,0,±1)。
#   v296 の記述と同じかどうかを段階 1 で照合する：
#     辺² 8φ² の正四面体が 10 個／頂点を分け合わない 5 個の組が 2 組（鏡像）／
#     12 面すべてで正五角形の 5 頂点が 5 つの別々の正四面体から来る／
#     組 1 と組 2 の正四面体が一つずつ組になって立方体（辺² 4φ² が 12、面の対角線² 8φ² が 12、体の対角線² 12φ² が 4）
#   どれか一つでも合わなければ、v296 の座標とは別物として止める。
#
# 事前基準：
#   段階 1：上の 4 項目がすべて一致し、20 頂点がすべて Z[φ] で書ける。
#   段階 2：5 回軸 n = (0, 1, φ²) のまわりの 72°・36° の回転行列を、ロドリゲスの式で厳密に作る。
#           sin θ/|n| が Q(φ) に入らなければ「作れない」と返す（入るかは、その二乗のノルムが有理数の平方かで判定）。
#           作れたら、行列の成分の分母と、20 頂点に作用させた像が Z[φ] に入るかを返す。
#   段階 3：R36 を 10 回、R72 を 5 回かけると恒等に厳密に戻る。
#   段階 4：R72・R36 が 20 頂点の集合を保つか、10 個の正四面体をどう移すか（組 1・組 2 の中で回すか、組を入れ替えるか、外へ出すか）。
#   負の対照：
#     (a) 5 回軸でない軸（z 軸）のまわりの 36° は、段階 2 で「作れない」と返すこと
#     (b) 3 回軸 (1,1,1) のまわりの 120° は作れて、20 頂点を保つこと（正の対照：判定が OK を返せる）
#     (c) 2 回軸のまわりの 72° は作れても、20 頂点を保たないこと
from fractions import Fraction as F
from itertools import combinations, product

class Q:
    __slots__ = ("a", "b")
    def __init__(s, a=0, b=0): s.a = F(a); s.b = F(b)
    def __add__(s, o): o = cv(o); return Q(s.a + o.a, s.b + o.b)
    __radd__ = __add__
    def __neg__(s): return Q(-s.a, -s.b)
    def __sub__(s, o): return s + (-cv(o))
    def __rsub__(s, o): return cv(o) - s
    def __mul__(s, o):
        o = cv(o)   # (a+bφ)(c+dφ) = ac + bd + (ad + bc + bd)φ
        return Q(s.a*o.a + s.b*o.b, s.a*o.b + s.b*o.a + s.b*o.b)
    __rmul__ = __mul__
    def conj(s): return Q(s.a + s.b, -s.b)        # φ → 1 − φ
    def norm(s): n = s * s.conj(); assert n.b == 0; return n.a
    def inv(s): n = s.norm(); c = s.conj(); return Q(c.a / n, c.b / n)
    def __truediv__(s, o): return s * cv(o).inv()
    def __eq__(s, o): o = cv(o); return s.a == o.a and s.b == o.b
    def __hash__(s): return hash((s.a, s.b))
    def isZ(s): return s.a.denominator == 1 and s.b.denominator == 1
    def den(s): from math import lcm; return lcm(s.a.denominator, s.b.denominator)
    def __repr__(s):
        if s.b == 0: return f"{s.a}"
        return f"({s.a}{'+' if s.b >= 0 else '-'}{abs(s.b)}φ)"
def cv(x): return x if isinstance(x, Q) else Q(x)
PHI = Q(0, 1); P2 = PHI * PHI
def vsub(u, v): return tuple(x - y for x, y in zip(u, v))
def vdot(u, v): return u[0]*v[0] + u[1]*v[1] + u[2]*v[2]
def vcross(u, v): return (u[1]*v[2] - u[2]*v[1], u[2]*v[0] - u[0]*v[2], u[0]*v[1] - u[1]*v[0])
def mmul(A, B): return tuple(tuple(sum((A[i][k] * B[k][j] for k in range(3)), Q()) for j in range(3)) for i in range(3))
def mvec(A, v): return tuple(sum((A[i][k] * v[k] for k in range(3)), Q()) for i in range(3))
I3 = tuple(tuple(Q(1 if i == j else 0) for j in range(3)) for i in range(3))
def is_rat_square(r):
    r = F(r)
    if r < 0: return False
    from math import isqrt
    n, d = r.numerator, r.denominator
    return isqrt(n) ** 2 == n and isqrt(d) ** 2 == d
def sqrt_in_Qphi(x):
    """x = s² となる s ∈ Q(φ) を返す（無ければ None）。s = p + qφ とおいて p, q を有理数で解く"""
    if not is_rat_square(x.norm()) or x.norm() < 0: return None
    # s² = p² + q² + (2pq + q²)φ = x.a + x.b φ。ノルムの平方根 m = ±(p² + pq − q²) を使って二次に落とす
    from math import isqrt
    nr = x.norm(); m0 = F(isqrt(nr.numerator), isqrt(nr.denominator))
    for m in (m0, -m0):
        # p² + q² = a, 2pq + q² = b, p² + pq − q² = m  →  (a + m) = 2p² + pq, 2q²... 解は有限個なので素直に解く
        # q² の満たす式：5q⁴ − (2b + ... ) を避け、p = (a + m − ... ) の代わりに数値を使わず二次方程式で解く
        # 2p² + pq = a + m かつ 2pq + q² = b から、q ≠ 0 のとき p = (b − q²)/(2q)
        # 代入：2(b − q²)²/(4q²) + (b − q²)/2 = a + m  →  (b − q²)² + q²(b − q²) = 2q²(a + m)
        #      → b² − b q² − 2(a + m) q² = 0 → q² = b² / (b + 2(a + m))
        den = x.b + 2 * (x.a + m)
        cands = []
        if den != 0:
            t = F(x.b) ** 2 / den
            if is_rat_square(t):
                from math import isqrt as S
                q = F(S(t.numerator), S(t.denominator))
                for qq in (q, -q):
                    if qq != 0: cands.append(Q((x.b - qq*qq) / (2*qq), qq))
        if x.b == 0:   # q = 0 のとき p² = a
            if is_rat_square(x.a): cands.append(Q(F(isqrt(F(x.a).numerator), isqrt(F(x.a).denominator)), 0))
        for s in cands:
            if s * s == x: return s
    return None
def rodrigues(n, cos_t, sin2_t):
    """軸 n（Q(φ) の成分）、cos θ、sin² θ から回転行列。sin θ/|n| が Q(φ) に無ければ None"""
    nn = vdot(n, n)
    s = sqrt_in_Qphi(cv(sin2_t) / nn)
    if s is None: return None
    c = cv(cos_t); k = (1 - c) / nn
    K = ((Q(), -n[2], n[1]), (n[2], Q(), -n[0]), (-n[1], n[0], Q()))
    return tuple(tuple((c if i == j else Q()) + s * K[i][j] + k * n[i] * n[j] for j in range(3)) for i in range(3))

print("段階 1：座標の照合（v296 §3.5 の記述）")
pm = (1, -1)
V = [tuple(Q(0, x) for x in (a, b, c)) for a, b, c in product(pm, pm, pm)]
for i in range(3):
    for s1, s2 in product(pm, pm):
        v = [Q(), Q(), Q()]; v[(i + 1) % 3] = Q(s1); v[(i + 2) % 3] = s2 * P2; V.append(tuple(v))
print("   頂点", len(V), " すべて Z[φ]：", all(x.isZ() for v in V for x in v))
d2 = lambda u, w: vdot(vsub(u, w), vsub(u, w))
E8 = 8 * P2
tets = [T for T in combinations(range(20), 4) if all(d2(V[i], V[j]) == E8 for i, j in combinations(T, 2))]
print("   辺² 8φ² の正四面体：", len(tets))
disj = [S for S in combinations(range(len(tets)), 5) if len(set().union(*[set(tets[t]) for t in S])) == 20]
print("   頂点を分け合わない 5 個の組：", len(disj))
# 正十二面体の辺（辺² = 4，座標では (2/φ)²·φ²… 最短の距離で取る）
dists = sorted({(d2(V[i], V[j]).a, d2(V[i], V[j]).b) for i, j in combinations(range(20), 2)})
emin = min((d2(V[i], V[j]) for i, j in combinations(range(20), 2)), key=lambda q: float(q.a) + float(q.b) * 1.618)  # 最短を選ぶための並べ替えだけ
adj = {i: [j for j in range(20) if j != i and d2(V[i], V[j]) == emin] for i in range(20)}
faces = set()
for i in range(20):
    for j in adj[i]:
        for k in adj[j]:
            if k == i: continue
            for l in adj[k]:
                if l in (i, j): continue
                for m in adj[l]:
                    if m in (i, j, k) or i not in adj[m]: continue
                    faces.add(frozenset((i, j, k, l, m)))
tet_of = [{v: ti for ti in S for v in tets[ti]} for S in disj]
ok_face = all(len({tet_of[0][v] for v in f}) == 5 for f in faces)
print("   正十二面体の面：", len(faces), " どの面も 5 頂点が 5 つの別々の正四面体から（組 1）：", ok_face)
cube_ok = 0
for a in disj[0]:
    for b in disj[1]:
        W = set(tets[a]) | set(tets[b])
        if len(W) != 8: continue
        c = {}
        for i, j in combinations(sorted(W), 2):
            k = d2(V[i], V[j]); c[k] = c.get(k, 0) + 1
        if c == {4 * P2: 12, 8 * P2: 12, 12 * P2: 4}: cube_ok += 1
print("   組 1 と組 2 の正四面体が立方体（辺² 4φ² 12・面の対角線² 8φ² 12・体の対角線² 12φ² 4）になる組：", cube_ok, "（v296 では 5）")
ok1 = len(V) == 20 and len(tets) == 10 and len(disj) == 2 and len(faces) == 12 and ok_face and cube_ok == 5
print("   段階 1：", "合格（v296 の記述と一致）" if ok1 else "NG")

print("\n段階 2：回転を厳密に作る")
cos72 = (PHI - 1) / 2; sin2_72 = 1 - cos72 * cos72
cos36 = PHI / 2;       sin2_36 = 1 - cos36 * cos36
f0 = sorted(faces, key=lambda f: sorted(f))[0]
n5 = tuple(sum((V[i][k] for i in f0), Q()) for k in range(3))   # 5 回軸：面の 5 頂点の和（中心×5）の向き
print("   5 回軸（面の 5 頂点の和）：", n5)
def show(name, R):
    if R is None: print(f"   {name}：作れない（sin θ/|n| が Q(φ) に無い）"); return
    den = max(x.den() for row in R for x in row)
    img = [mvec(R, v) for v in V]
    print(f"   {name}：作れた  成分の分母の最大 {den}  成分がすべて Z[φ]：{all(x.isZ() for row in R for x in row)}"
          f"  20 頂点の像がすべて Z[φ]：{all(x.isZ() for v in img for x in v)}")
R72 = rodrigues(n5, cos72, sin2_72); show("R72（5 回軸）", R72)
R36 = rodrigues(n5, cos36, sin2_36); show("R36（5 回軸）", R36)
Rz36 = rodrigues((Q(), Q(), Q(1)), cos36, sin2_36); show("負の対照 (a) z 軸まわりの 36°", Rz36)
R120 = rodrigues((Q(1), Q(1), Q(1)), Q(F(-1, 2)), Q(F(3, 4))); show("正の対照 (b) (1,1,1) まわりの 120°", R120)
R2_72 = rodrigues((Q(), Q(), Q(1)), cos72, sin2_72); show("負の対照 (c) 2 回軸 z まわりの 72°", R2_72)
if R72 is not None:
    print("   R36² = R72：", mmul(R36, R36) == R72 if R36 else "—")

print("\n段階 3：恒等に戻るか")
def power(R, k):
    X = I3
    for _ in range(k): X = mmul(X, R)
    return X
for name, R, k in (("R36", R36, 10), ("R72", R72, 5), ("R36（5 回で止める：負の対照）", R36, 5)):
    if R is None: print(f"   {name}：作れていない"); continue
    print(f"   {name} を {k} 回：恒等 {power(R, k) == I3}")

print("\n段階 4：20 頂点と 10 個の正四面体を保つか")
Vset = set(V); Vidx = {v: i for i, v in enumerate(V)}
def act(name, R):
    if R is None: print(f"   {name}：作れていない"); return
    img = [mvec(R, v) for v in V]
    keep = all(v in Vset for v in img)
    msg = f"   {name}：20 頂点を保つ {keep}"
    if keep:
        perm = [Vidx[v] for v in img]
        tset = {frozenset(T): ti for ti, T in enumerate(tets)}
        tp = [tset.get(frozenset(perm[i] for i in T)) for T in tets]
        grp = {ti: g for g, S in enumerate(disj) for ti in S}
        moves = [(grp[a], grp[b]) for a, b in enumerate(tp)]
        same = all(g0 == g1 for g0, g1 in moves); swap = all(g0 != g1 for g0, g1 in moves)
        msg += f"  正四面体の行き先 {tp}  組の中で回す {same}  組を入れ替える {swap}"
    else:
        on = sum(v in Vset for v in img)
        neg = [tuple(-x for x in v) for v in img]
        msg += f"（像のうち 20 頂点に乗るもの {on}）  像の符号を反転すると 20 頂点に乗る {all(v in Vset for v in neg)}"
    print(msg)
act("R72", R72); act("R36", R36); act("正の対照 (b) 120°", R120); act("負の対照 (c) 2 回軸の 72°", R2_72)

print("\n段階 2・4 の続き：R36 の像はどの整数の網に乗るか、元の 20 頂点と何を分け合うか")
R72i = power(R72, 4)
print("   R36² が R72 か R72⁻¹ か：", "R72" if mmul(R36, R36) == R72 else "R72⁻¹（向きが逆）" if mmul(R36, R36) == R72i else "どちらでもない")
SQ5 = 2 * PHI - 1   # √5 ＝ 2φ − 1（Z[φ] の元）
imgs = {k: [mvec(power(R36, k), v) for v in V] for k in range(10)}
for name, m in (("1", Q(1)), ("2", Q(2)), ("√5", SQ5), ("2√5", 2 * SQ5), ("5", Q(5)), ("10", Q(10))):
    ok = all((m * x).isZ() for k in imgs for v in imgs[k] for x in v)
    print(f"   R36 の 0〜9 乗の像を {name} 倍すると、すべて Z[φ]：{ok}")
odd = {v for k in (1, 3, 5, 7, 9) for v in imgs[k]}
even = {v for k in (0, 2, 4, 6, 8) for v in imgs[k]}
print("   偶数乗の像の集まり＝元の 20 頂点：", even == Vset, "  奇数乗の像の集まりの頂点数：", len(odd), "  元の 20 頂点と分け合う頂点：", len(odd & Vset))
tetsR = [frozenset(mvec(R36, V[i]) for i in T) for T in tets]
sh = [(a, b, len(set(V[i] for i in tets[a]) & tetsR[b])) for a in range(10) for b in range(10)]
from collections import Counter
print("   元の正四面体と R36 で回した正四面体が分け合う頂点の数の分布：", dict(Counter(x[2] for x in sh)))

"""
fullerene_transform.py
======================
フラーレン座標変換モジュール — B13位相セルオートマトンの対称性による信号解析。

理論的背景 (v79確立):
  切断20面体の対称性群:
    Z₅  (ペンタゴン) : STEP_Z5  = BASE/5  = 624
    Z₁₃ (B13核)     : STEP_Z13 = BASE/13 = 240
    Z₅ × Z₁₃ ≅ Z₆₅  (gcd(5,13)=1 より)

  信号の基音f₀の倍音列はZ₆₅の65点格子上を周回する。
  軌道サイズ = 65 / gcd(f₀ % 65, 65) によって共鳴クラスが確定。

共鳴分類:
  gcd(f₀, 65) = 1  → 完全共鳴   (full)     軌道65点
  gcd(f₀, 65) = 5  → Pentagon共鳴 (pentagon) 軌道13点
  gcd(f₀, 65) = 13 → Z₁₃共鳴   (z13)      軌道 5点
  gcd(f₀, 65) = 65 → 直流       (dc)       軌道 1点

4H回避との接続 (核57):
  Fib/Pellドライブは4H帯を完全回避
  → アトラクタはH/2H帯の倍音にのみ自然共鳴
  → 4H帯の倍音は構造的にフィルタされる

検証済み (2026-03-27, テストデータ):
  - 3クラスの完全分離 (Z₅節点比・Z₁₃節点比による判定)
  - ビブラート検出: Z₅節点比の低下量がビブラート深さの代数的指標
  - 浮動小数点演算ゼロ (完全整数演算)
  - S/N比 10¹²
"""
from __future__ import annotations

import math
from typing import List, Tuple, Dict

from .constants import BASE
from .level0_table import COS_TABLE, SIN_TABLE

# Z₅×Z₁₃ スペクトル型: spectrum[m5][m13] = (cx, cy)
Spectrum = List[List[Tuple[int, int]]]


# ─────────────────────────────────────────────────────────
# 基礎演算
# ─────────────────────────────────────────────────────────

def winding_int(signal: List[int], w: int) -> Tuple[int, int]:
    """
    整数演算による周波数wの巻き取り。
    浮動小数点演算ゼロ、Python任意精度整数。

    Args:
        signal: 整数値の信号列（BASEスケール推奨）
        w:      巻き付け周波数（整数）

    Returns:
        (cx, cy): 重心の実部・虚部（整数）

    S/N比: 10¹²（SIN_TABLEの丸め誤差由来のノイズ比）
    """
    cx, cy = 0, 0
    for k, s in enumerate(signal):
        p = (w * k) % BASE
        cx += s * COS_TABLE[p]
        cy += s * SIN_TABLE[p]
    return cx, cy


def mag_sq(cx: int, cy: int) -> int:
    """|重心|² — 完全整数。比較・ランキングに使用。"""
    return cx * cx + cy * cy


# ─────────────────────────────────────────────────────────
# フラーレン共鳴条件
# ─────────────────────────────────────────────────────────

def resonance_orbit_size(f0: int) -> int:
    """
    基音f₀の Z₅×Z₁₃ 軌道サイズを返す。
    軌道サイズ = 65 / gcd(f₀ % 65, 65)
    """
    g = math.gcd(f0 % 65, 65)
    return 65 // g


def resonance_label(f0: int) -> str:
    """
    基音f₀の共鳴クラスラベルを返す。

    Returns:
        'full'     : 完全共鳴 (gcd=1,  軌道65点)
        'pentagon' : Pentagon共鳴 (gcd=5,  軌道13点)
        'z13'      : Z₁₃共鳴 (gcd=13, 軌道5点)
        'dc'       : 直流     (gcd=65, 軌道1点)
    """
    g = math.gcd(f0 % 65, 65)
    if g == 1:  return 'full'
    if g == 5:  return 'pentagon'
    if g == 13: return 'z13'
    return 'dc'


def fullerene_coords(f0: int) -> Dict:
    """
    基音f₀のフラーレン座標情報を返す。

    Returns: dict with keys:
        f0, z5, z13, coset, resonance_class, orbit_size, harmonics
    """
    from .constants import H_SET, H2_SET

    def _coset(v):
        c = v % 13
        if c == 0:        return '0'
        if c in H_SET:    return 'H'
        if c in H2_SET:   return '2H'
        return '4H'

    harmonics = []
    for n in range(1, 14):
        nf0 = (n * f0) % BASE
        coset = _coset(nf0)
        harmonics.append({
            'n':         n,
            'z5':        nf0 % 5,
            'z13':       nf0 % 13,
            'coset':     coset,
            'fib_reach': coset != '4H',
        })

    return {
        'f0':              f0,
        'z5':              f0 % 5,
        'z13':             f0 % 13,
        'coset':           _coset(f0),
        'resonance_class': resonance_label(f0),
        'orbit_size':      resonance_orbit_size(f0),
        'harmonics':       harmonics,
    }


# ─────────────────────────────────────────────────────────
# フラーレン座標変換（メイン関数）
# ─────────────────────────────────────────────────────────

def signal_to_fullerene(
    signal: List[int],
    max_harmonics: int = 13,
) -> Spectrum:
    """
    任意の整数信号を Z₅×Z₁₃ の65点フラーレン座標に変換。

    手順:
      1. 各倍音 w=1..max_harmonics を整数巻き取りで抽出 → (cx, cy)
      2. (w%5, w%13) の2次元格子に配置
      3. Z₆₅ スペクトルを生成

    Args:
        signal:        整数値の信号列
        max_harmonics: 展開する倍音数（デフォルト13=Z₁₃の1周期）

    Returns:
        spectrum[m5][m13] = (cx, cy)  完全整数
        m5  ∈ {0,1,2,3,4}    (Z₅座標)
        m13 ∈ {0,1,...,12}   (Z₁₃座標)

    Note:
        max_harmonics=13 で Z₁₃の1周期を網羅。
        倍音が多い信号（楽器・電磁波）は max_harmonics=65 推奨。
    """
    spectrum: Spectrum = [[(0, 0) for _ in range(13)] for _ in range(5)]

    for w in range(1, max_harmonics + 1):
        cx, cy = winding_int(signal, w)
        m5, m13 = w % 5, w % 13
        old_cx, old_cy = spectrum[m5][m13]
        spectrum[m5][m13] = (old_cx + cx, old_cy + cy)

    return spectrum


def resonance_class(spectrum: Spectrum, max_harmonics: int = 13) -> Dict:
    """
    フラーレンスペクトルから共鳴クラス指標を計算。

    z5_excess 方式（v80確立）:
        z5_background = (max_harmonics // 5) / max_harmonics  # 均等分布時の期待値
        z5_excess     = z5_node_ratio - z5_background

        z5_excess > +0.70 → Pentagon共鳴
        z5_excess < -0.05 かつ z13_excess < -0.05 → 完全共鳴
        それ以外 → 混合

    ⚠️ max_harmonics を必ず渡すこと:
        mh=13 のとき Z5=0行の期待値 = 2/13 ≈ 0.154 (旧閾値0.1 を超える)
        → max_harmonics 不一致だと full が mixed に誤判定される

    Args:
        spectrum:       signal_to_fullerene() の出力
        max_harmonics:  signal_to_fullerene() に渡した値と同一であること

    Returns: dict with keys:
        z5_node_ratio:  Z₅=0行の強度比（生の値）
        z13_node_ratio: Z₁₃=0列の強度比（生の値）
        z5_excess:      z5_node_ratio - 均等分布期待値（判定に使用）
        z13_excess:     z13_node_ratio - 均等分布期待値
        z5_bg:          Z₅=0行の均等分布期待値
        z13_bg:         Z₁₃=0列の均等分布期待値
        total:          全格子点の|重心|²合計
        label:          推定共鳴クラス ('full'/'pentagon'/'z13'/'mixed'/'zero')

    検証済み閾値（v80, 実データC6 4楽器で確認）:
        THRESH_POS = +0.70  （pentagon/z13判定）
        THRESH_NEG = -0.05  （full判定）
    """
    z5_0  = sum(mag_sq(*spectrum[0][m13]) for m13 in range(13))
    z13_0 = sum(mag_sq(*spectrum[m5][0])  for m5  in range(5))
    total = sum(mag_sq(*spectrum[m5][m13])
                for m5 in range(5) for m13 in range(13))

    if total == 0:
        return {'z5_node_ratio': 0.0, 'z13_node_ratio': 0.0,
                'z5_excess': 0.0, 'z13_excess': 0.0,
                'z5_bg': 0.0, 'z13_bg': 0.0,
                'total': 0, 'label': 'zero'}

    z5_r  = z5_0  / total
    z13_r = z13_0 / total

    # 均等分布時の期待値（max_harmonics依存）
    mh = max_harmonics
    z5_bg  = (mh // 5)  / mh
    z13_bg = (mh // 13) / mh

    z5_excess  = z5_r  - z5_bg
    z13_excess = z13_r - z13_bg

    THRESH_POS = 0.70
    THRESH_NEG = -0.05

    if z5_excess > THRESH_POS:
        label = 'pentagon'
    elif z13_excess > THRESH_POS:
        label = 'z13'
    elif z5_excess < THRESH_NEG and z13_excess < THRESH_NEG:
        label = 'full'
    else:
        label = 'mixed'

    return {
        'z5_node_ratio':  z5_r,
        'z13_node_ratio': z13_r,
        'z5_excess':      z5_excess,
        'z13_excess':     z13_excess,
        'z5_bg':          z5_bg,
        'z13_bg':         z13_bg,
        'total':          total,
        'label':          label,
    }

def spectrum_intensity(spectrum: Spectrum) -> List[List[int]]:
    """スペクトルを |重心|² の2次元リストに変換（表示用）。"""
    return [[mag_sq(*spectrum[m5][m13])
             for m13 in range(13)]
            for m5 in range(5)]


# ─────────────────────────────────────────────────────────
# 時系列フレーム分析
# ─────────────────────────────────────────────────────────

def analyze_timeseries(
    signal: List[int],
    frame_size: int = BASE,
    hop_size: int = None,
    max_harmonics: int = 13,
) -> List[Dict]:
    """
    信号を時系列フレームに分割し、各フレームのフラーレン解析を記録。

    フレームごとに spectrum・resonance_class・intensity_map を全記録し、
    後から任意の切り口で分析できる。

    ⚠️  frame_size の設計原則（v80確立）:
        frame_size >= 信号の1周期長 が必須条件。
        frame_size が1周期未満だと位相が完結せず、resonance_classが崩壊する。

        - frame_size = BASE = 3120  : 確実（全周波数に対して1周期以上を保証）
        - frame_size = 信号の周期長 : 既知の場合に最小コストで正確
        - frame_size < 1周期        : 判定崩壊（使用禁止）

        デフォルト = BASE（安全側）。実データで周期が既知なら周期長を指定。

    Args:
        signal:        整数値の信号列
        frame_size:    1フレームのサンプル数（デフォルト BASE=3120）
        hop_size:      フレーム間隔（Noneの場合 = frame_size、重複なし）
        max_harmonics: 巻き取り倍音数（デフォルト13）

    Returns:
        List of FrameRecord dicts:
            frame_idx:       フレーム番号 (0-origin)
            start:           開始サンプルインデックス
            end:             終了サンプルインデックス（exclusive）
            spectrum:        Spectrum (5×13, 完全整数)
            resonance:       resonance_class() の出力
            intensity_map:   List[List[int]] — 5×13 の |重心|²
            total_power:     全格子点パワー合計
            dominant_cell:   最大パワーの (m5, m13)
    """
    if hop_size is None:
        hop_size = frame_size

    n = len(signal)
    frames = []
    idx = 0
    frame_idx = 0

    while idx + frame_size <= n:
        frame = signal[idx: idx + frame_size]
        sp = signal_to_fullerene(frame, max_harmonics=max_harmonics)
        rc = resonance_class(sp, max_harmonics=max_harmonics)
        imap = spectrum_intensity(sp)

        # 最大パワーのセルを探す
        max_pow = -1
        dom_cell = (0, 0)
        for m5 in range(5):
            for m13 in range(13):
                p = imap[m5][m13]
                if p > max_pow:
                    max_pow = p
                    dom_cell = (m5, m13)

        frames.append({
            'frame_idx':    frame_idx,
            'start':        idx,
            'end':          idx + frame_size,
            'spectrum':     sp,
            'resonance':    rc,
            'intensity_map': imap,
            'total_power':  rc['total'],
            'dominant_cell': dom_cell,
        })

        idx += hop_size
        frame_idx += 1

    return frames


def timeseries_summary(frames: List[Dict]) -> Dict:
    """
    analyze_timeseries() の出力を集計。

    Returns: dict with keys:
        n_frames:           総フレーム数
        label_counts:       各共鳴クラスの出現回数
        label_sequence:     フレーム順のラベル列
        z5_ratio_series:    Z₅節点比の時系列
        z13_ratio_series:   Z₁₃節点比の時系列
        power_series:       全パワーの時系列
        dominant_cell_series: 支配セル (m5,m13) の時系列
        transitions:        ラベル遷移リスト [(from, to, frame_idx), ...]
    """
    if not frames:
        return {}

    labels   = [f['resonance']['label']         for f in frames]
    z5_ser   = [f['resonance']['z5_node_ratio']  for f in frames]
    z13_ser  = [f['resonance']['z13_node_ratio'] for f in frames]
    pow_ser  = [f['total_power']                 for f in frames]
    dom_ser  = [f['dominant_cell']               for f in frames]

    label_counts: Dict[str, int] = {}
    for lb in labels:
        label_counts[lb] = label_counts.get(lb, 0) + 1

    transitions = []
    for i in range(1, len(labels)):
        if labels[i] != labels[i - 1]:
            transitions.append((labels[i - 1], labels[i], i))

    return {
        'n_frames':            len(frames),
        'label_counts':        label_counts,
        'label_sequence':      labels,
        'z5_ratio_series':     z5_ser,
        'z13_ratio_series':    z13_ser,
        'power_series':        pow_ser,
        'dominant_cell_series': dom_ser,
        'transitions':         transitions,
    }


def spectrum_subtract(sp_a: Spectrum, sp_b: Spectrum) -> Spectrum:
    """
    2つのスペクトルの差分 sp_a - sp_b を返す（格子点ごとの (cx,cy) 差）。

    用途: フレーム間の変化量、ベースラインとの差など。
    完全整数演算。
    """
    return [
        [(sp_a[m5][m13][0] - sp_b[m5][m13][0],
          sp_a[m5][m13][1] - sp_b[m5][m13][1])
         for m13 in range(13)]
        for m5 in range(5)
    ]


def spectrum_add(sp_a: Spectrum, sp_b: Spectrum) -> Spectrum:
    """2つのスペクトルの和 sp_a + sp_b（格子点ごとの (cx,cy) 和）。"""
    return [
        [(sp_a[m5][m13][0] + sp_b[m5][m13][0],
          sp_a[m5][m13][1] + sp_b[m5][m13][1])
         for m13 in range(13)]
        for m5 in range(5)
    ]



# ─────────────────────────────────────────────────────────
# 成分分離ユーティリティ（v80確立）
# ─────────────────────────────────────────────────────────

def spectrum_mask_z5(spectrum: Spectrum) -> Spectrum:
    """
    Z₅=0行のみ残す（pentagon成分抽出）。

    sp_pentagon = spectrum_mask_z5(sp)
    sp_residual = spectrum_subtract(sp, sp_pentagon)
    → sp_residual の Z₅=0行パワーは完全ゼロ（残留なし、v80実データで確認）

    用途: pentagon成分を単離して分析、またはpentagonを除去してfull/z13を見る
    """
    return [
        [(spectrum[m5][m13] if m5 == 0 else (0, 0)) for m13 in range(13)]
        for m5 in range(5)
    ]


def spectrum_mask_z13(spectrum: Spectrum) -> Spectrum:
    """
    Z₁₃=0列のみ残す（z13成分抽出）。

    sp_z13      = spectrum_mask_z13(sp)
    sp_residual = spectrum_subtract(sp, sp_z13)
    → sp_residual の Z₁₃=0列パワーは完全ゼロ（残留なし、v80実データで確認）

    用途: z13成分を単離、またはz13を除去してfull/pentagonを見る
    """
    return [
        [(spectrum[m5][m13] if m13 == 0 else (0, 0)) for m13 in range(13)]
        for m5 in range(5)
    ]


def spectrum_decompose(spectrum: Spectrum) -> Dict:
    """
    スペクトルをpentagon / z13 / full / dc の4成分に分解。

    各成分のパワーと比率を返す。成分の和 = 元スペクトルのパワー（完全分割）。

    Returns: dict with keys:
        pentagon:  Z₅=0行（Z₁₃≠0）のパワー
        z13:       Z₁₃=0列（Z₅≠0）のパワー
        dc:        (m5=0, m13=0) セルのパワー
        full:      Z₅≠0 かつ Z₁₃≠0 のパワー（主要成分）
        total:     全パワー
        pentagon_ratio, z13_ratio, dc_ratio, full_ratio: 各比率
    """
    dc   = mag_sq(*spectrum[0][0])
    pent = sum(mag_sq(*spectrum[0][m13]) for m13 in range(1, 13))  # Z5=0, Z13≠0
    z13  = sum(mag_sq(*spectrum[m5][0])  for m5  in range(1, 5))   # Z13=0, Z5≠0
    full = sum(mag_sq(*spectrum[m5][m13])
               for m5 in range(1, 5) for m13 in range(1, 13))

    total = dc + pent + z13 + full
    if total == 0:
        return {'pentagon': 0, 'z13': 0, 'dc': 0, 'full': 0, 'total': 0,
                'pentagon_ratio': 0.0, 'z13_ratio': 0.0,
                'dc_ratio': 0.0, 'full_ratio': 0.0}
    return {
        'pentagon': pent,  'z13': z13,  'dc': dc,  'full': full,
        'total':    total,
        'pentagon_ratio': pent / total,
        'z13_ratio':      z13  / total,
        'dc_ratio':       dc   / total,
        'full_ratio':     full / total,
    }

def vibrato_depth(spectrum_pure: Spectrum, spectrum_vibrato: Spectrum) -> float:
    """
    ビブラート深さを Z₅節点比の低下量として返す。

    Args:
        spectrum_pure:    純音のスペクトル
        spectrum_vibrato: ビブラート信号のスペクトル

    Returns:
        低下量 (0.0〜1.0)。大きいほどビブラートが深い。
    """
    rc_pure = resonance_class(spectrum_pure)
    rc_vib  = resonance_class(spectrum_vibrato)
    return rc_pure['z5_node_ratio'] - rc_vib['z5_node_ratio']

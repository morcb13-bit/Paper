"""
great_circle.py
===============
Great circle analysis for truncated icosahedron in B13 framework.

v64確定の正しい大円構造 (核22-28):
  1周 = 4頂点(対角線端点) + 10辺横断
  弧の配列 (半周): 頂点 → θ₃₁ → θ₂₁ → θ₁₈ → θ₁₈ → θ₂₁ → θ₃₁ → 頂点
  1周 = 2×θ_diag + 4×θ₃₁ + 4×θ₂₁ + 4×θ₁₈ = 360° 厳密 (核23)

φ-算術 (a=2系, R²=9φ+10):
  cos θ_diag = (8+7φ)/(9φ+10)       [対角線頂点間, 核24]
  cos θ_e    = (9φ+8)/(9φ+10)       [辺弧, 核26]
  sin θ_e    = 6φ/R²                 [辺弧sin, 核34]
  cos²θ₃₁   = (16849φ+10489)/(23185φ+14413)  [核27]
  cos²θ₁₈   = (203φ+170)/(228φ+187) [核27]

辺横断パラメータ (核25):
  t₁₈ = 1/2,  t₂₁ = 2/(3φ),  t₃₁ = 3φ/(4φ+3)

分母:
  109 = 8×F(7)+F(5) = 8×13+5

旧モデル (1.41%誤差) との違い:
  旧: 2θ_a + 4θ_h5 + 4θ_h6  (h5=pentagon高さ, h6=hexagon高さ)
  新: 2θ_diag + 4θ₃₁ + 4θ₂₁ + 4θ₁₈  (大円の真の弧構成)
"""

from __future__ import annotations
import math
from typing import Tuple, Dict
from .constants import BASE

PHI: float = (1.0 + math.sqrt(5.0)) / 2.0

# a=2系の外接球半径²
R_SQ_A2: float = 9.0 * PHI + 10.0          # 核: R²=9φ+10
R_A2:    float = math.sqrt(R_SQ_A2)

# a=1系 (コード内部)
R_SQ: float = R_SQ_A2 / 4.0
R:    float = math.sqrt(R_SQ)

# 有理化分母
DENOM: int = 109   # = 8×F(7)+F(5)


# ─────────────────────────────────────────────
# φ算術: cos値 (a=2系, R²=9φ+10)
# ─────────────────────────────────────────────

def cos_theta_diag_phi() -> Tuple[int, int]:
    """
    cos θ_diag = (8+7φ)/(9φ+10)  [対角線頂点間弧, 核24]
    Returns (rational_part, phi_coeff) for numerator over (9φ+10).
    """
    return (8, 7)

def cos_theta_e_phi() -> Tuple[int, int]:
    """
    cos θ_e = (9φ+8)/(9φ+10)  [辺弧, 核26]
    Returns (rational_part, phi_coeff) for numerator over (9φ+10).
    """
    return (8, 9)

def sin_theta_e_phi() -> Tuple[int, int]:
    """
    sin θ_e = 6φ/(9φ+10)  [辺弧sin, 核34]
    分子 = 6φ = 0+6φ
    Returns (rational_part, phi_coeff).
    """
    return (0, 6)

def cos2_theta_31_phi() -> Tuple[Tuple[int,int], Tuple[int,int]]:
    """
    cos²θ₃₁ = (16849φ+10489) / (23185φ+14413)  [核27]
    Returns (numerator, denominator) as (rat, phi_coeff) pairs.
    """
    return ((10489, 16849), (14413, 23185))

def cos2_theta_18_phi() -> Tuple[Tuple[int,int], Tuple[int,int]]:
    """
    cos²θ₁₈ = (203φ+170) / (228φ+187)  [核27]
    Returns (numerator, denominator) as (rat, phi_coeff) pairs.
    """
    return ((170, 203), (187, 228))


def cos2_theta_21_phi() -> Tuple[Tuple[int,int], Tuple[int,int]]:
    """
    cos²θ₂₁ = (106285+1965φ) / (182645−35575φ)  [核52]

    導出: cos²θ₂₁ = (cpB·cp42)² / (|cpB|²·|cp42|²)
      cpB  = (1−t_cpB)·A₃₁ + t_cpB·B₃₁,  t_cpB = 1−t₃₁
      cp42 = (1−t₂₁)·A₂₁  + t₂₁·B₂₁,    t₂₁  = 2/(3φ)
    全てZ[φ]整数演算 (φ²=φ+1 のみ使用)。

    数値: ≈ 0.87513132  → θ₂₁ ≈ 20.693°
    Returns (numerator, denominator) as (rat, phi_coeff) pairs.
    """
    return ((106285, 1965), (182645, -35575))


# ─────────────────────────────────────────────
# 核52: 辺端点・crossing点座標 (a=1系, edge=1)
# ─────────────────────────────────────────────
#
# Z[φ] 表記: 座標 = (r₀+p₀φ, r₁+p₁φ, r₂+p₂φ)
# 辺端点 (6点, a=1系):
#   A₃₁ = B₂₁ = (2, −1−2φ, φ)
#   B₃₁ =       (2+φ, −2φ, 1)
#   A₂₁ = A₁₈ = (1, −3φ, 0)
#   B₁₈ =       (−1, −3φ, 0)
#
# Crossing点 (3点):
#   cpB  = A₃₁ + t_cpB*(B₃₁−A₃₁),  t_cpB = 1−t₃₁
#   cp42 = A₂₁ + t₂₁*(B₂₁−A₂₁),   t₂₁  = 2/(3φ)
#   cp10 = (0, −3φ, 0) = A₁₈ + (1/2)*(B₁₈−A₁₈)

# 辺端点 Z[φ] 係数表: (rat, phi) 3成分
_EDGE_PTS_ZPH: dict = {
    # 名前: ((r0,p0), (r1,p1), (r2,p2))
    "A31": ((2, 0),  (-1, -2), (0,  1)),   # = B21
    "B31": ((2, 1),  ( 0, -2), (1,  0)),
    "A21": ((1, 0),  ( 0, -3), (0,  0)),   # = A18
    "B21": ((2, 0),  (-1, -2), (0,  1)),   # = A31
    "A18": ((1, 0),  ( 0, -3), (0,  0)),   # = A21
    "B18": ((-1, 0), ( 0, -3), (0,  0)),
}

# 辺端点間内積の完全表 [核52] (a=1系, R²=9φ+10 = (10,9))
# key: (pt1, pt2) の名前ペア, value: (rat, phi_coeff)
_INNER_PRODUCTS_ZPH: dict = {
    ("V",   "V"):   (10,  9),   # R² = 9φ+10  (全頂点)
    ("A",   "B"):   ( 8,  9),   # 9φ+8        (全辺)
    ("A31", "B21"): (10,  9),   # R² (A31=B21 同一頂点)
    ("B31", "A21"): ( 8,  7),   # 7φ+8
    ("A31", "B18"): ( 4,  9),   # 9φ+4
    ("B21", "B18"): ( 4,  9),   # 9φ+4
    ("B18", "B31"): ( 4,  5),   # 5φ+4
}


def edge_endpoint_zphi(name: str) -> Tuple[Tuple[int,int], Tuple[int,int], Tuple[int,int]]:
    """
    辺端点の Z[φ] 座標を返す (a=1系)。

    name: 'A31', 'B31', 'A21', 'B21', 'A18', 'B18'
    Returns: ((r0,p0), (r1,p1), (r2,p2)) where coord_i = r_i + p_i*φ
    """
    if name not in _EDGE_PTS_ZPH:
        raise KeyError(f"Unknown edge endpoint: {name}. "
                       f"Valid: {list(_EDGE_PTS_ZPH.keys())}")
    return _EDGE_PTS_ZPH[name]


def edge_endpoint_float(name: str) -> Tuple[float, float, float]:
    """辺端点を浮動小数点で返す (a=1系)。"""
    zph = edge_endpoint_zphi(name)
    return tuple(r + p * PHI for r, p in zph)


def inner_product_zphi(key: Tuple[str, str]) -> Tuple[int, int]:
    """
    辺端点間内積を Z[φ] 係数 (rat, phi_coeff) で返す [核52内積表]。

    key: ('A31','B21') など _INNER_PRODUCTS_ZPH のキー。
    Returns (r, p) such that inner_product = r + p*φ
    """
    if key not in _INNER_PRODUCTS_ZPH:
        raise KeyError(f"No entry for {key}. Valid: {list(_INNER_PRODUCTS_ZPH.keys())}")
    return _INNER_PRODUCTS_ZPH[key]


def crossing_points_float() -> Dict:
    """
    大円の crossing点座標を浮動小数点で返す (a=1系) [核52]。

    Returns dict:
      cpB  — θ₃₁辺の crossing点 (A₃₁→B₃₁, t=1−t₃₁)
      cp42 — θ₂₁辺の crossing点 (A₂₁→B₂₁, t=t₂₁)
      cp10 — θ₁₈辺の crossing点 (A₁₈→B₁₈, t=1/2)
    Each value: {'coords': (x,y,z), 't': float, 'edge': str}
    """
    A31 = edge_endpoint_float("A31")
    B31 = edge_endpoint_float("B31")
    A21 = edge_endpoint_float("A21")
    B21 = edge_endpoint_float("B21")
    A18 = edge_endpoint_float("A18")
    B18 = edge_endpoint_float("B18")

    t31  = 3.0 * PHI / (4.0 * PHI + 3.0)
    t21  = 2.0 / (3.0 * PHI)
    t_cpB = 1.0 - t31   # = (17−9φ)/5

    def lerp(P, Q, t):
        return tuple((1-t)*p + t*q for p, q in zip(P, Q))

    cpB  = lerp(A31, B31, t_cpB)
    cp42 = lerp(A21, B21, t21)
    cp10 = lerp(A18, B18, 0.5)

    return {
        "cpB":  {"coords": cpB,  "t": t_cpB, "edge": "A31→B31", "arc": "theta_31"},
        "cp42": {"coords": cp42, "t": t21,   "edge": "A21→B21", "arc": "theta_21"},
        "cp10": {"coords": cp10, "t": 0.5,   "edge": "A18→B18", "arc": "theta_18"},
    }


def crossing_inner_products_float() -> Dict:
    """
    連続する crossing点間の内積 (a=1系) [核52]。

    Returns dict with keys 'D1_cpB', 'cpB_cp42', 'cp42_cp10'.
    Values: {'inner': float, 'zphi_approx': str}
    """
    pts = crossing_points_float()
    cpB  = pts["cpB"]["coords"]
    cp42 = pts["cp42"]["coords"]
    cp10 = pts["cp10"]["coords"]

    def dot(u, v): return sum(a*b for a,b in zip(u,v))

    return {
        "cpB_cp42":  {
            "inner": dot(cpB, cp42),
            "zphi":  "(326+3φ)/15",
            "expected": (326 + 3*PHI) / 15,
            "match": abs(dot(cpB, cp42) - (326 + 3*PHI) / 15) < 1e-8,
        },
        "cp42_cp10": {
            "inner": dot(cp42, cp10),
            "zphi":  "11+7φ",
            "expected": 11 + 7*PHI,
            "match": abs(dot(cp42, cp10) - (11 + 7*PHI)) < 1e-8,
        },
    }


# ─────────────────────────────────────────────
# 数値計算
# ─────────────────────────────────────────────

def phi_value(rat: int, phi_coef: int) -> float:
    """rat + phi_coef × φ を浮動小数で返す。"""
    return rat + phi_coef * PHI


def _cos_from_phi_pair(num: Tuple[int,int], den: Tuple[int,int]) -> float:
    return phi_value(*num) / phi_value(*den)


def theta_diag_deg() -> float:
    """θ_diag を度数で返す。"""
    cos_d = phi_value(*cos_theta_diag_phi()) / R_SQ_A2
    return math.degrees(math.acos(max(-1.0, min(1.0, cos_d))))

def theta_31_deg() -> float:
    """θ₃₁ を度数で返す (cos²θ₃₁から)。"""
    cos2 = _cos_from_phi_pair(*cos2_theta_31_phi())
    return math.degrees(math.acos(math.sqrt(max(0.0, cos2))))

def theta_21_deg() -> float:
    """
    θ₂₁ を度数で返す (1周=360°の恒等式から)。
    θ₂₁ = (360° - 2θ_diag - 4θ₃₁ - 4θ₁₈) / 4
    """
    return (360.0 - 2*theta_diag_deg() - 4*theta_31_deg() - 4*theta_18_deg()) / 4.0

def theta_18_deg() -> float:
    """θ₁₈ を度数で返す (cos²θ₁₈から)。"""
    cos2 = _cos_from_phi_pair(*cos2_theta_18_phi())
    return math.degrees(math.acos(math.sqrt(max(0.0, cos2))))


# ─────────────────────────────────────────────
# 大円の完全構造 (核22-28)
# ─────────────────────────────────────────────

def great_circle_arcs() -> Dict:
    """
    大円の完全な弧構成を返す。

    1周 = 2×θ_diag + 4×θ₃₁ + 4×θ₂₁ + 4×θ₁₈ = 360° 厳密 (核23)

    半周の弧配列:
      頂点 → θ₃₁ → θ₂₁ → θ₁₈ → θ₁₈ → θ₂₁ → θ₃₁ → 頂点

    辺横断パラメータ (核25):
      θ₁₈: t=1/2        (辺中点)
      θ₂₁: t=2/(3φ)
      θ₃₁: t=3φ/(4φ+3)

    Returns dict with arc angles and sum verification.
    """
    td  = theta_diag_deg()
    t31 = theta_31_deg()
    t21 = theta_21_deg()
    t18 = theta_18_deg()

    total = 2*td + 4*t31 + 4*t21 + 4*t18
    error_deg = abs(total - 360.0)

    return {
        "theta_diag_deg": td,
        "theta_31_deg":   t31,
        "theta_21_deg":   t21,
        "theta_18_deg":   t18,
        "sum_deg":        total,
        "error_deg":      error_deg,
        "error_pct":      error_deg / 360.0 * 100.0,
        "n_vertices":     4,
        "n_edge_crossings": 10,
        "arc_sequence_half":  ["V", "θ₃₁", "θ₂₁", "θ₁₈", "θ₁₈", "θ₂₁", "θ₃₁", "V"],
        "t_values": {
            "t_18": 0.5,
            "t_21": 2.0 / (3.0 * PHI),
            "t_31": 3.0 * PHI / (4.0 * PHI + 3.0),
        },
    }


def phi_arithmetic_verify() -> Dict:
    """
    φ算術の検証: 各cos値の数値確認。[核24/27/52]
    """
    # cos θ_e (a=1系, chord=1)
    cos_e_phi = (71 + 18*PHI) / DENOM          # (71+18φ)/109
    cos_e_exact = 1.0 - 1.0 / (2.0 * R_SQ)     # 1 - a²/(2R²), a=1

    # cos θ_diag (a=2系)
    cos_d_phi = phi_value(*cos_theta_diag_phi()) / R_SQ_A2
    cos_d_exact = math.cos(math.radians(theta_diag_deg()))

    # sin θ_e (a=2系)
    sin_e_phi = 6.0 * PHI / R_SQ_A2
    sin_e_sqrt5 = (-24 + 30*math.sqrt(5)) / 109.0

    # cos²θ₃₁
    cos2_31_phi = _cos_from_phi_pair(*cos2_theta_31_phi())
    cos2_31_exact = math.cos(math.radians(theta_31_deg()))**2

    # cos²θ₁₈
    cos2_18_phi = _cos_from_phi_pair(*cos2_theta_18_phi())
    cos2_18_exact = math.cos(math.radians(theta_18_deg()))**2

    # cos²θ₂₁ [核52新規]
    cos2_21_phi = _cos_from_phi_pair(*cos2_theta_21_phi())
    cos2_21_exact = math.cos(math.radians(theta_21_deg()))**2

    # crossing点間内積 [核52新規]
    cp_inner = crossing_inner_products_float()
    cpB_cp42_ok  = abs(cp_inner["cpB_cp42"]["inner"]  - cp_inner["cpB_cp42"]["expected"])  < 1e-8
    cp42_cp10_ok = abs(cp_inner["cp42_cp10"]["inner"] - cp_inner["cp42_cp10"]["expected"]) < 1e-8

    def ok(a, b): return abs(a - b) < 1e-8

    return {
        "cos_theta_e": {
            "formula": "(71+18φ)/109",
            "phi_eval": cos_e_phi,
            "exact":    cos_e_exact,
            "match":    ok(cos_e_phi, cos_e_exact),
        },
        "cos_theta_diag": {
            "formula": "(8+7φ)/(9φ+10)",
            "phi_eval": cos_d_phi,
            "exact":    cos_d_exact,
            "match":    ok(cos_d_phi, cos_d_exact),
        },
        "sin_theta_e": {
            "formula": "6φ/(9φ+10) = (-24+30√5)/109",
            "phi_eval": sin_e_phi,
            "sqrt5_eval": sin_e_sqrt5,
            "match":    ok(sin_e_phi, sin_e_sqrt5),
        },
        "cos2_theta_31": {
            "formula": "(16849φ+10489)/(23185φ+14413)",
            "phi_eval": cos2_31_phi,
            "exact":    cos2_31_exact,
            "match":    ok(cos2_31_phi, cos2_31_exact),
        },
        "cos2_theta_18": {
            "formula": "(203φ+170)/(228φ+187)",
            "phi_eval": cos2_18_phi,
            "exact":    cos2_18_exact,
            "match":    ok(cos2_18_phi, cos2_18_exact),
        },
        "cos2_theta_21": {                          # 核52
            "formula": "(106285+1965φ)/(182645−35575φ)",
            "phi_eval": cos2_21_phi,
            "exact":    cos2_21_exact,
            "match":    ok(cos2_21_phi, cos2_21_exact),
        },
        "crossing_inner_cpB_cp42": {               # 核52
            "formula": "(326+3φ)/15",
            "computed": cp_inner["cpB_cp42"]["inner"],
            "expected": cp_inner["cpB_cp42"]["expected"],
            "match":    cpB_cp42_ok,
        },
        "crossing_inner_cp42_cp10": {              # 核52
            "formula": "11+7φ",
            "computed": cp_inner["cp42_cp10"]["inner"],
            "expected": cp_inner["cp42_cp10"]["expected"],
            "match":    cp42_cp10_ok,
        },
        "denom_109": "109 = 8×13+5 = 8×F(7)+F(5)",
    }


# ─────────────────────────────────────────────
# 旧API互換 (deprecated, 旧モデル1.41%誤差)
# ─────────────────────────────────────────────

def _legacy_h5_h6():
    """旧モデルの弦長 (参考のみ)。"""
    H5_SQ = (3.0 + 4.0*PHI) / 4.0
    H6_SQ = 3.0 / 4.0  # a=1 hexagon
    return H5_SQ, H6_SQ

def great_circle_traversal() -> Dict:
    """
    [互換API] 旧モデルの代わりに新モデルを返す。
    error_pct は新モデルの値 (≈0) を返す。
    """
    arcs = great_circle_arcs()
    return {
        "arc_diag":   R * math.radians(arcs["theta_diag_deg"]),
        "arc_31":     R * math.radians(arcs["theta_31_deg"]),
        "arc_21":     R * math.radians(arcs["theta_21_deg"]),
        "arc_18":     R * math.radians(arcs["theta_18_deg"]),
        "total":      2 * math.pi * R,
        "theoretical":2 * math.pi * R,
        "error_pct":  arcs["error_pct"],
        "elements":   14,  # 4頂点 + 10辺横断
        "model":      "v64 (4V+10E, exact)",
    }


def theta_values_degrees() -> Dict:
    """全弧の度数を返す。"""
    return {
        "theta_diag_deg": theta_diag_deg(),
        "theta_31_deg":   theta_31_deg(),
        "theta_21_deg":   theta_21_deg(),
        "theta_18_deg":   theta_18_deg(),
        "sum_check":      2*theta_diag_deg() + 4*theta_31_deg()
                         + 4*theta_21_deg()  + 4*theta_18_deg(),
    }


# ─────────────────────────────────────────────
# 旧API シンボル互換
# ─────────────────────────────────────────────
H5_SQ, H6_SQ = _legacy_h5_h6()
H5 = math.sqrt(H5_SQ)
H6 = math.sqrt(H6_SQ)

def cos_theta_a_phi():  return (71, 18)
def cos_theta_5_phi():  return (197, -13)
def cos_theta_6_phi():  return (-5, 54)

def arc_length(chord_sq: float) -> float:
    cos_t = 1.0 - chord_sq / (2.0 * R_SQ)
    return R * math.acos(max(-1.0, min(1.0, cos_t)))

def central_angle_from_chord(chord_sq: float) -> float:
    cos_t = 1.0 - chord_sq / (2.0 * R_SQ)
    return math.degrees(math.acos(max(-1.0, min(1.0, cos_t))))

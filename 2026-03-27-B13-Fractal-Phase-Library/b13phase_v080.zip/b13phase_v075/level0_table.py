"""
level0_table.py
===============
Level-0 lookup table for B13 fractal phase evaluator.

COS_TABLE[i] = round(BASE * cos(2π * i / BASE))
SIN_TABLE[i] = round(BASE * sin(2π * i / BASE))

for i in 0..BASE-1 (BASE = 3120).

Key values:
  i=0    → cos=3120,  sin=0      (0°)
  i=312  → cos=2524,  sin=1834   (36°,  cos≈φ/2)
  i=624  → cos=1560,  sin=2702   (72°)
  i=780  → cos=0,     sin=3120   (90°)
  i=936  → cos=-1560, sin=2702   (108°)
  i=1248 → cos=-2524, sin=1834   (144°)
  i=1560 → cos=-3120, sin=0      (180°)
  i=2340 → cos=0,     sin=-3120  (270°)
"""

from __future__ import annotations
import math
from .constants import BASE


def _build_tables(base: int):
    cos_table = [0] * base
    sin_table = [0] * base
    two_pi = 2.0 * math.pi
    for i in range(base):
        angle = two_pi * i / base
        cos_table[i] = round(base * math.cos(angle))
        sin_table[i] = round(base * math.sin(angle))
    return cos_table, sin_table


COS_TABLE, SIN_TABLE = _build_tables(BASE)


def verify_canonical() -> bool:
    """Verify key canonical values."""
    checks = [
        (COS_TABLE[0],        BASE,   "cos(0°)"),
        (SIN_TABLE[0],        0,      "sin(0°)"),
        (COS_TABLE[BASE//4],  0,      "cos(90°)"),
        (SIN_TABLE[BASE//4],  BASE,   "sin(90°)"),
        (COS_TABLE[BASE//2],  -BASE,  "cos(180°)"),
        (SIN_TABLE[BASE//2],  0,      "sin(180°)"),
        (COS_TABLE[BASE*3//4],0,      "cos(270°)"),
        (SIN_TABLE[BASE*3//4],-BASE,  "sin(270°)"),
    ]
    ok = True
    for val, expected, label in checks:
        if val != expected:
            print(f"  FAIL {label}: got {val}, expected {expected}")
            ok = False
    return ok


def coset_of(g: int) -> str:
    """Return the coset name of g in Z₁₃."""
    g = g % 13
    if g == 0:
        return "0"
    if g in {1, 5, 8, 12}:
        return "H"
    if g in {2, 3, 10, 11}:
        return "2H"
    return "4H"

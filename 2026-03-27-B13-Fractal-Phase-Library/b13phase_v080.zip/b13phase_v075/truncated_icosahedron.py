"""
truncated_icosahedron.py
========================
Vertex coordinates of the truncated icosahedron in B13/BASE3120 framework.

Key structural facts:
  60 vertices = 12 pentagons × 5 vertices
  Circumradius²  = (9φ+10)/4  (edge length a=1)
  φ = (1+√5)/2

Vertex map:
  f: Z₁₃* × Z₅ → V(truncated icosahedron)
  f(2^k mod 13, j) = pentagon P_k, vertex j

Angular encoding (BASE=3120 units):
  Pentagon face azimuth:  k × STEP_Z12 = k × 260
  Vertex local rotation:  j × STEP_Z5  = j × 624
  Combined azimuth:       (k × 260 + j × 624) % 3120

Coset structure:
  k=0,3,6,9   → 2^k ∈ H   (g = 1,8,12,5)
  k=1,4,7,10  → 2^k ∈ 2H  (g = 2,3,11,10)
  k=2,5,8,11  → 2^k ∈ 4H  (g = 4,6,9,7)  ← τ=0 transitions absent

Great circle (Observation R, empirically confirmed):
  One full traversal = h₅×4 + h₆×4 + a×2
  cos values in φ-arithmetic:
    cos(θ_a) = (71+18φ)/109
    cos(θ₅)  = (197-13φ)/218    ← F(7)=13 appears
    cos(θ₆)  = (54φ-5)/109
  Denominator 109 = 8×F(7)+F(5) = 8×13+5
"""

from __future__ import annotations
import math
from typing import Tuple, List, Optional
from .constants import BASE, STEP_Z5, STEP_Z12, Z13_STAR, PHI_BASE
from .phase_digits import digits_from_int
from .evaluator_proto import fractal_cos_sin_proto
from .z13_structure import coset_of, is_forbidden

# φ = (1+√5)/2
PHI: float = (1.0 + math.sqrt(5.0)) / 2.0

# Circumradius² = (9φ+10)/4 (edge length a=1)
R_SQ: float = (9.0 * PHI + 10.0) / 4.0
R: float = math.sqrt(R_SQ)

# Pentagon face polar angles (elevation from equator)
# Icosahedron vertex structure:
#   k=0:     top pole    (elevation = +arctan(φ²))  ← H
#   k=1..5:  upper band  (elevation = +arctan(1/2)) ← 2H,4H,H,2H,4H
#   k=6..10: lower band  (elevation = -arctan(1/2)) ← H,2H,4H,H,2H
#   k=11:    bottom pole (elevation = -arctan(φ²))  ← 4H

def _pentagon_elevation(k: int) -> float:
    """
    Return the polar elevation angle (in radians) of pentagon face P_k.
    k = 0..11 following Z₁₃* cyclic order.
    """
    if k == 0:
        return math.atan(PHI ** 2)
    elif 1 <= k <= 5:
        return math.atan(0.5)
    elif 6 <= k <= 10:
        return -math.atan(0.5)
    else:  # k == 11
        return -math.atan(PHI ** 2)


def _pentagon_azimuth_base(k: int) -> float:
    """
    Return the base azimuth angle (radians) of pentagon P_k center.
    Upper band (k=1..5): azimuth = (k-1) × 72°
    Lower band (k=6..10): azimuth = (k-6) × 72° + 36°  (36° offset)
    Poles: azimuth = 0 (arbitrary)
    """
    if k == 0 or k == 11:
        return 0.0
    elif 1 <= k <= 5:
        return (k - 1) * 2.0 * math.pi / 5.0
    else:  # 6..10
        return (k - 6) * 2.0 * math.pi / 5.0 + math.pi / 5.0  # +36°


def vertex_coords_float(k: int, j: int) -> Tuple[float, float, float]:
    """
    Return 3D float coordinates of vertex f(2^k mod 13, j).

    k: pentagon index (0..11) in Z₁₃* cyclic order
    j: local vertex index within pentagon (0..4)

    Returns (x, y, z) on circumsphere of radius R.
    """
    if not (0 <= k <= 11):
        raise ValueError("k must be in 0..11")
    if not (0 <= j <= 4):
        raise ValueError("j must be in 0..4")

    elev = _pentagon_elevation(k)
    az_base = _pentagon_azimuth_base(k)

    # Pentagon vertex j is at local angle j×72° from base azimuth
    # Plus the 36° twist for opposite-face orientation
    local_angle = j * 2.0 * math.pi / 5.0

    # Pentagon vertices sit on a cone at elevation elev
    # Pentagon circumradius in the tilted plane
    pent_r = R * math.cos(elev) * math.sin(math.pi / 5.0) / math.sin(2.0 * math.pi / 5.0)

    # Actually: use the exact circumsphere constraint
    # vertex = R * (sin(θ)cos(az), sin(θ)sin(az), cos(θ))
    # where θ = π/2 - elev (polar angle from north pole)
    theta = math.pi / 2.0 - elev
    az = az_base + local_angle

    x = R * math.sin(theta) * math.cos(az)
    y = R * math.sin(theta) * math.sin(az)
    z = R * math.cos(theta)

    return x, y, z


def vertex_phase_index(k: int, j: int) -> int:
    """
    Return the BASE3120 phase index for vertex f(2^k mod 13, j).

    Azimuth index = (k × STEP_Z12 + j × STEP_Z5) % BASE
                  = (k × 260 + j × 624) % 3120
    """
    return (k * STEP_Z12 + j * STEP_Z5) % BASE


def vertex_cos_sin(k: int, j: int, n_digits: int = 3) -> Tuple[int, int]:
    """
    Return (cx, cy) for the azimuthal component of vertex f(2^k mod 13, j).
    Uses fractal_cos_sin_proto for multi-digit precision.
    """
    idx = vertex_phase_index(k, j)
    digits = digits_from_int(idx, n_digits)
    return fractal_cos_sin_proto(digits)


def all_vertices() -> List[Tuple[int, int, Tuple[float, float, float], str]]:
    """
    Return all 60 vertices as list of (k, j, (x,y,z), coset).
    """
    result = []
    for k in range(12):
        g = Z13_STAR[k]
        c = coset_of(g)
        for j in range(5):
            xyz = vertex_coords_float(k, j)
            result.append((k, j, xyz, c))
    return result


def inner_product(k1: int, j1: int, k2: int, j2: int) -> float:
    """
    Return v_i · v_j for vertices f(2^k1,j1) and f(2^k2,j2).
    """
    x1, y1, z1 = vertex_coords_float(k1, j1)
    x2, y2, z2 = vertex_coords_float(k2, j2)
    return x1*x2 + y1*y2 + z1*z2


def central_angle(k1: int, j1: int, k2: int, j2: int) -> float:
    """
    Return central angle θ (degrees) between two vertices.
    θ < 90°  → elliptic class  → H∪2H (reachable)
    θ > 90°  → hyperbolic class → 4H   (forbidden)
    θ = 180° → antipodal        → hexagon opposite pair
    """
    ip = inner_product(k1, j1, k2, j2)
    cos_theta = ip / R_SQ
    cos_theta = max(-1.0, min(1.0, cos_theta))
    return math.degrees(math.acos(cos_theta))


def classify_pair(k1: int, j1: int, k2: int, j2: int) -> str:
    """
    Classify a vertex pair by central angle.
    Returns 'elliptic', 'hyperbolic', or 'antipodal'.
    """
    theta = central_angle(k1, j1, k2, j2)
    if abs(theta - 180.0) < 0.01:
        return "antipodal"
    if theta < 90.0:
        return "elliptic"
    return "hyperbolic"


def observation_n_verify() -> bool:
    """
    Observation N: No vertex pair has θ=90° (inner product = 0).
    Verify for all C(60,2) = 1770 pairs.
    """
    vertices = all_vertices()
    n = len(vertices)
    for i in range(n):
        k1, j1, (x1,y1,z1), _ = vertices[i]
        for j2 in range(i+1, n):
            k2, j2v, (x2,y2,z2), _ = vertices[j2]
            ip = x1*x2 + y1*y2 + z1*z2
            if abs(ip) < 1e-10:
                print(f"  FAIL: ({k1},{j1})-({k2},{j2v}) inner product ≈ 0")
                return False
    return True


def opposite_face_angles() -> dict:
    """
    Return central angles for opposite face pairs.
    Hexagon opposite: θ = 180° (antipodal, τ=0)
    Pentagon opposite: θ ≈ 148° (72° twist, τ=1)
    """
    # Pentagon P_0 vs P_11 (top pole vs bottom pole)
    theta_pent = central_angle(0, 0, 11, 1)  # j offset=1 for 72° twist

    # Representative hexagon opposite pair
    # Hexagon face corresponds to icosahedron triangle face
    # Use vertices from opposite hexagon faces
    theta_hex = central_angle(0, 0, 6, 3)  # approximate

    return {
        "pentagon_opposite_deg": theta_pent,
        "hexagon_opposite_deg": theta_hex,
    }

"""
z13_structure.py
================
Algebraic structure of Z₁₃ for B13 fractal analysis.

Z₁₃ = {0} ∪ H ∪ 2H ∪ 4H
H = {1, 5, 8, 12} ≅ Z₄  (cubic residue subgroup)
2H = {2, 3, 10, 11}
4H = {4, 6, 7, 9}        (forbidden zone for Fibonacci/Pell)

Key facts (all proven):
  F(n) mod 13 never lands in 4H  (Fib 4H-avoidance theorem)
  P(n) mod 13 never lands in 4H  (Pell 4H-avoidance theorem)
  M^7 ≡ 8I (mod 13)
  8 × 5 ≡ 1 (mod 13)  (φ-residue and δₛ-residue are multiplicative inverses)
  F(7) = 13, P(7) = 169 = 13²
"""

from __future__ import annotations
from typing import List, Optional
from .constants import H_SET, H2_SET, H4_SET, Z13_STAR


def coset_of(g: int) -> str:
    """Return the coset of g in Z₁₃: '0', 'H', '2H', or '4H'."""
    g = g % 13
    if g == 0:
        return "0"
    if g in H_SET:
        return "H"
    if g in H2_SET:
        return "2H"
    return "4H"


def coset_index(g: int) -> int:
    """Return 0,1,2,3 for {0}, H, 2H, 4H."""
    c = coset_of(g)
    return {"0": 0, "H": 1, "2H": 2, "4H": 3}[c]


def is_forbidden(g: int) -> bool:
    """Return True if g mod 13 is in 4H (forbidden zone)."""
    return (g % 13) in H4_SET


def z13_star_index(g: int) -> Optional[int]:
    """
    Return k such that 2^k ≡ g (mod 13), or None if g ≡ 0.
    """
    g = g % 13
    if g == 0:
        return None
    try:
        return Z13_STAR.index(g)
    except ValueError:
        return None


def pentagon_index(g: int) -> Optional[int]:
    """
    Map g ∈ Z₁₃* to pentagon face index k (0..11).
    f(2^k mod 13, j) = pentagon P_k, vertex j.
    """
    return z13_star_index(g)


def coset_pattern() -> List[str]:
    """
    Return the coset pattern of Z₁₃* in cyclic order (k=0..11).
    Should be [H, 2H, 4H, H, 2H, 4H, ...] (period 3).
    """
    return [coset_of(g) for g in Z13_STAR]


def fib_mod13(n: int) -> int:
    """Return F(n) mod 13."""
    a, b = 0, 1
    for _ in range(n):
        a, b = b, (a + b) % 13
    return a


def pell_mod13(n: int) -> int:
    """Return P(n) mod 13 (Pell: P(0)=0, P(1)=1, P(n)=2P(n-1)+P(n-2))."""
    a, b = 0, 1
    for _ in range(n):
        a, b = b, (2 * b + a) % 13
    return a


def verify_4h_avoidance(n_max: int = 100) -> bool:
    """
    Verify that F(n) and P(n) mod 13 never land in 4H for n=0..n_max.
    Returns True if theorem holds.
    """
    for n in range(n_max + 1):
        if is_forbidden(fib_mod13(n)):
            print(f"  FAIL: F({n}) mod 13 = {fib_mod13(n)} ∈ 4H")
            return False
        if is_forbidden(pell_mod13(n)):
            print(f"  FAIL: P({n}) mod 13 = {pell_mod13(n)} ∈ 4H")
            return False
    return True


def phi_residue_orbit() -> List[int]:
    """
    Return the orbit of 8 (φ-residue mod 13) under multiplication by 8.
    Should be [8, 12, 5, 1] (= H, traversed in order).
    """
    orbit = []
    x = 8
    for _ in range(4):
        orbit.append(x)
        x = (x * 8) % 13
    return orbit


def delta_s_orbit() -> List[int]:
    """
    Return the orbit of 5 (δₛ-residue mod 13) under multiplication by 5.
    Should be [5, 12, 8, 1] (= H, reverse order of φ orbit).
    """
    orbit = []
    x = 5
    for _ in range(4):
        orbit.append(x)
        x = (x * 5) % 13
    return orbit

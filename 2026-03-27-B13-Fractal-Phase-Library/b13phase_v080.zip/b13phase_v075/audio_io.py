"""
audio_io.py
===========
WAVファイル読み込みとf0推定ユーティリティ。

N≠BASE への対応（v80確立）:
  frame_size = BASE = 3120 (固定)
  Layer 1: max_harmonics = 13 (低域、常用)
  Layer 2: max_harmonics = w_f0 * 2 (基音帯、f0既知時)
  w_f0 = round(BASE * f0_hz / sr)

非整数周期の注意:
  実音高(C6=1046.5Hz)の1周期=10.535サンプル(非整数・Sturmian)
  → spectral leakage により max_harmonics=w_f0 で誤判定が発生
  → max_harmonics=w_f0*2 で漏れが相殺されfullに収束
  → f0推定にはFFT(numpy)を使用（autocorrelationはオクターブエラーあり）
"""
from __future__ import annotations
import struct
import wave
from typing import List, Optional, Tuple

from .constants import BASE
from .fullerene_transform import analyze_timeseries, Spectrum


def read_wav_scaled(
    path: str,
    base: int = BASE,
) -> Tuple[List[int], int]:
    """
    WAVファイルを BASE スケールの整数列に変換して返す。

    16bit モノラルWAV専用（b13phase の標準入力形式）。
    -32768〜32767 → -BASE〜BASE の範囲に線形スケーリング。

    Args:
        path: WAVファイルパス
        base: スケール係数（デフォルト BASE=3120）

    Returns:
        (samples, sr): 整数サンプル列とサンプリングレート
    """
    with wave.open(path) as w:
        sr  = w.getframerate()
        nf  = w.getnframes()
        sw  = w.getsampwidth()
        raw = w.readframes(nf)

    fmt = '<' + {1: 'b', 2: 'h', 4: 'i'}[sw] * nf
    raw_samples = struct.unpack(fmt, raw)
    max_val = 2 ** (8 * sw - 1)
    samples = [round(v * base / max_val) for v in raw_samples]
    return samples, sr


def estimate_f0_fft(
    samples: List[int],
    sr: int,
    base: int = BASE,
) -> float:
    """
    numpy.fft で基音周波数を推定。

    autocorrelation よりオクターブエラーが少ない。
    先頭 BASE サンプルを使用（約283ms @ sr=11025Hz）。

    Args:
        samples: 整数サンプル列
        sr:      サンプリングレート
        base:    FFT サイズ（デフォルト BASE=3120）

    Returns:
        推定基音周波数 [Hz]

    Note:
        numpy が必要。importエラーの場合は手動でf0を指定すること。
    """
    try:
        import numpy as np
    except ImportError:
        raise ImportError('estimate_f0_fft requires numpy: pip install numpy')

    seg = np.array(samples[:base], dtype=float)
    fft = np.fft.rfft(seg)
    freqs = np.fft.rfftfreq(base, d=1.0 / sr)
    mags = np.abs(fft)
    idx = int(np.argmax(mags[1:])) + 1
    return float(freqs[idx])


def wav_to_frames(
    path: str,
    f0_hz: Optional[float] = None,
    layer: int = 1,
    base: int = BASE,
):
    """
    WAVファイルを読み込み、フラーレン時系列フレームに変換。

    Args:
        path:   WAVファイルパス
        f0_hz:  基音周波数 [Hz]（layer=2 の場合は必須、省略時はFFTで推定）
        layer:  1=低域Layer（mh=13、高速）/ 2=基音Layer（mh=w_f0*2）
        base:   BASE（デフォルト 3120）

    Returns:
        (frames, max_harmonics_used, sr)
        frames: analyze_timeseries() の出力

    Layer 設計原則（v80）:
        layer=1: mh=13、〜46Hz@sr=11025の低域。楽器種別の粗い分類に使う。
        layer=2: mh=w_f0*2。基音帯の正確な共鳴クラス判定に使う。
                 leakage相殺のために「*2」が必須（*1では誤判定）。
    """
    samples, sr = read_wav_scaled(path, base=base)

    if layer == 1:
        mh = 13
    else:
        if f0_hz is None:
            f0_hz = estimate_f0_fft(samples, sr, base=base)
        w_f0 = round(base * f0_hz / sr)
        mh = w_f0 * 2

    n_blocks = len(samples) // base
    samples_trimmed = samples[:n_blocks * base]
    frames = analyze_timeseries(samples_trimmed, frame_size=base, max_harmonics=mh)
    return frames, mh, sr

"""
b13phase — B13 Fractal Phase Library (BASE=3120)
=================================================

BASE = 3120 = 2⁴ × 3 × 5 × 13
            = 60 × 52
            = truncated icosahedron vertices × active states

Core modules:
  constants              — BASE, angular step constants, Z₁₃ coset sets
  level0_table           — COS_TABLE, SIN_TABLE (3120 entries)
  phase_digits           — exact radix-BASE digit arithmetic (arbitrary precision)
  phase_packed_u64       — packed 5-digit u64 arithmetic
  evaluator_proto        — fractal_cos_sin_proto (multi-digit phase evaluator)
  z13_structure          — Z₁₃ coset algebra, Fibonacci/Pell mod 13
  truncated_icosahedron  — vertex coordinates, central angles, Proposition D
  great_circle           — great circle analysis, φ-arithmetic, Observation R

Quick start:
  from b13phase import fractal_cos_sin_proto, digits_from_int
  digits = digits_from_int(312, 3)   # 36° in 3-digit BASE3120
  cx, cy = fractal_cos_sin_proto(digits)
"""

from .constants import (BASE, INT64_MAX,
                         STEP_Z5, STEP_Z12, STEP_H, STEP_Z13, STEP_MIN,
                         PHI_BASE, PHI_HALF_BASE,
                         Z13_ORDER, H_ORDER, Z5_ORDER,
                         VERTICES, PENTAGONS, HEXAGONS, ACTIVE,
                         F7, P7,
                         H_SET, H2_SET, H4_SET, Z13_STAR)

from .level0_table import COS_TABLE, SIN_TABLE, coset_of

from .phase_digits import (digits_zero, digits_from_int, digits_to_int,
                            digits_add, digits_inc, digits_sub,
                            digits_mul_scalar, digits_phase,
                            digits_negate, digits_half)

from .phase_packed_u64 import (pack_u64_digits, unpack_u64_digits,
                                add_u64_packed, sub_u64_packed,
                                negate_u64_packed,
                                BITS_PER_DIGIT, MASK, U64_DIGITS)

from .evaluator_proto import fractal_cos_sin_proto, norm_sq, norm_ratio

from .z13_structure import (coset_of, coset_index, is_forbidden,
                             z13_star_index, pentagon_index,
                             coset_pattern, fib_mod13, pell_mod13,
                             verify_4h_avoidance,
                             phi_residue_orbit, delta_s_orbit)

from .audio_io import read_wav_scaled, estimate_f0_fft, wav_to_frames

from .fullerene_transform import (
    winding_int, mag_sq,
    resonance_orbit_size, resonance_label, fullerene_coords,
    signal_to_fullerene, resonance_class,
    spectrum_intensity, vibrato_depth,
    spectrum_mask_z5, spectrum_mask_z13, spectrum_decompose,
    analyze_timeseries, timeseries_summary,
    spectrum_subtract, spectrum_add,
)

from .truncated_icosahedron import (PHI, R, R_SQ,
                                     vertex_coords_float,
                                     vertex_phase_index,
                                     vertex_cos_sin,
                                     all_vertices,
                                     inner_product,
                                     central_angle,
                                     classify_pair,
                                     observation_n_verify,
                                     opposite_face_angles)

from .cell import (B13Cell, B13Fractal, StepEvent, all_cells)
from .connection import (neighbors_of, propagate_carry, edge_type,
                         build_connection_graph, build_edge_types)

from .fractal_engine import (crossing_thresholds, proj, band_of,
                              detect_crossings,
                              digits_add_trace, digits_inc_trace,
                              format_result, threshold_summary,
                              fire_response,
                              FIRE_RESPONSE_MAX, FIRE_RESPONSE_SLOPE, FIRE_SATURATION_F,
                              CrossingThreshold, CrossingEvent, AddResult)

from .great_circle import (great_circle_traversal,
                            theta_values_degrees,
                            phi_arithmetic_verify,
                            arc_length, central_angle_from_chord,
                            cos_theta_a_phi, cos_theta_5_phi, cos_theta_6_phi,
                            cos2_theta_21_phi,
                            edge_endpoint_zphi, edge_endpoint_float,
                            inner_product_zphi,
                            crossing_points_float,
                            crossing_inner_products_float,
                            DENOM, H5, H6, H5_SQ, H6_SQ)

from .fib_drive import (FibDriveEngine, DriveResult,
                         fib_step, pell_step,
                         SEQ_PERIOD,
                         UNIFORM_PERIOD,
                         FIB_PERIOD_A, FIB_PERIOD_B,
                         PELL_PERIOD_A, PELL_PERIOD_B,
                         ATTRACTOR_LSD_STEP, ATTRACTOR_LSD_OFFSET,
                         ATTRACTOR_LSD_MIN,
                         ATTRACTOR_MSD_HIGH_N, ATTRACTOR_MSD_LOW_N,
                         FIB_PERIOD_CARRY_OFF, FIB_PERIOD_SKIP)

__version__ = "0.8.0"
__all__ = [
    # constants
    "BASE", "INT64_MAX",
    "STEP_Z5", "STEP_Z12", "STEP_H", "STEP_Z13", "STEP_MIN",
    "PHI_BASE", "PHI_HALF_BASE",
    "Z13_ORDER", "H_ORDER", "Z5_ORDER",
    "VERTICES", "PENTAGONS", "HEXAGONS", "ACTIVE",
    "F7", "P7", "H_SET", "H2_SET", "H4_SET", "Z13_STAR",
    # tables
    "COS_TABLE", "SIN_TABLE",
    # audio I/O (v80)
    "read_wav_scaled", "estimate_f0_fft", "wav_to_frames",
    # fullerene transform (v79)
    "winding_int", "mag_sq",
    "resonance_orbit_size", "resonance_label", "fullerene_coords",
    "signal_to_fullerene", "resonance_class",
    "spectrum_intensity", "vibrato_depth",
    "spectrum_mask_z5", "spectrum_mask_z13", "spectrum_decompose",
    # timeseries (v80)
    "analyze_timeseries", "timeseries_summary",
    "spectrum_subtract", "spectrum_add",
    # digit ops
    "digits_zero", "digits_from_int", "digits_to_int",
    "digits_add", "digits_inc", "digits_sub",
    "digits_mul_scalar", "digits_phase",
    "digits_negate", "digits_half",
    # packed u64
    "pack_u64_digits", "unpack_u64_digits",
    "add_u64_packed", "sub_u64_packed", "negate_u64_packed",
    "BITS_PER_DIGIT", "MASK", "U64_DIGITS",
    # evaluator
    "fractal_cos_sin_proto", "norm_sq", "norm_ratio",
    # Z₁₃
    "coset_of", "coset_index", "is_forbidden",
    "z13_star_index", "pentagon_index",
    "coset_pattern", "fib_mod13", "pell_mod13",
    "verify_4h_avoidance", "phi_residue_orbit", "delta_s_orbit",
    # truncated icosahedron
    "PHI", "R", "R_SQ",
    "vertex_coords_float", "vertex_phase_index", "vertex_cos_sin",
    "all_vertices", "inner_product", "central_angle",
    "classify_pair", "observation_n_verify", "opposite_face_angles",
    # great circle
    "great_circle_traversal", "theta_values_degrees",
    "phi_arithmetic_verify", "arc_length", "central_angle_from_chord",
    "cos_theta_a_phi", "cos_theta_5_phi", "cos_theta_6_phi",
    "cos2_theta_21_phi",
    "edge_endpoint_zphi", "edge_endpoint_float",
    "inner_product_zphi",
    "crossing_points_float", "crossing_inner_products_float",
    "DENOM", "H5", "H6", "H5_SQ", "H6_SQ",
    # audio I/O (v80)
    "read_wav_scaled", "estimate_f0", "wav_to_frames",
    "harmonic_powers", "f0_power_series",
]

__version__ = "0.8.0"

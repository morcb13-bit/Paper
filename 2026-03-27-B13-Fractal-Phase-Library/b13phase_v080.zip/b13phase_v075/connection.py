"""
connection.py
=============
切端20面体の接続構造 → coneFFT の伝播ルール。

"Nature knows only addition."
macro-fire が起きたセルから隣接セルへ carry が伝わる。
この「どこへ伝わるか」を定義するのがこのモジュール。

接続の2種類:
  pentagon辺:  同一pentagon内の隣接頂点
               (g, τ) → (g, τ±1 mod 5)  [g固定, τ変化]

  hexagon辺:   異なるpentagonの頂点間
               (g, τ) → (g2, τ2)          [g変化, τも変化]

計算方法:
  a=2系の正確な座標から辺を列挙し、
  pentagon面 (12個) を検出して辺を分類する。

carry伝播ルール (現バージョン):
  macro-fire @ (g, τ) → 全隣接セル(g2,τ2) に +1 を加算
"""

from __future__ import annotations
import math
from typing import List, Tuple, Dict, Set, FrozenSet
from .constants import Z13_STAR, STEP_Z12, STEP_Z5, BASE
from .z13_structure import pentagon_index


PHI: float = (1.0 + math.sqrt(5.0)) / 2.0


# ─────────────────────────────────────────────
# a=2系の正確な座標
# ─────────────────────────────────────────────

def _build_vertices_a2() -> List[Tuple[float, float, float]]:
    """切端20面体の全60頂点 (a=2系, 辺長=2)。"""
    verts = []
    for s1 in (1, -1):
        for s2 in (1, -1):
            verts += [
                (0.0,      s1,        s2 * 3*PHI),
                (s2*3*PHI, 0.0,       s1),
                (s1,       s2*3*PHI,  0.0),
            ]
    for s1 in (1, -1):
        for s2 in (1, -1):
            for s3 in (1, -1):
                verts += [
                    (s1,           s2*(2+PHI),    s3*2*PHI),
                    (s3*2*PHI,     s1,             s2*(2+PHI)),
                    (s2*(2+PHI),   s3*2*PHI,       s1),
                    (s1*2,         s2*(1+2*PHI),   s3*PHI),
                    (s3*PHI,       s1*2,            s2*(1+2*PHI)),
                    (s2*(1+2*PHI), s3*PHI,          s1*2),
                ]
    return verts  # 60頂点


def _dist(v1, v2) -> float:
    return math.sqrt(sum((a-b)**2 for a,b in zip(v1,v2)))


def _build_adjacency(verts) -> Dict[int, Set[int]]:
    """辺長=2 の隣接グラフを構築。"""
    n = len(verts)
    adj: Dict[int, Set[int]] = {i: set() for i in range(n)}
    for i in range(n):
        for j in range(i+1, n):
            if abs(_dist(verts[i], verts[j]) - 2.0) < 0.01:
                adj[i].add(j)
                adj[j].add(i)
    return adj


def _find_pentagons(verts, adj) -> List[Tuple[int,...]]:
    """12個のpentagon面を検出する。"""
    pentagons: Set[Tuple[int,...]] = set()
    pent_diag = 2.0 * PHI  # pentagon対角線長

    for seed in range(len(verts)):
        nbs = list(adj[seed])
        for ii in range(len(nbs)):
            n1 = nbs[ii]
            for jj in range(ii+1, len(nbs)):
                n2 = nbs[jj]
                if abs(_dist(verts[n1], verts[n2]) - pent_diag) > 0.01:
                    continue
                for x in adj[n2] - {seed}:
                    for y in adj[n1] - {seed}:
                        if abs(_dist(verts[x], verts[y]) - 2.0) < 0.01:
                            pent = tuple(sorted([seed, n1, n2, x, y]))
                            if len(set(pent)) == 5:
                                pentagons.add(pent)

    return sorted(pentagons)


# ─────────────────────────────────────────────
# 座標→(k,j)インデックスへのマッピング
# ─────────────────────────────────────────────

def _build_coord_to_kj(pentagons: List[Tuple[int,...]],
                        verts: List[Tuple[float,float,float]]
                        ) -> Dict[int, Tuple[int,int]]:
    """
    座標インデックス → (k, j_local) のマッピング。

    pentagon面を Z座標 (高さ) でソートして k=0..11 を割り当てる。
    pentagon内の順序 j=0..4 は方位角順。
    """
    # 各pentagonの中心z座標でソート → k を割り当て
    def pent_center_z(pent):
        return sum(verts[v][2] for v in pent) / 5.0

    sorted_pentagons = sorted(enumerate(pentagons),
                               key=lambda x: -pent_center_z(x[1]))

    coord_to_kj: Dict[int, Tuple[int,int]] = {}
    for k, (orig_idx, pent) in enumerate(sorted_pentagons):
        # pentagon内の頂点を方位角順にソート
        cx = sum(verts[v][0] for v in pent) / 5.0
        cy = sum(verts[v][1] for v in pent) / 5.0
        def az(v_idx):
            return math.atan2(verts[v_idx][1]-cy, verts[v_idx][0]-cx)
        ordered = sorted(pent, key=az)
        for j, v_idx in enumerate(ordered):
            coord_to_kj[v_idx] = (k, j)

    return coord_to_kj


# ─────────────────────────────────────────────
# 接続グラフの構築
# ─────────────────────────────────────────────

def build_connection_graph() -> Dict[Tuple[int,int], List[Tuple[int,int]]]:
    """
    (k, j) → [(k2, j2), ...] の隣接リストを返す。

    辺の種類:
      pentagon辺: k同じ, j→j±1 mod 5
      hexagon辺:  k異なる

    Returns:
        Dict[(k,j)] → List[(k2,j2)]  (各頂点3近傍)
    """
    verts  = _build_vertices_a2()
    adj    = _build_adjacency(verts)
    pentagons = _find_pentagons(verts, adj)
    kj_map = _build_coord_to_kj(pentagons, verts)

    graph: Dict[Tuple[int,int], List[Tuple[int,int]]] = {}
    for v_idx in range(60):
        kj = kj_map[v_idx]
        neighbors = [kj_map[nb] for nb in adj[v_idx] if nb in kj_map]
        graph[kj] = sorted(neighbors)

    return graph


def build_edge_types() -> Dict[Tuple[Tuple[int,int],Tuple[int,int]], str]:
    """
    辺 ((k1,j1),(k2,j2)) → 'pentagon' or 'hexagon' の分類。
    """
    verts     = _build_vertices_a2()
    adj       = _build_adjacency(verts)
    pentagons = _find_pentagons(verts, adj)

    # 座標インデックスのpentagon所属
    v_to_pent: Dict[int,int] = {}
    for pi, pent in enumerate(pentagons):
        for v in pent:
            v_to_pent[v] = pi

    kj_map = _build_coord_to_kj(pentagons, verts)

    edge_types: Dict[Tuple,str] = {}
    for i in range(60):
        for j in adj[i]:
            if j <= i:
                continue
            kj_i = kj_map[i]
            kj_j = kj_map[j]
            etype = 'pentagon' if v_to_pent[i] == v_to_pent[j] else 'hexagon'
            edge_types[(kj_i, kj_j)] = etype
            edge_types[(kj_j, kj_i)] = etype

    return edge_types


# ─────────────────────────────────────────────
# (g, τ) ↔ (k, j) 変換
# ─────────────────────────────────────────────

def g_tau_to_kj(g: int, tau: int) -> Tuple[int, int]:
    """(g, τ) → (k, j_phase) ただし k=pentagon_index(g), j=τ。"""
    return (pentagon_index(g), tau)


def kj_to_g(k: int) -> int:
    """k → g = Z13_STAR[k]。"""
    return Z13_STAR[k]


# ─────────────────────────────────────────────
# coneFFT 伝播ルール
# ─────────────────────────────────────────────

# キャッシュ
_GRAPH: Dict[Tuple[int,int], List[Tuple[int,int]]] | None = None
_EDGE_TYPES: Dict | None = None


def get_graph() -> Dict[Tuple[int,int], List[Tuple[int,int]]]:
    global _GRAPH
    if _GRAPH is None:
        _GRAPH = build_connection_graph()
    return _GRAPH


def neighbors_of(k: int, j: int) -> List[Tuple[int, int]]:
    """(k,j) の隣接頂点リスト [(k2,j2), ...]。"""
    return get_graph().get((k, j), [])


def propagate_carry(
    g: int,
    tau: int,
    amount: int = 1,
) -> List[Tuple[int, int, int]]:
    """
    セル(g,τ)のmacro-fireから隣接セルへのcarry伝播。

    Args:
        g:      発火セルの Z₁₃* 元
        tau:    発火セルの τ ∈ Z₅
        amount: 伝播量 (デフォルト: 1)

    Returns:
        List[(g2, tau2, amount)] — 伝播先セルと伝播量
    """
    k = pentagon_index(g)
    nbs = neighbors_of(k, tau)
    result = []
    for k2, j2 in nbs:
        g2 = kj_to_g(k2)
        result.append((g2, j2, amount))
    return result


def edge_type(g1: int, tau1: int, g2: int, tau2: int) -> str:
    """2セル間の辺種別 ('pentagon' / 'hexagon' / 'none')。"""
    global _EDGE_TYPES
    if _EDGE_TYPES is None:
        _EDGE_TYPES = build_edge_types()
    k1, k2 = pentagon_index(g1), pentagon_index(g2)
    return _EDGE_TYPES.get(((k1,tau1),(k2,tau2)), 'none')

"""
phase_digits.py
===============
Exact radix-BASE (BASE=3120) phase representation using a digit array.

Representation
--------------
A phase is represented as a list of digits:
    d = [d0, d1, ..., d(n-1)]  (MSD -> LSD)

Each digit di is an integer in [0, BASE).

This is the "infinite fractal" option:
- you can increase n (digits) as far as you like
- operations are exact integer + carry
"""

from __future__ import annotations
from typing import List, Tuple
from .constants import BASE


def digits_zero(n: int) -> List[int]:
    """Create a zero phase with n digits (MSD->LSD)."""
    if n <= 0:
        raise ValueError("n must be >= 1")
    return [0] * n


def digits_from_int(x: int, n: int) -> List[int]:
    """
    Convert non-negative integer x into radix-BASE digits (MSD->LSD) of length n.
    Requires: 0 <= x < BASE^n
    """
    if n <= 0:
        raise ValueError("n must be >= 1")
    if x < 0:
        raise ValueError("x must be >= 0")
    out = [0] * n
    for i in range(n - 1, -1, -1):
        out[i] = x % BASE
        x //= BASE
    if x != 0:
        raise ValueError("x does not fit in n digits")
    return out


def digits_to_int(d: List[int]) -> int:
    """Convert radix-BASE digits (MSD->LSD) into an integer."""
    x = 0
    for v in d:
        if v < 0 or v >= BASE:
            raise ValueError("digit out of range")
        x = x * BASE + v
    return x


def digits_add(a: List[int], b: List[int]) -> Tuple[List[int], int]:
    """
    Add two digit arrays (same length), radix-BASE, exact with carry.
    Returns (sum_digits, carry_out) where carry_out is 0 or 1.
    """
    if len(a) != len(b):
        raise ValueError("digit arrays must have the same length")
    n = len(a)
    out = [0] * n
    carry = 0
    for i in range(n - 1, -1, -1):
        ai, bi = a[i], b[i]
        if not (0 <= ai < BASE and 0 <= bi < BASE):
            raise ValueError("digit out of range")
        s = ai + bi + carry
        if s >= BASE:
            s -= BASE
            carry = 1
        else:
            carry = 0
        out[i] = s
    return out, carry


def digits_inc(d: List[int], step: int = 1) -> Tuple[List[int], int]:
    """
    Increment digit array by a small integer step (step < BASE).
    Returns (new_digits, carry_out).
    """
    if step < 0:
        raise ValueError("step must be >= 0")
    if step >= BASE:
        raise ValueError("step must be < BASE for this helper")
    out = d[:]
    n = len(out)
    carry = step
    for i in range(n - 1, -1, -1):
        if carry == 0:
            break
        v = out[i]
        if not (0 <= v < BASE):
            raise ValueError("digit out of range")
        v += carry
        if v >= BASE:
            out[i] = v - BASE
            carry = 1
        else:
            out[i] = v
            carry = 0
    return out, (1 if carry else 0)


def digits_sub(a: List[int], b: List[int]) -> Tuple[List[int], int]:
    """
    Subtract b from a (same length), radix-BASE, exact with borrow.
    Returns (diff_digits, borrow_out) where borrow_out is 0 or 1.
    """
    if len(a) != len(b):
        raise ValueError("digit arrays must have the same length")
    n = len(a)
    out = [0] * n
    borrow = 0
    for i in range(n - 1, -1, -1):
        ai, bi = a[i], b[i]
        d = ai - bi - borrow
        if d < 0:
            d += BASE
            borrow = 1
        else:
            borrow = 0
        out[i] = d
    return out, borrow


def digits_mul_scalar(d: List[int], scalar: int) -> Tuple[List[int], int]:
    """
    Multiply digit array by a small scalar integer.
    Returns (product_digits, carry_out).
    """
    if scalar < 0:
        raise ValueError("scalar must be >= 0")
    n = len(d)
    out = [0] * n
    carry = 0
    for i in range(n - 1, -1, -1):
        val = d[i] * scalar + carry
        out[i] = val % BASE
        carry = val // BASE
    return out, carry


def digits_phase(idx: int, n: int) -> List[int]:
    """Alias for digits_from_int."""
    return digits_from_int(idx, n)


def digits_negate(d: List[int]) -> List[int]:
    """
    Negate a phase (mod BASE^n): result = BASE^n - d (if d != 0), else 0.
    Equivalent to phase reflection (angle → -angle).
    """
    n = len(d)
    if all(v == 0 for v in d):
        return d[:]
    # compute BASE^n - d = complement + 1
    out = [(BASE - 1 - v) for v in d]
    result, _ = digits_inc(out, 1)
    return result


def digits_half(d: List[int]) -> List[int]:
    """
    Divide phase by 2 (right-shift by half-step).
    Requires BASE is even (BASE=3120 is even). Result truncated.
    """
    n = len(d)
    out = [0] * n
    carry = 0
    for i in range(n):
        val = d[i] + carry * BASE
        out[i] = val // 2
        carry = val % 2
    return out

"""
cell.py
=======
B13セル — "Nature knows only addition."

B13Cell: Z₁₃* × Z₅ の1要素を表す計算単位。
  g    : Z₁₃* の元 (1..12)
  tau  : Z₅   の元 (0..4)
  level: フラクタル段 (0=最上位, 増えるほど細粒度)

phase_index(g, tau) = (pentagon_index(g)*STEP_Z12 + tau*STEP_Z5) % BASE

フラクタルエンジン:
  B13Fractal: n_levels 段の桁列を持つ全60セルの集合。
  step(): 指定の加算値を全セルに加算し、crossing/carry を収集する。

設計原則:
  cos/sin を計算しない。整数加算のみ。
  carry が macro-fire = 上位レベルへ +1 を伝播。
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from .constants import BASE, STEP_Z12, STEP_Z5, STEP_Z13, Z13_STAR
from .z13_structure import coset_of, pentagon_index, is_forbidden
from .fractal_engine import (digits_add_trace, digits_inc_trace,
                              AddResult, CrossingEvent, crossing_thresholds)
from .connection import propagate_carry as _conn_propagate


# ─────────────────────────────────────────────
# B13セル (単体)
# ─────────────────────────────────────────────

@dataclass
class B13Cell:
    """
    Z₁₃* × Z₅ の1要素。

    Attributes:
        g   : Z₁₃* の元 (1..12)
        tau : Z₅   の元 (0..4)
    """
    g:   int   # 1..12
    tau: int   # 0..4

    def __post_init__(self):
        if not (1 <= self.g <= 12):
            raise ValueError(f"g must be in 1..12, got {self.g}")
        if not (0 <= self.tau <= 4):
            raise ValueError(f"tau must be in 0..4, got {self.tau}")

    @property
    def coset(self) -> str:
        """H / 2H / 4H"""
        return coset_of(self.g)

    @property
    def pentagon_k(self) -> int:
        """pentagon インデックス k (0..11)"""
        return pentagon_index(self.g)

    @property
    def phase_index(self) -> int:
        """局所位相インデックス [0, BASE)"""
        return (self.pentagon_k * STEP_Z12 + self.tau * STEP_Z5) % BASE

    @property
    def is_forbidden(self) -> bool:
        """g が 4H (禁止帯) に属するか"""
        return is_forbidden(self.g)

    def __repr__(self) -> str:
        return (f"B13Cell(g={self.g}[{self.coset}], τ={self.tau}, "
                f"phase={self.phase_index})")


def all_cells() -> List[B13Cell]:
    """Z₁₃* × Z₅ の全60セルを返す (k=0..11, τ=0..4 順)。"""
    cells = []
    for k in range(12):
        g = Z13_STAR[k]
        for tau in range(5):
            cells.append(B13Cell(g=g, tau=tau))
    return cells


# ─────────────────────────────────────────────
# ステップ結果
# ─────────────────────────────────────────────

@dataclass
class StepEvent:
    """1ステップで1セルに起きたイベント。"""
    cell:        B13Cell
    add_result:  AddResult
    carry_up:    int          # 上位レベルへ伝播する carry (0 or 1)

    @property
    def micro_fires(self) -> List[CrossingEvent]:
        return self.add_result.crossings

    @property
    def macro_fired(self) -> bool:
        return bool(self.add_result.macro_fires)

    def summary(self) -> str:
        micro = len(self.micro_fires)
        macro = " +MACRO" if self.macro_fired else ""
        arcs  = [ev.threshold.arc for ev in self.micro_fires]
        return (f"{self.cell} micro={micro}{macro}"
                + (f" arcs={arcs}" if arcs else ""))


# ─────────────────────────────────────────────
# B13フラクタル (多段)
# ─────────────────────────────────────────────

@dataclass
class B13Fractal:
    """
    n_levels 段の桁列を持つ全60セルのフラクタルエンジン。

    state[cell_id] = [d_0, d_1, ..., d_{n-1}]  (MSD→LSD)
    cell_id = k * 5 + tau  (k=pentagon_index(g), tau∈Z₅)

    step(add_vec):
        add_vec: {cell_id: [add_digits]} の辞書、または全セル共通の桁列
        各セルに add_vec を digits_add_trace で加算
        macro-fire → 上位レベルへ carry+1 を伝播
    """
    n_levels: int
    cells:    List[B13Cell]           = field(default_factory=all_cells)
    state:    Dict[int, List[int]]    = field(default_factory=dict)

    def __post_init__(self):
        if not self.state:
            # 全セルをゼロ初期化
            for cell in self.cells:
                cid = self._cell_id(cell)
                self.state[cid] = [0] * self.n_levels

    @staticmethod
    def _cell_id(cell: B13Cell) -> int:
        return cell.pentagon_k * 5 + cell.tau

    def get_digits(self, cell: B13Cell) -> List[int]:
        return self.state[self._cell_id(cell)]

    def phase_proj(self, cell: B13Cell) -> int:
        """現在の最下位桁の幾何位相 (proj: d mod BASE)。"""
        return self.state[self._cell_id(cell)][-1]

    def step_cell(
        self,
        cell:       B13Cell,
        add_digits: List[int],
    ) -> StepEvent:
        """
        1セルに add_digits を加算し、StepEvent を返す。
        macro-fire が起きた場合、上位レベルへの +1 伝播は呼び出し側が処理。
        """
        cid     = self._cell_id(cell)
        current = self.state[cid]
        result  = digits_add_trace(current, add_digits)
        self.state[cid] = result.digits
        return StepEvent(cell=cell, add_result=result, carry_up=int(bool(result.macro_fires)))

    def step_all(
        self,
        add_digits: List[int],
    ) -> List[StepEvent]:
        """
        全60セルに同じ add_digits を加算する。
        macro-fire が起きたセルは上位レベルへ carry を伝播。

        Returns:
            List[StepEvent] — 全セルのイベント一覧
        """
        events = []
        for cell in self.cells:
            ev = self.step_cell(cell, add_digits)
            events.append(ev)

            # macro-fire → 隣接セルへ carry 伝播
            if ev.macro_fired:
                self._propagate_carry(cell)

        return events

    def _propagate_carry(self, cell: B13Cell) -> None:
        """
        macro-fire 後、隣接セルへ +1 を伝播する。
        connection.py の propagate_carry() で接続先を決定。
        """
        targets = _conn_propagate(cell.g, cell.tau, amount=1)
        for g2, tau2, amt in targets:
            # 伝播先セルを探す
            target_cell = next(
                (c for c in self.cells if c.g == g2 and c.tau == tau2), None
            )
            if target_cell is None:
                continue
            cid2 = self._cell_id(target_cell)
            # 最下位桁に +1 を加算 (再帰的carry は digits_add_trace が処理)
            add_b = [0] * (self.n_levels - 1) + [amt]
            result = digits_add_trace(self.state[cid2], add_b)
            self.state[cid2] = result.digits
            # 伝播先でもmacro-fireが起きたら再帰伝播 (1段のみ)
            if result.carry_out:
                self._propagate_carry(target_cell)

    def coset_distribution(self) -> Dict[str, int]:
        """現在の全セルのcoset分布。"""
        dist = {"H": 0, "2H": 0, "4H": 0}
        for cell in self.cells:
            c = cell.coset
            if c in dist:
                dist[c] += 1
        return dist

    def firing_summary(self, events: List[StepEvent]) -> Dict:
        """StepEvent リストから発火統計を集計。"""
        total_micro = sum(len(ev.micro_fires) for ev in events)
        total_macro = sum(1 for ev in events if ev.macro_fired)
        by_arc = {}
        for ev in events:
            for cf in ev.micro_fires:
                arc = cf.threshold.arc
                by_arc[arc] = by_arc.get(arc, 0) + 1
        by_coset = {"H": 0, "2H": 0, "4H": 0}
        for ev in events:
            if ev.micro_fires:
                c = ev.cell.coset
                if c in by_coset:
                    by_coset[c] += len(ev.micro_fires)
        return {
            "total_micro": total_micro,
            "total_macro": total_macro,
            "by_arc":      by_arc,
            "by_coset":    by_coset,
        }

"""
phase_packed_u64.py
===================
Exact radix-BASE (BASE=3120) phase for the "single-machine-word" case.

Since BASE=3120 < 2^12, each digit fits in 12 bits.
Therefore we can pack 5 digits into uint64 (12*5=60 bits).

This gives a compact, fast representation:
- exactly 5 radix digits in one 64-bit word
- exact digit-wise addition with carry (radix-BASE)
"""

from __future__ import annotations
from typing import List, Tuple
from .constants import BASE

BITS_PER_DIGIT: int = 12
MASK: int = (1 << BITS_PER_DIGIT) - 1
U64_DIGITS: int = 5  # 12*5=60 bits, fits in uint64


def pack_u64_digits(d: List[int]) -> int:
    """Pack 5 digits (MSD->LSD) into a single integer."""
    if len(d) != U64_DIGITS:
        raise ValueError(f"expected {U64_DIGITS} digits")
    x = 0
    for v in d:
        if v < 0 or v >= BASE:
            raise ValueError("digit out of range")
        x = (x << BITS_PER_DIGIT) | v
    return x


def unpack_u64_digits(x: int) -> List[int]:
    """Unpack packed integer into 5 digits (MSD->LSD)."""
    d = [0] * U64_DIGITS
    for i in range(U64_DIGITS - 1, -1, -1):
        d[i] = x & MASK
        x >>= BITS_PER_DIGIT
    for v in d:
        if v >= BASE:
            raise ValueError("packed digit exceeds BASE-1; invalid packed value")
    return d


def add_u64_packed(a: int, b: int) -> Tuple[int, int]:
    """
    Add two packed u64 phases in radix-BASE, exact.
    Returns (packed_sum, carry_out).
    """
    da = unpack_u64_digits(a)
    db = unpack_u64_digits(b)
    out = [0] * U64_DIGITS
    carry = 0
    for i in range(U64_DIGITS - 1, -1, -1):
        s = da[i] + db[i] + carry
        if s >= BASE:
            s -= BASE
            carry = 1
        else:
            carry = 0
        out[i] = s
    return pack_u64_digits(out), carry


def sub_u64_packed(a: int, b: int) -> Tuple[int, int]:
    """
    Subtract b from a in radix-BASE, exact.
    Returns (packed_diff, borrow_out).
    """
    da = unpack_u64_digits(a)
    db = unpack_u64_digits(b)
    out = [0] * U64_DIGITS
    borrow = 0
    for i in range(U64_DIGITS - 1, -1, -1):
        d = da[i] - db[i] - borrow
        if d < 0:
            d += BASE
            borrow = 1
        else:
            borrow = 0
        out[i] = d
    return pack_u64_digits(out), borrow


def negate_u64_packed(a: int) -> int:
    """Negate packed phase (BASE^5 - a)."""
    if a == 0:
        return 0
    da = unpack_u64_digits(a)
    out = [(BASE - 1 - v) for v in da]
    # add 1
    carry = 1
    for i in range(U64_DIGITS - 1, -1, -1):
        s = out[i] + carry
        if s >= BASE:
            out[i] = s - BASE
            carry = 1
        else:
            out[i] = s
            carry = 0
    return pack_u64_digits(out)

"""
fib_drive.py
============
Fib/Pell-drive エンジン — coneFFT の入力シーケンス生成。

設計:
  ステップn の加算量 = seq(n mod period) * STEP_Z13
  seq: Fib mod13 または Pell mod13

ドライブモード (核54/57):
  モードA: F(n)=0 → BASE を加算 (「クロック付き」, ゼロ位置でリセット1周)
  モードB: F(n)=0 をスキップ (「休止なし」, 実効ステップ数で周期を数える)
  モードC: F(n)=0 をそのまま (状態不変ステップ含む, モードBと実効的に同一)

確定周期 (核53, 54):
  Uniform drive (STEP_Z13): 1039 [H帯素数]
  Fib モードA n_levels=1:  139  [4H帯素数]
  Pell モードA n_levels=1: 139  [4H帯素数]  ← Fib=Pell (核57)
  Fib モードB n_levels=1:  157  [H帯素数]
  Pell モードB n_levels=1: 162  [4H帯]

核57: Fib mod13 = Pell mod13 の1周期(28項)multisetが完全一致
  0: 4回, H帯{1,5,8,12}: 各4回, 2H帯{2,3,10,11}: 各2回, 4H帯: 0回
  → 4H帯を代数的に完全回避 (「Fib/Pell は 4H を踏まない」の証明)

coset接続比率 (核55/56):
  H→4H: 3.3%,  4H→4H: 83.3%
  → H/2H帯macro-fireのcarryは主にH/2H帯に集中
"""
from __future__ import annotations
from typing import List, Optional, Dict, NamedTuple
from .constants import BASE, STEP_Z13
from .z13_structure import fib_mod13, pell_mod13
from .cell import B13Fractal, StepEvent

# Fib/Pell mod13 の周期
SEQ_PERIOD: int = 28

# 確定周期 (核53, 54) — LSD射影周期
UNIFORM_PERIOD:      int = 1039  # uniform drive, carry有効
FIB_PERIOD_A:        int = 139   # Fib モードA, n_levels=1
PELL_PERIOD_A:       int = 139   # Pell モードA, n_levels=1 (= FIB_PERIOD_A, 核57)
FIB_PERIOD_B:        int = 157   # Fib モードB (skip-zero), n_levels=1
PELL_PERIOD_B:       int = 162   # Pell モードB (skip-zero), n_levels=1

# フル状態周期 (n_levels=2) — 未確定
# アトラクタ上でMSDは79or80/LSD周期増加 (Sturmian列)
# LSD周期139は正確だがフル周期(全桁)は天文学的に大きい
# → FIB_FULL_PERIOD_A_N2 は計算誤りにつき削除 (v76で撤回)

# 後方互換エイリアス
FIB_PERIOD_CARRY_OFF = FIB_PERIOD_A
FIB_PERIOD_SKIP      = FIB_PERIOD_B
# アトラクタ構造定数 (核61) — Fib A n_levels=2, 標準初期条件
# アトラクタ上のLSD60個は BASE/60=52 間隔の等間隔格子を形成
# LSD[k] = (phase_index[k] + ATTRACTOR_LSD_OFFSET) mod BASE ± 2
ATTRACTOR_LSD_STEP:   int = BASE // 60   # = 52 = BASE/VERTICES
ATTRACTOR_LSD_OFFSET: int = 738          # = 14×52 + 10
ATTRACTOR_LSD_MIN:    int = 10           # アトラクタ上の最小LSD値
ATTRACTOR_MSD_HIGH_N: int = 14           # MSD高グループ数 = offset//52 mod 60
ATTRACTOR_MSD_LOW_N:  int = 46           # MSD低グループ数 = 60 - 14


def fib_step(n: int, mode: str = 'B') -> int:
    """
    ステップn の Fib-drive 加算量を返す。
    mode='A': F(n)=0 → BASE, mode='B'/'C': 通常
    """
    v = fib_mod13(n % SEQ_PERIOD)
    if v == 0 and mode == 'A':
        return BASE
    return (v * STEP_Z13) % BASE


def pell_step(n: int, mode: str = 'B') -> int:
    """ステップn の Pell-drive 加算量を返す。"""
    v = pell_mod13(n % SEQ_PERIOD)
    if v == 0 and mode == 'A':
        return BASE
    return (v * STEP_Z13) % BASE


class DriveResult(NamedTuple):
    """1ステップのドライブ結果。"""
    step_index:  int
    seq_n:       int          # 数列のインデックス (skip時はstep_indexと異なる)
    step_amount: int          # 実際の加算量
    events:      List[StepEvent]
    n_micro:     int
    n_macro:     int
    by_arc:      Dict[str, int]
    by_coset:    Dict[str, int]


class FibDriveEngine:
    """
    Fib/Pell-drive モードの coneFFT エンジン。

    モード (核54/57):
      'A': F(n)=0 → BASE を加算 (クロック付き, 周期139/139)
      'B': F(n)=0 をスキップ   (休止なし,   周期157/162)
      'C': F(n)=0 をゼロ加算   (休止あり,   実効はBと同じ)

    Usage:
        engine = FibDriveEngine(mode='A', n_levels=1)
        p = engine.find_period()       # → 139
        engine.reset()
        for result in engine.run(139):
            print(result.step_index, result.n_micro, result.by_arc)
    """

    def __init__(
        self,
        n_levels: int = 2,
        mode: str = 'B',
        use_pell: bool = False,
        skip_zero: bool = None,        # 後方互換: True→mode='B', False→mode='C'
        init_from_phase_index: bool = True,
    ):
        if skip_zero is not None:      # 旧 API との互換
            mode = 'B' if skip_zero else 'C'

        self.n_levels    = n_levels
        self.mode        = mode
        self.use_pell    = use_pell
        self.fractal     = B13Fractal(n_levels=n_levels)
        self._seq_n      = 0
        self._step_index = 0

        if init_from_phase_index:
            self._init_state()

    def _init_state(self) -> None:
        """各セルの初期状態を phase_index で設定。"""
        for cell in self.fractal.cells:
            cid = self.fractal._cell_id(cell)
            self.fractal.state[cid] = (
                [cell.phase_index] if self.n_levels == 1
                else [0] * (self.n_levels - 1) + [cell.phase_index]
            )

    def reset(self) -> None:
        """エンジンを初期状態にリセット。"""
        self.fractal     = B13Fractal(n_levels=self.n_levels)
        self._seq_n      = 0
        self._step_index = 0
        self._init_state()

    def _next_seq_value(self) -> int:
        """次の数列値を返す。モードBではゼロをスキップ。"""
        seq = pell_mod13 if self.use_pell else fib_mod13
        while True:
            v = seq(self._seq_n % SEQ_PERIOD)
            self._seq_n += 1
            if not (self.mode == 'B' and v == 0):
                return v

    def step(self) -> DriveResult:
        """1ステップ実行して DriveResult を返す。"""
        seq_val    = self._next_seq_value()
        seq_n_used = self._seq_n - 1

        if self.mode == 'A' and seq_val == 0:
            amount = BASE                       # クロックパルス: 全セル +1周
        else:
            amount = (seq_val * STEP_Z13) % BASE

        add_vec = [0] * (self.n_levels - 1) + [amount]
        events  = self.fractal.step_all(add_vec)
        summary = self.fractal.firing_summary(events)

        result = DriveResult(
            step_index  = self._step_index,
            seq_n       = seq_n_used,
            step_amount = amount,
            events      = events,
            n_micro     = summary["total_micro"],
            n_macro     = summary["total_macro"],
            by_arc      = summary["by_arc"],
            by_coset    = summary["by_coset"],
        )
        self._step_index += 1
        return result

    def run(self, n_steps: int):
        """n_steps ステップ実行して DriveResult をyieldする。"""
        for _ in range(n_steps):
            yield self.step()

    def state_hash(self) -> tuple:
        """
        全セルの最下位桁(LSD)のtuple。LSD射影周期の検出に使用。

        n_levels=1 ではフル状態と同一。
        n_levels≥2 では上位桁を無視した射影 → LSD周期を返す。
        フル状態周期の検出には full_state_hash() を使うこと。
        """
        return tuple(
            self.fractal.state[self.fractal._cell_id(c)][-1]
            for c in self.fractal.cells
        )

    def full_state_hash(self) -> tuple:
        """
        全セル全桁のtuple。フル状態周期の検出に使用。

        n_levels=1 では state_hash() と同一。
        n_levels=2: アトラクタ上でMSDはSturmian的に増加するため
                    フル状態周期は非常に大きく実用的には測定不可能。
                    LSD射影周期 (state_hash) の利用を推奨。
        """
        return tuple(
            v
            for c in self.fractal.cells
            for v in self.fractal.state[self.fractal._cell_id(c)]
        )

    def find_period(self, max_steps: int = 50000) -> Optional[int]:
        """
        状態周期を探索して返す。見つからなければ None。

        - step_amount=0 (モードCのゼロ) は状態を変えないため除外。
        - 周期は実効ステップ数 (amount != 0) で数える。
        - モードAでは BASE 加算もカウント対象。
        """
        seen: Dict[tuple, int] = {}
        n_eff = 0
        for _ in range(max_steps):
            sh = self.state_hash()
            if sh in seen:
                return n_eff - seen[sh]
            result = self.step()
            if result.step_amount != 0:
                seen[sh] = n_eff
                n_eff += 1
        return None

    def clone(self) -> "FibDriveEngine":
        """現在の状態を完全コピーした新エンジンを返す。"""
        import copy
        return copy.deepcopy(self)

    def set_state(self, state_snapshot: Dict[int, List[int]]) -> None:
        """state_snapshot (cell_id → digits) を現エンジンに適用する。"""
        import copy
        self.fractal.state = copy.deepcopy(state_snapshot)
        self._seq_n      = 0
        self._step_index = 0

    def perturb(self, cell_index: int, digit_pos: int, delta: int) -> None:
        """
        cell_index 番目のセル (0..59) の digit_pos 桁に delta を加算する。
        digit_pos: 0=MSD, n_levels-1=LSD
        摂動後の find_period / measure_transient で効果を検証する。
        """
        cell = self.fractal.cells[cell_index]
        cid  = self.fractal._cell_id(cell)
        st   = self.fractal.state[cid]
        st[digit_pos] = (st[digit_pos] + delta) % BASE
        self.fractal.state[cid] = st

    def measure_transient(
        self,
        period:    Optional[int] = None,
        max_steps: int = 50000,
    ) -> Optional[int]:
        """
        Floyd法でアトラクタへのtransientを測定して返す。

        アトラクタ判定: state_hash(t) == state_hash(t + period) となる最小 t。
        period が None の場合は find_period() で自動検出する。
        見つからなければ None。

        注意: このメソッドはエンジンの状態を進める（破壊的）。
              呼び出し前に clone() でコピーを取ること。
        """
        import copy
        if period is None:
            eng_p = self.clone()
            period = eng_p.find_period(max_steps=max_steps)
            if period is None:
                return None

        eng_ref = self.clone()
        for _ in range(period):
            eng_ref.step()

        for t in range(max_steps):
            if self.state_hash() == eng_ref.state_hash():
                return t
            self.step()
            eng_ref.step()
        return None

    def attractor_info(self, max_steps: int = 50000) -> Dict:
        """
        現在の初期状態からアトラクタ情報（周期・transient）を返す。

        Returns:
            dict with keys: period, transient, mode, n_levels, seq
        """
        eng = self.clone()
        period    = eng.find_period(max_steps=max_steps)
        eng2      = self.clone()
        transient = eng2.measure_transient(period=period, max_steps=max_steps)
        return {
            "period":    period,
            "transient": transient,
            "mode":      self.mode,
            "n_levels":  self.n_levels,
            "seq":       "Pell" if self.use_pell else "Fib",
        }

    def firing_stats(self, n_steps: int) -> Dict:
        """
        n_steps ステップの発火統計を集計して返す。
        """
        stats = {
            "n_steps":    0,
            "n_eff":      0,
            "total_micro": 0,
            "total_macro": 0,
            "by_arc":     {},
            "by_coset":   {},
            "by_mode":    self.mode,
        }
        for result in self.run(n_steps):
            stats["n_steps"]     += 1
            if result.step_amount != 0:
                stats["n_eff"]   += 1
            stats["total_micro"] += result.n_micro
            stats["total_macro"] += result.n_macro
            for arc, cnt in result.by_arc.items():
                stats["by_arc"][arc] = stats["by_arc"].get(arc, 0) + cnt
            for coset, cnt in result.by_coset.items():
                stats["by_coset"][coset] = stats["by_coset"].get(coset, 0) + cnt
        return stats

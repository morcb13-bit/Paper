"""検定3：2^a φ^b の倍率の刻み。大小は Z[φ] の整数だけで決める。"""
from functools import cmp_to_key, lru_cache
import math

@lru_cache(None)
def phipow(b):          # φ^b = p + qφ
    if b == 0: return (1, 0)
    if b > 0:
        p, q = phipow(b - 1); return (q, p + q)          # (p+qφ)φ = q + (p+q)φ
    p, q = phipow(b + 1); return (q - p, p)              # (p+qφ)(φ−1) = (q−p) + pφ

def sign(p, q):         # p + qφ の符号
    s = 2 * p + q
    if s >= 0 and q >= 0: return (s > 0 or q > 0) - 0
    if s <= 0 and q <= 0: return -1 if (s < 0 or q < 0) else 0
    d = s * s - 5 * q * q                                # 符号が分かれるとき
    return (1 if s > 0 else -1) if d > 0 else ((-1 if s > 0 else 1) if d < 0 else 0)

def diff(x, y, kx=1, ky=1):
    """kx·x − ky·y の符号。x=(a,b) は 2^a φ^b。"""
    (a, b), (c, d) = x, y
    m = min(a, c)
    p1, q1 = phipow(b); p2, q2 = phipow(d)
    s1 = kx << (a - m); s2 = ky << (c - m)
    return sign(s1 * p1 - s2 * p2, s1 * q1 - s2 * q2)

ONE, TWO = (0, 0), (1, 0)

def members(N, signed):
    out = set()
    for a in range(-N, N + 1):
        for b in range(-(N - abs(a)), N - abs(a) + 1):
            if not signed and (a < 0 or b < 0): continue
            if diff((a, b), ONE) > 0 and diff((a, b), TWO) <= 0:
                out.add((a, b))
    # 同じ値（2^1 φ^0 と 2^1 などは無い。φ^b=2^a は b=a=0 だけ）
    return sorted(out, key=cmp_to_key(diff))

def val(x): return 2.0 ** x[0] * ((1 + 5 ** .5) / 2) ** x[1]   # 表示用

def gap_le(x, y, K, M):   # y/x − 1 ≤ K/M か（整数）
    return diff(y, x, M, M + K) <= 0

print("## (i) a,b ≥ 0")
for N in (5, 10, 20, 40):
    L = members(N, False)
    print(f"N≤{N}: (1,2] に {len(L)} 個", [f"{x}→{val(x):.4f}" for x in L[:4]])

print("\n## (ii) 符号を問わない")
print("| N≤ | (1,2] の個数 | 最小の z | その (a,b) | 最大の刻み | 1e-2 | 1e-3 | 1e-4 |")
print("|---|---|---|---|---|---|---|---|")
for N in (5, 10, 20, 30, 40, 60, 80, 100, 140, 200, 280):
    L = [ONE] + members(N, True)
    first = L[1]
    gaps = list(zip(L, L[1:]))
    worst = max(gaps, key=lambda g: val(g[1]) / val(g[0]))
    ok = [all(gap_le(x, y, 1, M) for x, y in gaps) for M in (100, 1000, 10000)]
    print(f"| {N} | {len(L)-1} | {val(first)-1:.5f} | {first} | {val(worst[1])/val(worst[0])-1:.5f} |"
          + "".join(" 下回る |" if o else " — |" for o in ok))

print("\n## 2^a と φ^b が近い組（連分数の近似、整数で最良を更新）")
best = None
for b in range(1, 400):
    a = round(b * math.log((1 + 5 ** .5) / 2) / math.log(2))   # 候補の a（表示用の見当）
    for aa in (a - 1, a, a + 1):
        r = val((-aa, b))
        e = abs(math.log(r))
        if best is None or e < best:
            best = e; print(f"φ^{b} / 2^{aa} = {r:.6f}")

"""検定2：正五胞体ギャスケットの影の上の空き。整数と真偽値だけで数える。"""
import itertools, sys
import numpy as np

EULER = {2: [1, 1], 3: [1, 4, 1], 4: [1, 11, 11, 1]}
W = {"W1": (6774, 6920), "W2": (6833, 6945)}

def bases(nv, d):
    out = []
    for cs in itertools.product(range(nv), repeat=d):
        b = [0] * nv
        for j, c in enumerate(cs):
            b[c] += 1 << j
        out.append(tuple(b))
    return out

def covered(Bs, L, T, m):
    """覆われる体積（小さな上向き単体を 1 とする）。Bs は m 桁の基点、写しの辺は L、全体の辺は T。"""
    ind = np.zeros((T,) * m, dtype=bool)
    for B in Bs:
        assert sum(B) + L == T
        ind[B] = True
    for ax in range(m):
        ind = np.logical_or.accumulate(ind, axis=ax)
    grids = np.indices((T,) * m).sum(axis=0)
    n = m - 1
    V = 0
    for k, w in enumerate(EULER[n], start=1):
        V += w * int(np.count_nonzero(ind & (grids == T - k)))
    return V, T ** n

def proj(name, b, d):
    x0, x1, x2, x3, x4 = b
    if name == "3a": return (x0, x1, x2, x3 + x4), 1, 1 << d
    if name == "3b": return (4*x0+x4, 4*x1+x4, 4*x2+x4, 4*x3+x4), 4, 4 << d
    if name == "2a": return (x0, x1, x2 + x3 + x4), 1, 1 << d
    if name == "2b": return (x0, x1 + x2, x3 + x4), 1, 1 << d
    if name == "2c": return (3*x0+x3+x4, 3*x1+x3+x4, 3*x2+x3+x4), 3, 3 << d
    if name == "id4": return b, 1, 1 << d

def inwin(num, den):   # 空き num/den が窓に入るか（整数の比較）
    return [w for w, (lo, hi) in W.items() if lo * den <= 10000 * num <= hi * den]

def run(name, dmax, gen=None):
    print(f"\n### {name}")
    print("| 段 | 覆われる/全体 | 空き | 1段の空き | 窓 |")
    print("|---|---|---|---|---|")
    prev = None
    for d in range(1, dmax + 1):
        if gen:
            Bs = gen(d); L = 1; T = 1 << d; m = len(Bs[0])
        else:
            res = [proj(name, b, d) for b in bases(5, d)]
            Bs = sorted(set(r[0] for r in res)); L = res[0][1]; T = res[0][2]; m = len(Bs[0])
        V, A = covered(Bs, L, T, m)
        s = f"| {d} | {V}/{A} | {100*(A-V)/A:.2f}% |"
        if prev:
            Vp, Ap = prev
            num = A * Vp - V * Ap; den = A * Vp     # 1 − (V/A)/(Vp/Ap)
            s += f" {100*num/den:.2f}% | {','.join(inwin(num, den)) or '—'} |"
        else:
            s += " — | — |"
        print(s); sys.stdout.flush()
        prev = (V, A)

run("id4", 4)
run("3次元ギャスケット（影なし）", 5, gen=lambda d: bases(4, d))
run("3a", 6); run("3b", 4)
run("2a", 6); run("2b", 6); run("2c", 6)

"""検定A・B：ノルムの最小と実際の大きさの最小。判定は整数だけ。"""
from math import isqrt
import itertools

# 実数の世界：x = a + bθ を「(2a + b·t0) + b·t1·√d」/den の形で持つ（den=2 で φ も整数に）
# φ = (1+√5)/2 → 2x = (2a+b) + b√5 ;  √d → x = a + b√d
REAL = {
    "Z[φ]": dict(d=5, norm=lambda a, b: a*a + a*b - b*b, half=True),
    "Z[√2]": dict(d=2, norm=lambda a, b: a*a - 2*b*b, half=False),
    "Z[√3]": dict(d=3, norm=lambda a, b: a*a - 3*b*b, half=False),
}
CPLX = {
    "Z[i]": lambda a, b: a*a + b*b,
    "Z[ω]": lambda a, b: a*a - a*b + b*b,
}

def sgn(p, q, d):      # p + q√d の符号
    if p >= 0 and q >= 0: return 1 if (p or q) else 0
    if p <= 0 and q <= 0: return -1
    t = p*p - d*q*q
    if t == 0: return 0
    return (1 if p > 0 else -1) if t > 0 else (1 if q > 0 else -1)

def pq(R, a, b):       # x を k·x = p + q√d の (p, q, k) に
    return (2*a + b, b, 2) if R["half"] else (a, b, 1)

def lt_inv(R, a, b, M):   # |x| < 1/M ?
    p, q, k = pq(R, a, b)
    # −k < M·k·x < k  ⇔  M·p + k > −…  : M·(p+q√d) − k < 0 かつ M·(p+q√d) + k > 0
    return sgn(M*p - k, M*q, R["d"]) < 0 and sgn(M*p + k, M*q, R["d"]) > 0

def abs_lt(R, x, y):      # |x| < |y| ? （x² − y² = (x−y)(x+y) の符号）
    (p1, q1, _), (p2, q2, _) = pq(R, *x), pq(R, *y)
    s1 = sgn(p1 - p2, q1 - q2, R["d"]); s2 = sgn(p1 + p2, q1 + q2, R["d"])
    return s1 * s2 < 0

def near(R, b, conj):     # −bθ（conj なら −bθ̄）の近くの a 候補
    s = isqrt(R["d"] * b * b) * (1 if b >= 0 else -1)
    if conj: s = -s
    c = -(b + s) // 2 if R["half"] else -s
    return range(c - 2, c + 3)

def val(R, a, b):          # 表示用
    t = (1 + 5 ** .5) / 2 if R["half"] else R["d"] ** .5
    return a + b * t

def run_real(name, R, B):
    best = (1, 0); units = set(); mnorm = None
    for b in range(-B, B + 1):
        for conj in (False, True):
            for a in near(R, b, conj):
                if abs(a) > B or (a, b) == (0, 0): continue
                n = R["norm"](a, b)
                mnorm = abs(n) if mnorm is None else min(mnorm, abs(n))
                if abs(n) == 1: units.add((a, b))
                if not conj and abs_lt(R, (a, b), best): best = (a, b)
    return mnorm, best, R["norm"](*best), len(units)

def brute_real(R, B):
    best = (1, 0); units = 0; mnorm = None
    for a, b in itertools.product(range(-B, B + 1), repeat=2):
        if (a, b) == (0, 0): continue
        n = abs(R["norm"](a, b)); mnorm = n if mnorm is None else min(mnorm, n)
        units += n == 1
        if abs_lt(R, (a, b), best): best = (a, b)
    return mnorm, best, R["norm"](*best), units

print("## 照合：B=100 の総当たりと候補法")
for name, R in REAL.items():
    c, d = run_real(name, R, 100), brute_real(R, 100)
    same = c[0] == d[0] and c[3] == d[3] and c[2] == d[2] and c[1] in (d[1], (-d[1][0], -d[1][1]))
    print(name, "一致（最小の元は ±x の違いだけ）" if same else ("不一致", c, d))

Bs = (10, 100, 1000, 10000)
print("\n## 実数の世界と Z")
print("| 環 | B | ノルムの最小 | 大きさの最小 | その元 (a,b) | その元のノルム | 単数の個数 | <1e-2 | <1e-3 | <1e-4 |")
print("|---|---|---|---|---|---|---|---|---|---|")
for B in Bs:
    print(f"| Z | {B} | 1 | 1 | (1,0) | 1 | 2 | — | — | — |")
for name, R in REAL.items():
    for B in Bs:
        mn, best, bn, nu = run_real(name, R, B)
        th = ["はい" if lt_inv(R, *best, M) else "—" for M in (100, 1000, 10000)]
        print(f"| {name} | {B} | {mn} | {abs(val(R, *best)):.3e} | {best} | {bn:+d} | {nu} | " + " | ".join(th) + " |")

print("\n## 複素の世界（|x|² = ノルム）")
print("| 環 | B | ノルムの最小 | 大きさの最小 | 単数の個数 |")
print("|---|---|---|---|---|")
for name, nf in CPLX.items():
    for B in (10, 100, 1000):
        mn = None; nu = 0
        for a, b in itertools.product(range(-B, B + 1), repeat=2) if B <= 100 else []:
            if (a, b) == (0, 0): continue
            n = nf(a, b); mn = n if mn is None else min(mn, n); nu += n == 1
        if B > 100:   # 正定値なので、ノルム 1 の元は |a|,|b| ≤ 2 にしかない
            mn = 1; nu = sum(1 for a, b in itertools.product(range(-2, 3), repeat=2) if nf(a, b) == 1)
        print(f"| {name} | {B} | {mn} | {'1' if mn == 1 else '?'} | {nu} |")

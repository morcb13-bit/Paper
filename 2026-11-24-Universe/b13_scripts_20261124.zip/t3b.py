"""検定3′：φ を 1 とした列の残渣 z_n と、2・3 の段を掛けたときの刻み。
倍率 X = 2^a 3^b F_{n+1} / (F_n φ)。1/φ は共通なので、大小は有理数 R = 2^a 3^b F_{n+1}/F_n で決める。
X∈(1,2] ⇔ φ < R ≤ 2φ。有理数と φ の比較は整数だけ。"""
from fractions import Fraction as Fr

F = [0, 1]
for _ in range(80): F.append(F[-1] + F[-2])
PHI = (1 + 5 ** .5) / 2  # 表示用だけ

def gt_phi(R, k=1):      # R > kφ ?   P/Q > kφ ⇔ 2P − kQ > kQ√5
    P, Q = R.numerator, R.denominator
    s = 2 * P - k * Q
    return s > 0 and s * s > 5 * k * k * Q * Q

def rel_le(x, y, K, M):  # y/x − 1 ≤ K/M（x, y は有理数）
    return M * y <= (M + K) * x

print("## 基準3：z_n = F_{n+1}/(F_n φ) − 1")
need = {100: None, 1000: None, 10000: None}
for n in range(1, 30):
    R = Fr(F[n + 1], F[n])
    # |R/φ − 1| < 1/M ⇔ φ(M−1)/M < R < φ(M+1)/M
    for M in need:
        if need[M] is None and gt_phi(R * M, M - 1) and not gt_phi(R * M, M + 1):
            need[M] = n
    if n <= 12: print(n, f"{float(R)/PHI-1:+.6f}")
print("|z_n| < 1/M となる最初の n:", need)

print("\n## 基準4：2^a 3^b を掛けて (1,2] を埋める（一歩の数 |a|+|b|+n ≤ N）")
print("| N≤ | 個数 | 最大の刻み | 1e-2 | 1e-3 | 1e-4 |")
print("|---|---|---|---|---|---|")
for N in (4, 6, 8, 10, 12, 14, 16, 20, 24):
    S = set()
    for n in range(1, N + 1):
        base = Fr(F[n + 1], F[n])
        r = N - n
        for a in range(-r, r + 1):
            for b in range(-(r - abs(a)), r - abs(a) + 1):
                R = base * Fr(2) ** a * Fr(3) ** b
                if gt_phi(R) and not gt_phi(R, 2):
                    S.add(R)
    L = sorted(S)
    gaps = list(zip(L, L[1:]))
    worst = max((y / x for x, y in gaps), default=None)
    ok = [all(rel_le(x, y, 1, M) for x, y in gaps) for M in (100, 1000, 10000)]
    print(f"| {N} | {len(L)} | {float(worst)-1:.5f} |" + "".join(" 下回る |" if o else " — |" for o in ok))

"""動く図のデータ。順序と最大の刻みは有理数（整数）で決め、座標だけ浮動小数にする。"""
import json
from fractions import Fraction as Fr
F = [0, 1]
for _ in range(60): F.append(F[-1] + F[-2])
PHI = (1 + 5 ** .5) / 2

def gt_phi(R, k=1):
    P, Q = R.numerator, R.denominator
    s = 2 * P - k * Q
    return s > 0 and s * s > 5 * k * k * Q * Q

fill = {}
for N in (4, 6, 8, 10, 12, 14, 16, 20, 24):
    S = {}
    for n in range(1, N + 1):
        base = Fr(F[n + 1], F[n]); r = N - n
        for a in range(-r, r + 1):
            for b in range(-(r - abs(a)), r - abs(a) + 1):
                R = base * Fr(2) ** a * Fr(3) ** b
                if gt_phi(R) and not gt_phi(R, 2):
                    if R not in S or S[R][2] > abs(a) + abs(b) + n:
                        S[R] = (a, b, abs(a) + abs(b) + n, n)
    L = sorted(S)
    gi = max(range(len(L) - 1), key=lambda i: L[i + 1] / L[i])   # 有理数の比較で最大の刻み
    fill[N] = {"x": [round(float(R) / PHI, 6) for R in L],
               "lab": [f"2^{S[R][0]}·3^{S[R][1]}·F{S[R][3]+1}/(F{S[R][3]}φ)" for R in L],
               "gi": gi, "gap": round(float(L[gi + 1] / L[gi]) - 1, 5)}
data = {"F": F[:30], "fill": fill}
json.dump(data, open('data.json', 'w'), ensure_ascii=False)
print({N: (len(v["x"]), v["gap"]) for N, v in fill.items()})

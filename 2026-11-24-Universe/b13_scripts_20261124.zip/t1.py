"""検定1：負の対照。判定は整数と掛け算の比較だけ（表示の％だけ浮動小数）。"""
W = {"W1": (6774, 6920), "W2": (6833, 6945)}

def fams(n):
    p2, p3 = 2 ** n, 3 ** n
    yield "単体", p2, n + 1
    yield "カントール", p3, p2
    yield "メンガー", p3, p2 + n * 2 ** (n - 1)
    yield "ヴィチェク", p3, 1 + 2 * n

def hit(m, k):
    v = 10000 * (m - k)
    return [w for w, (lo, hi) in W.items() if lo * m <= v <= hi * m]

print("## 主判定（1段）")
print("| 形 | 次元 | 残り/全体 | 空き | 窓 |")
print("|---|---|---|---|---|")
main = []
for n in range(1, 9):
    for name, m, k in fams(n):
        h = hit(m, k)
        if h:
            main.append((name, n))
        if n <= 6 or h:
            print(f"| {name} | {n} | {k}/{m} | {100*(m-k)/m:.2f}% | {','.join(h) or '—'} |")
print("\n主判定で窓に入ったもの:", main)

print("\n## 副判定（d段まとめ、d=2..6）")
sub = []
for n in range(1, 9):
    for name, m, k in fams(n):
        if k in (0, m):
            continue
        for d in range(2, 7):
            M, K = m ** d, k ** d
            h = hit(M, K)
            if h:
                sub.append((name, n, d, f"{100*(M-K)/M:.2f}%", ",".join(h)))
for s in sub:
    print(s)

"""
fractal_vertex_recurrence.py
============================
Fibonacci的頂点座標の漸化式（Proposition D フラクタル展開）

【確定した定理】
  v_{n+1} = φ · R(36°_z) · v_n

  行列要素（φ算術）：
    φ·cos(36°) = φ²/2 = (φ+1)/2 = 1 + cos(72°)   [carry=1 が自動発生]
    φ·sin(36°) = sin(72°)                            [φ·√(3-φ)/2 = sin(72°)]

  BASE3120 での整数表現：
    cos(36°) → 2524,  sin(36°) → 1834
    cos(72°) → 964,   sin(72°) → 2967
    φ·cos36 mod BASE = 964 = cos(72°)  ← carry=1

【幾何的構造（確定）】
  ・極角 θ_polar は全レベルで不変（自己相似）
  ・北極帯(k=0,11):  sin(θ) = 1/(φ√3),  cos(θ) = φ/√3
  ・上下帯(k=1-10):  sin(θ) = 2/√5,     cos(θ) = 1/√5
  ・外接球半径: R_n = φⁿ · R₀,  R_n² = φ²ⁿ · (9φ+10)/4
  ・方位角:     az_n = az_0 + n×36°  (BASE3120: + n×312)

【carryとZ₅の接続（新発見）】
  φ·cos(36°) = 1 + cos(72°)  → carry = 1 per step
  carry数(mod 5) = Z₅の周回軌道インデックス
  STEP_Z5 = 624 = BASE/5 = 72°  ← level5でaz=0°に戻る

【漸化式のBASE3120完全表現】
  az_idx(level n) = az_idx(level 0) + n × 312  (mod 3120)
  R_n² = φ²ⁿ × (9φ+10)/4
  carry_n = n  (z軸周り1ステップごとに carry = 1 発生)
"""

from __future__ import annotations
import math
from typing import Tuple, List, NamedTuple

PHI: float = (1.0 + math.sqrt(5.0)) / 2.0
BASE: int = 3120

# 36°の基本量（φ算術確定）
COS36: float = PHI / 2           # = 2524/3120
SIN36: float = math.sqrt(3.0 - PHI) / 2.0  # = sin(72°)/φ... = √(3-φ)/2
# 注: sin(36°) = √(3-φ)/2  ← sin²(36°) = (3-φ)/4 = (10-2√5)/16

# φ·R(36°)の行列要素（φ算術）
# φ·cos36 = φ²/2 = 1 + cos(72°) → 整数部1=carry, 余り=cos(72°)
# φ·sin36 = sin(72°)
PHI_COS36: float = PHI**2 / 2      # = (φ+1)/2 ≈ 1.309  > 1 → carry=1
PHI_SIN36: float = math.sin(math.radians(72.0))  # = sin(72°)

# BASE3120 整数値
COS36_B: int = 2524   # round(BASE * cos36)
SIN36_B: int = 1834   # round(BASE * sin36)
COS72_B: int = 964    # round(BASE * cos72) = round(PHI_COS36 * BASE - BASE)
SIN72_B: int = 2967   # round(BASE * sin72)

# 36° の方位角インデックス
STEP_36DEG: int = 312   # = BASE // 10

# 外接球半径² (level 0, edge a=1)
R0_SQ: float = (9.0 * PHI + 10.0) / 4.0   # (9φ+10)/4
R0: float = math.sqrt(R0_SQ)

# 極角の sin/cos（各帯ごと）
# 北極帯 (k=0,11):  1+φ⁴ = 3φ²  → sin = 1/(φ√3), cos = φ/√3
SIN_THETA_POLE: float = 1.0 / (PHI * math.sqrt(3.0))   # 1/(φ√3)
COS_THETA_POLE: float = PHI / math.sqrt(3.0)             # φ/√3

# 上下帯 (k=1-10):  sin = 2/√5, cos = 1/√5  (arctan(2))
SIN_THETA_BAND: float = 2.0 / math.sqrt(5.0)   # 2/√5
COS_THETA_BAND: float = 1.0 / math.sqrt(5.0)   # 1/√5


class FractalVertex(NamedTuple):
    """フラクタルレベルnにおける頂点の完全記述"""
    level: int         # フラクタルレベル (0, 1, 2, ...)
    k: int             # 系統インデックス (0..11)
    j: int             # 五角形内局所インデックス (0..4)
    x: float           # x座標
    y: float           # y座標
    z: float           # z座標
    az_idx: int        # 方位角 BASE3120インデックス
    r_sq: float        # 外接球半径²
    carry_total: int   # 累積carry数 (= level)


def polar_angles(k: int) -> Tuple[float, float]:
    """
    系統kの極角 (sin_θ, cos_θ) を返す。
    全レベルで不変（自己相似性の核心）。

    Returns:
        (sin_theta_polar, cos_theta_polar)
    """
    if k == 0 or k == 11:
        # 北極・南極帯: sin = 1/(φ√3), cos = ±φ/√3
        sign = 1.0 if k == 0 else -1.0
        return SIN_THETA_POLE, sign * COS_THETA_POLE
    elif 1 <= k <= 5:
        # 上帯: sin = 2/√5, cos = 1/√5
        return SIN_THETA_BAND, COS_THETA_BAND
    else:
        # 下帯 (k=6..10): sin = 2/√5, cos = -1/√5
        return SIN_THETA_BAND, -COS_THETA_BAND


def base_azimuth_idx(k: int, j: int) -> int:
    """
    Level 0 における頂点(k,j)の方位角インデックス (BASE3120)。
    az_idx = (k × STEP_Z12 + j × STEP_Z5) % BASE
    """
    STEP_Z12 = 260   # = BASE // 12
    STEP_Z5  = 624   # = BASE // 5
    return (k * STEP_Z12 + j * STEP_Z5) % BASE


def level_n_azimuth_idx(k: int, j: int, n: int) -> int:
    """
    Level n における頂点(k,j)の方位角インデックス。

    漸化式: az_n = az_0 + n × 312 (mod BASE)
    36°ずつ方位角が進む（不変: 極角θ, 変化: 方位角, スケール: φⁿ）

    Returns:
        方位角インデックス (0 .. BASE-1)
    """
    az0 = base_azimuth_idx(k, j)
    return (az0 + n * STEP_36DEG) % BASE


def level_n_radius_sq(n: int) -> float:
    """
    Level n の外接球半径²。

    R_n² = φ²ⁿ × (9φ+10)/4
    R_n  = φⁿ × R₀

    拘束条件（引継書より）: R_n² = (9φ+10)/4 × φ^(2n)
    """
    return R0_SQ * (PHI ** (2 * n))


def vertex_coords(k: int, j: int, n: int = 0) -> Tuple[float, float, float]:
    """
    Level n における頂点 f(2^k mod 13, j) の3D座標。

    漸化式: v_{n+1} = φ · R(36°_z-axis) · v_n
    解の閉形式:
      az_n     = az_0 + n × 36°
      |v_n|   = φⁿ · R₀
      θ_polar  = const  (全levelで不変)

    Args:
        k: 系統インデックス (0..11)
        j: 局所頂点インデックス (0..4)
        n: フラクタルレベル (0, 1, 2, ...)

    Returns:
        (x, y, z) on circumsphere of radius R_n = φⁿ · R₀
    """
    Rn = math.sqrt(level_n_radius_sq(n))   # = φⁿ · R₀
    sin_th, cos_th = polar_angles(k)

    # 方位角インデックス → ラジアン
    az_idx = level_n_azimuth_idx(k, j, n)
    az_rad = 2.0 * math.pi * az_idx / BASE

    # 球面座標 → 直交座標
    x = Rn * sin_th * math.cos(az_rad)
    y = Rn * sin_th * math.sin(az_rad)
    z = Rn * cos_th

    return x, y, z


def fractal_vertex(k: int, j: int, n: int = 0) -> FractalVertex:
    """
    Level n における頂点の完全記述を返す。
    """
    x, y, z = vertex_coords(k, j, n)
    az_idx = level_n_azimuth_idx(k, j, n)
    r_sq = level_n_radius_sq(n)

    return FractalVertex(
        level=n, k=k, j=j,
        x=x, y=y, z=z,
        az_idx=az_idx,
        r_sq=r_sq,
        carry_total=n,  # carry = 1 per level step
    )


def verify_recurrence(k: int = 0, j: int = 0, n_levels: int = 5) -> bool:
    """
    漸化式 v_{n+1} = φ·R(36°)·v_n の直接検証。
    閉形式 vertex_coords と逐次計算が一致するか確認。
    """
    print(f"=== 漸化式検証 (k={k}, j={j}) ===")
    print(f"{'level':>6} {'x_closed':>12} {'x_iter':>12} {'|v|²_closed':>14} {'|v|²_iter':>12} {'一致':>6}")
    print("-" * 70)

    # 逐次計算の初期値（level 0）
    x_iter, y_iter, z_iter = vertex_coords(k, j, 0)

    ok = True
    for n in range(n_levels):
        x_cl, y_cl, z_cl = vertex_coords(k, j, n)
        r_sq_cl = level_n_radius_sq(n)
        r_sq_it = x_iter**2 + y_iter**2 + z_iter**2

        match = abs(x_cl - x_iter) < 1e-8 and abs(r_sq_cl - r_sq_it) < 1e-8
        if not match:
            ok = False
        print(f"{n:>6} {x_cl:>12.6f} {x_iter:>12.6f} {r_sq_cl:>14.6f} {r_sq_it:>12.6f} {'✓' if match else '✗':>6}")

        # 漸化式で次のlevelを計算
        x_next = PHI * (COS36 * x_iter - SIN36 * y_iter)
        y_next = PHI * (SIN36 * x_iter + COS36 * y_iter)
        z_next = PHI * z_iter
        x_iter, y_iter, z_iter = x_next, y_next, z_next

    return ok


def carry_z5_connection(n_levels: int = 10) -> None:
    """
    carryとZ₅軌道の接続を可視化。
    
    φ·cos(36°) = 1 + cos(72°) → 1ステップごとにcarry=1
    level n で carry_total = n
    carry_total mod 5 = Z₅軌道の位置
    """
    print("=== carry と Z₅ 軌道 ===")
    print(f"φ·cos(36°) = φ²/2 = {PHI**2/2:.6f}  → carry=1, rem=cos(72°)={PHI**2/2-1:.6f}")
    print(f"cos(72°) = {math.cos(math.radians(72)):.6f}  一致: {abs(PHI**2/2-1 - math.cos(math.radians(72))) < 1e-8}")
    print()
    print(f"{'level':>6} {'az_idx':>8} {'az_deg':>8} {'carry_total':>12} {'Z₅_pos':>8} {'az_mod360':>10}")
    print("-" * 60)
    for n in range(n_levels):
        az_idx = level_n_azimuth_idx(0, 0, n)
        az_deg = 360.0 * az_idx / BASE
        carry  = n
        z5_pos = carry % 5
        print(f"{n:>6} {az_idx:>8} {az_deg:>8.1f}° {carry:>12} {z5_pos:>8} {az_deg%360:>10.1f}°")


def phi_arithmetic_summary() -> None:
    """φ算術での漸化式行列要素を表示"""
    print("=== φ算術での漸化式行列要素（確定） ===")
    print()
    print("  v_{n+1} = φ · R(36°) · v_n")
    print()
    print("  行列 φ·R(36°) の要素：")
    print(f"    (1,1): φ·cos(36°) = φ²/2 = (φ+1)/2 = 1 + cos(72°)")
    print(f"           → {PHI**2/2:.8f}  carry=1, rem=cos(72°)={PHI**2/2-1:.8f}")
    print(f"    (1,2): -φ·sin(36°) = -sin(72°)")
    print(f"           → -{math.sin(math.radians(72)):.8f}")
    print(f"    (2,1): φ·sin(36°) = sin(72°)")
    print(f"           → {math.sin(math.radians(72)):.8f}")
    print(f"    (2,2): φ·cos(36°) = 1 + cos(72°)")
    print()
    print("  補助公式：")
    print(f"    sin²(36°) = (3-φ)/4   → sin(36°) = √(3-φ)/2")
    print(f"    φ²/2 = (φ+1)/2 > 1   → carry=1 は代数的必然")
    print(f"    φ·√(3-φ)/2 = sin(72°) [証明: = √(φ(3-φ))·φ/2... 数値確認済み]")
    print()
    print("  極角（全レベル不変）：")
    print(f"    北極帯: sin = 1/(φ√3) = {SIN_THETA_POLE:.8f}")
    print(f"             cos = φ/√3   = {COS_THETA_POLE:.8f}")
    print(f"    上下帯: sin = 2/√5    = {SIN_THETA_BAND:.8f}")
    print(f"             cos = ±1/√5  = ±{COS_THETA_BAND:.8f}")
    print()
    print("  外接球半径：")
    print(f"    R₀² = (9φ+10)/4 = {R0_SQ:.8f}")
    print(f"    Rₙ  = φⁿ · R₀")
    print(f"    Rₙ² = φ²ⁿ · (9φ+10)/4")
    print()
    print("  BASE3120 整数係数：")
    print(f"    cos(36°) = {COS36_B},  sin(36°) = {SIN36_B}")
    print(f"    cos(72°) = {COS72_B},  sin(72°) = {SIN72_B}")
    print(f"    36°ステップ = {STEP_36DEG} (= BASE/10)")


def demo() -> None:
    """fractal_vertex_recurrence モジュールの全機能デモ"""
    print("=" * 70)
    print("  fractal_vertex_recurrence.py — デモ")
    print("  Fibonacci的頂点座標漸化式  v_{n+1} = φ·R(36°)·v_n")
    print("=" * 70)
    print()

    phi_arithmetic_summary()
    print()

    ok = verify_recurrence(k=0, j=0, n_levels=6)
    print(f"\n漸化式検証: {'PASS' if ok else 'FAIL'}")
    print()

    # 複数系統での検証
    print("=== 複数系統での漸化式検証 ===")
    all_ok = True
    for k in [0, 1, 2, 6, 11]:
        for j in [0, 2]:
            ok_kj = True
            x_i, y_i, z_i = vertex_coords(k, j, 0)
            for n in range(5):
                x_cl, y_cl, z_cl = vertex_coords(k, j, n)
                if abs(x_cl - x_i) > 1e-7:
                    ok_kj = False
                x_i2 = PHI*(COS36*x_i - SIN36*y_i)
                y_i2 = PHI*(SIN36*x_i + COS36*y_i)
                z_i2 = PHI*z_i
                x_i, y_i, z_i = x_i2, y_i2, z_i2
            status = '✓' if ok_kj else '✗'
            print(f"  k={k:2d}, j={j}: {status}")
            all_ok = all_ok and ok_kj
    print(f"  全系統: {'PASS' if all_ok else 'FAIL'}")
    print()

    carry_z5_connection(n_levels=11)
    print()

    # level 0〜3 の頂点サンプル
    print("=== level 0〜3 の頂点（k=0, j=0） ===")
    print(f"{'level':>6} {'x':>10} {'y':>10} {'z':>10} {'R_n':>10} {'az°':>8} {'carry':>7}")
    print("-" * 65)
    for n in range(4):
        v = fractal_vertex(0, 0, n)
        Rn = math.sqrt(v.r_sq)
        az_deg = 360.0 * v.az_idx / BASE
        print(f"{v.level:>6} {v.x:>10.4f} {v.y:>10.4f} {v.z:>10.4f} {Rn:>10.4f} {az_deg:>8.1f}° {v.carry_total:>7}")

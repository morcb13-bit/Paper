"""
exact_icosahedron.py
====================
Exact Cartesian coordinates for the truncated icosahedron.

Uses the standard Wikipedia form (edge length a=2):
  All even permutations of:
    (0, ±1, ±3φ)
    (±1, ±(2+φ), ±2φ)
    (±2, ±(1+2φ), ±φ)

Properties (a=2, R²=9φ+10):
  - All 60 vertices distinct (bijection confirmed)
  - All 90 edges have length exactly 2
  - 12 pentagonal faces, 20 hexagonal faces

Pentagon face centroids (confirmed by φ²=φ+1):
  tan(θ_centroid) = 1/φ  →  θ = arctan(1/φ) ≈ 31.72°  [proof: (2φ+9)/(11φ+2)=1/φ]
  tan(θ_centroid) = φ    →  θ = arctan(φ) ≈ 58.28°
  θ = 90° (equatorial band)
  and their supplements.

Issue with truncated_icosahedron.py:
  The original implementation uses icosahedral vertex positions for pentagon
  centers, resulting in duplicate coordinates (only 20 distinct points instead
  of 60). This module provides the correct implementation.

Key φ-arithmetic identities used:
  φ³ = 2φ+1
  φ⁴ = 3φ+2
  (φ+2)² = 5φ²
"""

from __future__ import annotations
import math
from typing import List, Tuple, Set, Dict

PHI: float = (1.0 + math.sqrt(5.0)) / 2.0
R_SQ_A2: float = 9.0 * PHI + 10.0   # R² for edge a=2
R_A2: float = math.sqrt(R_SQ_A2)


def build_vertices_a2() -> List[Tuple[float, float, float]]:
    """
    Return all 60 vertices of the truncated icosahedron with edge length a=2.

    Coordinates are exact (using floating-point φ arithmetic):
      Type 1: even permutations of (0, ±1, ±3φ)           →  12 vertices
      Type 2: even permutations of (±1, ±(2+φ), ±2φ)      →  24 vertices
      Type 3: even permutations of (±2, ±(1+2φ), ±φ)      →  24 vertices
    Total: 60 vertices

    φ-arithmetic values:
      3φ = 4.854...,  2+φ = 3.618...,  2φ = 3.236...,
      1+2φ = 4.236...,  φ = 1.618...
    """
    p = PHI
    verts = []

    # Type 1: even permutations of (0, ±1, ±3φ)
    for s1 in [1, -1]:
        for s2 in [1, -1]:
            verts += [
                (0,       s1 * 1,     s2 * 3*p),   # (0, ±1, ±3φ)
                (s1 * 1,  s2 * 3*p,   0),            # (±1, ±3φ, 0)
                (s2 * 3*p, 0,         s1 * 1),        # (±3φ, 0, ±1)
            ]  # 12 vertices

    # Type 2: even permutations of (±1, ±(2+φ), ±2φ)
    for s1 in [1, -1]:
        for s2 in [1, -1]:
            for s3 in [1, -1]:
                verts += [
                    (s1 * 1,      s2 * (2+p),   s3 * 2*p),
                    (s3 * 2*p,    s1 * 1,       s2 * (2+p)),
                    (s2 * (2+p),  s3 * 2*p,     s1 * 1),
                ]  # 24 vertices

    # Type 3: even permutations of (±2, ±(1+2φ), ±φ)
    for s1 in [1, -1]:
        for s2 in [1, -1]:
            for s3 in [1, -1]:
                verts += [
                    (s1 * 2,      s2 * (1+2*p), s3 * p),
                    (s3 * p,      s1 * 2,       s2 * (1+2*p)),
                    (s2 * (1+2*p), s3 * p,      s1 * 2),
                ]  # 24 vertices

    return verts


def build_edges(verts: List) -> List[Tuple[int, int]]:
    """Return all 90 edges (pairs of adjacent vertices, distance = 2)."""
    edges = []
    n = len(verts)
    for i in range(n):
        for j in range(i + 1, n):
            d2 = sum((verts[i][k] - verts[j][k])**2 for k in range(3))
            if abs(d2 - 4.0) < 0.01:
                edges.append((i, j))
    return edges


def find_pentagons(adj: Dict[int, List[int]]) -> List[Tuple[int, ...]]:
    """
    Find all 12 pentagonal faces as sorted 5-tuples of vertex indices.
    Uses DFS to find 5-cycles.
    """
    pentagons: Set[Tuple[int, ...]] = set()
    for s in range(60):
        for n1 in adj[s]:
            for n2 in adj[n1]:
                if n2 == s:
                    continue
                for n3 in adj[n2]:
                    if n3 in (s, n1):
                        continue
                    for n4 in adj[n3]:
                        if n4 in (s, n1, n2):
                            continue
                        if s in adj[n4]:
                            pentagons.add(tuple(sorted([s, n1, n2, n3, n4])))
    return sorted(pentagons)


def pentagon_centroid(pent: Tuple[int, ...], verts: List) -> Tuple[float, float, float]:
    """Return the centroid of a pentagonal face."""
    coords = [verts[i] for i in pent]
    return tuple(sum(c[k] for c in coords) / 5 for k in range(3))


def pentagon_polar_angle(pent: Tuple[int, ...], verts: List) -> float:
    """
    Return the polar angle θ (degrees) of the pentagon face centroid.

    Theorem: For the 'top' pentagons (k=0,1), tan(θ) = 1/φ.
    Proof: cy/cz = (2φ+9)/(11φ+2) = 1/φ
           since φ(2φ+9) = 2φ²+9φ = 2(φ+1)+9φ = 11φ+2  [φ²=φ+1]  □
    """
    cx, cy, cz = pentagon_centroid(pent, verts)
    r_xy = math.sqrt(cx**2 + cy**2)
    return math.degrees(math.atan2(r_xy, cz))


def verify_bijection(verts: List) -> bool:
    """Verify all 60 vertex coordinates are distinct."""
    seen = set()
    for v in verts:
        key = tuple(round(c, 8) for c in v)
        if key in seen:
            return False
        seen.add(key)
    return len(seen) == 60


def demo():
    """Demonstrate the exact icosahedron module."""
    print("=== exact_icosahedron.py デモ ===")
    print()

    verts = build_vertices_a2()
    print(f"頂点数: {len(verts)} (期待60)")

    ok = verify_bijection(verts)
    print(f"全単射確認: {'PASS' if ok else 'FAIL'}")
    print()

    edges = build_edges(verts)
    print(f"辺数: {len(edges)} (期待90)")

    adj = {i: [] for i in range(60)}
    for i, j in edges:
        adj[i].append(j); adj[j].append(i)
    degrees = [len(adj[i]) for i in range(60)]
    print(f"次数: {set(degrees)} (全て3)")
    print()

    pentagons = find_pentagons(adj)
    print(f"五角形面数: {len(pentagons)} (期待12)")
    print()

    print("五角形重心の極角:")
    for k, pent in enumerate(pentagons):
        theta = pentagon_polar_angle(pent, verts)
        cx, cy, cz = pentagon_centroid(pent, verts)
        print(f"  k={k:2d}: θ={theta:8.4f}°  centroid=({cx:.3f},{cy:.3f},{cz:.3f})")

    print()
    print("φ算術定理: tan(θ_重心,k=0) = 1/φ")
    print("  (2φ+9)/(11φ+2) = 1/φ  ← φ²=φ+1 より証明  □")

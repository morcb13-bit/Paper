"""
great_circle.py
===============
Great circle analysis for truncated icosahedron in B13 framework.

Observation R (empirically confirmed from physical model):
  A great circle passes through:
    - 2 pentagon vertices
    - connected via hexagon edges
  One full traversal = h₅×4 + h₆×4 + a×2  (10 geometric elements)

φ-arithmetic of the circumradius:
  R² = (9φ+10)/4
  1/(9φ+10) = (19-9φ)/109    [rationalization: denominator 109]
  109 = 8×F(7) + F(5) = 8×13 + 5

Central angle cosines (φ-exact):
  cos(θ_a) = (71+18φ)/109     [edge a=1]
  cos(θ₅)  = (197-13φ)/218    [pentagon height, F(7)=13 appears]
  cos(θ₆)  = (54φ-5)/109      [hexagon height]

Observation P (confirmed):
  Equatorial cross-section = regular decagon (10 vertices)
  Symmetry group: Z₂×Z₅
    Z₅ ↔ pentagon local rotation (τ unit)
    Z₂ ↔ carry sign (±1)
  10 edges of decagon = 10 critical carry-firing edges

Observation Q (confirmed):
  Center O has 5-fold rotational symmetry in ALL directions
  A₅ has 6 axes of 5-fold rotation covering the sphere
  → Regular decagon cross-section appears in any direction
"""

from __future__ import annotations
import math
from typing import Tuple
from .constants import BASE

PHI: float = (1.0 + math.sqrt(5.0)) / 2.0
R_SQ: float = (9.0 * PHI + 10.0) / 4.0
R: float = math.sqrt(R_SQ)

# Pentagon height (edge a=1)
H5_SQ: float = (3.0 + 4.0 * PHI) / 4.0
H5: float = math.sqrt(H5_SQ)

# Hexagon height (edge a=1, regular hexagon)
H6_SQ: float = 3.0
H6: float = math.sqrt(H6_SQ)

# Edge length
A: float = 1.0

# Rationalization denominator (φ-arithmetic)
# (9φ+10)(19-9φ) = 109
DENOM: int = 109

def cos_theta_a_phi() -> Tuple[int, int]:
    """
    cos(θ_a) = (71+18φ)/109 in φ-arithmetic.
    Returns (rational_part, phi_coeff) → value = (a + b×φ)/109
    """
    return (71, 18)

def cos_theta_5_phi() -> Tuple[int, int]:
    """
    cos(θ₅) = (197-13φ)/218 in φ-arithmetic.
    Note: F(7)=13 appears as the φ coefficient.
    Returns (rational_part, phi_coeff) for numerator over 218.
    """
    return (197, -13)

def cos_theta_6_phi() -> Tuple[int, int]:
    """
    cos(θ₆) = (54φ-5)/109 in φ-arithmetic.
    Returns (rational_part, phi_coeff) for numerator over 109.
    """
    return (-5, 54)

def phi_value(a: int, b: int) -> float:
    """Evaluate a + b×φ as float."""
    return a + b * PHI

def central_angle_from_chord(chord_sq: float) -> float:
    """
    Return central angle θ (degrees) from chord² using law of cosines.
    cos(θ) = 1 - chord²/(2R²)
    """
    cos_theta = 1.0 - chord_sq / (2.0 * R_SQ)
    cos_theta = max(-1.0, min(1.0, cos_theta))
    return math.degrees(math.acos(cos_theta))

def arc_length(chord_sq: float) -> float:
    """Return arc length on circumsphere for given chord²."""
    theta = math.radians(central_angle_from_chord(chord_sq))
    return R * theta

def great_circle_traversal() -> dict:
    """
    Compute the great circle traversal lengths and verify sum = 2πR.

    Returns dict with arc lengths and total vs theoretical circumference.
    """
    arc_a  = arc_length(A * A)
    arc_h5 = arc_length(H5_SQ)
    arc_h6 = arc_length(H6_SQ)

    total = 2 * arc_a + 4 * arc_h5 + 4 * arc_h6
    theoretical = 2.0 * math.pi * R

    return {
        "arc_a":        arc_a,
        "arc_h5":       arc_h5,
        "arc_h6":       arc_h6,
        "total":        total,
        "theoretical":  theoretical,
        "error_pct":    abs(total - theoretical) / theoretical * 100,
        "elements":     10,  # 2+4+4 = 10 elements = decagon vertices
        "denom_109":    DENOM,
        "109_factored": "8×F(7)+F(5) = 8×13+5",
    }

def theta_values_degrees() -> dict:
    """Return central angles for each geometric element."""
    return {
        "theta_a_deg":  central_angle_from_chord(A * A),
        "theta_h5_deg": central_angle_from_chord(H5_SQ),
        "theta_h6_deg": central_angle_from_chord(H6_SQ),
        "sum_check":    (2 * central_angle_from_chord(A*A) +
                         4 * central_angle_from_chord(H5_SQ) +
                         4 * central_angle_from_chord(H6_SQ)),
    }

def phi_arithmetic_verify() -> dict:
    """
    Verify cos values using φ-arithmetic.
    cos(θ) = 1 - d²/(2R²)
    R² = (9φ+10)/4
    1/(9φ+10) = (19-9φ)/109
    """
    # cos(θ_a) = 1 - 1/(2R²) = 1 - 2/(9φ+10) = 1 - 2(19-9φ)/109
    #          = (109 - 38 + 18φ)/109 = (71+18φ)/109
    a_rat, a_phi = cos_theta_a_phi()
    cos_a_phi = phi_value(a_rat, a_phi) / DENOM
    cos_a_exact = 1.0 - 1.0 / (2.0 * R_SQ)

    # cos(θ₅) = 1 - h₅²/(2R²) = 1 - (3+4φ)/4 / ((9φ+10)/2)
    #          = 1 - (3+4φ)/(2(9φ+10))
    #          = 1 - (3+4φ)(19-9φ)/(2×109)
    # (3+4φ)(19-9φ) = 57-27φ+76φ-36φ² = 57+49φ-36(φ+1) = 21+13φ
    #          = (218 - 21 - 13φ)/218 = (197-13φ)/218
    h5_rat, h5_phi = cos_theta_5_phi()
    cos_h5_phi = phi_value(h5_rat, h5_phi) / (2 * DENOM)
    cos_h5_exact = 1.0 - H5_SQ / (2.0 * R_SQ)

    # cos(θ₆) = 1 - 3/(2R²) = 1 - 6/(9φ+10)
    #          = 1 - 6(19-9φ)/109 = (109-114+54φ)/109 = (54φ-5)/109
    h6_rat, h6_phi = cos_theta_6_phi()
    cos_h6_phi = phi_value(h6_rat, h6_phi) / DENOM
    cos_h6_exact = 1.0 - H6_SQ / (2.0 * R_SQ)

    return {
        "cos_a":  {"phi_formula": f"(71+18φ)/109",
                   "phi_eval": cos_a_phi, "exact": cos_a_exact,
                   "match": abs(cos_a_phi - cos_a_exact) < 1e-10},
        "cos_h5": {"phi_formula": f"(197-13φ)/218  [F(7)=13]",
                   "phi_eval": cos_h5_phi, "exact": cos_h5_exact,
                   "match": abs(cos_h5_phi - cos_h5_exact) < 1e-10},
        "cos_h6": {"phi_formula": f"(54φ-5)/109",
                   "phi_eval": cos_h6_phi, "exact": cos_h6_exact,
                   "match": abs(cos_h6_phi - cos_h6_exact) < 1e-10},
        "denom_109": f"109 = 8×13+5 = 8×F(7)+F(5)",
    }


# ============================================================
# Great Circle Closure Theorem (proved v53, 2026-03-15)
# ============================================================
#
# Correct great circle structure (a=2 Cartesian coordinates):
# 10 intersection points on x=0 plane:
#   4 vertices: (0, ±1, ±3φ)
#   6 edge-midpoints: (0, ±(φ+2), ±2φ), (0, ±3φ, 0)
#
# Arc segments (central angles):
#   θ_A: vertex ↔ edge-midpoint
#   θ_B: edge-midpoint ↔ edge-midpoint
#   θ_edge: vertex ↔ vertex (actual edge)
#
# One full traversal = 4θ_A + 4θ_B + 2θ_edge = 360°
# ↔ Half circle: 2θ_A + 2θ_B + θ_edge = 180°
#
# φ-arithmetic values:
#   cos(θ_B)    = (φ+2)/(3φ)         sin(θ_B) = 2/3  [rational!]
#   cos(θ_edge) = (9φ+8)/(9φ+10)     sin(θ_edge) = 6φ/(9φ+10)
#   cos(2θ_A)   = (70φ+55)/(252φ+171)
#
# Key identities used:
#   (φ+2)² = 5φ²  →  sin²(θ_B) = 4/9  →  sin(θ_B) = 2/3
#   cos(2θ_B) = 1/9
#   5(3φ+8)(28φ+19) = (70φ+55)(9φ+10) = 1825φ+1180  □
#
# Note: great_circle.py uses h₅,h₆ (face heights, a=1 normalization)
#   which gives cos values cos(θ_h5)=(197-13φ)/218, cos(θ_h6)=(54φ-5)/109
#   These differ from the above due to different edge-midpoint definition.

def great_circle_closure_proof() -> dict:
    """
    Verify the great circle closure theorem 2θ_A+2θ_B+θ_edge = 180°.
    Uses exact Cartesian coordinates (a=2, R²=9φ+10).
    """
    p = PHI
    R2_a2 = 9*p + 10

    # Vertices and edge-midpoints on x=0 great circle
    v0 = (0, 1.0, 3*p)          # vertex (0, 1, 3φ)
    v1 = (0, p+2, 2*p)          # edge-midpoint (0, φ+2, 2φ)  [unprojected]
    v2 = (0, 3*p, 0.0)          # edge-midpoint (0, 3φ, 0)    [unprojected]
    vn = (0, -1.0, 3*p)         # adjacent vertex (0, -1, 3φ)  [edge]

    def central_angle(va, vb):
        ra = math.sqrt(sum(c**2 for c in va))
        rb = math.sqrt(sum(c**2 for c in vb))
        dot = sum(a*b for a,b in zip(va, vb))
        return math.degrees(math.acos(max(-1.0, min(1.0, dot/(ra*rb)))))

    theta_A    = central_angle(v0, v1)
    theta_B    = central_angle(v1, v2)
    theta_edge = central_angle(v0, vn)

    # φ-arithmetic cos values
    cos_B    = (p+2)/(3*p)           # = (φ+2)/(3φ)
    sin_B    = 2.0/3.0               # exact rational
    cos_edge = (9*p+8)/(9*p+10)      # = (9φ+8)/(9φ+10)
    sin_edge = 6*p/(9*p+10)          # = 6φ/(9φ+10)
    cos_2A   = (70*p+55)/(252*p+171) # = (70φ+55)/(252φ+171)

    # Verify: cos(2θ_B+θ_edge) = -cos(2θ_A)
    cos_2B = 2*cos_B**2 - 1          # = 1/9
    sin_2B = 2*sin_B*cos_B           # = 4(φ+2)/(9φ)
    cos_2B_plus_edge = cos_2B*cos_edge - sin_2B*sin_edge

    half_sum = 2*theta_A + 2*theta_B + theta_edge

    return {
        'theta_A_deg':   theta_A,
        'theta_B_deg':   theta_B,
        'theta_edge_deg': theta_edge,
        'half_sum_deg':  half_sum,
        'full_sum_deg':  2*half_sum,
        'cos_B_phi':     cos_B,
        'sin_B_rational': sin_B,
        'cos_2A_phi':    cos_2A,
        'cos_2B_edge':   cos_2B_plus_edge,
        'closure_proved': abs(cos_2B_plus_edge - (-cos_2A)) < 1e-8,
        'full_360':      abs(2*half_sum - 360.0) < 1e-6,
    }


def great_circle_closure_sin_b_origin() -> dict:
    """
    Origin of sin(θ_B) = 2/3 (rational number).

    Edge-midpoints before projection: (0, φ+2, 2φ) and (0, 3φ, 0)
    Both have radius |r|² = (φ+2)²+(2φ)² = 9φ²  →  |r| = 3φ

    Cross product magnitude: |A×B| = (φ+2)·0 - 2φ·3φ = 6φ²
    sin(θ_B) = |A×B|/(|A||B|) = 6φ²/(9φ²) = 2/3  [φ cancels entirely]

    Returns dict with key identities.
    """
    p = PHI
    r_mid_sq = (p+2)**2 + (2*p)**2   # = 9φ²
    cos_B = (p+2)/(3*p)               # = (φ+2)/(3φ)
    sin_B = 2.0/3.0

    return {
        'r_mid_sq': r_mid_sq,
        'r_mid_phi2': 9*p**2,
        'cos_B': cos_B,
        'sin_B': sin_B,
        'sin_B_rational': True,
        'identity': '(φ+2)² = 5φ²  →  sin²(θ_B)=4/9',
    }

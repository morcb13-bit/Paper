"""
connection.py
=============
切端20面体の接続構造 → coneFFT の伝播ルール。

"Nature knows only addition."
macro-fire が起きたセルから隣接セルへ carry が伝わる。
この「どこへ伝わるか」を定義するのがこのモジュール。

接続の2種類:
  pentagon辺:  同一pentagon内の隣接頂点  (k固定, j変化)
  hexagon辺:   異なるpentagonの頂点間    (k変化)

----------------------------------------------------------------------
v066 変更:
  幾何（60頂点・隣接・pentagon検出・(k,j)割り当て）は
  truncated_icosahedron._canonical() に一本化した。
  以前は connection.py が独自の _build_vertices_a2() を持っていたが、
  vertex_coords_float と build_connection_graph が同一頂点を指すことを
  保証するため、両者は同じキャッシュ済み幾何を共有する。
  (k,j) ラベル付けのアルゴリズムは v065 と同一。
----------------------------------------------------------------------
"""

from __future__ import annotations
from typing import List, Tuple, Dict
from .constants import Z13_STAR
from .z13_structure import pentagon_index
from .truncated_icosahedron import _canonical


# ─────────────────────────────────────────────
# 接続グラフの構築（唯一の幾何ソースから）
# ─────────────────────────────────────────────

def build_connection_graph() -> Dict[Tuple[int, int], List[Tuple[int, int]]]:
    """
    (k, j) → [(k2, j2), ...] の隣接リストを返す（各頂点3近傍）。

    辺の種類:
      pentagon辺: k同じ, j→j±1 mod 5
      hexagon辺:  k異なる
    """
    c = _canonical()
    graph: Dict[Tuple[int, int], List[Tuple[int, int]]] = {}
    for v_idx in range(60):
        kj = c.coord_to_kj[v_idx]
        neighbors = [c.coord_to_kj[nb] for nb in c.adj[v_idx]]
        graph[kj] = sorted(neighbors)
    return graph


def build_edge_types() -> Dict[Tuple[Tuple[int, int], Tuple[int, int]], str]:
    """
    辺 ((k1,j1),(k2,j2)) → 'pentagon' or 'hexagon' の分類。
    """
    c = _canonical()
    edge_types: Dict[Tuple, str] = {}
    for i in range(60):
        for j in c.adj[i]:
            if j <= i:
                continue
            kj_i = c.coord_to_kj[i]
            kj_j = c.coord_to_kj[j]
            etype = 'pentagon' if c.v_to_pent[i] == c.v_to_pent[j] else 'hexagon'
            edge_types[(kj_i, kj_j)] = etype
            edge_types[(kj_j, kj_i)] = etype
    return edge_types


# ─────────────────────────────────────────────
# (g, τ) ↔ (k, j) 変換
# ─────────────────────────────────────────────

def g_tau_to_kj(g: int, tau: int) -> Tuple[int, int]:
    """(g, τ) → (k, j_phase) ただし k=pentagon_index(g), j=τ。"""
    return (pentagon_index(g), tau)


def kj_to_g(k: int) -> int:
    """k → g = Z13_STAR[k]。"""
    return Z13_STAR[k]


# ─────────────────────────────────────────────
# coneFFT 伝播ルール
# ─────────────────────────────────────────────

# キャッシュ
_GRAPH: Dict[Tuple[int, int], List[Tuple[int, int]]] | None = None
_EDGE_TYPES: Dict | None = None


def get_graph() -> Dict[Tuple[int, int], List[Tuple[int, int]]]:
    global _GRAPH
    if _GRAPH is None:
        _GRAPH = build_connection_graph()
    return _GRAPH


def neighbors_of(k: int, j: int) -> List[Tuple[int, int]]:
    """(k,j) の隣接頂点リスト [(k2,j2), ...]。"""
    return get_graph().get((k, j), [])


def propagate_carry(g: int, tau: int, amount: int = 1) -> List[Tuple[int, int, int]]:
    """
    セル(g,τ)のmacro-fireから隣接セルへのcarry伝播。

    Returns:
        List[(g2, tau2, amount)] — 伝播先セルと伝播量
    """
    k = pentagon_index(g)
    nbs = neighbors_of(k, tau)
    result = []
    for k2, j2 in nbs:
        g2 = kj_to_g(k2)
        result.append((g2, j2, amount))
    return result


def edge_type(g1: int, tau1: int, g2: int, tau2: int) -> str:
    """2セル間の辺種別 ('pentagon' / 'hexagon' / 'none')。"""
    global _EDGE_TYPES
    if _EDGE_TYPES is None:
        _EDGE_TYPES = build_edge_types()
    k1, k2 = pentagon_index(g1), pentagon_index(g2)
    return _EDGE_TYPES.get(((k1, tau1), (k2, tau2)), 'none')

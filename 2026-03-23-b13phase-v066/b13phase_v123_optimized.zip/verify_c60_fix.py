#!/usr/bin/env python3
"""
verify_c60_fix.py
=================
引継書 v132 §5/§6 task 1 の受け入れテスト。

「幾何計算に使う前に、ライブラリ関数が distinct で忠実な点を返すか必ず検証する」
（教訓）の自動チェック。これを実行して全 assert が通れば、
vertex_coords_float の 60→20 縮退バグは解消され、float 座標と
build_connection_graph が同一の60頂点を指すことが保証される。

    python3 verify_c60_fix.py
"""
import sys
import b13phase as b


def main() -> int:
    print(f"b13phase __version__ = {b.__version__}\n")

    # --- 1. 幾何の厳密 assert（distinct / 辺長 / 角欠損 / Euler / 一貫性） ---
    print("[1] assert_geometry()")
    m = b.assert_geometry(verbose=True)
    print("    -> PASS\n")

    # --- 2. float 座標 ⇔ 接続グラフ の頂点一致 ---
    print("[2] vertex_coords_float <-> build_connection_graph 一致")
    g = b.build_connection_graph()
    consistent = all(
        sorted(g[(k, j)]) == b.neighbors_geom(k, j)
        for k in range(12) for j in range(5)
    )
    assert consistent, "labels diverge"
    print("    -> PASS (同一 (k,j) 規約)\n")

    # --- 3. 旧バグの不在を明示的に確認 ---
    print("[3] 旧バグ（60->20 縮退）の不在")
    pts = {tuple(round(c, 6) for c in b.vertex_coords_float(k, j))
           for k in range(12) for j in range(5)}
    assert len(pts) == 60, f"distinct points = {len(pts)} (bug not fixed!)"
    print(f"    -> PASS (distinct points = {len(pts)})\n")

    # --- 4. B13 内部構造（不変）の健全性 ---
    print("[4] B13 内部構造（修正の影響を受けない）")
    assert b.verify_4h_avoidance(200), "4H avoidance broken"
    assert b.coset_pattern() == ["H", "2H", "4H"] * 4
    assert b.observation_n_verify()
    print("    -> PASS (4H回避 / coset周期3 / 直交ペア無し)\n")

    print("ALL CHECKS PASSED.")
    print("注意: (k,j) と B13 coset（H/2H/4H）の幾何的対応づけは task #2。")
    print("      all_vertices() の coset 欄は暫定ラベルであり確定ではない。")
    return 0


if __name__ == "__main__":
    sys.exit(main())

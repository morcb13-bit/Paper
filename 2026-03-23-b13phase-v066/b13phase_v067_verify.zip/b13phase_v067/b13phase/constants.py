"""
constants.py
============
Common constants for B13 fractal phase representation.

BASE = 3120 = 2^4 × 3 × 5 × 13
             = 60 × 52
             = 切端20面体頂点数(60) × 活性状態数(52)

Angular units (BASE subdivisions = 360°):
  3120 / 5  = 624   → 72°  (Z₅ step, pentagon local rotation)
  3120 / 12 = 260   → 30°  (Z₁₂ step)
  3120 / 4  = 780   → 90°  (H step)
  3120 / 13 = 240   → 1 Z₁₃ step
  3120 / 60 = 52    → 6°   (minimum unit)
"""

BASE: int = 3120
INT64_MAX: int = (1 << 63) - 1  # signed int64 max

# Angular unit constants
STEP_Z5:  int = BASE // 5    # 624  → 72°
STEP_Z12: int = BASE // 12   # 260  → 30°
STEP_H:   int = BASE // 4    # 780  → 90°
STEP_Z13: int = BASE // 13   # 240  → 1 Z₁₃ step
STEP_MIN: int = BASE // 60   # 52   → 6°

# ---------------------------------------------------------------------------
# DEPRECATED (2026-07-16 監査, v0.67): PHI_BASE / PHI_HALF_BASE
#
# 全文検索の結果、**消費側はゼロ**（v0.66 全 14 ファイル・2357 行）:
#   constants.py:32,33              定義
#   truncated_icosahedron.py:51     import のみ、本体で未使用（v0.67 で除去）
#   __init__.py:27,89               再エクスポートのみ
# 計算に一度も入っていない。したがって ζ整数（厳密表現）への置換は行わない
# ── 使われない定数を厳密にしても、厳密になるものが無い（director 裁定）。
#
# 記録: BASE 単位の整数 φ は統治公理 φ² = φ + 1 を満たさない。
#   PHI_BASE² = 25482304,  BASE·PHI_BASE + BASE² = 25484160,  差 = −1856
#   BASE=3120 単位でこれを厳密に満たす整数は**存在しない**（√5 が無理数）。
#   φ の閉包が要る計算が現れたら、この定数ではなく Z[ζ10] を使うこと
#   （φ = (1,0,1,−1)、φ²−φ−1 = 0 が厳密に成立）。
#
# 消費側ゼロのため、削除しても API 以外は壊れない。削除する場合の変更点は
# 上記 5 行のみ。当面は deprecated として残す。
# ---------------------------------------------------------------------------
PHI_BASE: int = 5048       # DEPRECATED: round(BASE × φ) ≈ 3120 × 1.6180339887
PHI_HALF_BASE: int = 2524  # DEPRECATED: round(BASE × φ/2) = cos(36°) in BASE units

# B13 structural constants
Z13_ORDER: int = 13
H_ORDER:   int = 4   # |H| = |{1,5,8,12}|
Z5_ORDER:  int = 5
VERTICES:  int = 60  # truncated icosahedron vertices
PENTAGONS: int = 12  # pentagon faces
HEXAGONS:  int = 20  # hexagon faces
ACTIVE:    int = 52  # = Z₁₃ × H = 13 × 4

# F(7) = 13, P(7) = 169 = 13²
F7: int = 13
P7: int = 169

# Coset structure of Z₁₃
H_SET:  frozenset = frozenset({1, 5, 8, 12})
H2_SET: frozenset = frozenset({2, 3, 10, 11})
H4_SET: frozenset = frozenset({4, 6, 7, 9})

# Z₁₃* as powers of generator 2
# 2^k mod 13 for k=0..11
Z13_STAR: list = [pow(2, k, 13) for k in range(12)]
# = [1, 2, 4, 8, 3, 6, 12, 11, 9, 5, 10, 7]

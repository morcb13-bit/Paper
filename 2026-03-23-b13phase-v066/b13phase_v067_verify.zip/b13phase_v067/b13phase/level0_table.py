"""
level0_table.py
===============
Level-0 lookup table for B13 fractal phase evaluator.

COS_TABLE[i] = round(BASE * cos(2π * i / BASE))
SIN_TABLE[i] = round(BASE * sin(2π * i / BASE))

for i in 0..BASE-1 (BASE = 3120).

Key values (all machine-checked by verify_canonical()):
  i=0    → cos=3120,  sin=0      (0°)
  i=312  → cos=2524,  sin=1834   (36°,   cos≈φ/2)
  i=520  → cos=1560,  sin=2702   (60°)   <- 六角形の中心角
  i=624  → cos=964,   sin=2967   (72°)   <- 五角形の中心角
  i=780  → cos=0,     sin=3120   (90°)
  i=936  → cos=-964,  sin=2967   (108°)  <- 五角形の内角
  i=1040 → cos=-1560, sin=2702   (120°)  <- 六角形の内角
  i=1248 → cos=-2524, sin=1834   (144°)
  i=1560 → cos=-3120, sin=0      (180°)
  i=2340 → cos=0,     sin=-3120  (270°)

注記 (2026-07-16 監査, v0.67):
  v0.66 までの本 docstring は i=624 / i=936 の行に、60°/120°（六角形の角）の値を
  72°/108°（五角形の角）のラベルで載せていた。**コードは常に正しく、誤りは docstring
  のみ**（計算結果に影響なし）。旧 verify_canonical() は 0/90/180/270 の四点しか
  見ておらず、五角形の角に否と言える目が一つも無かったため、誤記が残った。
  v0.67 で verify_canonical() に検査能力を追加した（director 裁定 2026-07-16）。
"""

from __future__ import annotations
import math
from .constants import BASE


def _build_tables(base: int):
    cos_table = [0] * base
    sin_table = [0] * base
    two_pi = 2.0 * math.pi
    for i in range(base):
        angle = two_pi * i / base
        cos_table[i] = round(base * math.cos(angle))
        sin_table[i] = round(base * math.sin(angle))
    return cos_table, sin_table


COS_TABLE, SIN_TABLE = _build_tables(BASE)


# ---------------------------------------------------------------------------
# 丸め誤差の上界（導出。実測の最大値に合わせてはならない ── それでは必ず通る）
#   c = B·cosθ + δc,  s = B·sinθ + δs,   |δ| ≤ 1/2
#   c² + s² − B² = 2B(cosθ·δc + sinθ·δs) + δc² + δs²
#                ≤ 2B·√(δc²+δs²) + 1/2  ≤ 2B·(√2/2) + 1/2 = √2·B + 1/2
# B=3120 で 4413。実測の最大偏差は 3839（< 4413）。
# ---------------------------------------------------------------------------
PYTH_TOL: int = int(math.sqrt(2) * BASE) + 1     # 4413


def verify_canonical(verbose: bool = True) -> bool:
    """
    Verify the level-0 tables.

    v0.66 は 0/90/180/270 の四点しか見ていなかった。その四点は五角形にも
    六角形にも触れないため、docstring の 72°/108° 誤記に否と言えなかった
    （2026-07-16 監査）。v0.67 は以下の四層を検査する:

      (1) 軸上の四点          … 厳密
      (2) 五角形・六角形の角  … 厳密（36/60/72/108/120/144°）
      (3) 対称性の恒等式      … 全 BASE 添字で**厳密**（丸めは cos の偶性・
                                sin の奇性を破らない ── 実測で偏差 0）
      (4) ピタゴラス          … 全 BASE 添字、導出上界 PYTH_TOL 以内
    """
    ok = True

    def fail(msg):
        nonlocal ok
        ok = False
        if verbose:
            print(f"  FAIL {msg}")

    # (1) 軸上の四点 ------------------------------------------------------
    for val, expected, label in [
        (COS_TABLE[0],          BASE,  "cos(0°)"),
        (SIN_TABLE[0],          0,     "sin(0°)"),
        (COS_TABLE[BASE//4],    0,     "cos(90°)"),
        (SIN_TABLE[BASE//4],    BASE,  "sin(90°)"),
        (COS_TABLE[BASE//2],    -BASE, "cos(180°)"),
        (SIN_TABLE[BASE//2],    0,     "sin(180°)"),
        (COS_TABLE[BASE*3//4],  0,     "cos(270°)"),
        (SIN_TABLE[BASE*3//4],  -BASE, "sin(270°)"),
    ]:
        if val != expected:
            fail(f"{label}: got {val}, expected {expected}")

    # (2) 五角形・六角形の角 ----------------------------------------------
    #     ここが v0.66 に無かった目。C60 の二種の面の角を厳密に押さえる。
    for deg, i, c, s, tag in [
        ( 36,  312,  2524, 1834, "pentagon half-apex, cos=φ/2"),
        ( 60,  520,  1560, 2702, "hexagon central"),
        ( 72,  624,   964, 2967, "pentagon central"),
        (108,  936,  -964, 2967, "pentagon interior"),
        (120, 1040, -1560, 2702, "hexagon interior"),
        (144, 1248, -2524, 1834, "pentagon exterior"),
    ]:
        if i != round(BASE * deg / 360):
            fail(f"index for {deg}°: {i} != {round(BASE*deg/360)}")
        if (COS_TABLE[i], SIN_TABLE[i]) != (c, s):
            fail(f"{deg}° ({tag}): got ({COS_TABLE[i]}, {SIN_TABLE[i]}), "
                 f"expected ({c}, {s})")

    # (3) 対称性 ── 添字・象限・符号の誤りに否と言う -----------------------
    for i in range(BASE):
        j = (BASE - i) % BASE          # −θ
        k = (BASE // 2 - i) % BASE     # 180° − θ
        if COS_TABLE[j] != COS_TABLE[i]:
            fail(f"cos(−θ) != cos θ at i={i}"); break
        if SIN_TABLE[j] != -SIN_TABLE[i]:
            fail(f"sin(−θ) != −sin θ at i={i}"); break
        if COS_TABLE[k] != -COS_TABLE[i]:
            fail(f"cos(180°−θ) != −cos θ at i={i}"); break
        if SIN_TABLE[k] != SIN_TABLE[i]:
            fail(f"sin(180°−θ) != sin θ at i={i}"); break

    # (4) ピタゴラス ------------------------------------------------------
    worst = 0
    for i in range(BASE):
        d = COS_TABLE[i]**2 + SIN_TABLE[i]**2 - BASE*BASE
        if abs(d) > abs(worst):
            worst = d
        if abs(d) > PYTH_TOL:
            fail(f"cos²+sin² off by {d} at i={i} (tol {PYTH_TOL})")
            break
    if verbose:
        print(f"  pythagorean worst deviation: {worst}  (tol {PYTH_TOL}, "
              f"= √2·BASE + 1/2)")

    return ok


def self_test_negative(verbose: bool = True) -> bool:
    """
    verify_canonical() が実際に否と言えるかを確かめる（検査の検査）。

    v0.66 の誤記 ── 72°/108° の行に 60°/120° の値 ── を表へ注入し、
    verify_canonical() が False を返すことを要求する。旧版はこの注入に
    True を返した。**否と言えない検査は、通っても情報を運ばない。**
    """
    injuries = [
        ("v0.66 の docstring 誤記を表へ注入 (72°→60° の値)",
         lambda: _swap(624, 1560, 2702)),
        ("符号反転 (sin の奇性を壊す)", lambda: _swap(1, SIN_TABLE[1], -SIN_TABLE[1])),
        ("スケール誤り (ピタゴラスを壊す)", lambda: _swap(700, 0, 0)),
    ]
    all_caught = True
    for label, injure in injuries:
        undo = injure()
        caught = not verify_canonical(verbose=False)
        undo()
        if verbose:
            print(f"  [{'caught' if caught else 'MISSED'}] {label}")
        all_caught &= caught
    return all_caught


def _swap(i, c, s):
    """i 番の値を差し替え、元へ戻す関数を返す（self_test_negative 専用）。"""
    oc, os_ = COS_TABLE[i], SIN_TABLE[i]
    COS_TABLE[i], SIN_TABLE[i] = c, s
    def undo():
        COS_TABLE[i], SIN_TABLE[i] = oc, os_
    return undo


def coset_of(g: int) -> str:
    """Return the coset name of g in Z₁₃."""
    g = g % 13
    if g == 0:
        return "0"
    if g in {1, 5, 8, 12}:
        return "H"
    if g in {2, 3, 10, 11}:
        return "2H"
    return "4H"

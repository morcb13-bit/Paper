"""
fractal_engine.py
=================
B13フラクタル化エンジン — "Nature knows only addition."

設計:
  段階A: 算術層 — d_i の加算・carry・crossing検出
  段階B: 幾何層 — crossing_thresholds (大円横断の5閾値)
  段階C: 射影   — proj(d_i) = d_i mod BASE → 幾何判定

大円横断閾値 (BASE=3120, a=2系):
  1周を5点で分割 → 6区間 [1286, 235, 39, 39, 235, 1286]

  T_21     = 1286  [H→4H 境界]      t=2/(3φ),       arc=θ₂₁
  T_31_sym = 1521  [4H→4H 内部]     t=1-3φ/(4φ+3),  arc=θ₃₁ (対称)
  T_18     = 1560  [4H→4H 内部]     t=1/2,           arc=θ₁₈ (自己対称)
  T_31     = 1599  [4H→4H 内部]     t=3φ/(4φ+3),    arc=θ₃₁
  T_21_sym = 1834  [4H→H 境界]      t=1-2/(3φ),     arc=θ₂₁ (対称)
  BASE     = 3120  [macro-carry]     1周完了

核心定理 (実装):
  全大円横断は 4H帯の内部または H/4H 境界で起きる
  Fib/Pell は 4H を踏まない → 大円横断=carry発火を構造的に回避

発火の2層構造:
  micro-fire: prev < T_k <= new  (大円横断, 幾何イベント)
  macro-fire: new >= BASE         (桁繰り上がり, 算術イベント)
"""

from __future__ import annotations
import math
from typing import List, Tuple, NamedTuple, Optional
from .constants import BASE, STEP_Z13, H_SET, H4_SET

PHI: float = (1.0 + math.sqrt(5.0)) / 2.0


# ─────────────────────────────────────────────
# 段階B: 幾何閾値
# ─────────────────────────────────────────────

class CrossingThreshold(NamedTuple):
    name:       str    # 識別名 (T_21, T_18, T_31, T_21_sym, T_31_sym)
    threshold:  int    # BASE単位の整数閾値
    t_value:    float  # 辺上パラメータ t ∈ (0,1)
    arc:        str    # 弧種別 (theta_18, theta_21, theta_31)
    band_cross: str    # 帯境界の種類 (H→4H, 4H→4H, 4H→H)
    symmetric:  bool   # 後半周の対称点か


def crossing_thresholds(base: int = BASE) -> List[CrossingThreshold]:
    """
    大円横断の完全閾値セット (5点, 昇順) を返す。

    区間幅: [T_21, T_31_sym-T_21, T_18-T_31_sym,
             T_31-T_18, T_21_sym-T_31, BASE-T_21_sym]
           = [1286, 235, 39, 39, 235, 1286]  (対称)

    Returns:
        List[CrossingThreshold] — threshold の昇順
    """
    half   = base // 2                                  # 1560 厳密
    t21    = round(2.0 / (3.0 * PHI) * base)           # 1286
    t31    = round(3.0 * PHI / (4.0 * PHI + 3.0) * base)  # 1599
    t31s   = base - t31                                 # 1521
    t21s   = base - t21                                 # 1834

    raw = [
        CrossingThreshold("T_21",     t21,  2.0/(3.0*PHI),                 "theta_21", "H→4H",  False),
        CrossingThreshold("T_31_sym", t31s, 1.0-3.0*PHI/(4.0*PHI+3.0),    "theta_31", "4H→4H", True),
        CrossingThreshold("T_18",     half, 0.5,                            "theta_18", "4H→4H", False),
        CrossingThreshold("T_31",     t31,  3.0*PHI/(4.0*PHI+3.0),         "theta_31", "4H→4H", False),
        CrossingThreshold("T_21_sym", t21s, 1.0-2.0/(3.0*PHI),             "theta_21", "4H→H",  True),
    ]
    return sorted(raw, key=lambda x: x.threshold)


_THRESHOLDS: List[CrossingThreshold] = crossing_thresholds(BASE)
_TH_VALUES:  List[int] = [t.threshold for t in _THRESHOLDS]


# ─────────────────────────────────────────────
# 段階C: 射影 d_i → 幾何位相
# ─────────────────────────────────────────────

def proj(d: int, base: int = BASE) -> int:
    """
    算術状態 d → 幾何位相 α = d mod BASE。

    現バージョン: 恒等射影 (d は [0, BASE) に保持される前提)。
    将来: より複雑な射影に差し替えるフック。
    """
    return d % base


def band_of(alpha: int) -> str:
    """
    幾何位相 α の帯 (H / 2H / 4H / 0) を返す。
    α は [0, BASE) の整数。
    """
    # STEP_Z13=240 の倍数かチェック
    if alpha % STEP_Z13 != 0:
        return "?"          # 帯境界外 (辺の内部)
    g = alpha // STEP_Z13
    if g == 0:
        return "0"
    g = g % 13
    if g in H_SET:
        return "H"
    if g in H4_SET:
        return "4H"
    return "2H"


# ─────────────────────────────────────────────
# 段階A: crossing検出・加算トレース
# ─────────────────────────────────────────────

class CrossingEvent(NamedTuple):
    digit_pos:  int                 # 何桁目 (0=MSD)
    threshold:  CrossingThreshold  # 越えた閾値
    prev_val:   int                # 加算前の桁値
    raw_val:    int                # 加算後 (wrap前) の値


class AddResult(NamedTuple):
    digits:       List[int]           # 結果桁列
    carry_out:    int                 # 最上位からの桁carry (0 or 1)
    crossings:    List[CrossingEvent] # micro-fire 一覧 (MSD順)
    macro_fires:  List[int]           # macro-fire が起きた桁インデックス一覧


def detect_crossings(
    pos:        int,
    prev:       int,
    raw:        int,
    thresholds: List[CrossingThreshold],
) -> List[CrossingEvent]:
    """
    prev → raw の昇方向遷移で越えた閾値を全て検出する。
    wrap越え (降方向) は現バージョンでは扱わない。
    """
    events = []
    for th in thresholds:
        if prev < th.threshold <= raw:
            events.append(CrossingEvent(pos, th, prev, raw))
    return events


def digits_add_trace(
    a:    List[int],
    b:    List[int],
    base: int = BASE,
) -> AddResult:
    """
    桁列 a + b を加算し、全イベントをトレースして返す。

    算術結果は digits_add と同一。追加情報:
      crossings   — micro-fire (大円横断) の一覧
      macro_fires — macro-fire (桁carry) が起きた桁位置

    Args:
        a, b: 同長の桁列 [MSD, ..., LSD]
        base: BASE (デフォルト 3120)

    Returns:
        AddResult
    """
    if len(a) != len(b):
        raise ValueError("digit arrays must have the same length")

    n = len(a)
    out           = [0] * n
    carry         = 0
    all_crossings: List[CrossingEvent] = []
    macro_fires:   List[int]           = []
    thresholds     = crossing_thresholds(base)

    for i in range(n - 1, -1, -1):      # LSD → MSD
        ai  = a[i]
        raw = ai + b[i] + carry

        # micro-fire 検出
        evs = detect_crossings(i, ai, raw, thresholds)
        all_crossings.extend(evs)

        # macro-fire (桁carry)
        if raw >= base:
            out[i] = raw - base
            carry  = 1
            macro_fires.append(i)
        else:
            out[i] = raw
            carry  = 0

    all_crossings.sort(key=lambda e: e.digit_pos)  # MSD順

    return AddResult(
        digits      = out,
        carry_out   = carry,
        crossings   = all_crossings,
        macro_fires = sorted(macro_fires),
    )


def digits_inc_trace(
    d:    List[int],
    step: int = 1,
    base: int = BASE,
) -> AddResult:
    """桁列を step だけインクリメントし、イベントをトレースする。"""
    b = [0] * len(d)
    b[-1] = step
    return digits_add_trace(d, b, base)


# ─────────────────────────────────────────────
# ユーティリティ
# ─────────────────────────────────────────────

def format_result(result: AddResult, verbose: bool = False) -> str:
    """AddResult を読みやすい文字列に整形する。"""
    lines = [f"digits: {result.digits}  carry_out={result.carry_out}"]

    if result.macro_fires:
        lines.append(f"  macro-fire: 桁{result.macro_fires} (1周完了)")

    if result.crossings:
        lines.append(f"  micro-fires: {len(result.crossings)}件")
        if verbose:
            for ev in result.crossings:
                lines.append(
                    f"    桁{ev.digit_pos} {ev.threshold.name}"
                    f"({ev.threshold.threshold}) [{ev.prev_val}→{ev.raw_val}]"
                    f" arc={ev.threshold.arc} [{ev.threshold.band_cross}]"
                )
    else:
        lines.append("  micro-fires: なし")

    return "\n".join(lines)


def threshold_summary(base: int = BASE) -> str:
    """閾値セットの概要を返す。"""
    ths = crossing_thresholds(base)
    lines = [f"BASE={base} の大円横断閾値 (5点):"]
    prev = 0
    for th in ths:
        gap = th.threshold - prev
        lines.append(
            f"  {th.name:10s} = {th.threshold:4d}"
            f"  (gap={gap:4d}, {th.band_cross}, arc={th.arc})"
        )
        prev = th.threshold
    lines.append(f"  {'BASE':10s} = {base:4d}  (gap={base-prev:4d})")
    lines.append(f"  区間幅: {[ths[0].threshold] + [ths[i+1].threshold-ths[i].threshold for i in range(len(ths)-1)] + [base-ths[-1].threshold]}")
    return "\n".join(lines)

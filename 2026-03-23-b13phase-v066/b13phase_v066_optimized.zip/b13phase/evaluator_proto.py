"""
evaluator_proto.py
==================
Prototype evaluator for multi-digit phase -> (cos, sin) integer vector.

Important:
- The phase representation (digits) is exact.
- This evaluator is *experimental* and intentionally labeled "proto".

What it does:
- Uses Level0 table from digit-0 as a base vector.
- Applies lower digits as small rotation-like corrections.

This is useful for demonstrations and pipeline shaping, but not guaranteed to be
a mathematically exact refinement of angle.
If/when you want a "production evaluator", replace this module.
"""

from __future__ import annotations
from typing import List, Tuple
from .constants import BASE
from .level0_table import COS_TABLE, SIN_TABLE


def fractal_cos_sin_proto(digits: List[int]) -> Tuple[int, int]:
    """
    digits: MSD->LSD radix-BASE digits (length >= 1)
    returns: (cx, cy) scaled by BASE

    cx = BASE * cos(2π * digits[0] / BASE)
    cy = BASE * sin(2π * digits[0] / BASE)

    OPTIMIZED: MSD を az_idx として COS/SIN TABLE を直接引く。
    理論的根拠 (fractal_vertex_recurrence.py):
      az_n = az_0 + n × 312  (mod 3120)  ← 整数加算のみ
      極角 θ は全 level で不変
      → 位相評価 = table 引き 1 回で完結
    下位桁の補正ループは理論で確定した近道を使わない迂回路だったため削除。
    """
    if len(digits) < 1:
        raise ValueError("digits must have length >= 1")
    az = digits[0]
    if az < 0 or az >= BASE:
        raise ValueError("digit out of range")
    return COS_TABLE[az], SIN_TABLE[az]


def fractal_cos_sin_az(az_idx: int) -> Tuple[int, int]:
    """
    az_idx (0..BASE-1) を直接受け取り (cos, sin) を返す推奨 API。
    fractal_vertex_recurrence の漸化式と直結:
      az_idx = (az_0 + level * 312) % 3120
    """
    return COS_TABLE[az_idx % BASE], SIN_TABLE[az_idx % BASE]


def norm_sq(cx: int, cy: int) -> int:
    """Return cx² + cy² (should be ≈ BASE²)."""
    return cx * cx + cy * cy


def norm_ratio(cx: int, cy: int) -> float:
    """Return |v|² / BASE² (should be ≈ 1.0)."""
    return norm_sq(cx, cy) / (BASE * BASE)

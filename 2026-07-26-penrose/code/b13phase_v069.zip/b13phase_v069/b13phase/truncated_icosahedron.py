"""
truncated_icosahedron.py
========================
Vertex coordinates of the truncated icosahedron (C60) in the B13/BASE3120
framework.

----------------------------------------------------------------------
v066 FIX (引継書 v132 §5/§6 task 1):
    The previous `vertex_coords_float` used a band model
    (`_pentagon_elevation` returned only 4 distinct elevations and an
    azimuth depending solely on (k-1+j) mod 5). That collapsed the 60
    vertices onto 20 distinct points (4 latitude rings x 5 = a regular
    dodecahedron), corrupting every downstream geometric quantity.

    This module now derives ALL geometry from the exact "a=2" coordinate
    set (three orbit families x cyclic permutations x all signs -> 60
    vertices, edge length 2). This is the SAME generator that
    connection.py already used to build the logical graph, so for the
    first time `vertex_coords_float` and `build_connection_graph` refer
    to the identical 60 physical vertices under one (k,j) convention.

    The (k,j) -> vertex labelling is UNCHANGED from what
    build_connection_graph produced in v065 (pentagons sorted by centre
    height, vertices ordered by azimuth within each pentagon). Whether
    this geometric labelling matches the B13 coset semantics
    (H / 2H / 4H, the 36 degree twist, the +-6 director) is task #2 of
    the handover and is NOT asserted here. The `coset` field returned by
    all_vertices() is therefore PROVISIONAL (it is just coset_of(2^k mod
    13) attached to the height-rank k).
----------------------------------------------------------------------

Key structural facts (a=2 system, verified by verify_geometry()):
  60 vertices = 12 pentagons x 5 vertices  (each vertex in exactly 1 pentagon)
  90 edges, all length 2
  32 faces (12 pentagons + 20 hexagons), V - E + F = 2
  circumradius^2 = 9*phi + 10                  (edge length a = 2)
  angle deficit (discrete Gaussian curvature) = 12 deg at every vertex
  total angle deficit = 720 deg  (Descartes; Q = 1 skyrmion-equivalent)
  phi = (1+sqrt 5)/2

Great circle (Observation R, retained from earlier analysis):
  cos(theta_a) = (71+18 phi)/109
  cos(theta_5) = (197-13 phi)/218   <- F(7)=13 appears
  cos(theta_6) = (54 phi-5)/109
  Denominator 109 = 8*F(7)+F(5) = 8*13+5
"""

from __future__ import annotations
import math
from typing import Tuple, List, Dict, Set, Optional
from .constants import BASE, STEP_Z5, STEP_Z12, Z13_STAR
from .phase_digits import digits_from_int
from .evaluator_proto import fractal_cos_sin_proto
from .z13_structure import coset_of, is_forbidden

# phi = (1+sqrt5)/2
PHI: float = (1.0 + math.sqrt(5.0)) / 2.0

# Circumradius^2 of the a=2 truncated icosahedron (edge length 2).
#   |(0, 1, 3 phi)|^2 = 1 + 9 phi^2 = 1 + 9(phi+1) = 9 phi + 10
R_SQ: float = 9.0 * PHI + 10.0
R: float = math.sqrt(R_SQ)

# Numerical tolerance for distance comparisons.
_EPS: float = 1e-6
_EDGE: float = 2.0          # canonical edge length
_PENT_DIAG: float = 2.0 * PHI   # pentagon diagonal length


# ──────────────────────────────────────────────────────────────────
# Canonical exact geometry (a=2 system) — single source of truth
# ──────────────────────────────────────────────────────────────────

def _build_vertices_a2() -> List[Tuple[float, float, float]]:
    """The 60 vertices of the truncated icosahedron, edge length 2.

    Three orbit families under cyclic permutation x all signs:
      (0, +-1, +-3 phi)
      (+-1, +-(2+phi), +-2 phi)
      (+-2, +-(1+2 phi), +-phi)
    """
    verts: List[Tuple[float, float, float]] = []
    for s1 in (1, -1):
        for s2 in (1, -1):
            verts += [
                (0.0,        s1,          s2 * 3 * PHI),
                (s2 * 3*PHI, 0.0,         s1),
                (s1,         s2 * 3*PHI,  0.0),
            ]
    for s1 in (1, -1):
        for s2 in (1, -1):
            for s3 in (1, -1):
                verts += [
                    (s1,            s2*(2+PHI),     s3*2*PHI),
                    (s3*2*PHI,      s1,             s2*(2+PHI)),
                    (s2*(2+PHI),    s3*2*PHI,       s1),
                    (s1*2,          s2*(1+2*PHI),   s3*PHI),
                    (s3*PHI,        s1*2,           s2*(1+2*PHI)),
                    (s2*(1+2*PHI),  s3*PHI,         s1*2),
                ]
    return verts  # 60 vertices


def _dist(v1: Tuple[float, float, float],
          v2: Tuple[float, float, float]) -> float:
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(v1, v2)))


def _build_adjacency(verts: List[Tuple[float, float, float]]
                     ) -> Dict[int, Set[int]]:
    """Edge-length-2 nearest-neighbour adjacency (3-regular)."""
    n = len(verts)
    adj: Dict[int, Set[int]] = {i: set() for i in range(n)}
    for i in range(n):
        for j in range(i + 1, n):
            if abs(_dist(verts[i], verts[j]) - _EDGE) < 0.01:
                adj[i].add(j)
                adj[j].add(i)
    return adj


def _find_pentagons(verts: List[Tuple[float, float, float]],
                    adj: Dict[int, Set[int]]) -> List[Tuple[int, ...]]:
    """Detect the 12 pentagonal faces."""
    pentagons: Set[Tuple[int, ...]] = set()
    for seed in range(len(verts)):
        nbs = list(adj[seed])
        for ii in range(len(nbs)):
            n1 = nbs[ii]
            for jj in range(ii + 1, len(nbs)):
                n2 = nbs[jj]
                if abs(_dist(verts[n1], verts[n2]) - _PENT_DIAG) > 0.01:
                    continue
                for x in adj[n2] - {seed}:
                    for y in adj[n1] - {seed}:
                        if abs(_dist(verts[x], verts[y]) - _EDGE) < 0.01:
                            pent = tuple(sorted([seed, n1, n2, x, y]))
                            if len(set(pent)) == 5:
                                pentagons.add(pent)
    return sorted(pentagons)


def _build_coord_to_kj(pentagons: List[Tuple[int, ...]],
                       verts: List[Tuple[float, float, float]]
                       ) -> Dict[int, Tuple[int, int]]:
    """coord-index -> (k, j_local).

    Pentagons sorted by centre z (descending) -> k = 0..11.
    Vertices within a pentagon ordered by azimuth -> j = 0..4.
    (Identical labelling to b13phase v065 build_connection_graph.)
    """
    def pent_center_z(pent: Tuple[int, ...]) -> float:
        return sum(verts[v][2] for v in pent) / 5.0

    sorted_pentagons = sorted(enumerate(pentagons),
                              key=lambda x: -pent_center_z(x[1]))

    coord_to_kj: Dict[int, Tuple[int, int]] = {}
    for k, (_orig_idx, pent) in enumerate(sorted_pentagons):
        cx = sum(verts[v][0] for v in pent) / 5.0
        cy = sum(verts[v][1] for v in pent) / 5.0

        def az(v_idx: int) -> float:
            return math.atan2(verts[v_idx][1] - cy, verts[v_idx][0] - cx)

        ordered = sorted(pent, key=az)
        for j, v_idx in enumerate(ordered):
            coord_to_kj[v_idx] = (k, j)
    return coord_to_kj


class _Canonical:
    """Cached canonical geometry (built once)."""
    verts: List[Tuple[float, float, float]]
    adj: Dict[int, Set[int]]
    pentagons: List[Tuple[int, ...]]
    coord_to_kj: Dict[int, Tuple[int, int]]
    kj_to_coord: Dict[Tuple[int, int], int]
    v_to_pent: Dict[int, int]


_CANON: Optional[_Canonical] = None


def _canonical() -> _Canonical:
    global _CANON
    if _CANON is None:
        c = _Canonical()
        c.verts = _build_vertices_a2()
        c.adj = _build_adjacency(c.verts)
        c.pentagons = _find_pentagons(c.verts, c.adj)
        c.coord_to_kj = _build_coord_to_kj(c.pentagons, c.verts)
        c.kj_to_coord = {kj: idx for idx, kj in c.coord_to_kj.items()}
        c.v_to_pent = {}
        for pi, pent in enumerate(c.pentagons):
            for v in pent:
                c.v_to_pent[v] = pi
        _CANON = c
    return _CANON


# ──────────────────────────────────────────────────────────────────
# Public vertex API
# ──────────────────────────────────────────────────────────────────

def vertex_coords_float(k: int, j: int) -> Tuple[float, float, float]:
    """3D coordinates of vertex (k, j) on the a=2 truncated icosahedron.

    k: pentagon index 0..11 (pentagons sorted by descending centre height)
    j: local vertex index 0..4 (azimuthal order within the pentagon)

    Returns (x, y, z) on the circumsphere of radius R = sqrt(9 phi + 10).
    Guaranteed to return 60 DISTINCT points across all (k, j).
    """
    if not (0 <= k <= 11):
        raise ValueError("k must be in 0..11")
    if not (0 <= j <= 4):
        raise ValueError("j must be in 0..4")
    c = _canonical()
    return c.verts[c.kj_to_coord[(k, j)]]


def vertex_phase_index(k: int, j: int) -> int:
    """BASE3120 azimuth index of vertex (k, j) (integer phase, unchanged).

    Azimuth index = (k * STEP_Z12 + j * STEP_Z5) % BASE
                  = (k * 260 + j * 624) % 3120
    NOTE: this is the integer phase encoding, independent of the float
    geometry above.
    """
    return (k * STEP_Z12 + j * STEP_Z5) % BASE


def vertex_cos_sin(k: int, j: int, n_digits: int = 3) -> Tuple[int, int]:
    """Integer (cx, cy) for the azimuthal phase of vertex (k, j)."""
    idx = vertex_phase_index(k, j)
    digits = digits_from_int(idx, n_digits)
    return fractal_cos_sin_proto(digits)


def all_vertices() -> List[Tuple[int, int, Tuple[float, float, float], str]]:
    """All 60 vertices as (k, j, (x,y,z), coset).

    WARNING (handover v132 task #2): `coset` is PROVISIONAL. It is
    coset_of(2^k mod 13) attached to the geometric height-rank k; it is
    NOT a verified correspondence between the C60 geometry and the B13
    coset structure. Treat it as a label placeholder only.
    """
    result = []
    for k in range(12):
        g = Z13_STAR[k]
        c = coset_of(g)
        for j in range(5):
            xyz = vertex_coords_float(k, j)
            result.append((k, j, xyz, c))
    return result


def neighbors_geom(k: int, j: int) -> List[Tuple[int, int]]:
    """Geometric nearest-neighbours (the 3 edge-length-2 partners) of (k,j)."""
    c = _canonical()
    idx = c.kj_to_coord[(k, j)]
    return sorted(c.coord_to_kj[nb] for nb in c.adj[idx])


def inner_product(k1: int, j1: int, k2: int, j2: int) -> float:
    """v_i . v_j."""
    x1, y1, z1 = vertex_coords_float(k1, j1)
    x2, y2, z2 = vertex_coords_float(k2, j2)
    return x1 * x2 + y1 * y2 + z1 * z2


def central_angle(k1: int, j1: int, k2: int, j2: int) -> float:
    """Central angle theta (degrees) between two vertices.

    theta < 90  -> elliptic class
    theta > 90  -> hyperbolic class
    theta = 180 -> antipodal (C60 is centrally symmetric)
    """
    ip = inner_product(k1, j1, k2, j2)
    cos_theta = max(-1.0, min(1.0, ip / R_SQ))
    return math.degrees(math.acos(cos_theta))


def classify_pair(k1: int, j1: int, k2: int, j2: int) -> str:
    """'elliptic', 'hyperbolic', or 'antipodal'."""
    theta = central_angle(k1, j1, k2, j2)
    if abs(theta - 180.0) < 0.01:
        return "antipodal"
    if theta < 90.0:
        return "elliptic"
    return "hyperbolic"


def observation_n_verify() -> bool:
    """Observation N: no vertex pair is orthogonal (inner product = 0)."""
    verts = all_vertices()
    n = len(verts)
    for i in range(n):
        _, _, (x1, y1, z1), _ = verts[i]
        for m in range(i + 1, n):
            _, _, (x2, y2, z2), _ = verts[m]
            if abs(x1 * x2 + y1 * y2 + z1 * z2) < 1e-9:
                return False
    return True


def opposite_face_angles() -> dict:
    """Representative central angles, computed from the real geometry.

    Returns the genuine antipodal angle (180) and the pentagon-opposite
    angle (centres of the two pentagons related by inversion through the
    centre). Computed, not hard-coded.
    """
    c = _canonical()

    # antipodal vertex of (0,0): the vertex v with v = -v0
    v0 = vertex_coords_float(0, 0)
    anti_theta = max(
        central_angle(0, 0, *c.coord_to_kj[idx])
        for idx in range(60)
    )

    # pentagon centres
    centres = []
    for pi, pent in enumerate(c.pentagons):
        cx = sum(c.verts[v][0] for v in pent) / 5.0
        cy = sum(c.verts[v][1] for v in pent) / 5.0
        cz = sum(c.verts[v][2] for v in pent) / 5.0
        centres.append((cx, cy, cz))

    def cangle(a, bb):
        da = math.sqrt(sum(t * t for t in a))
        db = math.sqrt(sum(t * t for t in bb))
        cs = max(-1.0, min(1.0, sum(p * q for p, q in zip(a, bb)) / (da * db)))
        return math.degrees(math.acos(cs))

    # pentagon centre most opposite to pentagon 0's centre
    c0 = centres[0]
    pent_opp = max(cangle(c0, centres[i]) for i in range(1, 12))

    return {
        "antipodal_vertex_deg": anti_theta,           # ~180
        "pentagon_opposite_centre_deg": pent_opp,     # ~180 (inversion sym)
    }


# ──────────────────────────────────────────────────────────────────
# Geometry verification (引継書 v132 教訓: always verify before use)
# ──────────────────────────────────────────────────────────────────

def _angle(u, w) -> float:
    du = math.sqrt(sum(t * t for t in u))
    dw = math.sqrt(sum(t * t for t in w))
    cs = max(-1.0, min(1.0, sum(a * b for a, b in zip(u, w)) / (du * dw)))
    return math.degrees(math.acos(cs))


def verify_geometry() -> dict:
    """Return a dict of geometric audit metrics for the C60 vertex set.

    Keys:
      distinct_points     : number of distinct (x,y,z) over all (k,j)  -> 60
      n_edges             : edges at length 2                          -> 90
      edge_len_min/max    : extreme edge lengths                       -> 2,2
      min_vertex_distance : smallest pairwise distance (== edge)       -> 2
      circumradius_sq_min/max : extreme |v|^2                          -> 9phi+10
      degree_set          : set of vertex degrees                      -> {3}
      n_pentagons         : detected pentagonal faces                  -> 12
      angle_deficit_min/max : discrete Gaussian curvature per vertex   -> 12,12
      total_angle_deficit : sum over vertices                          -> 720
      euler_V_E_F         : V - E + F (F = 12 pentagons + 20 hexagons)  -> 2
      kj_consistent       : vertex_coords_float matches build_connection_graph
    """
    c = _canonical()
    V = c.verts

    # distinct points over the (k,j) API
    pts = set()
    for k in range(12):
        for j in range(5):
            x, y, z = vertex_coords_float(k, j)
            pts.add((round(x, 6), round(y, 6), round(z, 6)))

    # pairwise distances
    dists = []
    for i in range(60):
        for j in range(i + 1, 60):
            dists.append(_dist(V[i], V[j]))
    edge_lens = [d for d in dists if abs(d - _EDGE) < 0.01]

    norms2 = [sum(t * t for t in v) for v in V]

    degs = {len(c.adj[i]) for i in range(60)}

    # angle deficit (degree-3 vertices: deficit = 360 - sum of 3 pair angles)
    deficits = []
    for i in range(60):
        nb = list(c.adj[i])
        e = [tuple(V[n][t] - V[i][t] for t in range(3)) for n in nb]
        s = _angle(e[0], e[1]) + _angle(e[1], e[2]) + _angle(e[0], e[2])
        deficits.append(360.0 - s)

    n_edges = len(edge_lens)
    n_faces = 12 + 20  # pentagons + hexagons
    euler = 60 - n_edges + n_faces

    # consistency with the logical connection graph (same labels?)
    kj_consistent = True
    try:
        from .connection import build_connection_graph
        g = build_connection_graph()
        for (k, j), nbs in g.items():
            if sorted(nbs) != neighbors_geom(k, j):
                kj_consistent = False
                break
    except Exception:
        kj_consistent = None

    return {
        "distinct_points": len(pts),
        "n_edges": n_edges,
        "edge_len_min": min(edge_lens),
        "edge_len_max": max(edge_lens),
        "min_vertex_distance": min(dists),
        "circumradius_sq_min": min(norms2),
        "circumradius_sq_max": max(norms2),
        "degree_set": degs,
        "n_pentagons": len(c.pentagons),
        "angle_deficit_min": min(deficits),
        "angle_deficit_max": max(deficits),
        "total_angle_deficit": sum(deficits),
        "euler_V_E_F": euler,
        "kj_consistent": kj_consistent,
    }


def assert_geometry(verbose: bool = False) -> dict:
    """Hard assertions that the C60 geometry is faithful. Raises on failure."""
    m = verify_geometry()
    if verbose:
        for key, val in m.items():
            print(f"  {key:24s}: {val}")
    assert m["distinct_points"] == 60, m
    assert m["n_edges"] == 90, m
    assert abs(m["edge_len_min"] - 2.0) < _EPS, m
    assert abs(m["edge_len_max"] - 2.0) < _EPS, m
    assert abs(m["min_vertex_distance"] - 2.0) < _EPS, m
    assert abs(m["circumradius_sq_min"] - R_SQ) < 1e-6, m
    assert abs(m["circumradius_sq_max"] - R_SQ) < 1e-6, m
    assert m["degree_set"] == {3}, m
    assert m["n_pentagons"] == 12, m
    assert abs(m["angle_deficit_min"] - 12.0) < 1e-6, m
    assert abs(m["angle_deficit_max"] - 12.0) < 1e-6, m
    assert abs(m["total_angle_deficit"] - 720.0) < 1e-6, m
    assert m["euler_V_E_F"] == 2, m
    assert m["kj_consistent"] in (True, None), m
    return m

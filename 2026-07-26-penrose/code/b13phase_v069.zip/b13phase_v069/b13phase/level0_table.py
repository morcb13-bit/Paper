"""
level0_table.py
===============
Level-0 lookup table for B13 fractal phase evaluator.

COS_TABLE[i] = round(BASE * cos(2π * i / BASE))
SIN_TABLE[i] = round(BASE * sin(2π * i / BASE))

for i in 0..BASE-1 (BASE = 3120).

Key values (all machine-checked by verify_canonical()):
  i=0    → cos=3120,  sin=0      (0°)
  i=312  → cos=2524,  sin=1834   (36°,   cos≈φ/2)
  i=520  → cos=1560,  sin=2702   (60°)   <- 六角形の中心角
  i=624  → cos=964,   sin=2967   (72°)   <- 五角形の中心角
  i=780  → cos=0,     sin=3120   (90°)
  i=936  → cos=-964,  sin=2967   (108°)  <- 五角形の内角
  i=1040 → cos=-1560, sin=2702   (120°)  <- 六角形の内角
  i=1248 → cos=-2524, sin=1834   (144°)
  i=1560 → cos=-3120, sin=0      (180°)
  i=2340 → cos=0,     sin=-3120  (270°)

注記 (2026-07-16 監査, v0.67):
  v0.66 までの本 docstring は i=624 / i=936 の行に、60°/120°（六角形の角）の値を
  72°/108°（五角形の角）のラベルで載せていた。**コードは常に正しく、誤りは docstring
  のみ**（計算結果に影響なし）。旧 verify_canonical() は 0/90/180/270 の四点しか
  見ておらず、五角形の角に否と言える目が一つも無かったため、誤記が残った。
  v0.67 で verify_canonical() に検査能力を追加した（director 裁定 2026-07-16）。
"""

from __future__ import annotations
import math
from .constants import BASE


def _build_tables(base: int):
    cos_table = [0] * base
    sin_table = [0] * base
    two_pi = 2.0 * math.pi
    for i in range(base):
        angle = two_pi * i / base
        cos_table[i] = round(base * math.cos(angle))
        sin_table[i] = round(base * math.sin(angle))
    return cos_table, sin_table


COS_TABLE, SIN_TABLE = _build_tables(BASE)


# ---------------------------------------------------------------------------
# 主張の身分区分 (2026-07-16 director 裁定, v0.68)
#
#   EXACT_IDENTITY  : 独立に定義された両辺の厳密一致
#   BOUNDED_NUMERIC : 導出済み上界による数値検査
#   CONSTRUCTION    : 一方を満たすように定義したもの
#   ROUNDTRIP       : 逆関数・符号化復号などの実装整合性
#   OBSERVATION     : 実測値の記録
#
# **CONSTRUCTION と ROUNDTRIP を verified と数えない。**
# v0.66 の四件（自動成立3 + 残差構成1）は、この区分が無かったために
# verified を名乗っていた。区分を持たせること自体が再発防止である。
# ---------------------------------------------------------------------------
EXACT_IDENTITY  = "EXACT_IDENTITY"
BOUNDED_NUMERIC = "BOUNDED_NUMERIC"
CONSTRUCTION    = "CONSTRUCTION"
ROUNDTRIP       = "ROUNDTRIP"
OBSERVATION     = "OBSERVATION"
VERIFIABLE_KINDS = frozenset({EXACT_IDENTITY, BOUNDED_NUMERIC})

# ---------------------------------------------------------------------------
# 丸め誤差の上界（導出。**実測の最大値に追従させてはならない** ── それでは必ず通る）
#   c = B·cosθ + δc,  s = B·sinθ + δs,   |δc|,|δs| ≤ 1/2
#   c² + s² − B² = 2B(cosθ·δc + sinθ·δs) + δc² + δs²
#   |2B(cosθ·δc + sinθ·δs)| ≤ 2B·√(δc²+δs²) ≤ √2·B ,   δc²+δs² ≤ 1/2
#   ⟹ 上界 = √2·B + 1/2 。B=3120 で 4412.85… ⟹ 安全な整数上界 4413。
# 実測最大偏差は 3839 だが、**上界はそれから独立に導かれている**（director 確認済）。
# ---------------------------------------------------------------------------
PYTH_TOL: int = int(math.sqrt(2) * BASE) + 1     # 4413


# ── 四層。各層は単独で呼べる。self_test_negative が層ごとに否定能力を要求する。──

def _layer1_axis(fail) -> None:
    """層1 [EXACT_IDENTITY] 軸上の四点。"""
    for val, exp, label in [
        (COS_TABLE[0], BASE, "cos(0°)"),           (SIN_TABLE[0], 0, "sin(0°)"),
        (COS_TABLE[BASE//4], 0, "cos(90°)"),       (SIN_TABLE[BASE//4], BASE, "sin(90°)"),
        (COS_TABLE[BASE//2], -BASE, "cos(180°)"),  (SIN_TABLE[BASE//2], 0, "sin(180°)"),
        (COS_TABLE[BASE*3//4], 0, "cos(270°)"),    (SIN_TABLE[BASE*3//4], -BASE, "sin(270°)"),
    ]:
        if val != exp:
            fail(f"[layer1] {label}: got {val}, expected {exp}")


#: (deg, index, cos, sin, tag) ── C60 の二種の面の角。v0.66 に**目が一つも無かった**層。
POLYGON_ANGLES = [
    ( 36,  312,  2524, 1834, "pentagon half-apex, cos=φ/2"),
    ( 60,  520,  1560, 2702, "hexagon central"),
    ( 72,  624,   964, 2967, "pentagon central"),
    (108,  936,  -964, 2967, "pentagon interior"),
    (120, 1040, -1560, 2702, "hexagon interior"),
    (144, 1248, -2524, 1834, "pentagon exterior"),
]


def _layer2_polygon(fail) -> None:
    """層2 [EXACT_IDENTITY] 五角形・六角形の角。"""
    for deg, i, c, s, tag in POLYGON_ANGLES:
        if i != round(BASE * deg / 360):
            fail(f"[layer2] index for {deg}°: {i} != {round(BASE*deg/360)}")
        if (COS_TABLE[i], SIN_TABLE[i]) != (c, s):
            fail(f"[layer2] {deg}° ({tag}): got ({COS_TABLE[i]}, {SIN_TABLE[i]}), "
                 f"expected ({c}, {s})")


def _layer3_symmetry(fail) -> None:
    """
    層3 [EXACT_IDENTITY] 対称性、全 BASE 添字。

    **許容幅を置かない。** 実測で全添字の偏差が 0 ── 丸めは cos の偶性・sin の奇性を
    破らない。厳密に判定できる層に許容幅を置けば、判定力をただ捨てることになる。
    """
    for i in range(BASE):
        j = (BASE - i) % BASE          # −θ
        k = (BASE // 2 - i) % BASE     # 180° − θ
        if COS_TABLE[j] != COS_TABLE[i]:
            fail(f"[layer3] cos(−θ) != cos θ at i={i}"); return
        if SIN_TABLE[j] != -SIN_TABLE[i]:
            fail(f"[layer3] sin(−θ) != −sin θ at i={i}"); return
        if COS_TABLE[k] != -COS_TABLE[i]:
            fail(f"[layer3] cos(180°−θ) != −cos θ at i={i}"); return
        if SIN_TABLE[k] != SIN_TABLE[i]:
            fail(f"[layer3] sin(180°−θ) != sin θ at i={i}"); return


def _layer4_pythagorean(fail, verbose=False) -> None:
    """層4 [BOUNDED_NUMERIC] cos²+sin² − BASE²、導出上界 PYTH_TOL 以内。"""
    worst = 0
    for i in range(BASE):
        d = COS_TABLE[i]**2 + SIN_TABLE[i]**2 - BASE*BASE
        if abs(d) > abs(worst):
            worst = d
        if abs(d) > PYTH_TOL:
            fail(f"[layer4] cos²+sin² off by {d} at i={i} (derived bound {PYTH_TOL})")
            return
    if verbose:
        print(f"  [layer4] pythagorean worst deviation: {worst}  "
              f"(bound {PYTH_TOL} = √2·BASE + 1/2, 実測から独立)")


LAYERS = {
    1: ("axis four points",   EXACT_IDENTITY,  _layer1_axis),
    2: ("polygon angles",     EXACT_IDENTITY,  _layer2_polygon),
    3: ("symmetry identities", EXACT_IDENTITY, _layer3_symmetry),
    4: ("pythagorean bound",  BOUNDED_NUMERIC, _layer4_pythagorean),
}


def verify_layer(n: int) -> bool:
    """層 n を単独で走らせる。self_test_negative が「どの目が見たか」を固定するために使う。"""
    ok = [True]
    def fail(msg): ok[0] = False
    _, _, fn = LAYERS[n]
    fn(fail)
    return ok[0]


def verify_canonical(verbose: bool = True) -> bool:
    """
    level-0 表の検査。四層すべて [EXACT_IDENTITY] または [BOUNDED_NUMERIC]。
    **CONSTRUCTION / ROUNDTRIP はここに入れない。**

    v0.66 は 0/90/180/270 の四点しか見ておらず、docstring の 72°/108° 誤記に
    否と言えなかった（2026-07-16 監査、旧版へ実物注入して見逃しを実証済）。
    """
    ok = [True]
    def fail(msg):
        ok[0] = False
        if verbose:
            print(f"  FAIL {msg}")
    _layer1_axis(fail)
    _layer2_polygon(fail)
    _layer3_symmetry(fail)
    _layer4_pythagorean(fail, verbose=verbose)
    return ok[0]


def _swap(i, c, s):
    """i 番の値を差し替え、元へ戻す関数を返す（self_test_negative 専用）。"""
    oc, os_ = COS_TABLE[i], SIN_TABLE[i]
    COS_TABLE[i], SIN_TABLE[i] = c, s
    def undo():
        COS_TABLE[i], SIN_TABLE[i] = oc, os_
    return undo


def _inject_orbit(i, c, s):
    """
    i の対称軌道 {i, −i, 180°−i, 180°+i} を、偶奇・符号則を保ったまま一括で差し替える。
    ⟹ 層3（対称性）を通したまま、他の層だけを壊せる。
    """
    j, k, m = (BASE - i) % BASE, (BASE//2 - i) % BASE, (BASE//2 + i) % BASE
    old = {t: (COS_TABLE[t], SIN_TABLE[t]) for t in (i, j, k, m)}
    COS_TABLE[i], SIN_TABLE[i] =  c,  s
    COS_TABLE[j], SIN_TABLE[j] =  c, -s
    COS_TABLE[k], SIN_TABLE[k] = -c,  s
    COS_TABLE[m], SIN_TABLE[m] = -c, -s
    def undo():
        for t, (a, b) in old.items():
            COS_TABLE[t], SIN_TABLE[t] = a, b
    return undo


def _inject_layer4_only():
    """
    層4 だけを壊す注入。

    層3（対称性）を保ったまま長さだけを狂わせる必要がある。i=700 の対称軌道
    {700, 2420, 860, 2260} の cos を、偶性と 180°−θ の符号則を保ったまま +100 する。
    ⟹ 対称性は保たれ、cos²+sin² だけが上界を超える。
    """
    i = 700
    c = COS_TABLE[i] + 100
    orbit = {700: c, 2420: c, 860: -c, 2260: -c}
    old = {k: COS_TABLE[k] for k in orbit}
    for k, v in orbit.items():
        COS_TABLE[k] = v
    def undo():
        for k, v in old.items():
            COS_TABLE[k] = v
    return undo


#: (label, injection, 期待する失敗層) ── **各層が単独で落とせることを要求する。**
INJECTIONS = [
    ("層1: 軸上 cos(0°) を 3120→3119",        lambda: _swap(0, BASE - 1, 0),          1),
    # v0.66 の実物の誤記。対称軌道ごと入れ替えるので層3 は通り、層2 だけが落ちる。
    # (1560,2702) は 60° の正当な点なので層4 も通る ⟹ **層2 が単独で見るしかない。**
    ("層2: v0.66 の実物の誤記 (72° の枠に 60° の値、軌道ごと)",
     lambda: _inject_orbit(624, 1560, 2702), 2),
    ("層3: sin の奇性を壊す (i=1 の符号反転、cos は保つ)",
     lambda: _swap(1, COS_TABLE[1], -SIN_TABLE[1]), 3),
    ("層4: 対称性を保ったまま長さを狂わせる (i=700 軌道 cos+100)", _inject_layer4_only, 4),
]


def self_test_negative(verbose: bool = True) -> bool:
    """
    **検査の検査。** verify_canonical が実際に否と言えるかを確かめる。

    各注入について、**期待する失敗層を固定する**（director 裁定 v0.68）。
    複数層が同時に落ちると「どの目が見たか」が曖昧になるため、
    期待層が**単独で**落とせることを要求する。
    """
    all_ok = True
    for label, injure, layer in INJECTIONS:
        undo = injure()
        caught_whole = not verify_canonical(verbose=False)
        caught_alone = not verify_layer(layer)
        undo()
        fired = [n for n in LAYERS if not verify_layer_after(injure, n)]
        ok = caught_whole and caught_alone
        all_ok &= ok
        if verbose:
            kind = LAYERS[layer][1]
            print(f"  [{'OK  ' if ok else 'MISS'}] {label}")
            print(f"         期待層 {layer} ({LAYERS[layer][0]}, {kind}) 単独で捕捉: {caught_alone}"
                  f" / 全体: {caught_whole} / 落ちた層: {fired}  [OBSERVATION]")
    return all_ok


def verify_layer_after(injure, n):
    undo = injure(); r = verify_layer(n); undo(); return r


def coset_of(g: int) -> str:
    """Return the coset name of g in Z₁₃."""
    g = g % 13
    if g == 0:
        return "0"
    if g in {1, 5, 8, 12}:
        return "H"
    if g in {2, 3, 10, 11}:
        return "2H"
    return "4H"

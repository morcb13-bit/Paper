"""
great_circle.py
===============
Great circle analysis for truncated icosahedron in B13 framework.

v64確定の正しい大円構造 (核22-28):
  1周 = 4頂点(対角線端点) + 10辺横断
  弧の配列 (半周): 頂点 → θ₃₁ → θ₂₁ → θ₁₈ → θ₁₈ → θ₂₁ → θ₃₁ → 頂点
  1周 = 2×θ_diag + 4×θ₃₁ + 4×θ₂₁ + 4×θ₁₈ = 360°  [構成上の恒等式。下記注記を読むこと]

φ-算術 (a=2系, R²=9φ+10):
  cos θ_diag = (8+7φ)/(9φ+10)       [対角線頂点間, 核24]
  cos θ_e    = (9φ+8)/(9φ+10)       [辺弧, 核26]
  sin θ_e    = 6φ/R²                 [辺弧sin, 核34]
  cos²θ₃₁   = (16849φ+10489)/(23185φ+14413)  [核27]
  cos²θ₁₈   = (203φ+170)/(228φ+187) [核27]

辺横断パラメータ (核25):
  t₁₈ = 1/2,  t₂₁ = 2/(3φ),  t₃₁ = 3φ/(4φ+3)

分母:
  109 = 8×F(7)+F(5) = 8×13+5

旧モデル (1.41%誤差) との違い:
  旧: 2θ_a + 4θ_h5 + 4θ_h6  (h5=pentagon高さ, h6=hexagon高さ)
  新: 2θ_diag + 4θ₃₁ + 4θ₂₁ + 4θ₁₈  (大円の真の弧構成)
"""

from __future__ import annotations
import math
from typing import Tuple, Dict
from .constants import BASE
from .level0_table import EXACT_IDENTITY, CONSTRUCTION, ROUNDTRIP

PHI: float = (1.0 + math.sqrt(5.0)) / 2.0

# a=2系の外接球半径²
R_SQ_A2: float = 9.0 * PHI + 10.0          # 核: R²=9φ+10
R_A2:    float = math.sqrt(R_SQ_A2)

# a=1系 (コード内部)
R_SQ: float = R_SQ_A2 / 4.0
R:    float = math.sqrt(R_SQ)

# 有理化分母
DENOM: int = 109   # = 8×F(7)+F(5)


# ─────────────────────────────────────────────
# φ算術: cos値 (a=2系, R²=9φ+10)
# ─────────────────────────────────────────────

def cos_theta_diag_phi() -> Tuple[int, int]:
    """
    cos θ_diag = (8+7φ)/(9φ+10)  [対角線頂点間弧, 核24]
    Returns (rational_part, phi_coeff) for numerator over (9φ+10).
    """
    return (8, 7)

def cos_theta_e_phi() -> Tuple[int, int]:
    """
    cos θ_e = (9φ+8)/(9φ+10)  [辺弧, 核26]
    Returns (rational_part, phi_coeff) for numerator over (9φ+10).
    """
    return (8, 9)

def sin_theta_e_phi() -> Tuple[int, int]:
    """
    sin θ_e = 6φ/(9φ+10)  [辺弧sin, 核34]
    分子 = 6φ = 0+6φ
    Returns (rational_part, phi_coeff).
    """
    return (0, 6)

def cos2_theta_31_phi() -> Tuple[Tuple[int,int], Tuple[int,int]]:
    """
    cos²θ₃₁ = (16849φ+10489) / (23185φ+14413)  [核27]
    Returns (numerator, denominator) as (rat, phi_coeff) pairs.
    """
    return ((10489, 16849), (14413, 23185))

def cos2_theta_18_phi() -> Tuple[Tuple[int,int], Tuple[int,int]]:
    """
    cos²θ₁₈ = (203φ+170) / (228φ+187)  [核27]
    Returns (numerator, denominator) as (rat, phi_coeff) pairs.
    """
    return ((170, 203), (187, 228))


# ─────────────────────────────────────────────
# 数値計算
# ─────────────────────────────────────────────

def phi_value(rat: int, phi_coef: int) -> float:
    """rat + phi_coef × φ を浮動小数で返す。"""
    return rat + phi_coef * PHI


def _cos_from_phi_pair(num: Tuple[int,int], den: Tuple[int,int]) -> float:
    return phi_value(*num) / phi_value(*den)


def theta_diag_deg() -> float:
    """θ_diag を度数で返す。"""
    cos_d = phi_value(*cos_theta_diag_phi()) / R_SQ_A2
    return math.degrees(math.acos(max(-1.0, min(1.0, cos_d))))

def theta_31_deg() -> float:
    """θ₃₁ を度数で返す (cos²θ₃₁から)。"""
    cos2 = _cos_from_phi_pair(*cos2_theta_31_phi())
    return math.degrees(math.acos(math.sqrt(max(0.0, cos2))))

def theta_21_deg() -> float:
    """
    θ₂₁ を、一周が 360° に閉じる**残差角として定義する**。

        θ₂₁ := (360° − 2θ_diag − 4θ₃₁ − 4θ₁₈) / 4

    したがって総和 360° は**構成上の恒等式であり、独立な検証ではない**
    (2026-07-16 監査・director 裁定)。θ₂₁ は測られた角ではなく、閉包を
    強制するために残りから引かれた角である。

    構成だから無価値、ではない。BASE=3120 による添字閉包と同様、閉じる
    ように設計されたものが実際に閉じることは**実装確認**になる。ただし
    **幾何学的発見の証拠として数えてはならない。**
    """
    return (360.0 - 2*theta_diag_deg() - 4*theta_31_deg() - 4*theta_18_deg()) / 4.0

def theta_18_deg() -> float:
    """θ₁₈ を度数で返す (cos²θ₁₈から)。"""
    cos2 = _cos_from_phi_pair(*cos2_theta_18_phi())
    return math.degrees(math.acos(math.sqrt(max(0.0, cos2))))


# ─────────────────────────────────────────────
# 大円の完全構造 (核22-28)
# ─────────────────────────────────────────────

def great_circle_arcs() -> Dict:
    """
    大円の完全な弧構成を返す。

    1周 = 2×θ_diag + 4×θ₃₁ + 4×θ₂₁ + 4×θ₁₈ = 360°

    **注記 (2026-07-16 監査)**: この総和は θ₂₁ の定義（残差角）への代入であり、
    恒等式の検証ではない。返り値 reconstruction_roundoff_deg は理論誤差ではなく
    **実装上の丸め・評価誤差**である。旧名 error_deg / error_pct は主張の
    格付けを誤らせるため改名した。

    半周の弧配列:
      頂点 → θ₃₁ → θ₂₁ → θ₁₈ → θ₁₈ → θ₂₁ → θ₃₁ → 頂点

    辺横断パラメータ (核25):
      θ₁₈: t=1/2        (辺中点)
      θ₂₁: t=2/(3φ)
      θ₃₁: t=3φ/(4φ+3)

    Returns dict with arc angles and the closure round-off residual.
    """
    td  = theta_diag_deg()
    t31 = theta_31_deg()
    t21 = theta_21_deg()
    t18 = theta_18_deg()

    total = 2*td + 4*t31 + 4*t21 + 4*t18
    # θ₂₁ が残差角として定義されている以上、これは定義への代入である。
    # 残るのは float の丸めのみ。理論誤差ではない。
    reconstruction_roundoff_deg = abs(total - 360.0)

    return {
        "theta_diag_deg": td,
        "theta_31_deg":   t31,
        "theta_21_deg":   t21,
        "theta_18_deg":   t18,
        "sum_deg":        total,
        "reconstruction_roundoff_deg": reconstruction_roundoff_deg,
        "reconstruction_roundoff_pct": reconstruction_roundoff_deg / 360.0 * 100.0,
        "kind": CONSTRUCTION,             # **verified に加算しない**
        "verified": False,
        "closure_is_constructed": True,   # θ₂₁ は残差角。総和は θ₂₁ の定義である。
        "n_vertices":     4,
        "n_edge_crossings": 10,
        "arc_sequence_half":  ["V", "θ₃₁", "θ₂₁", "θ₁₈", "θ₁₈", "θ₂₁", "θ₃₁", "V"],
        "t_values": {
            "t_18": 0.5,
            "t_21": 2.0 / (3.0 * PHI),
            "t_31": 3.0 * PHI / (4.0 * PHI + 3.0),
        },
    }


def phi_arithmetic_verify() -> Dict:
    """
    φ 算術のうち、**独立照合が成立する項だけ**を検査する（2026-07-16 監査で改訂）。

    v0.66 の phi_arithmetic_verify は 5 件すべて match=True を返していたが、
    うち 3 件（cos θ_diag / cos²θ₃₁ / cos²θ₁₈）は同一の φ 式から acos で角を作り、
    その cos を取り直して元の φ 式と比べていた。cos(acos(x)) == x は自動で真であり、
    測っていたのは float の往復誤差だけだった。**φ は片側にしか入っていなかった。**

    v0.67 の内訳:
      - cos θ_e   : 有理化の厳密恒等式。sympy で厳密確認済（差 = 0）。**残す。**
      - sin θ_e   : 同上。**残す。**
      - cos θ_diag: **独立経路が実在した** ── truncated_icosahedron の頂点座標の
                    内積 / R²。φ 式と幾何が別経路で一致するため、**本物の検査へ置換。**
      - cos²θ₃₁ / cos²θ₁₈: 辺上の交点の角であり、頂点対の余弦 21 種のいずれとも
                    一致しない。独立経路はコード内に存在しない ⟹ 検査から外し、
                    phi_derived_angles() へ移した（**無理に独立検査を捏造しない**。
                    独立な入口が無ければ、それは検証ではなく構成である）。

    **返す全項目が kind=EXACT_IDENTITY**。CONSTRUCTION / ROUNDTRIP は入れない。

    **件数は三で確定**（director 裁定 2026-07-16）。cos_theta_diag は v0.66 では
    自動成立だったが、v0.67 で独立入口（頂点座標の内積）が実在すると判明し、
    φ 係数 (8,7)→(8,6) の破壊に対して False を返すことも確認した。したがって
    cos(acos(x))=x 型の自己確認ではなく、**独立経路の一致検査**である。

    **判定基準との競合では、件数ではなく基準が優先される** ── 「独立な入口が
    なければ、それは検証ではなく構成である」。この規約自体が、本セッションで
    見つかった四件（自動成立3 + 残差構成1）と同型の再発を防ぐ。
    """
    cos_e_phi   = (71 + 18*PHI) / DENOM          # (71+18φ)/109
    cos_e_exact = 1.0 - 1.0 / (2.0 * R_SQ)       # 1 − a²/(2R²), a=1

    sin_e_phi   = 6.0 * PHI / R_SQ_A2            # 6φ/(9φ+10)
    sin_e_sqrt5 = (-24 + 30*math.sqrt(5)) / 109.0

    # cos θ_diag: 独立経路 ── 五角形の対角線をなす頂点対の中心角
    from .truncated_icosahedron import vertex_coords_float
    v0 = vertex_coords_float(0, 0)
    v2 = vertex_coords_float(0, 2)
    cos_d_geom = sum(x*y for x, y in zip(v0, v2)) / R_SQ_A2   # 座標側
    cos_d_phi  = phi_value(*cos_theta_diag_phi()) / R_SQ_A2   # φ 式側

    def ok(a, b): return abs(a - b) < 1e-8

    # 全項目 kind=EXACT_IDENTITY（項目ごとに持つ。top-level には置かない）
    return {
        "cos_theta_e": {
            "formula": "(71+18φ)/109 = 1 − 1/(2R²)",
            "phi_eval": cos_e_phi, "other": cos_e_exact,
            "independent": "有理化の恒等式（sympy で厳密確認済: 差 = 0）",
            "kind": EXACT_IDENTITY,
            "match": ok(cos_e_phi, cos_e_exact),
        },
        "sin_theta_e": {
            "formula": "6φ/(9φ+10) = (−24+30√5)/109",
            "phi_eval": sin_e_phi, "other": sin_e_sqrt5,
            "independent": "有理化の恒等式（sympy で厳密確認済: 差 = 0）",
            "kind": EXACT_IDENTITY,
            "match": ok(sin_e_phi, sin_e_sqrt5),
        },
        "cos_theta_diag": {
            "formula": "(8+7φ)/(9φ+10)",
            "phi_eval": cos_d_phi, "other": cos_d_geom,
            "independent": "vertex_coords_float(0,0)·(0,2) / R² ── 頂点座標からの内積",
            "kind": EXACT_IDENTITY,
            "match": ok(cos_d_phi, cos_d_geom),
        },
        "denom_109": DENOM,
    }


def phi_derived_angles() -> Dict:
    """
    **検査ではない。φ 式から角度を構成する生成関数である**（director 裁定 v0.68）。

    θ₃₁ / θ₁₈ は cos²θ の φ 式から acos∘sqrt で作られる。その cos を取り直して
    元の φ 式と比べても、φ の幾何は検証されない ── 測っているのは float の
    acos/cos が逆関数であることだけである。verify / match の名札を外した。

    独立経路（辺上の交点を頂点座標から構成する経路）はコード内に存在しない。
    捏造しないこと ── 検証対象が無いのに検証の形だけ作るのは、ζ整数化と同じ罠。

    **三件を別の同値変形で飾り直して「検証」に戻さないこと。**
    出力は verified ではなく constructed_from_phi=True。roundtrip_error は
    実装整合性 [ROUNDTRIP] であって、幾何の検証ではない。
    """
    d = {}
    for name, pair, theta in (
        ("cos2_theta_31", cos2_theta_31_phi(), theta_31_deg()),
        ("cos2_theta_18", cos2_theta_18_phi(), theta_18_deg()),
    ):
        src = _cos_from_phi_pair(*pair)
        back = math.cos(math.radians(theta))**2
        d[name] = {
            "kind": ROUNDTRIP,
            "constructed_from_phi": True,
            "verified": False,          # **数えない**
            "phi_eval": src,
            "roundtrip": back,
            "roundtrip_error": abs(src - back),
            "note": "同一の φ 式の往復。独立照合ではない。独立入口が無い ⟹ 構成。",
        }
    return d



# ─────────────────────────────────────────────
# 旧API互換 (deprecated, 旧モデル1.41%誤差)
# ─────────────────────────────────────────────

def _legacy_h5_h6():
    """旧モデルの弦長 (参考のみ)。"""
    H5_SQ = (3.0 + 4.0*PHI) / 4.0
    H6_SQ = 3.0 / 4.0  # a=1 hexagon
    return H5_SQ, H6_SQ

def great_circle_traversal() -> Dict:
    """
    [互換API] 旧モデルの代わりに新モデルを返す。

    **注記 (2026-07-16 監査)**: 旧キー error_pct を reconstruction_roundoff_pct へ改名した
    （理論誤差ではなく実装上の丸め ── great_circle_arcs の注記を読むこと）。

    **v0.69 改名**: 旧キー total / theoretical はどちらも同一式 `2πR` であり、
    **構成上等しい**。二つ並べることが「実測 vs 理論の照合」を騙るため、
    単一キー `circumference_2piR` [CONSTRUCTION] へ統合した。
    消費側は repo 全走査でゼロ（本関数の内部のみ）。
    ※ total を弧の実和へ差し替える案は採らない ── θ₂₁ が残差角である以上、
    和が 2πR になるのは定義であり、並べれば再び照合を騙る。
    """
    arcs = great_circle_arcs()
    return {
        "arc_diag":   R * math.radians(arcs["theta_diag_deg"]),
        "arc_31":     R * math.radians(arcs["theta_31_deg"]),
        "arc_21":     R * math.radians(arcs["theta_21_deg"]),
        "arc_18":     R * math.radians(arcs["theta_18_deg"]),
        "circumference_2piR": 2 * math.pi * R,   # [CONSTRUCTION] 定義。検証値ではない
        "reconstruction_roundoff_pct": arcs["reconstruction_roundoff_pct"],
        "elements":   14,  # 4頂点 + 10辺横断
        "model":      "v64 (4V+10E, exact)",
    }


def theta_values_degrees() -> Dict:
    """全弧の度数を返す。"""
    return {
        "theta_diag_deg": theta_diag_deg(),
        "theta_31_deg":   theta_31_deg(),
        "theta_21_deg":   theta_21_deg(),
        "theta_18_deg":   theta_18_deg(),
        "sum_check":      2*theta_diag_deg() + 4*theta_31_deg()
                         + 4*theta_21_deg()  + 4*theta_18_deg(),
    }


# ─────────────────────────────────────────────
# 旧API シンボル互換
# ─────────────────────────────────────────────
H5_SQ, H6_SQ = _legacy_h5_h6()
H5 = math.sqrt(H5_SQ)
H6 = math.sqrt(H6_SQ)

def cos_theta_a_phi():  return (71, 18)
def cos_theta_5_phi():  return (197, -13)
def cos_theta_6_phi():  return (-5, 54)

def arc_length(chord_sq: float) -> float:
    cos_t = 1.0 - chord_sq / (2.0 * R_SQ)
    return R * math.acos(max(-1.0, min(1.0, cos_t)))

def central_angle_from_chord(chord_sq: float) -> float:
    cos_t = 1.0 - chord_sq / (2.0 * R_SQ)
    return math.degrees(math.acos(max(-1.0, min(1.0, cos_t))))

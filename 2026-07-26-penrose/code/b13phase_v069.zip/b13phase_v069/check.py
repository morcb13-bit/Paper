#!/usr/bin/env python3
"""終了条件の確認。版に依存しない名前（v0.69: check_v068.py から改名 ── 版番号入りの名前は必ず古びる）"""
import sys; sys.path.insert(0, ".")
import b13phase
from b13phase.level0_table import (verify_canonical, self_test_negative, verify_layer,
                                   LAYERS, INJECTIONS, VERIFIABLE_KINDS)
from b13phase.great_circle import phi_arithmetic_verify, phi_derived_angles, great_circle_arcs

r = []
print("=== 終了条件 1: verify_canonical() の四層が通る ===")
c1 = verify_canonical(verbose=False)
for n, (name, kind, _) in LAYERS.items():
    print(f"  層{n} {name:20} [{kind:15}] : {verify_layer(n)}")
print(f"  ⟹ {c1}"); r.append(c1)

print("\n=== 終了条件 2: 四層それぞれの単独注入を捕捉する ===")
c2 = self_test_negative(verbose=False)
for (label, injure, layer) in INJECTIONS:
    undo = injure(); alone = not verify_layer(layer); fired = [n for n in LAYERS if not verify_layer(n)]; undo()
    print(f"  期待層{layer} 単独捕捉={alone}  落ちた層={fired}   {label}")
print(f"  ⟹ {c2}"); r.append(c2)

print("\n=== 終了条件 3: phi_arithmetic_verify() は内容のある項目だけ ===")
items = {k: v for k, v in phi_arithmetic_verify().items() if isinstance(v, dict)}
c3 = all(v["kind"] in VERIFIABLE_KINDS and v["match"] for v in items.values())
for k, v in items.items():
    print(f"  {k:15} [{v['kind']}] match={v['match']}  独立入口: {v['independent'][:38]}…")
print(f"  検証件数 = {len(items)}  ⟹ 全項目が独立入口を持つ: {c3}")
print(f"  ※ 件数は三で確定（director 裁定 2026-07-16）。基準 > 件数。"); r.append(c3)

print("\n=== 終了条件 4: 360° は CONSTRUCTION、検証件数へ加算されない ===")
a = great_circle_arcs()
c4 = (a["kind"] == "CONSTRUCTION" and a["verified"] is False
      and a["kind"] not in VERIFIABLE_KINDS
      and all(d["kind"] == "ROUNDTRIP" and d["verified"] is False for d in phi_derived_angles().values()))
print(f"  great_circle_arcs : kind={a['kind']} verified={a['verified']} "
      f"reconstruction_roundoff_deg={a['reconstruction_roundoff_deg']:.1e}")
for k, v in phi_derived_angles().items():
    print(f"  {k:15} : kind={v['kind']} verified={v['verified']} constructed_from_phi={v['constructed_from_phi']}")
print(f"  ⟹ {c4}"); r.append(c4)

print("\n=== 終了条件 5: PHI_BASE の消費・公開・再エクスポートがゼロ ===")
c5 = not hasattr(b13phase, "PHI_BASE") and not hasattr(b13phase, "PHI_HALF_BASE")
import b13phase.constants as C
c5 &= not hasattr(C, "PHI_BASE") and not hasattr(C, "PHI_HALF_BASE")
print(f"  b13phase.PHI_BASE: {hasattr(b13phase,'PHI_BASE')} / constants.PHI_BASE: {hasattr(C,'PHI_BASE')}")
print(f"  __all__ 内: {'PHI_BASE' in b13phase.__all__}")
print(f"  ⟹ {c5}"); r.append(c5)

print("\n=== 終了条件 6 (v0.69): demo 完走 ── 主張ではなく実行 ===")
# v0.68 は回帰に「demo 通過」と記したが、この検査は demo を呼んでいなかった。
# ⟹ 誰も走らせていない主張（空ラベル四例目）。以後 demo の身分は本検査の出力に束縛する。
# 「書いて主張する」ではなく「走らせて吐かせる」。ログを信じる必要が無くなる。
import subprocess, sys as _sys, pathlib as _pl
_root = _pl.Path(__file__).resolve().parent
_p = subprocess.run([_sys.executable, "-m", "b13phase.demo"],
                    cwd=str(_root), capture_output=True, text=True)
c6 = (_p.returncode == 0)
print(f"  {_sys.executable} -m b13phase.demo (cwd={_root.name}) -> returncode={_p.returncode}")
if not c6:
    for _l in _p.stderr.strip().splitlines()[-3:]:
        print("  " + _l)
print(f"  ⟹ {c6}"); r.append(c6)

print(f"\n{'='*54}\n終了条件 {sum(r)}/{len(r)} ── {'閉じてよい' if all(r) else '未達'}\n{'='*54}")
